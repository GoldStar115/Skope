//
//  UIBarButtonItem+Categories.h
//  Skope
//
//  Created by Nguyen Truong Luu on 9/13/15.
//  Copyright (c) 2015 CHAU HUYNH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIBarButtonItem (Categories)
- (CGRect)frameInView:(UIView *)view;
@end
