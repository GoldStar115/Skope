//
//  UIButtonLeftIcon.h
//  UnitsScanner
//
//  Created by Nguyen Truong Luu on 9/8/15.
//  Copyright (c) 2015 Phan Phuoc Luong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButtonLeftIcon : UIButton

@end
