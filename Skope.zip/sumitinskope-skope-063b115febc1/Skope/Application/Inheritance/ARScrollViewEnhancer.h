//
//  ARScrollViewEnhancer.h
//  ScrollViewPagingExample
//
//  Created by Alexander Repty on 12.02.10.
//  Copyright 2010 Enough Software. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ARScrollViewEnhancer : UIView {
	//IBOutlet UIScrollView	*_scrollView;
}
@property (nonatomic, weak) IBOutlet UIScrollView *scrollView;
@end
