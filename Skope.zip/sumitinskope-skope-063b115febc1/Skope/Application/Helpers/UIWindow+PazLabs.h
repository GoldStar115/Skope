//
//  UIWindow+PazLabs.h
//  Skope
//
//  Created by Nguyen Truong Luu on 10/28/15.
//  Copyright © 2015 CHAU HUYNH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWindow (PazLabs)
- (UIViewController *) visibleViewController;
@end
