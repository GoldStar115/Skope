//
//  ChatViewNavigationController.h
//  Skope
//
//  Created by Nguyen Truong Luu on 5/1/15.
//  Copyright (c) 2015 CHAU HUYNH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChatViewNavigationController : UINavigationController

@end
