//
//  CommentTableViewCellLastWithoutLoadMore.m
//  Skope
//
//  Created by Nguyen Truong Luu on 10/17/15.
//  Copyright © 2015 CHAU HUYNH. All rights reserved.
//

#import "CommentTableViewCellLastWithoutLoadMore.h"

@implementation CommentTableViewCellLastWithoutLoadMore

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

@end
