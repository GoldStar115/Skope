//
//  PostCellLastSectionNoComment.m
//  Skope
//
//  Created by Nguyen Truong Luu on 10/17/15.
//  Copyright © 2015 CHAU HUYNH. All rights reserved.
//

#import "PostCellLastSectionNoComment.h"

@implementation PostCellLastSectionNoComment

- (void)awakeFromNib {
    // Initialization code
    [super awakeFromNib];
}

@end
