//
//  SinglePostVC.h
//  Skope
//
//  Created by Nguyen Truong Luu on 10/26/15.
//  Copyright © 2015 CHAU HUYNH. All rights reserved.
//

#import "PostListVC.h"

@interface SinglePostVC : PostListVC

- (void)setPostID:(NSString *)postID;

@end
