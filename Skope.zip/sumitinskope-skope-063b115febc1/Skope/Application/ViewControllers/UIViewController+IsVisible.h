//
//  UIViewController+IsVisible.h
//  Skope
//
//  Created by Nguyen Truong Luu on 8/10/15.
//  Copyright (c) 2015 CHAU HUYNH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (IsVisible)
- (BOOL)isVisible;
@end
