//
//  CustomLocationView.h
//  Skope
//
//  Created by Nguyen Truong Luu on 5/2/15.
//  Copyright (c) 2015 CHAU HUYNH. All rights reserved.
//

#import <MapKit/MapKit.h>

@interface CustomLocationView : MKAnnotationView

@end
