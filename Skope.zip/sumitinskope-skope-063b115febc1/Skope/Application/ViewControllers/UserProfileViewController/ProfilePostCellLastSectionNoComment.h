//
//  ProfilePostCellLastSectionNoComment.h
//  Skope
//
//  Created by Nguyen Truong Luu on 10/17/15.
//  Copyright © 2015 CHAU HUYNH. All rights reserved.
//

#import "ProfilePostCell.h"

@interface ProfilePostCellLastSectionNoComment : ProfilePostCell

@end
