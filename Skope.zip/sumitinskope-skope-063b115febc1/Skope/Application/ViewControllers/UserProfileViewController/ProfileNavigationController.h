//
//  ProfileNavigationController.h
//  Skope
//
//  Created by Nguyen Truong Luu on 10/21/15.
//  Copyright © 2015 CHAU HUYNH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileNavigationController : UINavigationController

@end
