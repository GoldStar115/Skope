//
//  ProfilePostCellLastSectionNoComment.m
//  Skope
//
//  Created by Nguyen Truong Luu on 10/17/15.
//  Copyright © 2015 CHAU HUYNH. All rights reserved.
//

#import "ProfilePostCellLastSectionNoComment.h"

@implementation ProfilePostCellLastSectionNoComment

- (void)awakeFromNib {
    [super awakeFromNib];
    
}


@end
