//
//  NTLViewController.h
//  Sync Shot
//
//  Created by Nguyen Truong Luu on 3/27/15.
//  Copyright (c) 2015 Nguyen Truong Luu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NTLViewController : UIViewController

- (void)deviceOrientationDidChange:(NSNotification *)notification;
@end
