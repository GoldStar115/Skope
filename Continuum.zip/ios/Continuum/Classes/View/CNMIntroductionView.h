#import <UIKit/UIKit.h>


/**
 @brief  View which is used to show introduction pages.
 
 @author Sergey Mamontov
 @since 1.0
 @copyright © 2015 Continuum LLC.
 */
@interface CNMIntroductionView : UIView


#pragma mark -


@end
