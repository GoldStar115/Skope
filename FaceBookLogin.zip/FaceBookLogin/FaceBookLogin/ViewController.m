//
//  ViewController.m
//  FaceBookLogin
//
//  Created by My Star on 1/24/16.
//  Copyright © 2016 My Star. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import <FBSDKLoginKit/FBSDKLoginManagerLoginResult.h>
#import <Twitter/Twitter.h>


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)LogInWithFaceBook:(id)sender {
    FBSDKLoginManager * logIn = [[FBSDKLoginManager alloc] init];
    [logIn logInWithReadPermissions:@[@"public_profile", @"email", @"user_location", @"user_photos"] fromViewController:self handler:^(FBSDKLoginManagerLoginResult *result , NSError *error){
        if (error) {
            NSLog(@"Process error");
        }else if (result.isCancelled){
            NSLog(@"Cancelled");
        } else{
            NSLog(@"Loggedd in");
            NSLog(@"%@",result.token.tokenString);
//            NSString* email = [result objectForKey:@"email"];
            
            if ([FBSDKAccessToken currentAccessToken]) {
                [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:@{@"fields": @"first_name, last_name, picture.type(large), email, name, id, gender"}]
                 startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id result, NSError *error) {
                     if (!error) {
                         NSLog(@"fetched user:%@", result);
                         NSLog(@"E_mail %@", result[@"email"]);
                         NSLog(@"name %@",result[@"name"]);
                         NSLog(@"url %@",result[@"picture"][@"data"][@"url"]);
                         NSURL *imageURL = [NSURL URLWithString:result[@"picture"][@"data"][@"url"]];
                         _portrait.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:imageURL]];
                         
                     }
                 }];
            }
            
            
        }
    }];
    
}
- (IBAction)onLoginWithTwitter:(id)sender {
    
//    [[Twitter sharedInstance] logInWithCompletion:^(TWTRSession *session, NSError *error) {
//        if (session) {
//            NSLog(@"signed in as %@", [session userName]);
//        } else {
//            NSLog(@"error: %@", [error localizedDescription]);
//        }
//    }];
    
}


@end
