//
//  ViewController.h
//  FaceBookLogin
//
//  Created by My Star on 1/24/16.
//  Copyright © 2016 My Star. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *btnLogInWithFaceBook;
@property (weak, nonatomic) IBOutlet UIImageView *portrait;
@property (weak, nonatomic) IBOutlet UIButton *btnLoginWithTwitter;

@end

