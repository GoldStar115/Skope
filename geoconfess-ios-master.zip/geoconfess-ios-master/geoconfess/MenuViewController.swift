//
//  MenuViewController.swift
//  geoconfess
//
//  Created by whitesnow0827 on 3/16/16.
//  Copyright © 2016 Andrei Costache. All rights reserved.
//

import UIKit

protocol SlideMenuDelegate {
    func slideMenuItemSelectedAtIndex(index : Int32)
}

class MenuViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    @IBOutlet weak var tblMenuOptions: UITableView!
    @IBOutlet weak var btnCloseMenuOverlay: UIButton!

    var btnMenu : UIButton!
    var delegate : SlideMenuDelegate?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        tblMenuOptions.delegate = self
        tblMenuOptions.dataSource = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func onCloseMenuClick(sender: AnyObject) {
        btnMenu.tag = 0
        
        if (self.delegate != nil) {
            var index = Int32(btnMenu.tag)
            if(btnMenu == self.btnCloseMenuOverlay){
                index = -1
            }
            delegate?.slideMenuItemSelectedAtIndex(index)
        }
        
        UIView.animateWithDuration(0.3, animations: { () -> Void in
            self.view.frame = CGRectMake(-UIScreen.mainScreen().bounds.size.width, 0, UIScreen.mainScreen().bounds.size.width,UIScreen.mainScreen().bounds.size.height)
            self.view.layoutIfNeeded()
            self.view.backgroundColor = UIColor.clearColor()
            }, completion: { (finished) -> Void in
                self.view.removeFromSuperview()
                self.removeFromParentViewController()
        })
    }
    
//    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
//        return 1;
//    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 8;
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        let btn = UIButton(type: UIButtonType.Custom)
        btn.tag = indexPath.row
        self.onCloseMenuClick(btn)
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if indexPath.row == 0 {
            let cell = tblMenuOptions.dequeueReusableCellWithIdentifier("firstcell", forIndexPath: indexPath) as! FirstTableViewCell
            return cell
        } else if indexPath.row == 1 {
            let cell = tblMenuOptions.dequeueReusableCellWithIdentifier("secondcell", forIndexPath: indexPath) as! SecondTableViewCell
            return cell
        } else if indexPath.row == 2 {
            let cell = tblMenuOptions.dequeueReusableCellWithIdentifier("thirdcell", forIndexPath: indexPath) as! ThirdTableViewCell
            return cell
        } else if indexPath.row == 3 {
            let cell = tblMenuOptions.dequeueReusableCellWithIdentifier("forthcell", forIndexPath: indexPath) as! ForthTableViewCell
            return cell
        } else if indexPath.row == 4 {
            let cell = tblMenuOptions.dequeueReusableCellWithIdentifier("fifthcell", forIndexPath: indexPath) as! FifthTableViewCell
            return cell
        } else if indexPath.row == 5 {
            let cell = tblMenuOptions.dequeueReusableCellWithIdentifier("sixthcell", forIndexPath: indexPath) as! SixthTableViewCell
            return cell
        } else if indexPath.row == 6 {
            let cell = tblMenuOptions.dequeueReusableCellWithIdentifier("seventhcell", forIndexPath: indexPath) as! SeventhTableViewCell
            return cell
        } else {
            let cell = tblMenuOptions.dequeueReusableCellWithIdentifier("eighthcell", forIndexPath: indexPath) as! EighthTableViewCell
            return cell
        }
        
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
