//
//  UserSignUpViewController.swift
//  geoconfess
//
//  Created by whitesnow0827 on 3/4/16.
//  Copyright © 2016 Andrei Costache. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

var surname: String = ""
var name: String = ""
var email: String = ""
var telephone: String = ""

class UserSignUpViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var surnameTextField: UITextField!
    @IBOutlet weak var nameTextField: UITextField!
    @IBOutlet weak var emailTextField: UITextField!
    @IBOutlet weak var telephoneTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        surnameTextField.delegate=self
        nameTextField.delegate=self
        emailTextField.delegate=self
        telephoneTextField.delegate=self

        setupBarTitle()
    }
    
    func setupBarTitle(){
        
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.Plain, target: nil, action: nil)
        
        
        if NavViewController.isTitleSet {
            return
        }
        
        let logo = UIImage(named: "geoconfess-blanc")
        let imageView = UIImageView(frame: CGRect(x: 0, y: 30, width: view.frame.width, height: 20))
        imageView.contentMode = .ScaleAspectFit
        imageView.image = logo
        
        self.navigationController?.view.addSubview(imageView)
        NavViewController.isTitleSet = true
        
        //self.navigationItem.titleView = imageView
    }


    func textFieldShouldReturn(textField: UITextField) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
    
    @IBAction func userSignUpButtonTapped(sender: AnyObject) {
        if (self.surnameTextField.text == "" || self.nameTextField.text == "" || self.emailTextField.text == "" || self.telephoneTextField.text == "" )  {
            let text = self.surnameTextField.text!
            NSLog(text)
            let alertView = UIAlertView(title: nil, message: "Tous les champs sont requis.", delegate: self, cancelButtonTitle: "OK")
            alertView.show()
        } else {
            let isValidEmail = self.isValidEmail(self.emailTextField.text!)
            if isValidEmail == false {
                let alertView = UIAlertView(title: nil, message: "Email invalide.", delegate: self, cancelButtonTitle: "OK")
                alertView.show()
            }
            surname = surnameTextField.text!
            name = nameTextField.text!
            email = emailTextField.text!
            telephone = telephoneTextField.text!
            self.performSegueWithIdentifier("goto_userPass", sender: self)
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func isValidEmail(testStr:String) -> Bool {
        // println("validate calendar: \(testStr)")
        let emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluateWithObject(testStr)
    }

    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
