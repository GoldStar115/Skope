//
//  PriestSignUpViewController.swift
//  geoconfess
//
//  Created by whitesnow0827 on 3/5/16.
//  Copyright © 2016 Andrei Costache. All rights reserved.
//

import UIKit

var priestName: String = String()
var priestSurname: String = String()
var priestEmail: String = String()
var priestTelephon: String = String()
var parishName: String = String()
var parishEmail: String = String()

class PriestSignUpViewController: UIViewController, UITextFieldDelegate, UIScrollViewDelegate {

    @IBOutlet weak var priestNameField: UITextField!
    @IBOutlet weak var priestSurnameField: UITextField!
    @IBOutlet weak var priestEmailField: UITextField!
    @IBOutlet weak var priestTelephoneField: UITextField!
    @IBOutlet weak var parishNameField: UITextField!
    @IBOutlet weak var parishEmailField: UITextField!
    @IBOutlet weak var scrollview: UIScrollView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Navigation Setting
        setupBarTitle()
        
        // ScrollView Setting
        self.scrollview.contentSize.height = 1000
        self.scrollview.scrollEnabled = true
        self.scrollview.delegate = self
        
        // Do any additional setup after loading the view.
        priestNameField.delegate = self
        priestSurnameField.delegate = self
        priestEmailField.delegate = self
        priestTelephoneField.delegate = self
        parishNameField.delegate = self
        parishEmailField.delegate = self
    }
    
    func setupBarTitle(){
        
        self.navigationItem.backBarButtonItem = UIBarButtonItem(title: "", style: UIBarButtonItemStyle.Plain, target: nil, action: nil)
        if NavViewController.isTitleSet {
        return
        }
        
        let logo = UIImage(named: "geoconfess-blanc")
        let imageView = UIImageView(frame: CGRect(x: 0, y: 30, width: view.frame.width, height: 20))
        imageView.contentMode = .ScaleAspectFit
        imageView.image = logo
        
        self.navigationController?.view.addSubview(imageView)
        NavViewController.isTitleSet = true
        
        //self.navigationItem.titleView = imageView
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
    
    @IBAction func gotoPasswordVC(sender: AnyObject) {
        
        if (self.priestNameField.text == "" || self.priestSurnameField.text == "" || self.priestEmailField.text == "" || self.priestTelephoneField.text == "" || self.parishNameField.text == "" || self.parishEmailField.text == "")  {
            let alertView = UIAlertView(title: nil, message: "Tous les champs sont requis.", delegate: self, cancelButtonTitle: "OK")
            alertView.show()
        } else {
            let isValidPriestEmail = isValidEmail(self.priestEmailField.text!)
            if isValidPriestEmail == false {
                let alertView = UIAlertView(title: nil, message: "L'email est invalide.", delegate: self, cancelButtonTitle: "OK")
                alertView.show()
            }
            let isValidParishEmail: Bool = isValidEmail(self.parishEmailField.text!)
            if isValidParishEmail == false {
                let alertView = UIAlertView(title: nil, message: "L'email de la paroisse est invalide.", delegate: self, cancelButtonTitle: "OK")
                alertView.show()
            }
            else {
                priestName = priestNameField.text!
                priestSurname = priestSurnameField.text!
                priestEmail = priestEmailField.text!
                priestTelephon = priestTelephoneField.text!
                parishName = parishNameField.text!
                parishEmail = parishEmailField.text!
                
                self.performSegueWithIdentifier("goto_priestPass", sender: self)

            }
        }
        
    }
    
    func isValidEmail(testStr:String) -> Bool {
        // println("validate calendar: \(testStr)")
        let emailRegEx = "^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$"
        
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluateWithObject(testStr)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
