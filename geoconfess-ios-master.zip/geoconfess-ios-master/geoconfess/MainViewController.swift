//
//  MainViewController.swift
//  GeoConfess
//
//  Created by Матвей Кравцов on 01.03.16.
//  Copyright © 2016 Andrei Costache. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

var userName = String()
class MainViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        getUserInfo()
        
        let menuButton : UIButton = UIButton(type: UIButtonType.Custom) as UIButton
        menuButton.frame = CGRectMake(0, 0, 33, 23)
        menuButton.setImage(UIImage(named: "menu_icon"), forState: UIControlState.Normal)
        menuButton.addTarget(self, action: "menuButtonTapped:", forControlEvents: UIControlEvents.TouchUpInside)
        let leftBarButtonItem : UIBarButtonItem = UIBarButtonItem(customView: menuButton)
        self.navigationItem.setLeftBarButtonItem(leftBarButtonItem, animated: true)
        navigationController?.navigationBar.barTintColor = UIColor.whiteColor()
    }
    
    func getUserInfo() {
        let URL = NSURL(string: "https://geoconfess.herokuapp.com/api/v1/me")
        Alamofire.request(.GET, URL!)
            .responseJSON { response in
                switch response.result {
                case .Success(let data):
                    let json = JSON(data)
                    let name = json["name"].string
                    let surname = json["surname"].string
                    userName = name! + " " + surname!
                case .Failure(let error):
                    NSLog(error.description)
                }
        }
    }
    
    func menuButtonTapped(sender: UIButton) {
        if (sender.tag == 10)
        {
            // To Hide Menu If it already there
            
            sender.tag = 0;
            
            let viewMenuBack : UIView = view.subviews.last!
            
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                var frameMenu : CGRect = viewMenuBack.frame
                frameMenu.origin.x = -1 * UIScreen.mainScreen().bounds.size.width
                viewMenuBack.frame = frameMenu
                viewMenuBack.layoutIfNeeded()
                viewMenuBack.backgroundColor = UIColor.clearColor()
                }, completion: { (finished) -> Void in
                    viewMenuBack.removeFromSuperview()
            })
            
            return
        }
        
        sender.enabled = false
        sender.tag = 10
        
        let menuVC : MenuViewController = self.storyboard!.instantiateViewControllerWithIdentifier("MenuViewController") as! MenuViewController
        menuVC.btnMenu = sender
        //        menuVC.delegate = self
        self.view.addSubview(menuVC.view)
        self.addChildViewController(menuVC)
        menuVC.view.layoutIfNeeded()
        
        
        menuVC.view.frame=CGRectMake(0 - UIScreen.mainScreen().bounds.size.width, 0, UIScreen.mainScreen().bounds.size.width, UIScreen.mainScreen().bounds.size.height);
        
        UIView.animateWithDuration(0.3, animations: { () -> Void in
            menuVC.view.frame=CGRectMake(0, 0, UIScreen.mainScreen().bounds.size.width, UIScreen.mainScreen().bounds.size.height);
            sender.enabled = true
            }, completion:nil)
    }

}

 