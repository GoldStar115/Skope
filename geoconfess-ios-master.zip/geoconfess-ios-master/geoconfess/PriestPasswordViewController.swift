//
//  PriestPasswordViewController.swift
//  geoconfess
//
//  Created by whitesnow0827 on 3/5/16.
//  Copyright © 2016 Andrei Costache. All rights reserved.
//

import UIKit
import AWSMobileAnalytics
import AWSCognito
import AWSS3
import AWSCore
import Photos
import MobileCoreServices
import AssetsLibrary
import Alamofire
import SwiftyJSON

class PriestPasswordViewController: UIViewController, UINavigationControllerDelegate, UIImagePickerControllerDelegate, UITextFieldDelegate {

    @IBOutlet weak var priestPasswordField: UITextField!
    @IBOutlet weak var priestConfirmField: UITextField!
    @IBOutlet weak var img_priestCheckPoint: UIImageView!
    @IBOutlet weak var progressView: UIProgressView!
    @IBOutlet weak var containProgressView: UIView!
    
    var isNotificationChecked : Bool = false
    var imagePicker: UIImagePickerController!
    var image: UIImage = UIImage()
    var celebret_url: NSURL = NSURL()
//
//    //handles upload
//    var uploadCompletionHandler: AWSS3TransferUtilityUploadCompletionHandlerBlock?
//    
//    var uploadFileURL: NSURL?
   
    var uploadRequest:AWSS3TransferManagerUploadRequest?
    var filesize:Int64 = 0
    var amountUploaded:Int64 = 0

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.img_priestCheckPoint.hidden = true
        self.containProgressView.hidden = true
        self.view.alpha = 1.0
        
        // configure authentication with Cognito
        
        priestPasswordField.delegate = self
        priestConfirmField.delegate = self

        //setting progress bar to 0
        self.progressView.progress = 0.0;
        
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    @IBAction func checkButtonTapped(sender: AnyObject) {
        isNotificationChecked = !isNotificationChecked
        if isNotificationChecked {
            self.img_priestCheckPoint.hidden = false
        } else {
            self.img_priestCheckPoint.hidden = true
        }
    }
    
    //Using Camera
    
    @IBAction func cameraButtonTapped(sender: AnyObject) {

        imagePicker =  UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .PhotoLibrary
        
        presentViewController(imagePicker, animated: true, completion: nil)
    }
    
    func update(){
        let percentageUploaded:Float = Float(amountUploaded) / Float(filesize) * 100
        
        print(NSString(format:"Uploading: %.0f%%", percentageUploaded) as String)
        
        let progress = Float(amountUploaded) / Float(filesize)
        self.containProgressView.hidden = false
        self.view.userInteractionEnabled = false
        self.view.alpha = 0.7
        self.progressView.progress = progress
        print("Progress is: %f",progress)
    }

    func imagePickerController(picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : AnyObject]) {
        
        if(picker.sourceType == UIImagePickerControllerSourceType.PhotoLibrary) {
            //defining bucket and upload file name
            //getting actual image
            let image = info[UIImagePickerControllerOriginalImage] as! UIImage
            let imageData = UIImageJPEGRepresentation(image, 0.1)

            let path:NSString = (NSTemporaryDirectory() as NSString).stringByAppendingPathComponent("image.jpg")
            imageData!.writeToFile(path as String, atomically: true)
            
            let url:NSURL = NSURL(fileURLWithPath: path as String)

            uploadRequest = AWSS3TransferManagerUploadRequest()
            uploadRequest?.bucket = "geoconfessapp"
            uploadRequest?.ACL = AWSS3ObjectCannedACL.PublicRead
            
            let dateFormatter = NSDateFormatter()
            dateFormatter.dateFormat = "dd_MM_yyyy_hh_mm_ss"
            let strKey:String = String(format: "%@.jpg", arguments: [dateFormatter.stringFromDate(NSDate())])

            uploadRequest?.key = strKey
            uploadRequest?.contentType = "image/jpeg"
            uploadRequest?.body = url;
            
            uploadRequest?.uploadProgress = {[unowned self](bytesSent:Int64, totalBytesSent:Int64, totalBytesExpectedToSend:Int64) in
                
                dispatch_sync(dispatch_get_main_queue(), { () -> Void in
                    self.amountUploaded = totalBytesSent
                    self.filesize = totalBytesExpectedToSend;
                    self.update()
                })
            }
            
            let transferManager:AWSS3TransferManager = AWSS3TransferManager.defaultS3TransferManager()
            transferManager.upload(uploadRequest).continueWithExecutor(AWSExecutor.mainThreadExecutor(), withBlock:{ [unowned self]
                task -> AnyObject in
                
                if(task.error != nil){
                    print(task.error);
                }else{ // This is image url
                    self.containProgressView.hidden = true
                    self.view.userInteractionEnabled = true
                    self.view.alpha = 1.0
                    self.celebret_url = NSURL(string: String(format: "https://geoconfessapp.s3.amazonaws.com/%@", arguments: [strKey]))!
                    print(String(format: "https://geoconfessapp.s3.amazonaws.com/%@", arguments: [strKey]));
                }
                
                return "all done";
                })

            
//            //defining bucket and upload file name
//            let S3BucketName: String = "geoconfess"
//            //setting temp name for upload
//            let S3UploadKeyName = "TestCameraUpload.png"
//            
//            //settings temp location for image
//            let imageName = NSURL.fileURLWithPath(NSTemporaryDirectory() + S3UploadKeyName).lastPathComponent
//            let documentDirectory = NSSearchPathForDirectoriesInDomains(.DocumentDirectory, .UserDomainMask, true).first! as String
//            
//            // getting local path
//            let localPath = (documentDirectory as NSString).stringByAppendingPathComponent(imageName!)
//            print(String(localPath))
//            //getting actual image
//            let image = info[UIImagePickerControllerOriginalImage] as! UIImage
//            let data = UIImageJPEGRepresentation(image, 0.1)
//            data!.writeToFile(localPath, atomically: true)
//            let photoURL = NSURL(fileURLWithPath: localPath)
//            
//            let expression = AWSS3TransferUtilityUploadExpression()
//            expression.uploadProgress = {(task: AWSS3TransferUtilityTask, bytesSent: Int64, totalBytesSent: Int64, totalBytesExpectedToSend: Int64) in
//                dispatch_async(dispatch_get_main_queue(), {
//                    let progress = Float(totalBytesSent) / Float(totalBytesExpectedToSend)
//                    self.containProgressView.hidden = false
//                    self.view.userInteractionEnabled = false
//                    self.view.alpha = 0.7
//                    self.progressView.progress = progress
//                    NSLog("Progress is: %f",progress)
//                })
//            }
//            
//            self.uploadCompletionHandler = { (task, error) -> Void in
//                dispatch_async(dispatch_get_main_queue(), {
//                    if ((error) != nil){
//                        NSLog("Failed with error")
//                        NSLog("Error: %@",error!);
//                        //    self.statusLabel.text = "Failed"
//                    }
//                    else if(self.progressView.progress != 1.0) {
//                        //    self.statusLabel.text = "Failed"
//                        NSLog("Error: Failed - Likely due to invalid region / filename")
//                    }
//                    else{
//                        //    self.statusLabel.text = "Success"
//                        NSLog("Sucess")
//                        self.containProgressView.hidden = false
//                        self.view.userInteractionEnabled = true
//                        self.view.alpha = 1.0
//                    }
//                })
//            }
//            
//            let transferUtility = AWSS3TransferUtility.defaultS3TransferUtility()
//            transferUtility.uploadFile(photoURL, bucket: S3BucketName, key: strKey, contentType: "image/jpeg", expression: expression, completionHander: uploadCompletionHandler).continueWithBlock { (task) -> AnyObject! in
//                if let error = task.error {
//                    NSLog("Error: %@",error.localizedDescription);
//                    //  self.statusLabel.text = "Failed"
//                }
//                if let exception = task.exception {
//                    NSLog("Exception: %@",exception.description);
//                    //   self.statusLabel.text = "Failed"
//                }
//                if let _ = task.result {
//                    // self.statusLabel.text = "Generating Upload File"
//                    NSLog("Upload Starting!")
//                    // Do something with uploadTask.
//                    self.celebret_url = NSURL(string: "https://(S3BucketName).s3.amazonaws.com/\(strKey)")!
//                    NSLog(String(self.celebret_url))
//                }
//                
//                return nil;
//            }
            
            //end if photo library upload
            self.dismissViewControllerAnimated(true, completion: nil);
            
        }
    }
    
    @IBAction func signUpButtonTapped(sender: AnyObject) {
        if (self.priestPasswordField.text == "") || (self.priestConfirmField.text == "") {
            let alertView = UIAlertView(title: nil, message: "Tous les champs sont requis.", delegate: self, cancelButtonTitle: "OK")
            alertView.show()
        } else if self.priestPasswordField.text != self.priestConfirmField.text {
            let alertView = UIAlertView(title: nil, message: "Les mots de passe doivent être identiques.", delegate: self, cancelButtonTitle: "OK")
            alertView.show()
        } else if self.priestPasswordField.text?.characters.count < 6 {
            let alertView = UIAlertView(title: nil, message: "Le mot de passe doit faire au moins 6 caractères.", delegate: self, cancelButtonTitle: "OK")
            alertView.show()
        }
        else {
            
            let userpassword: String = self.priestPasswordField.text!
            let userNotification: String = self.isNotificationChecked.description
            NSLog(userNotification)
            
            let URL = NSURL(string: "https://geoconfess.herokuapp.com/api/v1/registrations")
            let params = ["user[role]":"priest",
                "user[email]":priestEmail,
                "user[password]":userpassword,
                "user[name]":priestName,
                "user[surname]":priestSurname,
                "user[notification]":userNotification,
                "user[newsletter]":"true",
                "user[phone]":priestTelephon,
                "user[parish_attributes][name]": parishName,
                "user[parish_attributes][email]": parishEmail,
                "user[celebret_url]": celebret_url
                ]
            
            print(params)
            let loadingHUD = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
            
            Alamofire.request(.POST, URL!, parameters: params).responseJSON
                { response in
                    switch response.result {
                    case .Success(let data):
                        let jsonResult = JSON(data)
                        let result = jsonResult["result"].string
                        if result == "success" {
                            let success_alert = UIAlertView(title: nil, message: "Priest Registration Success", delegate: self, cancelButtonTitle: "OK")
                            MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                            success_alert.show()
                        } else {
 
                            var alertMessage: String = String()
                            let errorResult = jsonResult["errors"].dictionary
                            let errorJson = JSON(errorResult!)
                            if let emailResult = errorJson["email"][0].string {
                                if emailResult != "" {
                                    alertMessage = alertMessage +
                                        "email " + emailResult
                                }
                            }
                            
                            if let passwordResult = errorJson["password"][0].string {
                                if passwordResult != "" {
                                    alertMessage = alertMessage +
                                        "password " + passwordResult
                                }
                            }
                            if let phoneResult = errorJson["phone"][0].string {
                                if phoneResult != "" {
                                    alertMessage = alertMessage +
                                        "phoneNumber " + phoneResult
                                }
                            }
                            
                            let failure_alert = UIAlertView(title: nil, message: alertMessage, delegate: self, cancelButtonTitle: "OK")
                            MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                            failure_alert.show()
                        }
                        
                    case .Failure(let error):
                        let connectionFailure_alert = UIAlertView(title: nil, message: "Pas de connexion internet detectée", delegate: self, cancelButtonTitle: "OK")
                        connectionFailure_alert.show()
                        print("Request Failed Reason: \(error)")
                        MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                        
                    }
            }
        }

    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
