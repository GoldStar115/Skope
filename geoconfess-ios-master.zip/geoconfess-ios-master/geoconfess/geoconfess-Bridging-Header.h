//
//  geoconfess-Bridging-Header.h
//  geoconfess
//
//  Created by iOS Maven on 09/03/16.
//  Copyright © 2016 Andrei Costache. All rights reserved.
//

#import <AWSCore/AWSCore.h>
#import <AWSS3/AWSS3.h>
#import "MBProgressHUD.h"