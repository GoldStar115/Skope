//
//  UserPasswordViewController.swift
//  geoconfess
//
//  Created by whitesnow0827 on 3/4/16.
//  Copyright © 2016 Andrei Costache. All rights reserved.
//

import UIKit
import Alamofire
import SwiftyJSON

class UserPasswordViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var confirmPassTextField: UITextField!
    @IBOutlet weak var notificationChekckImage: UIImageView!
    
    var isNotificationChecked : Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.notificationChekckImage.hidden = true
        
        passwordTextField.delegate = self
        confirmPassTextField.delegate = self

    }

    func textFieldShouldReturn(textField: UITextField) -> Bool // called when 'return' key pressed. return NO to ignore.
    {
        textField.resignFirstResponder()
        return true;
    }
    
    @IBAction func signUpButtonTapped(sender: AnyObject) {
        if (self.passwordTextField.text == "") || (self.confirmPassTextField.text == "") {
            let alertView = UIAlertView(title: nil, message: "Tous les champs sont requis.", delegate: self, cancelButtonTitle: "OK")
            alertView.show()
        } else if self.passwordTextField.text != self.confirmPassTextField.text {
            let alertView = UIAlertView(title: nil, message: "Le mot de passe doit être unique.", delegate: self, cancelButtonTitle: "OK")
            alertView.show()
        } else if self.passwordTextField.text?.characters.count < 6 {
            let alertView = UIAlertView(title: nil, message: "Le mot de passe doit faire au moins 6 caractères.", delegate: self, cancelButtonTitle: "OK")
            alertView.show()
        }
        else {

            let userpassword: String = self.passwordTextField.text!
            let userNotification: String = self.isNotificationChecked.description
            NSLog(userNotification)
            
            let URL = NSURL(string: "https://geoconfess.herokuapp.com/api/v1/registrations")
            let params = ["user[role]":"user",
                "user[email]":email,
                "user[password]":userpassword,
                "user[name]":name,
                "user[surname]":surname,
                "user[notification]":userNotification,
                "user[newsletter]":"true",
                "user[phone]":telephone ]
            let loadingHUD = MBProgressHUD.showHUDAddedTo(self.view, animated: true)
            Alamofire.request(.POST, URL!, parameters: params).responseJSON
                { response in
                    switch response.result {
                    case .Success(let data):
                        let jsonResult = JSON(data)
                        let result = jsonResult["result"].string
                        if result == "success" {
                            let success_alert = UIAlertView(title: nil, message: "User Registration Success", delegate: self, cancelButtonTitle: "OK")
                            MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                            success_alert.show()
                        } else {
                            var alertMessage: String = String()
                            let errorResult = jsonResult["errors"].dictionary
                            let errorJson = JSON(errorResult!)
                            
                            if let emailResult = errorJson["email"][0].string {
                                if emailResult != "" {
                                    alertMessage = alertMessage +
                                        "email " + emailResult
                                }
                            }
                            
                            if let passwordResult = errorJson["password"][0].string {
                                if passwordResult != "" {
                                    alertMessage = alertMessage +
                                        "password " + passwordResult
                                }
                            }

                            if let phoneResult = errorJson["phone"][0].string {
                                if phoneResult != "" {
                                    alertMessage = alertMessage +
                                        "phoneNumber " + phoneResult
                                }
                            }

                            let failure_alert = UIAlertView(title: nil, message: alertMessage, delegate: self, cancelButtonTitle: "OK")
                            MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                            failure_alert.show()
                        }
                        
                    case .Failure(let error):
                        let connectionFailure_alert = UIAlertView(title: nil, message: "Aucune connexion à internet detectée.", delegate: self, cancelButtonTitle: "OK")
                        connectionFailure_alert.show()
                        print("Request Failed Reason: \(error)")
                        MBProgressHUD.hideAllHUDsForView(self.view, animated: true)
                        
                }
            }
        }

    }

    @IBAction func checkButtonTapped(sender: AnyObject) {
        isNotificationChecked = !isNotificationChecked
        if isNotificationChecked {
            self.notificationChekckImage.hidden = false
        } else {
            self.notificationChekckImage.hidden = true
        }

        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
