//
//  UserSignUpCell.swift
//  geoconfess
//
//  Created by whitesnow0827 on 3/4/16.
//  Copyright © 2016 Andrei Costache. All rights reserved.
//

import UIKit

class UserSignUpCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    @IBOutlet weak var userInfoTextField: UITextField!

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
