//
//  StaticViewController.swift
//  geoconfess
//
//  Created by whitesnow0827 on 3/17/16.
//  Copyright © 2016 Andrei Costache. All rights reserved.
//

import UIKit
import APAddressBook

class StaticViewController: UIViewController, UIScrollViewDelegate {

    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var bottomView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
    
    var contactsTableViewController:ContactsTableViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        self.scrollView.contentSize = CGSizeMake(274, 300)
        self.scrollView.delegate = self
        
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        if contactsTableViewController == nil {
            contactsTableViewController = ContactsTableViewController()
            contactsTableViewController?.tableView.frame = CGRectMake(0, self.mainView.frame.height, mainView.frame.size.width, mainView.frame.size.height - bottomView.frame.size.height)
            self.addChildViewController(contactsTableViewController!)
            self.mainView.addSubview(contactsTableViewController!.tableView)
            self.mainView.bringSubviewToFront(bottomView)
        }
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func backButtonTapped(sender: AnyObject) {
        self.dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func btnEnvelopTapped(sender: UIButton) {
        if contactsTableViewController?.tableView.frame.origin.y == 0 {
            self.showhiddenContactsTableView()
            return
        }
        let apAddressBook:APAddressBook = APAddressBook.init()
        switch(APAddressBook.access())
        {
        case APAddressBookAccess.Unknown:
            // Application didn't request address book access yet
            self.loadContacts()
            break;
            
        case APAddressBookAccess.Granted:
            // Access granted
            self.loadContacts()
            break;
            
        case APAddressBookAccess.Denied:
            // Access denied or restricted by privacy settings
            ABAddressBookRequestAccessWithCompletion(apAddressBook, { (bool granted, CFErrorRef error) -> Void in
                if granted && error == nil {
                    self.loadContacts()
                }else {
                    
                    let alertController:UIAlertController = UIAlertController.init(title: "", message:"Please go to settings and set allow to access Contacts" as String , preferredStyle: .Alert )
                    let defaultAction = UIAlertAction(title: "OK", style: .Default, handler: nil)
                    alertController.addAction(defaultAction)
                    self.presentViewController(alertController, animated: true, completion: { () -> Void in
                    })
                }
            })
            break;
        }
    }
    func loadContacts() {
        let apAddressBook:APAddressBook = APAddressBook.init()
        apAddressBook.loadContacts(
            { (contacts: [APContact]?, error: NSError?) in
                if let uwrappedContacts = contacts {
                    // do something with contacts
                    self.contactsTableViewController!.setarrayContacts(uwrappedContacts as NSArray)
                    self.showhiddenContactsTableView()
                }
                else if let unwrappedError = error {
                    // show error
                }
        })
    }
    func showhiddenContactsTableView() {
        let changeingRect:CGRect?
        if contactsTableViewController?.view.frame.origin.y == 0 {
            changeingRect = CGRectMake(0, self.mainView.frame.height, mainView.frame.size.width, mainView.frame.size.height - bottomView.frame.size.height)
        }else {
            changeingRect = CGRectMake(0, 0, mainView.frame.size.width, mainView.frame.size.height - bottomView.frame.size.height);
        }
        UIView.animateWithDuration(0.6, delay: 0, options: .CurveEaseOut, animations: {
            
            self.contactsTableViewController?.tableView.frame = changeingRect!
            
            }, completion: { finished in
        })
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
