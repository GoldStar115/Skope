//
//  AppointmentListVC.h
//  Medical
//
//  Created by Dong Nguyen on 2/24/16.
//  Copyright © 2016 QTS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MainVC.h"

@interface AppointmentListVC : UIViewController
@property (nonatomic, strong) MainVC *mainVC;
- (IBAction)btnBack:(id)sender;
- (IBAction)btnHome:(id)sender;
- (IBAction)btnNotification:(id)sender;
@end
