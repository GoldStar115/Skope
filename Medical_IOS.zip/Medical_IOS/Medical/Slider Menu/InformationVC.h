//
//  InformationVC.h
//  Medical
//
//  Created by Dong Nguyen on 2/24/16.
//  Copyright © 2016 QTS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InformationVC : UIViewController

@end
