//
//  SignUpVC.h
//  Medical
//
//  Created by MAC OS on 2/23/16.
//  Copyright © 2016 QTS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TableViewWithBlock.h"
#import "SSCheckBoxView.h"
#import "UIHelpers.h"
@interface SignUpVC : UIViewController
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
- (IBAction)backAction:(id)sender;

@property (retain, nonatomic) IBOutlet UIButton *openButton;
@property (retain, nonatomic) IBOutlet UITextField *inputTextField;
@property (retain, nonatomic) IBOutlet TableViewWithBlock *tb;
@property (weak, nonatomic) IBOutlet UILabel *titleLb;

- (IBAction)changeOpenStatus:(id)sender;
@property (weak, nonatomic) IBOutlet UILabel *cv_lb;
@property (weak, nonatomic) IBOutlet UILabel *cv_lb2;

@property (nonatomic, strong) NSMutableArray *checkboxes;
@end
