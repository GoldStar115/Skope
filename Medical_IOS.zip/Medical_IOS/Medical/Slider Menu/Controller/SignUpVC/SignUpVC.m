//
//  SignUpVC.m
//  Medical
//
//  Created by MAC OS on 2/23/16.
//  Copyright © 2016 QTS. All rights reserved.
//

#import "SignUpVC.h"
#import "SelectionCell.h"
@interface SignUpVC ()<UITextFieldDelegate,UIScrollViewDelegate>
{
    BOOL isOpened;
}
@end

@implementation SignUpVC

- (void)viewDidLoad {
    [super viewDidLoad];
    isOpened=NO;
    [_tb initTableViewDataSourceAndDelegate:^NSInteger(UITableView *tableView, NSInteger section) {
        return 2;
    } setCellForIndexPathBlock:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=[tableView dequeueReusableCellWithIdentifier:@"SelectionCell"];
        if (!cell) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"SelectionCell" owner:self options:nil]objectAtIndex:0];
            [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
        }
        return cell;
    } setDidSelectRowBlock:^(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=(SelectionCell*)[tableView cellForRowAtIndexPath:indexPath];
        _inputTextField.text=cell.lb.text;
        [_openButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }];
    
    [_tb.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_tb.layer setCornerRadius:2];
    [_tb.layer setBorderWidth:1];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    tap.cancelsTouchesInView = NO;
    [self.view addGestureRecognizer:tap];

    NSMutableArray *a = [[NSMutableArray alloc] initWithCapacity:10];
    self.checkboxes = a;
    
    SSCheckBoxView *cb = nil;
    for (int i = 0; i < 2; i++) {
        if (i == 0 ) {
            cb = [[SSCheckBoxView alloc]initWithFrame:_cv_lb.frame style:kSSCheckBoxViewStyleGlossy checked:YES];
            [cb setText:@"Are you already existing patient"];
            
        }else{
            cb = [[SSCheckBoxView alloc]initWithFrame:_cv_lb2.frame style:kSSCheckBoxViewStyleGlossy checked:NO];
            [cb setText:@"Accept the Terms and Conditions"];
        }
        cb.tag = i;
        [self.scrollView addSubview:cb];
        [self.checkboxes addObject:cb];
    }
    [cb setStateChangedBlock:^(SSCheckBoxView *v) {
        [self checkBoxViewChangedState:v];
    }];
    
}

- (void) checkBoxViewChangedState:(SSCheckBoxView *)cbv
{
//    for (SSCheckBoxView *cbv in self.checkboxes) {
////        cbv.enabled = !cbv.enabled;
//    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)backAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)scrollViewDidScroll:(UIScrollView *)sender {
    if (sender.contentOffset.x != 0) {
        CGPoint offset = sender.contentOffset;
        offset.x = 0;
        sender.contentOffset = offset;
    }
}
- (IBAction)changeOpenStatus:(id)sender {
    
    if (isOpened) {
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *closeImage=[UIImage imageNamed:@"dropdown.png"];
            [_openButton setImage:closeImage forState:UIControlStateNormal];
            
            CGRect frame=_tb.frame;
            
            frame.size.height=0;
            [_tb setFrame:frame];
            
        } completion:^(BOOL finished){
            isOpened=NO;
        }];
    }else{
        
        
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *openImage=[UIImage imageNamed:@"dropup.png"];
            [_openButton setImage:openImage forState:UIControlStateNormal];
            
            CGRect frame=_tb.frame;
            
            frame.size.height=2*40;
            [_tb setFrame:frame];
        } completion:^(BOOL finished){
            isOpened=YES;
        }];
        
        
    }
    
}

-(void)dismissKeyboard
{
    [self.view endEditing:YES];
    [UIView animateWithDuration:0.3 animations:^{
        CGRect frame=_tb.frame;
        
        frame.size.height=0;
        [_tb setFrame:frame];
        
    } completion:^(BOOL finished){
        isOpened=NO;
    }];
}
-(void)textFieldDidBeginEditing:(UITextField *)textField{
    [UIView animateWithDuration:0.3 animations:^{
        CGRect frame=_tb.frame;
        
        frame.size.height=0;
        [_tb setFrame:frame];
        
    } completion:^(BOOL finished){
        isOpened=NO;
    }];
    
    
}
@end
