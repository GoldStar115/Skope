//
//  MainVC.m
//  Slider Menu
//
//  Created by COLIN NGO on 7/10/14.
//  Copyright (c) 2014 QTS. All rights reserved.
//

#import "MainVC.h"
#import "MFSideMenuContainerViewController.h"
#import "AppDelegate.h"
#import "SelectionCell.h"
#import "TreeViewNode.h"
#import "InformationCell.h"
#import "AppointmentListVC.h"

@interface MainVC ()<UITextViewDelegate,UITextFieldDelegate,UIScrollViewDelegate,UITableViewDataSource>
{
    AppDelegate* app;
    int item_count_dropdown;
    NSArray *nodes;
}

@property (nonatomic, retain) NSMutableArray *displayArray;
- (void)expandCollapseNode:(NSNotification *)notification;
- (void)fillDisplayArray;
- (void)fillNodeWithChildrenArray:(NSArray *)childrenArray;
- (void)fillNodesArray;
- (NSArray *)fillChildrenForNode;

@end

@implementation MainVC

- (MFSideMenuContainerViewController *)menuContainerViewController {
    return (MFSideMenuContainerViewController *)self.navigationController.parentViewController;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    tap.cancelsTouchesInView = NO;
    app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    self.navigationController.navigationBarHidden = YES;
    
    CGRect size = app.sizeView;
    size.size.height = app.sizeView.size.height;
    self.myAccount_view.frame = size;
    self.notification_view.frame = size;
    self.appointment_view.frame = size;
    self.contactUs_view.frame = size;
    self.information_view.frame = size;
    self.prescription_view.frame = size;
    self.prescriptionPlus_View.frame = size;
    self.home_view.frame = size;
    
    self.parent_view.frame = size;
    
    [self.accountScroll setContentSize:CGSizeMake(app.sizeView.size.width, self.myAccount_view.frame.size.height + 1000)];
    [self.contactScroll setContentSize:CGSizeMake(app.sizeView.size.width, self.contactUs_view.frame.size.height + 1000)];
    [self.prescriptionPlusScroll setContentSize:CGSizeMake(app.sizeView.size.width, self.prescriptionPlus_View.frame.size.height + 1000)];
    item_count_dropdown = 2;
    [self.parent_view addSubview:self.aboutUs_view];
    [self.parent_view addSubview:self.notification_view];
    [self.parent_view addSubview:self.appointment_view];
    [self.parent_view addSubview:self.myAccount_view];
    [self.parent_view addSubview:self.contactUs_view];
    [self.parent_view addSubview:self.information_view];
    [self.parent_view addSubview:self.prescription_view];
    [self.parent_view addSubview:self.prescriptionPlus_View];
    [self.parent_view addSubview:self.home_view];
//Dropdown for my account
    isOpened=NO;
    [self.update_btn.layer setCornerRadius:5];
    self.update_btn.clipsToBounds = YES;
    
    
   [_tb initTableViewDataSourceAndDelegate:^NSInteger(UITableView *tableView, NSInteger section) {
       return item_count_dropdown;
   } setCellForIndexPathBlock:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
       SelectionCell *cell=[tableView dequeueReusableCellWithIdentifier:@"SelectionCell"];
       if (!cell) {
           cell=[[[NSBundle mainBundle]loadNibNamed:@"SelectionCell" owner:self options:nil]objectAtIndex:0];
           [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
       }
       return cell;
   } setDidSelectRowBlock:^(UITableView *tableView, NSIndexPath *indexPath) {
       SelectionCell *cell=(SelectionCell*)[tableView cellForRowAtIndexPath:indexPath];
       _inputTextField.text=cell.lb.text;
       [_openButton sendActionsForControlEvents:UIControlEventTouchUpInside];
   }];

    [_tb.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_tb.layer setCornerRadius:2];
    [_tb.layer setBorderWidth:1];
    _accountScroll.delaysContentTouches = NO;

//Dropdown for APPOINTMENT
    [_tbClinic initTableViewDataSourceAndDelegate:^NSInteger(UITableView *tableView, NSInteger section) {
        return item_count_dropdown;
    } setCellForIndexPathBlock:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=[tableView dequeueReusableCellWithIdentifier:@"SelectionCell"];
        if (!cell) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"SelectionCell" owner:self options:nil]objectAtIndex:0];
            [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
        }
        return cell;
    } setDidSelectRowBlock:^(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=(SelectionCell*)[tableView cellForRowAtIndexPath:indexPath];
        _inputTextField.text=cell.lb.text;
        [_openButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }];
    
    [_tbClinic.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_tbClinic.layer setCornerRadius:2];
    [_tbClinic.layer setBorderWidth:1];
    _appointmentScroll.delaysContentTouches = NO;
    
    [_tbAvailability initTableViewDataSourceAndDelegate:^NSInteger(UITableView *tableView, NSInteger section) {
        return item_count_dropdown;
    } setCellForIndexPathBlock:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=[tableView dequeueReusableCellWithIdentifier:@"SelectionCell"];
        if (!cell) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"SelectionCell" owner:self options:nil]objectAtIndex:0];
            [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
        }
        return cell;
    } setDidSelectRowBlock:^(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=(SelectionCell*)[tableView cellForRowAtIndexPath:indexPath];
        _inputTextField.text=cell.lb.text;
        [_openButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }];
    
    [_tbAvailability.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_tbAvailability.layer setCornerRadius:2];
    [_tbAvailability.layer setBorderWidth:1];
    
    [_tbAppType initTableViewDataSourceAndDelegate:^NSInteger(UITableView *tableView, NSInteger section) {
        return item_count_dropdown;
    } setCellForIndexPathBlock:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=[tableView dequeueReusableCellWithIdentifier:@"SelectionCell"];
        if (!cell) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"SelectionCell" owner:self options:nil]objectAtIndex:0];
            [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
        }
        return cell;
    } setDidSelectRowBlock:^(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=(SelectionCell*)[tableView cellForRowAtIndexPath:indexPath];
        _inputTextField.text=cell.lb.text;
        [_openButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }];
    
    [_tbAppType.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_tbAppType.layer setCornerRadius:2];
    [_tbAppType.layer setBorderWidth:1];
    
    [_makeAppointment_btn.layer setCornerRadius:5];
    
    //Dropdown for APPOINTMENT
    [_tbMedicine initTableViewDataSourceAndDelegate:^NSInteger(UITableView *tableView, NSInteger section) {
        return item_count_dropdown;
    } setCellForIndexPathBlock:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=[tableView dequeueReusableCellWithIdentifier:@"SelectionCell"];
        if (!cell) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"SelectionCell" owner:self options:nil]objectAtIndex:0];
            [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
        }
        return cell;
    } setDidSelectRowBlock:^(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=(SelectionCell*)[tableView cellForRowAtIndexPath:indexPath];
        _inputTextField.text=cell.lb.text;
        [_openButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }];
    
    [_tbMedicine.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_tbMedicine.layer setCornerRadius:2];
    [_tbMedicine.layer setBorderWidth:1];
    
    [_tbWhentoTake initTableViewDataSourceAndDelegate:^NSInteger(UITableView *tableView, NSInteger section) {
        return item_count_dropdown;
    } setCellForIndexPathBlock:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=[tableView dequeueReusableCellWithIdentifier:@"SelectionCell"];
        if (!cell) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"SelectionCell" owner:self options:nil]objectAtIndex:0];
            [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
        }
        return cell;
    } setDidSelectRowBlock:^(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=(SelectionCell*)[tableView cellForRowAtIndexPath:indexPath];
        _inputTextField.text=cell.lb.text;
        [_openButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }];
    
    [_tbWhentoTake.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_tbWhentoTake.layer setCornerRadius:2];
    [_tbWhentoTake.layer setBorderWidth:1];

    [_tbFrequency initTableViewDataSourceAndDelegate:^NSInteger(UITableView *tableView, NSInteger section) {
        return item_count_dropdown;
    } setCellForIndexPathBlock:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=[tableView dequeueReusableCellWithIdentifier:@"SelectionCell"];
        if (!cell) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"SelectionCell" owner:self options:nil]objectAtIndex:0];
            [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
        }
        return cell;
    } setDidSelectRowBlock:^(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=(SelectionCell*)[tableView cellForRowAtIndexPath:indexPath];
        _inputTextField.text=cell.lb.text;
        [_openButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }];
    
    [_tbFrequency.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_tbFrequency.layer setCornerRadius:2];
    [_tbFrequency.layer setBorderWidth:1];
    
    [_tbSelectTime initTableViewDataSourceAndDelegate:^NSInteger(UITableView *tableView, NSInteger section) {
        return item_count_dropdown;
    } setCellForIndexPathBlock:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=[tableView dequeueReusableCellWithIdentifier:@"SelectionCell"];
        if (!cell) {
            cell=[[[NSBundle mainBundle]loadNibNamed:@"SelectionCell" owner:self options:nil]objectAtIndex:0];
            [cell setSelectionStyle:UITableViewCellSelectionStyleGray];
        }
        return cell;
    } setDidSelectRowBlock:^(UITableView *tableView, NSIndexPath *indexPath) {
        SelectionCell *cell=(SelectionCell*)[tableView cellForRowAtIndexPath:indexPath];
        _inputTextField.text=cell.lb.text;
        [_openButton sendActionsForControlEvents:UIControlEventTouchUpInside];
    }];
    
    [_tbSelectTime.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_tbSelectTime.layer setCornerRadius:2];
    [_tbSelectTime.layer setBorderWidth:1];

    
    //Home
    _notification_home_btn.tag = 0;
    _appointment_home_btn.tag = 1;
    _myaccount_home_btn.tag = 2;
    _contactUs_home_btn.tag = 3;
    _info_home_btn.tag = 4;
    _prescription_home_btn.tag = 5;
    
    //Border
    [[self.commentContact layer] setCornerRadius:5];
    [[self.commentContact layer] setBorderWidth:0.3];
    [[self.commentContact layer] setBorderColor:[[UIColor grayColor] CGColor]];
    [[self.commentAppointment layer] setCornerRadius:5];
    [[self.commentAppointment layer] setBorderWidth:0.3];
    [[self.commentAppointment layer] setBorderColor:[[UIColor grayColor] CGColor]];
    
    [[_update_btn layer] setCornerRadius:5];
    [[_btnReset layer] setCornerRadius:5];
    [[_btnSend layer] setCornerRadius:5];
    [_makeAppointment_btn.layer setCornerRadius:5];
    [[_btnSave layer] setCornerRadius:5];
    self.update_btn.clipsToBounds = YES;
    self.btnReset.clipsToBounds = YES;
    self.btnSend.clipsToBounds = YES;
    self.btnSave.clipsToBounds = YES;
    self.makeAppointment_btn.clipsToBounds = YES;
    
    datePicker=[[UIDatePicker alloc]init];
    datePicker.datePickerMode=UIDatePickerModeDate;
    
    [self.dateAppointment setInputView:datePicker];
    UIToolbar *toolBar=[[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    [toolBar setTintColor:[UIColor blueColor]];
    UIBarButtonItem *doneBtn=[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(ShowSelectedDate)];
    UIBarButtonItem *space=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolBar setItems:[NSArray arrayWithObjects:space,doneBtn, nil]];
    [self.dateAppointment setInputAccessoryView:toolBar];
    
    [self.tfFromDate setInputView:datePicker];
    UIToolbar *toolBar1=[[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    [toolBar1 setTintColor:[UIColor blueColor]];
    UIBarButtonItem *doneBtn1=[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(ShowSelectedFromDate)];
    UIBarButtonItem *space1=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolBar1 setItems:[NSArray arrayWithObjects:space1,doneBtn1, nil]];
    [self.tfFromDate setInputAccessoryView:toolBar1];
    
    [self.tfToDate setInputView:datePicker];
    UIToolbar *toolBar2=[[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 44)];
    [toolBar2 setTintColor:[UIColor blueColor]];
    UIBarButtonItem *doneBtn2=[[UIBarButtonItem alloc]initWithTitle:@"Done" style:UIBarButtonItemStyleBordered target:self action:@selector(ShowSelectedToDate)];
    UIBarButtonItem *space2=[[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    [toolBar2 setItems:[NSArray arrayWithObjects:space2,doneBtn2, nil]];
    [self.tfToDate setInputAccessoryView:toolBar2];
    
    //Table Information
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(expandCollapseNode:) name:@"ProjectTreeNodeButtonClicked" object:nil];
    [self fillNodesArray];
    [self fillDisplayArray];
    [self.tableInfomation reloadData];
}

- (void)expandCollapseNode:(NSNotification *)notification
{
    [self fillDisplayArray];
    [self.tableInfomation reloadData];
}

- (void)fillNodesArray
{
    TreeViewNode *firstLevelNode1 = [[TreeViewNode alloc]init];
    firstLevelNode1.nodeLevel = 0;
    firstLevelNode1.nodeObject = [NSString stringWithFormat:@"tester"];
    firstLevelNode1.isExpanded = NO;
    firstLevelNode1.nodeChildren = [[self fillChildrenForNode] mutableCopy];
//    firstLevelNode1.tag = 0;
    
    TreeViewNode *firstLevelNode2 = [[TreeViewNode alloc]init];
    firstLevelNode2.nodeLevel = 0;
    firstLevelNode2.nodeObject = [NSString stringWithFormat:@"home"];
    firstLevelNode2.isExpanded = NO;
    firstLevelNode2.nodeChildren = [[self fillChildrenForNode] mutableCopy];
//    firstLevelNode2.tag = 1;
    
    TreeViewNode *firstLevelNode3 = [[TreeViewNode alloc]init];
    firstLevelNode3.nodeLevel = 0;
    firstLevelNode3.nodeObject = [NSString stringWithFormat:@"test123"];
    firstLevelNode3.isExpanded = NO;
    firstLevelNode3.nodeChildren = [[self fillChildrenForNode] mutableCopy];
//    firstLevelNode3.tag = 2;
    
    TreeViewNode *firstLevelNode4 = [[TreeViewNode alloc]init];
    firstLevelNode4.nodeLevel = 0;
    firstLevelNode4.nodeObject = [NSString stringWithFormat:@"testingteam"];
    firstLevelNode4.isExpanded = NO;
    firstLevelNode4.nodeChildren = [[self fillChildrenForNode] mutableCopy];
//    firstLevelNode4.tag = 3;
    
    nodes = [NSMutableArray arrayWithObjects:firstLevelNode1, firstLevelNode2, firstLevelNode3, firstLevelNode4, nil];
}

- (NSArray *)fillChildrenForNode
{
    TreeViewNode *secondLevelNode1 = [[TreeViewNode alloc]init];
    secondLevelNode1.nodeLevel = 1;
    secondLevelNode1.nodeObject = [NSString stringWithFormat:@"Home tester"];
//    secondLevelNode1.tag  =0;
    
    TreeViewNode *secondLevelNode2 = [[TreeViewNode alloc]init];
    secondLevelNode2.nodeLevel = 1;
    secondLevelNode2.nodeObject = [NSString stringWithFormat:@"Child node 2"];
//    secondLevelNode2.tag  =1;
//
    TreeViewNode *secondLevelNode3 = [[TreeViewNode alloc]init];
    secondLevelNode3.nodeLevel = 1;
    secondLevelNode3.nodeObject = [NSString stringWithFormat:@"Child node 3"];
//    secondLevelNode3.tag  = 2;
    
//
    TreeViewNode *secondLevelNode4 = [[TreeViewNode alloc]init];
    secondLevelNode4.nodeLevel = 1;
    secondLevelNode4.nodeObject = [NSString stringWithFormat:@"Child node 4"];
//    secondLevelNode4.tag  = 3;
    
    NSArray *childrenArray = [NSArray arrayWithObjects:secondLevelNode1
                              , secondLevelNode2, secondLevelNode3, secondLevelNode4
                              , nil];
    
    return childrenArray;
}

//This function is used to fill the array that is actually displayed on the table view
- (void)fillDisplayArray
{
    self.displayArray = [[NSMutableArray alloc]init];
    for (TreeViewNode *node in nodes) {
        [self.displayArray addObject:node];
        if (node.isExpanded) {
           
            [self fillNodeWithChildrenArray:node.nodeChildren];
        }
    }
}

//This function is used to add the children of the expanded node to the display array
- (void)fillNodeWithChildrenArray:(NSArray *)childrenArray
{
    for (TreeViewNode *node in childrenArray) {
        
        [self.displayArray addObject:node];
        if (node.isExpanded) {
            
            [self fillNodeWithChildrenArray:node.nodeChildren];
          
        }
        NSLog(@"----- %d",(int)node.tag);
        
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return self.displayArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //It's cruical here that this identifier is treeNodeCell and that the cell identifier in the story board is anything else but not treeNodeCell
    static NSString *CellIdentifier = @"treeNodeCell";
    UINib *nib = [UINib nibWithNibName:@"InformationCell" bundle:nil];
    [tableView registerNib:nib forCellReuseIdentifier:CellIdentifier];
    
    InformationCell *cell = (InformationCell*)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    TreeViewNode *node = [self.displayArray objectAtIndex:indexPath.row];
    
    
    cell.cellLabel.text = node.nodeObject;
    if (node.isExpanded) {
        [cell setTheButtonBackgroundImage:[UIImage imageNamed:@"minus_tab"]];
    }
    else {
        [cell setTheButtonBackgroundImage:[UIImage imageNamed:@"plus_tab"]];
    }
    cell.treeNode = node;
    [cell setNeedsDisplay];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"lollllllll : %ld",(long)indexPath.row);
}


- (BOOL)touchesShouldCancelInContentView:(UIView *)view {
    if ([view isKindOfClass:UIButton.class]) {
        return YES;
    }
    
    return NO;
}

-(void)dismissKeyboard
{
    
    [self.view endEditing:YES];
    [UIView animateWithDuration:0.3 animations:^{
        UIImage *closeImage=[UIImage imageNamed:@"dropdown.png"];
        [_openButton setImage:closeImage forState:UIControlStateNormal];
            
        CGRect frame=_tb.frame;
        CGRect frame1=_tbClinic.frame;
        CGRect frame2=_tbAvailability.frame;
        CGRect frame3=_tbAppType.frame;
        CGRect frame4=_tbMedicine.frame;
        CGRect frame5=_tbWhentoTake.frame;
        CGRect frame6=_tbFrequency.frame;
        CGRect frame7=_tbSelectTime.frame;
        
        frame.size.height=0;
        frame1.size.height=0;
        frame2.size.height=0;
        frame3.size.height=0;
        frame4.size.height=0;
        frame5.size.height=0;
        frame6.size.height=0;
        frame7.size.height=0;
        [_tb setFrame:frame];
        [_tbClinic setFrame:frame1];
        [_tbAvailability setFrame:frame2];
        [_tbAppType setFrame:frame3];
        [_tbMedicine setFrame:frame4];
        [_tbWhentoTake setFrame:frame5];
        [_tbFrequency setFrame:frame6];
        [_tbSelectTime setFrame:frame7];
            
    } completion:^(BOOL finished){
            isOpened=NO;
    }];
    [self.accountScroll setContentOffset:CGPointMake(0, 0) animated:YES];
    [self.contactScroll setContentOffset:CGPointMake(0, 0) animated:YES];
    [self.appointmentScroll setContentOffset:CGPointMake(0, 0) animated:YES];
    [self.prescriptionPlusScroll setContentOffset:CGPointMake(0, 0) animated:YES];
}

- (IBAction)changeOpenStatus:(id)sender {
    
    if (isOpened) {
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *closeImage=[UIImage imageNamed:@"dropdown.png"];
            [_openButton setImage:closeImage forState:UIControlStateNormal];
            
            CGRect frame=_tb.frame;
            
            frame.size.height=0;
            [_tb setFrame:frame];
            
        } completion:^(BOOL finished){
            isOpened=NO;
        }];
    }else{
        
        
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *openImage=[UIImage imageNamed:@"dropup.png"];
            [_openButton setImage:openImage forState:UIControlStateNormal];
            
            CGRect frame=_tb.frame;
            
            frame.size.height=item_count_dropdown*40;
            [_tb setFrame:frame];
        } completion:^(BOOL finished){
            isOpened=YES;
        }];
        
        
    }
    
}

- (IBAction)changeAvailability:(id)sender {
    if (isOpened) {
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *closeImage=[UIImage imageNamed:@"dropdown.png"];
            [_openButton setImage:closeImage forState:UIControlStateNormal];
            
            CGRect frame=_tbAvailability.frame;
            
            frame.size.height=0;
            [_tbAvailability setFrame:frame];
            
        } completion:^(BOOL finished){
            isOpened=NO;
        }];
    }else{
        
        
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *openImage=[UIImage imageNamed:@"dropup.png"];
            [_openButton setImage:openImage forState:UIControlStateNormal];
            
            CGRect frame=_tbAvailability.frame;
            
            frame.size.height=item_count_dropdown*40;
            [_tbAvailability setFrame:frame];
        } completion:^(BOOL finished){
            isOpened=YES;
        }];
        
        
    }
}

- (IBAction)changeAppType:(id)sender {
    if (isOpened) {
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *closeImage=[UIImage imageNamed:@"dropdown.png"];
            [_openButton setImage:closeImage forState:UIControlStateNormal];
            
            CGRect frame=_tbAppType.frame;
            
            frame.size.height=0;
            [_tbAppType setFrame:frame];
            
        } completion:^(BOOL finished){
            isOpened=NO;
        }];
    }else{
        
        
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *openImage=[UIImage imageNamed:@"dropup.png"];
            [_openButton setImage:openImage forState:UIControlStateNormal];
            
            CGRect frame=_tbAppType.frame;
            
            frame.size.height=item_count_dropdown*40;
            [_tbAppType setFrame:frame];
        } completion:^(BOOL finished){
            isOpened=YES;
        }];
        
        
    }
}

- (IBAction)changeClinic:(id)sender {
    if (isOpened) {
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *closeImage=[UIImage imageNamed:@"dropdown.png"];
            [_openButton setImage:closeImage forState:UIControlStateNormal];
            
            CGRect frame=_tbClinic.frame;
            
            frame.size.height=0;
            [_tbClinic setFrame:frame];
            
        } completion:^(BOOL finished){
            isOpened=NO;
        }];
    }else{
        
        
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *openImage=[UIImage imageNamed:@"dropup.png"];
            [_openButton setImage:openImage forState:UIControlStateNormal];
            
            CGRect frame=_tbClinic.frame;
            
            frame.size.height=item_count_dropdown*40;
            [_tbClinic setFrame:frame];
        } completion:^(BOOL finished){
            isOpened=YES;
        }];
        
        
    }
}

- (IBAction)btnMediceneType:(id)sender {
    if (isOpened) {
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *closeImage=[UIImage imageNamed:@"dropdown.png"];
            [_openButton setImage:closeImage forState:UIControlStateNormal];
            
            CGRect frame=_tbMedicine.frame;
            
            frame.size.height=0;
            [_tbMedicine setFrame:frame];
            
        } completion:^(BOOL finished){
            isOpened=NO;
        }];
    }else{
        
        
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *openImage=[UIImage imageNamed:@"dropup.png"];
            [_openButton setImage:openImage forState:UIControlStateNormal];
            
            CGRect frame=_tbMedicine.frame;
            
            frame.size.height=item_count_dropdown*40;
            [_tbMedicine setFrame:frame];
        } completion:^(BOOL finished){
            isOpened=YES;
        }];
        
        
    }

}

- (IBAction)btnWhenToTake:(id)sender {
    if (isOpened) {
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *closeImage=[UIImage imageNamed:@"dropdown.png"];
            [_openButton setImage:closeImage forState:UIControlStateNormal];
            
            CGRect frame=_tbWhentoTake.frame;
            
            frame.size.height=0;
            [_tbWhentoTake setFrame:frame];
            
        } completion:^(BOOL finished){
            isOpened=NO;
        }];
    }else{
        
        
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *openImage=[UIImage imageNamed:@"dropup.png"];
            [_openButton setImage:openImage forState:UIControlStateNormal];
            
            CGRect frame=_tbWhentoTake.frame;
            
            frame.size.height=item_count_dropdown*40;
            [_tbWhentoTake setFrame:frame];
        } completion:^(BOOL finished){
            isOpened=YES;
        }];
        
        
    }

}

- (IBAction)btnFrequency:(id)sender {
    if (isOpened) {
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *closeImage=[UIImage imageNamed:@"dropdown.png"];
            [_openButton setImage:closeImage forState:UIControlStateNormal];
            
            CGRect frame=_tbFrequency.frame;
            
            frame.size.height=0;
            [_tbFrequency setFrame:frame];
            
        } completion:^(BOOL finished){
            isOpened=NO;
        }];
    }else{
        
        
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *openImage=[UIImage imageNamed:@"dropup.png"];
            [_openButton setImage:openImage forState:UIControlStateNormal];
            
            CGRect frame=_tbFrequency.frame;
            
            frame.size.height=item_count_dropdown*40;
            [_tbFrequency setFrame:frame];
        } completion:^(BOOL finished){
            isOpened=YES;
        }];
        
        
    }

}

- (IBAction)tfTime:(id)sender {
    if (isOpened) {
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *closeImage=[UIImage imageNamed:@"dropdown.png"];
            [_openButton setImage:closeImage forState:UIControlStateNormal];
            
            CGRect frame=_tbSelectTime.frame;
            
            frame.size.height=0;
            [_tbSelectTime setFrame:frame];
            
        } completion:^(BOOL finished){
            isOpened=NO;
        }];
    }else{
        
        
        [UIView animateWithDuration:0.3 animations:^{
            UIImage *openImage=[UIImage imageNamed:@"dropup.png"];
            [_openButton setImage:openImage forState:UIControlStateNormal];
            
            CGRect frame=_tbSelectTime.frame;
            
            frame.size.height=item_count_dropdown*40;
            [_tbSelectTime setFrame:frame];
        } completion:^(BOOL finished){
            isOpened=YES;
        }];
        
        
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)doSideMenu:(id)sender {
    [self.menuContainerViewController toggleLeftSideMenuCompletion:^{
    }];
}

- (void)reloadAction:(int)index{
    [self switchView:index];
    NSLog(@"%d",index);
}

- (void)scrollViewDidScroll:(UIScrollView *)sender {
    if (sender.contentOffset.x != 0) {
        CGPoint offset = sender.contentOffset;
        offset.x = 0;
        sender.contentOffset = offset;
    }
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    if (textField == self.phoneNum) {
        [self.accountScroll setContentOffset:CGPointMake(0, 120) animated:YES];
    }else if(textField == self.email){
        [self.accountScroll setContentOffset:CGPointMake(0, 200) animated:YES];
    }else if(textField == self.password){
        [self.accountScroll setContentOffset:CGPointMake(0, 240) animated:YES];
    }
    if (textField == self.nameContact) {
        [self.contactScroll setContentOffset:CGPointMake(0, 200) animated:YES];
    }else if(textField == self.phoneContact){
        [self.contactScroll setContentOffset:CGPointMake(0, 250) animated:YES];
    }else if(textField == self.mailContact){
        [self.contactScroll setContentOffset:CGPointMake(0, 280) animated:YES];
    }
    if (textField == self.tfDoes) {
        [self.prescriptionPlusScroll setContentOffset:CGPointMake(0, 300) animated:YES];
    }
}
- (void)textViewDidBeginEditing:(UITextView *)textView{
    if(textView == self.commentContact){
        [self.contactScroll setContentOffset:CGPointMake(0, 380) animated:YES];
    }
    if(textView == self.commentAppointment){
        [self.appointmentScroll setContentOffset:CGPointMake(0, 300) animated:YES];
    }
}
- (IBAction)updateAction:(id)sender {
}

#pragma make Home
- (IBAction)homeButtonAction:(id)sender {
    UIButton *homeButton = (UIButton*)sender;
    [self switchView:(int)homeButton.tag];
    switch (homeButton.tag) {
        case 0:
            
            break;
        case 1:
            
            break;
        case 2:
            
            break;
        case 3:
            
            break;
        case 4:
            
            break;
        case 5:
            
            break;
            
        default:
            break;
    }
}

-(void)switchView:(int)index{
    [_home_view setHidden:YES];
    switch (index) {
        case 0:
            [_notification_view setHidden:NO];
            [_appointment_view setHidden:YES];
            [_myAccount_view setHidden:YES];
            [_contactUs_view setHidden:YES];
            [_information_view setHidden:YES];
            [_prescription_view setHidden:YES];
            [_prescriptionPlus_View setHidden:YES];
            break;
        case 1:
            [_notification_view setHidden:YES];
            [_appointment_view setHidden:NO];
            [_myAccount_view setHidden:YES];
            [_contactUs_view setHidden:YES];
            [_information_view setHidden:YES];
            [_prescription_view setHidden:YES];
            [_aboutUs_view setHidden:YES];
            [_prescriptionPlus_View setHidden:YES];
            break;
        case 2:
            [_notification_view setHidden:YES];
            [_appointment_view setHidden:YES];
            [_myAccount_view setHidden:NO];
            [_contactUs_view setHidden:YES];
            [_information_view setHidden:YES];
            [_prescription_view setHidden:YES];
            [_aboutUs_view setHidden:YES];
            [_prescriptionPlus_View setHidden:YES];
            break;
        case 3:
            [_notification_view setHidden:YES];
            [_appointment_view setHidden:YES];
            [_myAccount_view setHidden:YES];
            [_contactUs_view setHidden:NO];
            [_information_view setHidden:YES];
            [_prescription_view setHidden:YES];
            [_aboutUs_view setHidden:YES];
            [_prescriptionPlus_View setHidden:YES];
            break;
        case 4:
            [_notification_view setHidden:YES];
            [_appointment_view setHidden:YES];
            [_myAccount_view setHidden:YES];
            [_contactUs_view setHidden:YES];
            [_information_view setHidden:NO];
            [_prescription_view setHidden:YES];
            [_aboutUs_view setHidden:YES];
            [_prescriptionPlus_View setHidden:YES];
            break;
        case 5:
            [_notification_view setHidden:YES];
            [_appointment_view setHidden:YES];
            [_myAccount_view setHidden:YES];
            [_contactUs_view setHidden:YES];
            [_information_view setHidden:YES];
            [_prescription_view setHidden:NO];
            [_aboutUs_view setHidden:YES];
            [_prescriptionPlus_View setHidden:YES];
            break;
        case 6:
            [_notification_view setHidden:YES];
            [_appointment_view setHidden:YES];
            [_myAccount_view setHidden:YES];
            [_contactUs_view setHidden:YES];
            [_information_view setHidden:YES];
            [_prescription_view setHidden:YES];
            [_aboutUs_view setHidden:NO];
            [_prescriptionPlus_View setHidden:YES];
            break;
        case 7:
            [_notification_view setHidden:YES];
            [_appointment_view setHidden:YES];
            [_myAccount_view setHidden:YES];
            [_contactUs_view setHidden:YES];
            [_information_view setHidden:YES];
            [_prescription_view setHidden:YES];
            [_aboutUs_view setHidden:YES];
            [_prescriptionPlus_View setHidden:NO];
        case 8:
            //Logout
//            [self.navigationController pushViewController:[[LoginVC alloc] initWithNibName:@"LoginVC" bundle:nil] animated:YES];
            break;
        case 9:
            //Term and condition
            break;
        default:
            break;
    }
}

- (IBAction)datePickerBtn:(id)sender {
}

- (IBAction)makeAppointmentAction:(id)sender {
}

-(void)ShowSelectedDate
{
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"dd/MM/YYYY"];
    self.dateAppointment.text=[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];
    [self.dateAppointment resignFirstResponder];
}

-(void)ShowSelectedFromDate
{
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"dd/MM/YYYY"];
    self.tfFromDate.text=[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];
    [self.tfFromDate resignFirstResponder];
}

-(void)ShowSelectedToDate
{
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    [formatter setDateFormat:@"dd/MM/YYYY"];
    self.tfToDate.text=[NSString stringWithFormat:@"%@",[formatter stringFromDate:datePicker.date]];
    [self.tfToDate resignFirstResponder];
}

- (IBAction)btnHome:(id)sender {
     [_home_view setHidden:NO];
}

- (IBAction)btnNotification:(id)sender {
    [self switchView:0];
}
- (IBAction)btnAppoToHome:(id)sender {
    AppointmentListVC * vc = [[AppointmentListVC alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)btnAppoToNotifi:(id)sender {
    [self switchView:0];
}
- (IBAction)btnPrescriptionPlus:(id)sender {
    [self switchView:7];
}

- (IBAction)btnPrescriptionNotifi:(id)sender {
    [self switchView:0];
}
- (IBAction)btnPrescriptionPlusHome:(id)sender {
    [self switchView:5];
}

- (IBAction)btnPrescriptionPlusNotifi:(id)sender {
    [self switchView:0];
}

- (IBAction)btnNotifiHome:(id)sender {
    [_home_view setHidden:NO];
}


- (IBAction)btnInfomationHome:(id)sender {
    [_home_view setHidden:NO];
}

- (void)back {
    [self switchView:0];
//    [_home_view setHidden:NO];
    NSLog(@"okokokokookok");
}

- (void)actionPickerCancelled:(id)sender {
    NSLog(@"Delegate has been informed that ActionSheetPicker was cancelled");
}

- (IBAction)btnSend:(id)sender {
}

- (IBAction)btnReset:(id)sender {
}
- (IBAction)btnActionSend:(id)sender {
}

- (IBAction)btnActionReset:(id)sender {
}
@end
