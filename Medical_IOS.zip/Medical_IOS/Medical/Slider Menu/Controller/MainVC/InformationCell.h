//
//  InformationCell.h
//  Medical
//
//  Created by Dong Nguyen on 2/24/16.
//  Copyright © 2016 QTS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TreeViewNode.h"

@interface InformationCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *cellLabel;
@property (weak, nonatomic) IBOutlet UIButton *cellButton;
@property (weak, nonatomic) IBOutlet UIButton *btnStatus;
@property (retain, strong) TreeViewNode *treeNode;
- (IBAction)btnExpand:(id)sender;
- (void)setTheButtonBackgroundImage:(UIImage *)backgroundImage;
@end
