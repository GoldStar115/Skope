//
//  InformationCell.m
//  Medical
//
//  Created by Dong Nguyen on 2/24/16.
//  Copyright © 2016 QTS. All rights reserved.
//

#import "InformationCell.h"

@implementation InformationCell

- (void)drawRect:(CGRect)rect
{
    CGRect cellFrame = self.cellLabel.frame;
    CGRect cellStatus = self.btnStatus.frame;
//    CGRect cellBtn = self.cellButton.frame;
    long indentation = self.treeNode.nodeLevel * 25;
    cellFrame.origin.x = 20 + indentation;
    cellStatus.origin.x = [UIScreen mainScreen].applicationFrame.size.width + indentation - 25;
    self.cellLabel.frame = cellFrame;
    self.btnStatus.frame = cellStatus;
//    self.cellButton.frame = cellBtn;
}

- (void)setTheButtonBackgroundImage:(UIImage *)backgroundImage
{
    [self.btnStatus setBackgroundImage:backgroundImage forState:UIControlStateNormal];
}

- (IBAction)btnExpand:(id)sender {
    self.treeNode.isExpanded = !self.treeNode.isExpanded;
    [self setSelected:NO];
    [[NSNotificationCenter defaultCenter]postNotificationName:@"ProjectTreeNodeButtonClicked" object:self];
}
@end
