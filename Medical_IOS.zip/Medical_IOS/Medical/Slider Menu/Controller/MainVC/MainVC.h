//
//  MainVC.h
//  Slider Menu
//
//  Created by COLIN NGO on 7/10/14.
//  Copyright (c) 2014 QTS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TableViewWithBlock.h"
#import "LoginVC.h"
@interface MainVC : UIViewController{
    BOOL isOpened;
    UIDatePicker *datePicker;
}

- (IBAction)doSideMenu:(id)sender;
- (void)reloadAction:(int)index;
- (void)back;
@property (strong, nonatomic) IBOutlet UIView *myAccount_view;
@property (weak, nonatomic) IBOutlet UIView *parent_view;

@property (retain, nonatomic) IBOutlet UIButton *openButton;
@property (retain, nonatomic) IBOutlet UITextField *inputTextField;
@property (retain, nonatomic) IBOutlet TableViewWithBlock *tb;
@property (weak, nonatomic) IBOutlet TableViewWithBlock *tbClinic;
@property (weak, nonatomic) IBOutlet TableViewWithBlock *tbAvailability;
@property (weak, nonatomic) IBOutlet TableViewWithBlock *tbAppType;
@property (weak, nonatomic) IBOutlet TableViewWithBlock *tbMedicine;
@property (weak, nonatomic) IBOutlet TableViewWithBlock *tbWhentoTake;
@property (weak, nonatomic) IBOutlet TableViewWithBlock *tbFrequency;
@property (weak, nonatomic) IBOutlet TableViewWithBlock *tbSelectTime;
@property (weak, nonatomic) IBOutlet UILabel *titleLb;

- (IBAction)changeOpenStatus:(id)sender;
- (IBAction)changeAvailability:(id)sender;
- (IBAction)changeAppType:(id)sender;
- (IBAction)changeClinic:(id)sender;
@property (weak, nonatomic) IBOutlet UIScrollView *accountScroll;
@property (weak, nonatomic) IBOutlet UIScrollView *contactScroll;
@property (weak, nonatomic) IBOutlet UIScrollView *appointmentScroll;

//Contact
@property (weak, nonatomic) IBOutlet UITextField *nameContact;
@property (weak, nonatomic) IBOutlet UITextField *phoneContact;
@property (weak, nonatomic) IBOutlet UITextField *mailContact;
@property (weak, nonatomic) IBOutlet UITextView *commentContact;
@property (weak, nonatomic) IBOutlet UITextView *commentAppointment;

//My account
@property (weak, nonatomic) IBOutlet UITextField *firstName;
@property (weak, nonatomic) IBOutlet UITextField *lastName;
@property (weak, nonatomic) IBOutlet UITextField *gender;
@property (weak, nonatomic) IBOutlet UITextField *phoneNum;
@property (weak, nonatomic) IBOutlet UITextField *email;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UITextField *confirmPassword;
@property (weak, nonatomic) IBOutlet UIButton *update_btn;
- (IBAction)updateAction:(id)sender;

// Home
- (IBAction)btnHome:(id)sender;
- (IBAction)btnNotification:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *home_view;
- (IBAction)homeButtonAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *notification_home_btn;
@property (weak, nonatomic) IBOutlet UIButton *appointment_home_btn;
@property (weak, nonatomic) IBOutlet UIButton *myaccount_home_btn;
@property (weak, nonatomic) IBOutlet UIButton *contactUs_home_btn;
@property (weak, nonatomic) IBOutlet UIButton *info_home_btn;
@property (weak, nonatomic) IBOutlet UIButton *prescription_home_btn;

//Prescription
@property (strong, nonatomic) IBOutlet UIView *prescription_view;
- (IBAction)btnPrescriptionPlus:(id)sender;
- (IBAction)btnPrescriptionNotifi:(id)sender;

//Prescription Plus
@property (weak, nonatomic) IBOutlet UIScrollView *prescriptionPlusScroll;
@property (strong, nonatomic) IBOutlet UIView *prescriptionPlus_View;
@property (weak, nonatomic) IBOutlet UIButton *btnSave;
- (IBAction)btnPrescriptionPlusHome:(id)sender;
- (IBAction)btnPrescriptionPlusNotifi:(id)sender;
- (IBAction)btnMediceneType:(id)sender;
- (IBAction)btnWhenToTake:(id)sender;
- (IBAction)btnFrequency:(id)sender;
- (IBAction)tfTime:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *tfMedicineType;
@property (weak, nonatomic) IBOutlet UITextField *tfFrequency;
@property (weak, nonatomic) IBOutlet UITextField *tfWhenToTake;
@property (weak, nonatomic) IBOutlet UITextField *tfTime;
@property (weak, nonatomic) IBOutlet UITextField *tfFromDate;
@property (weak, nonatomic) IBOutlet UITextField *tfToDate;
@property (weak, nonatomic) IBOutlet UITextField *tfMedicineName;
@property (weak, nonatomic) IBOutlet UITextField *tfDoes;

//Notification
@property (strong, nonatomic) IBOutlet UIView *notification_view;
- (IBAction)btnNotifiHome:(id)sender;

//Information
@property (strong, nonatomic) IBOutlet UIView *information_view;
- (IBAction)btnInfomationHome:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tableInfomation;


//About us
@property (strong, nonatomic) IBOutlet UIView *aboutUs_view;


//Contact us
@property (strong, nonatomic) IBOutlet UIView *contactUs_view;
- (IBAction)btnActionSend:(id)sender;
- (IBAction)btnActionReset:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnSend;
@property (weak, nonatomic) IBOutlet UIButton *btnReset;

//APPOINTMENT
- (IBAction)btnAppoToHome:(id)sender;
- (IBAction)btnAppoToNotifi:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *appointment_view;
@property (weak, nonatomic) IBOutlet UITextField *dateAppointment;
- (IBAction)datePickerBtn:(id)sender;
- (IBAction)makeAppointmentAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *makeAppointment_btn;

@end
