//
//  SelectionCell.h
//  ComboBox
//
//  Created by Eric Che on 7/17/13.
//  Copyright (c) 2013 Eric Che. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectionCell : UITableViewCell

@property (retain, nonatomic) IBOutlet UILabel *lb;
@end
