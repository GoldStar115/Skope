//
//  LoginVC.m
//  Medical
//
//  Created by MAC OS on 2/23/16.
//  Copyright © 2016 QTS. All rights reserved.
//

#import "LoginVC.h"
#import "AppDelegate.h"
#import "ForgotVC.h"
#import "SignUpVC.h"
@interface LoginVC ()<UITextFieldDelegate,UIScrollViewDelegate>
{
    
    AppDelegate* app;
}
@end

@implementation LoginVC

- (void)viewDidLoad {
    app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    self.navigationController.navigationBarHidden = YES;
    [super viewDidLoad];
    [_bg_username_view.layer setCornerRadius:5];
    [_bg_password_view.layer setCornerRadius:5];
    
    [self.sign_in_btn.layer setCornerRadius:5];
    self.sign_in_btn.clipsToBounds = YES;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
    
    CGRect size = app.sizeView;
    size.size.height = app.sizeView.size.height;
    self.scrollView.frame = size;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidLayoutSubviews{
    [super viewDidLayoutSubviews];
    CGRect size = app.sizeView;
    size.size.height = app.sizeView.size.height;
    [self.scrollView setContentSize:CGSizeMake(size.size.width, size.size.height)];
}

- (IBAction)signinAction:(id)sender {
    [app intSideMenu];
}

-(void)dismissKeyboard
{
    [self.scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    [self.view endEditing:YES];
}

-(void)textFieldDidBeginEditing:(UITextField *)textField{
    if (IS_IPHONE_4_OR_LESS) {
        if (textField == _password_textfield) {
            [self.scrollView setContentOffset:CGPointMake(0, 130) animated:YES];
        }
    }
}
- (IBAction)forgotAction:(id)sender {
    [self.navigationController pushViewController:[[ForgotVC alloc] initWithNibName:@"ForgotVC" bundle:nil] animated:YES];
}

- (IBAction)signUpAction:(id)sender {
    [self.navigationController pushViewController:[[SignUpVC alloc] initWithNibName:@"SignUpVC" bundle:nil] animated:YES];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    if (textField == _email_textfield) {
        [_password_textfield becomeFirstResponder];
    }else if (textField == _password_textfield){
        [self.view endEditing:YES];
        [self.scrollView setContentOffset:CGPointMake(0, 0) animated:YES];
    }
    return YES;
}
@end
