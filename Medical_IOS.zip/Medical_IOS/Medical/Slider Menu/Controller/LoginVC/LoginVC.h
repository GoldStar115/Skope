//
//  LoginVC.h
//  Medical
//
//  Created by MAC OS on 2/23/16.
//  Copyright © 2016 QTS. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LoginVC : UIViewController
@property (weak, nonatomic) IBOutlet UIView *bg_username_view;
@property (weak, nonatomic) IBOutlet UIView *bg_password_view;

@property (weak, nonatomic) IBOutlet UIButton *sign_in_btn;
- (IBAction)signinAction:(id)sender;

@property (weak, nonatomic) IBOutlet UITextField *email_textfield;
@property (weak, nonatomic) IBOutlet UITextField *password_textfield;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
- (IBAction)forgotAction:(id)sender;
- (IBAction)signUpAction:(id)sender;

@end
