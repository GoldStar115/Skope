//
//  ForgotVC.m
//  Medical
//
//  Created by MAC OS on 2/23/16.
//  Copyright © 2016 QTS. All rights reserved.
//

#import "ForgotVC.h"
#import "ForgotVC.h"
@interface ForgotVC ()

@end

@implementation ForgotVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.send_btn.layer setCornerRadius:5];
    self.send_btn.clipsToBounds = YES;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboard)];
    [self.view addGestureRecognizer:tap];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)backAction:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)sendAction:(id)sender {
}

-(void)dismissKeyboard
{
    [self.view endEditing:YES];
}
@end
