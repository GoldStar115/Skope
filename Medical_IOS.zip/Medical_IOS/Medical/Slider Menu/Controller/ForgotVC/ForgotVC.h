//
//  ForgotVC.h
//  Medical
//
//  Created by MAC OS on 2/23/16.
//  Copyright © 2016 QTS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgotVC : UIViewController
- (IBAction)backAction:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *email_textfield;
- (IBAction)sendAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *send_btn;


@end
