//
//  LeftVC.h
//  Slider Menu
//
//  Created by COLIN NGO on 7/10/14.
//  Copyright (c) 2014 QTS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftVC : UIViewController
@property (strong, nonatomic) IBOutlet UITableView *tblMenu;
- (IBAction)leftAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *myAccount_btn;
@property (weak, nonatomic) IBOutlet UIButton *appointment_btn;
@property (weak, nonatomic) IBOutlet UIButton *myPrescrition_btn;
@property (weak, nonatomic) IBOutlet UIButton *notification_btn;
@property (weak, nonatomic) IBOutlet UIButton *information_btn;
@property (weak, nonatomic) IBOutlet UIButton *aboutUs_btn;
@property (weak, nonatomic) IBOutlet UIButton *contactUs_btn;
@property (weak, nonatomic) IBOutlet UIButton *logout_btn;
@property (weak, nonatomic) IBOutlet UIButton *terms_btn;

@end
