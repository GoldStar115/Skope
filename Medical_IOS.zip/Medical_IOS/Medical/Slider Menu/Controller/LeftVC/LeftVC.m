//
//  LeftVC.m
//  Slider Menu
//
//  Created by COLIN NGO on 7/10/14.
//  Copyright (c) 2014 QTS. All rights reserved.
//

#import "LeftVC.h"
#import "MFSideMenuContainerViewController.h"
#import "AppDelegate.h"
@interface LeftVC ()
{
    AppDelegate* app;
}
@end

@implementation LeftVC
- (MFSideMenuContainerViewController *)menuContainerViewController {
    return (MFSideMenuContainerViewController *)self.parentViewController;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    [super viewDidLoad];
    self.myAccount_btn.tag = 0;
    self.appointment_btn.tag = 1;
    self.myPrescrition_btn.tag = 2;
    self.notification_btn.tag = 3;
    self.information_btn.tag = 4;
    self.aboutUs_btn.tag = 5;
    self.contactUs_btn.tag = 6;
    self.logout_btn.tag = 7;
    self.terms_btn.tag = 8;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)leftAction:(id)sender {
    [app.container setMenuState:MFSideMenuStateClosed];
    UIButton* indexButton = (UIButton*)sender;
    switch (indexButton.tag) {
        case  0:
            [app.mainVC reloadAction:2];
            break;
        case  1:
            [app.mainVC reloadAction:1];
            break;
        case  2:
            [app.mainVC reloadAction:5];
            break;
        case  3:
            [app.mainVC reloadAction:0];
            break;
        case  4:
            [app.mainVC reloadAction:4];
            break;
        case  5:
            [app.mainVC reloadAction:6];
            break;
        case  6:
            [app.mainVC reloadAction:3];
            break;
        case  7:
            [app.mainVC reloadAction:7];
            break;
        case  8:
            [app.mainVC reloadAction:8];
            break;
    }
}
@end
