//
//  AppDelegate.h
//  Slider Menu
//
//  Created by COLIN NGO on 7/10/14.
//  Copyright (c) 2014 QTS. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MFSideMenuContainerViewController.h"
#import "LeftVC.h"
#import "MainVC.h"
@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
//    MFSideMenuContainerViewController *container;
}
@property(nonatomic,retain) LeftVC *leftVC;
@property(nonatomic,retain) MainVC *mainVC;
@property (strong, nonatomic) UIWindow *window;
@property (nonatomic, assign) MFSideMenuContainerViewController* container;
@property (nonatomic, assign) CGRect sizeView;
-(void) intSideMenu;
@end
