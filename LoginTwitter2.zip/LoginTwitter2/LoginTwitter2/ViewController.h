//
//  ViewController.h
//  LoginTwitter2
//
//  Created by My Star on 1/26/16.
//  Copyright © 2016 My Star. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

