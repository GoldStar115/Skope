

#import <UIKit/UIKit.h>
#import "AppcustomTabbar.h"

@interface AppcustomTabbar : UITabBarController<UITabBarControllerDelegate>

+(AppcustomTabbar *)singletonMethod;
@property int preSelectedTab;
@end

