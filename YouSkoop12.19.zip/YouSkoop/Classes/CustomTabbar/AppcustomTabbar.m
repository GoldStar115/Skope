

#import "AppcustomTabbar.h"
#define kAnimationDuration .3

@interface AppcustomTabbar ()

@end

@implementation AppcustomTabbar
@synthesize preSelectedTab;

+(AppcustomTabbar *)singletonMethod
{
    static AppcustomTabbar *singleton;
    if(!singleton)
    {
        singleton=[[AppcustomTabbar alloc] init];
        singleton.view.backgroundColor = [UIColor clearColor];
    }
    return singleton;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        [AppHelper saveToUserDefaults:@"1" withKey:KPreSelectedTab];
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UITabBarController *tabBarCont = (UITabBarController *)self;
    tabBarCont.delegate=self;
    
    UITabBar *tabBarRef = tabBarCont.tabBar;
    
    UITabBarItem *tabBarItem1 = [tabBarRef.items objectAtIndex:0];
    UITabBarItem *tabBarItem2 = [tabBarRef.items objectAtIndex:1];
    UITabBarItem *tabBarItem3 = [tabBarRef.items objectAtIndex:2];
    
    if(IS_Greater_Or_Equal_to_IOS_7){
        
        [tabBarRef setBackgroundImage:[[UIImage alloc] init]];
        [[UITabBar appearance] setShadowImage:[[UIImage alloc] init]];
        
        tabBarItem1=[tabBarItem1 initWithTitle:nil image:[[UIImage imageNamed:@"group_tab_mrenu_icon.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:@"group_active_tab_mrenu_icon.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
        
        tabBarItem2=[tabBarItem2 initWithTitle:nil image:[[UIImage imageNamed:@"skoop_tab_mrenu_icon.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:@"skoop_active_tab_mrenu_icon.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
        
         tabBarItem3=[tabBarItem3 initWithTitle:nil image:[[UIImage imageNamed:@"calender_tab_mrenu_icon.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal] selectedImage:[[UIImage imageNamed:@"calender_active_tab_mrenu_icon.png"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]];
    }
    else{
        tabBarItem1.title = nil;
        [tabBarItem1 setFinishedSelectedImage:[UIImage imageNamed:@"group_active_tab_mrenu_icon.png"] withFinishedUnselectedImage:[UIImage imageNamed:@"group_tab_mrenu_icon.png"]];
        
        tabBarItem2.title = nil;
        [tabBarItem2 setFinishedSelectedImage:[UIImage imageNamed:@"skoop_active_tab_mrenu_icon.png"] withFinishedUnselectedImage:[UIImage imageNamed:@"skoop_tab_mrenu_icon.png"]];
        
        tabBarItem3.title = nil;
        [tabBarItem3 setFinishedSelectedImage:[UIImage imageNamed:@"calender_active_tab_mrenu_icon.png"] withFinishedUnselectedImage:[UIImage imageNamed:@"calender_tab_mrenu_icon.png"]];
    }
    [self setSelectedIndex:1];
}

- (BOOL)tabBarController:(UITabBarController *)tabBarController shouldSelectViewController:(UIViewController *)viewController{
    
    NSLog(@"shouldSelectViewController::%i",(int)self.selectedIndex);
    return YES;
}

- (void)tabBarController:(UITabBarController *)tabBarController didSelectViewController:(UIViewController *)viewController{
    
    if(self.selectedIndex == 0 || self.selectedIndex == 1){
        
        [AppHelper saveToUserDefaults:[NSString stringWithFormat:@"%i",(int)tabBarController.selectedIndex] withKey:KPreSelectedTab];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
