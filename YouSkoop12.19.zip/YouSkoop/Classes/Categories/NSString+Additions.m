//
//  NSString+Additions.m
//  FetcherApp
//
//  Created by AppStudioz on 5/6/15.
//  Copyright (c) 2015 AppStudioz. All rights reserved.
//

#import "NSString+Additions.h"

@implementation NSString (Additions)
-(CGSize)getSizeWithFont:(UIFont*)font andSize:(CGSize)size{
    
    if (SYSTEM_VERSION_LESS_THAN(@"7.0")) {
        
        //version < 7.0
        return [self sizeWithFont:font constrainedToSize:size lineBreakMode:NSLineBreakByWordWrapping];
    }
    else
        return [self boundingRectWithSize:size
                                      options:NSStringDrawingUsesLineFragmentOrigin
                                   attributes:@{
                                                NSFontAttributeName : font
                                                }
                                  context:nil].size;
}

@end

