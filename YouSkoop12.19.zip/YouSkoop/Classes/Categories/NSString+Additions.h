//
//  NSString+Additions.h
//  FetcherApp
//
//  Created by AppStudioz on 5/6/15.
//  Copyright (c) 2015 AppStudioz. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Additions)
-(CGSize)getSizeWithFont:(UIFont*)font andSize:(CGSize)size;
@end
