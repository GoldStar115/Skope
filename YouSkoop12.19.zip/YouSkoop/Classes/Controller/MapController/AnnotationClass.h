//
//  AnnotationClass.h
//  SwatiLMFourthProject
//
//  Created by TechAhead Software on 01/02/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import<MapKit/MKAnnotation.h>

@interface AnnotationClass : NSObject<MKAnnotation>
{
    CLLocationCoordinate2D coordinate;  
    NSString *title,*email,*distance,*subtitle;
    //int tag;
}
@property int tag;
@property(nonatomic,assign) CLLocationCoordinate2D coordinate;
@property(nonatomic,copy) NSString *title,*email,*distance,*subtitle;

@end
