//
//  CLController.h
//  SwatiLMFourthProject
//
//  Created by TechAhead Software on 04/02/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreLocation/CoreLocation.h>
#import <MapKit/MapKit.h>
@protocol MyCLControllerDelegate 
@required
- (void)locationUpdate:(CLLocation *)location; 
- (void)locationError:(NSError *)error;
@end
@interface CLController : NSObject<CLLocationManagerDelegate,MKMapViewDelegate>
{ 
    CLLocationManager *locationManager;
    CLLocation *userCurrentLocation;
}
@property(nonatomic,retain) CLLocation *userCurrentLocation;
@property (nonatomic, retain) CLLocationManager *locationManager;  

+ (CLController*) sharedInstance;

-(void)initializelocationManager;
-(void)stopLocationUpdate;

@end
