//
//  CLController.m
//  SwatiLMFourthProject
//
//  Created by TechAhead Software on 04/02/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "CLController.h"

#import "Defines.h"
@implementation CLController
@synthesize locationManager;
@synthesize userCurrentLocation;
+ (CLController*) sharedInstance
{
	static CLController* singleton;
    
	if (!singleton) 
	{
		singleton = [[CLController alloc] init];
	}
	return singleton;
}
#pragma mark - locationManager
-(void)initializelocationManager
{
#if TARGET_IPHONE_SIMULATOR
    //simulator code
    CLLocationCoordinate2D cord;
    cord.latitude =  28.615573;
    cord.longitude = 77.374428;
    
//    cord.latitude = 34.197371;
//    cord.longitude = -118.193917;
    
    NSDate *today = [NSDate date];
    self.userCurrentLocation = [[CLLocation alloc] initWithCoordinate:cord  altitude:1 horizontalAccuracy:1 verticalAccuracy:-1 timestamp:today];
    
    [[WebServicesController WebServiceMethod] updateUserLocationWithUserId:[AppHelper userDefaultsForKey:KUserId] latitude:[NSString stringWithFormat:@"%f",self.userCurrentLocation.coordinate.latitude] longitude:[NSString stringWithFormat:@"%f",self.userCurrentLocation.coordinate.longitude] andToken:KAppToken];
#else
    //device code
    [self performSelector:@selector(initLocation)];
#endif
}

- (id) init {
    self = [super init];
    if (self != nil) {
        
        // send loc updates to myself
    }
    return self;
}

-(void)initLocation
{
    if(!self.locationManager)
        self.locationManager = [[CLLocationManager alloc] init] ;
    self.locationManager.desiredAccuracy = 300.0f;
    self.locationManager.delegate = self;
    if(IS_Greater_Or_Equal_to_IOS_8){
        if ([self.locationManager respondsToSelector:@selector(requestAlwaysAuthorization)]) {
            [self.locationManager requestAlwaysAuthorization];
        }
    }
    [self.locationManager startUpdatingLocation];
}

-(void)stopLocationUpdate{
    
    [self.locationManager stopUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    self.userCurrentLocation = [locations lastObject];
    //NSLog(@"%f ====== %f",self.userCurrentLocation.coordinate.latitude,self.userCurrentLocation.coordinate.longitude);
    
    if(locations.count>0 && locations.count==1){
        
        [[WebServicesController WebServiceMethod] updateUserLocationWithUserId:[AppHelper userDefaultsForKey:KUserId] latitude:[NSString stringWithFormat:@"%f",self.userCurrentLocation.coordinate.latitude] longitude:[NSString stringWithFormat:@"%f",self.userCurrentLocation.coordinate.longitude] andToken:KAppToken];
    }
    else if(locations.count>1){
        
        CLLocationDistance distance= [[locations lastObject] distanceFromLocation:[locations objectAtIndex:locations.count-2]];
        if(distance>=100){
            
            [[WebServicesController WebServiceMethod] updateUserLocationWithUserId:[AppHelper userDefaultsForKey:KUserId] latitude:[NSString stringWithFormat:@"%f",self.userCurrentLocation.coordinate.latitude] longitude:[NSString stringWithFormat:@"%f",self.userCurrentLocation.coordinate.longitude] andToken:KAppToken];
        }
    }
    
     [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Did_Update_Location object:nil userInfo:nil];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{   
	NSLog(@"ErrorLocationManager: %@", [error description]);
     [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Did_Update_Location object:nil userInfo:nil];
}

@end
