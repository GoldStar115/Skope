//
//  AnnotationClass.m
//  SwatiLMFourthProject
//
//  Created by TechAhead Software on 01/02/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

#import "AnnotationClass.h"

@implementation AnnotationClass
@synthesize coordinate;
@synthesize title,email;
@synthesize tag,distance,subtitle;

@end
