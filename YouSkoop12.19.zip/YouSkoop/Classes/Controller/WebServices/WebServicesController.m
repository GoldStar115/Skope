//
//  WebServicesController.m
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "WebServicesController.h"
#import "AFNetworking.h"
#import "AFHTTPClient.h"
#import "SBJson.h"
#import "SignInView.h"
#import "Defines.h"


@implementation WebServicesController

+(WebServicesController *)WebServiceMethod
{
    static WebServicesController *singleton;
    if(!singleton)
    {
        singleton=[[WebServicesController alloc] init];
    }
    return singleton;
}

- (id)init{
    self = [super init];
    if (self){
        // Initialization code here.
        _managedObjectContext = [[AppDelegate getAppDelegate] managedObjectContext];
    }
    return self;
}

-(void)deleteFileFromDocumentDirectoryWithFileName:(NSString*)fileName{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectoryPath = [paths objectAtIndex:0];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    NSError *error = nil;
    for (NSString *file in [fm contentsOfDirectoryAtPath:documentsDirectoryPath error:&error]) {
        
        if ([file rangeOfString:@".mov"].location!=NSNotFound){
            
            NSLog(@"Substring Not Found");
            NSLog(@"Substring Found Successfully");
            NSLog(@"%@",[NSString stringWithFormat:@"%@/%@", documentsDirectoryPath, file]);
            if([file isEqualToString:fileName]){
                BOOL success = [fm removeItemAtPath:[NSString stringWithFormat:@"%@/%@", documentsDirectoryPath, file] error:&error];
                if (!success || error) {
                    // it failed.
                    NSLog(@"failed");
                }
                else
                    NSLog(@"success");
            }
        }
    }
}

-(void)deleteAllVideoFileFromDocumentDirectory{
    
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectoryPath = [paths objectAtIndex:0];
    
    NSFileManager *fm = [NSFileManager defaultManager];
    
    NSError *error = nil;
    for (NSString *file in [fm contentsOfDirectoryAtPath:documentsDirectoryPath error:&error]) {
        
        if ([file rangeOfString:@".mov"].location!=NSNotFound){
            
            NSLog(@"Substring Not Found");
            NSLog(@"Substring Found Successfully");
            NSLog(@"%@",[NSString stringWithFormat:@"%@/%@", documentsDirectoryPath, file]);
            BOOL success = [fm removeItemAtPath:[NSString stringWithFormat:@"%@/%@", documentsDirectoryPath, file] error:&error];
            if (!success || error) {
                // it failed.
                NSLog(@"failed");
            }
            else
                NSLog(@"success");
        }
    }
}


-(NSEntityDescription *) makeEntityDescription: (NSString *)name{
    NSEntityDescription* descr = [NSEntityDescription entityForName:name
											 inManagedObjectContext:_managedObjectContext];
    return descr;
}

-(NSFetchRequest *)getBasicRequestForEntityName: (NSString *)entityName
{
	NSFetchRequest *request = [[NSFetchRequest alloc] init];
	NSEntityDescription *entity = [NSEntityDescription entityForName:entityName inManagedObjectContext:_managedObjectContext];
	[request setEntity:entity];
	return request;
}

#pragma mark Parse into core data
-(void)parseSkoopReplyDataWithDataDictionary:(NSDictionary*)skoopReplyDict
{
    SkoopReplyData *skoopReplyObject =[self getStoredSkoopWithSkoopId:[skoopReplyDict valueForKey:@"skoop_id"]];
    
    if(!skoopReplyObject)
        skoopReplyObject=[NSEntityDescription insertNewObjectForEntityForName:@"SkoopReplyData"
                                                inManagedObjectContext:_managedObjectContext];
    
    if([skoopReplyDict valueForKey:@"skoop_id"] && ![[skoopReplyDict valueForKey:@"skoop_id"] isKindOfClass:[NSNull class]])
        skoopReplyObject.skoopId=[skoopReplyDict valueForKey:@"skoop_id"];
    
    if([skoopReplyDict valueForKey:@"name"] && ![[skoopReplyDict valueForKey:@"name"] isKindOfClass:[NSNull class]])
        skoopReplyObject.name=[skoopReplyDict valueForKey:@"name"];
    else
        skoopReplyObject.name=@"";
    
    if([skoopReplyDict valueForKey:@"date"] && ![[skoopReplyDict valueForKey:@"date"] isKindOfClass:[NSNull class]])
        skoopReplyObject.replyDate=[skoopReplyDict valueForKey:@"date"];
    else
        skoopReplyObject.replyDate=@"";
    
    if([skoopReplyDict valueForKey:@"duration"] && ![[skoopReplyDict valueForKey:@"duration"] isKindOfClass:[NSNull class]])
        skoopReplyObject.videoLength=[skoopReplyDict valueForKey:@"duration"];
    
    if([skoopReplyDict valueForKey:@"image"] && ![[skoopReplyDict valueForKey:@"image"] isKindOfClass:[NSNull class]])
        skoopReplyObject.userImageUrl=[skoopReplyDict valueForKey:@"image"];
    
    if([skoopReplyDict valueForKey:@"message"] && ![[skoopReplyDict valueForKey:@"message"] isKindOfClass:[NSNull class]])
        skoopReplyObject.message=[skoopReplyDict valueForKey:@"message"];
    
    if([skoopReplyDict valueForKey:@"paymentStatus"] && ![[skoopReplyDict valueForKey:@"paymentStatus"] isKindOfClass:[NSNull class]])
        skoopReplyObject.paymentStatus=[skoopReplyDict valueForKey:@"paymentStatus"];
    
    if([skoopReplyDict valueForKey:@"thumbimage"] && ![[skoopReplyDict valueForKey:@"thumbimage"] isKindOfClass:[NSNull class]])
        skoopReplyObject.thumbImage=[skoopReplyDict valueForKey:@"thumbimage"];
    
    if([skoopReplyDict valueForKey:@"video_path"] && ![[skoopReplyDict valueForKey:@"video_path"] isKindOfClass:[NSNull class]])
        skoopReplyObject.videoUrl=[skoopReplyDict valueForKey:@"video_path"];
    
    if([skoopReplyDict valueForKey:@"video_data"] && ![[skoopReplyDict valueForKey:@"video_data"] isKindOfClass:[NSNull class]])
        skoopReplyObject.videoNsdata=[skoopReplyDict valueForKey:@"video_data"];
    
    if([skoopReplyDict valueForKey:@"upload"] && ![[skoopReplyDict valueForKey:@"upload"] isKindOfClass:[NSNull class]])
        skoopReplyObject.isUpload=[skoopReplyDict valueForKey:@"upload"];
    
    NSError *error;
    if (![_managedObjectContext save:&error])
	{
        
	}
}

#pragma mark Retrive from core data
-(SkoopReplyData *)getStoredSkoopWithSkoopId:(NSString *)skoopId
{
    NSFetchRequest *request = [self getBasicRequestForEntityName:@"SkoopReplyData"];
	NSPredicate *predicate = [NSPredicate predicateWithFormat:@"skoopId==%@",skoopId];
	[request setPredicate:predicate];
	
	NSError *error = nil;
	NSArray *results = [_managedObjectContext executeFetchRequest:request error:&error];
	SkoopReplyData *skoopData = nil;
    
	if (!error && [results count] > 0)
		skoopData = [results objectAtIndex:0];
    
    return skoopData;
}

-(NSArray*)getAllSkoopReplyData
{
    NSFetchRequest *request = [self getBasicRequestForEntityName:@"SkoopReplyData"];
	NSError *error = nil;
	NSArray *results = [_managedObjectContext executeFetchRequest:request error:&error];
    NSMutableArray *resArray=[[NSMutableArray alloc] initWithArray:results];
    return resArray;
}

#pragma mark  delete from core data
-(void)deleteSkoopWithSkoopId:(NSString *)skoopId{
    if(skoopId){
        NSManagedObject *request = [self getStoredSkoopWithSkoopId:skoopId];
        NSError *error;
        if(request){
            [_managedObjectContext deleteObject:request];
            if (![_managedObjectContext save:&error]){
                
            }
        }
    }
}

- (void) deleteAllObjectsWithEntityName: (NSString *) entityName
{
    NSFetchRequest *request = [self getBasicRequestForEntityName:entityName];
    NSError *error;
    NSArray *items = [_managedObjectContext executeFetchRequest:request error:&error];
    for(NSManagedObject *managedObject in items)
    {
        [_managedObjectContext deleteObject:managedObject];
    }
}



#pragma mark- SignInMethod/LoginIN
-(void) signIn:(NSMutableDictionary *)dictUserCredentials{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_auth_post]]];
        
        
        if([AppHelper userDefaultsForKey:Device_Token])
            [dictUserCredentials setValue:[AppHelper userDefaultsForKey:Device_Token] forKey:Device_Token];
        else
            [dictUserCredentials setValue:Default_device_token forKey:Device_Token];
        [dictUserCredentials setValue:Device_Type forKey:@"device_type"];
        [dictUserCredentials setValue:[AppHelper userDefaultsForKey:Device_Id] forKey:Device_Id];
        
        NSLog(@"%@",[dictUserCredentials JSONRepresentation]);
        
        NSDictionary *param=[[NSDictionary alloc]initWithDictionary:dictUserCredentials];
        NSMutableURLRequest *request=[client requestWithMethod:@"POST" path:@"login" parameters:param];
        [request setTimeoutInterval:Timeout_Interval];
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSString *decodedString=[[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
             NSDictionary *dict=[decodedString JSONValue];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_login object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_login object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_login object:nil userInfo:dict];
    }
 }

-(void) signOutWithUserId:(NSString*)userId deviceId:(NSString *)deviceId andToken:(NSString*)appToken{
    
    if([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSMutableDictionary *paramDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:appToken,@"token", userId,KUserId,[AppHelper userDefaultsForKey:Device_Id],Device_Id, nil];
        
        NSLog(@"%@",[paramDict JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_logout]);
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_logout]]];
        NSDictionary *param=[[NSDictionary alloc]initWithDictionary:paramDict];
        NSMutableURLRequest *request=[client requestWithMethod:@"POST" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSString *decodedString=[[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
             NSDictionary *dict=[decodedString JSONValue];
             NSLog(@"DICT VALUE%@",dict);
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_logout object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_logout object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_logout object:nil userInfo:dict];
    }
}


#pragma  mark- SignUpMethod
-(void) signUpServices:(NSMutableDictionary *)dictSignUpCredentials
{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_signup_post]]];
        
        if([AppHelper userDefaultsForKey:Device_Token])
            [dictSignUpCredentials setValue:[AppHelper userDefaultsForKey:Device_Token] forKey:Device_Token];
        else
            [dictSignUpCredentials setValue:Default_device_token forKey:Device_Token];
        [dictSignUpCredentials setValue:Device_Type forKey:@"device_type"];
        [dictSignUpCredentials setValue:[AppHelper userDefaultsForKey:Device_Id] forKey:Device_Id];
        
        NSLog(@"%@",[dictSignUpCredentials JSONRepresentation]);
        
        NSDictionary *param=[[NSDictionary alloc]initWithDictionary:dictSignUpCredentials];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_userRegistration object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_userRegistration object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_userRegistration object:nil userInfo:dict];
    }
}

#pragma mark- Forgot Password
-(void) forgotpasswordServices:(NSMutableDictionary *)dictForgotCredentials
{
    
    NSLog(@"%@",dictForgotCredentials);
    
    AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_forgot_post]]];
    
    NSDictionary *param=[[NSDictionary alloc]initWithDictionary:dictForgotCredentials];
    
    NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
    [request setTimeoutInterval:Timeout_Interval];;
    AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         //NSLog(@"%@",responseObject);
         NSString *decodedString=[[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
         NSLog(@"%@",decodedString);
         NSError *error;
         NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
         
         [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_ForgotPassword object:nil userInfo:dict];
         
         
     }
                                     failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         NSLog(@"Error....%@",[error description]);
     }
     ];
    [operation start];
   }


#pragma mark- Change Password
-(void) changePassword:(NSMutableDictionary *)dictChangeCredentials
{
    NSLog(@"%@",dictChangeCredentials);
    
    AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_forgot_update]]];
    
    NSDictionary *param=[[NSDictionary alloc]initWithDictionary:dictChangeCredentials];
    
    NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
    [request setTimeoutInterval:Timeout_Interval];;
    AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         NSError *error;
         NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
         [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_ChangePassword object:nil userInfo:dict];
    }
    failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         NSLog(@"Error....%@",[error description]);
     }
     ];
    [operation start];
}

-(void) sendSkoopWithUserId:(NSString *)userId groupId:(NSString*)groupId skoopDate:(NSString*)skoopDate offer:(NSString*)offer searchText:(NSString*)searchText token:(NSString*)token livePortal:(NSString*)livePortal location:(NSString *)location latitude:(NSString *)latitude longitude:(NSString *)longitude andSkoopType:(NSString *)skoopType{

    if([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSMutableDictionary *paramDict;
        if ([groupId isEqualToString:@"0"]) {
            paramDict = [[NSMutableDictionary alloc] initWithObjectsAndKeys:userId,KUserId,skoopDate,@"skoopDate",offer,@"offer",searchText,@"searchText",token,@"token",livePortal,@"live_portal",[AppHelper getGmtDifference],@"gmt",location,@"location",latitude,@"lat",longitude,@"long",skoopType,@"skoop_type", nil];
        } else {
            paramDict = [[NSMutableDictionary alloc] initWithObjectsAndKeys:userId,KUserId,groupId,@"group_id",skoopDate,@"skoopDate",offer,@"offer",searchText,@"searchText",token,@"token",livePortal,@"live_portal",[AppHelper getGmtDifference],@"gmt",location,@"location",latitude,@"lat",longitude,@"long",skoopType,@"skoop_type", nil];
        }
        
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_post]]];
        
        NSLog(@"%@",[paramDict JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_post]);
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:paramDict];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc] initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
            
            NSError *error;
            NSLog(@"::::%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
            NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_Request object:nil userInfo:dict];
        }
        failure:^(AFHTTPRequestOperation *operation, NSError *error){
            NSLog(@"Error....%@",[error description]);
            NSMutableDictionary *dict = nil;
            dict = [[NSMutableDictionary alloc] init];
            [dict setObject:@"1" forKey:@"errorCode"];
            [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_Request object:nil userInfo:dict];
        }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_Request object:nil userInfo:dict];
    }
}

-(void) sendGroupSkoopWithUserId:(NSString *)userId groupId:(NSString*)groupId skoopDate:(NSString*)skoopDate offer:(NSString*)offer searchText:(NSString*)searchText token:(NSString*)token livePortal:(NSString*)livePortal andSkoopType:(NSString *)skoopType{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSMutableDictionary *paramDict = [[NSMutableDictionary alloc] initWithObjectsAndKeys:userId,KUserId,groupId,@"group_id",skoopDate,@"skoopDate",offer,@"offer",searchText,@"searchText",token,@"token",livePortal,@"live_portal",[AppHelper getGmtDifference],@"gmt",skoopType,@"skoop_type", nil];
        
        NSLog(@"%@",[paramDict JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_Group_skoop]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_Group_skoop]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:paramDict];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
            NSError *error;
            NSLog(@"::::%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
            NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_Group_Skoop_Request object:nil userInfo:dict];
        }
        failure:^(AFHTTPRequestOperation *operation, NSError *error){
                                             NSLog(@"Error....%@",[error description]);
            NSLog(@"Error....%@",[error description]);
            NSMutableDictionary *dict = nil;
            dict = [[NSMutableDictionary alloc] init];
            [dict setObject:@"1" forKey:@"errorCode"];
            [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_Group_Skoop_Request object:nil userInfo:dict];
        }
         ];
        [operation start];
    }
    else{
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_Group_Skoop_Request object:nil userInfo:dict];
    }
}

//Count of users in particular location
-(void) countUsers:(NSMutableDictionary *)dictoflocation{
    NSLog(@"%@",dictoflocation);
    
    AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_user_get_user]]];
    NSLog(@":::%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_user_get_user]);
    NSDictionary *param=[[NSDictionary alloc]initWithDictionary:dictoflocation];
    
    NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
    [request setTimeoutInterval:Timeout_Interval];;
    AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
         NSError *error;
         NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
         [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_Count_Users object:nil userInfo:dict];
     }
    failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         NSLog(@"Error....%@",[error description]);
     }
     ];
    [operation start];
}

#pragma  mark- MY REQUESTS
-(void) myRequests:(NSMutableDictionary *)dictOfRequests
{
    NSLog(@"%@",dictOfRequests);
    NSLog(@"::::::::::::::::%@",[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_my_skoop]]);
    AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_my_skoop]]];
    [client cancelAllHTTPOperationsWithMethod:Method_skoop_my_skoop path:BaseURLString];
    
    NSDictionary *param=[[NSDictionary alloc]initWithDictionary:dictOfRequests];
    NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
    [request setTimeoutInterval:Timeout_Interval];;
    AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
         //NSLog(@"%@",responseObject);
         NSString *decodedString=[[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
         NSLog(@"string %@",decodedString);
         NSError *error;
         NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
         [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_myrequests object:nil userInfo:dict];
     }
    failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         NSLog(@"Error....%@",[error description]);
     }
     ];
    
    [operation start];
    
}

#pragma  mark- MY Reply
-(void) getSkoopReplyVideoWithSkoopId:(NSString *)skoopId buy:(NSString*)buy andAppToken:(NSString*)appToken andGroupId:(NSString *)groupId
{
    if([[AppDelegate getAppDelegate] checkInternateConnection]){
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_get_reply]]];
        
        NSMutableDictionary *param =[[NSMutableDictionary alloc] initWithObjectsAndKeys:skoopId,@"skoop_id",buy,@"buy",appToken,@"token",[AppHelper getGmtDifference],@"gmt", nil];
        if (groupId != nil) {
            param[@"group_id"] = groupId;
        }
    
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_get_reply]);
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_reply_skoopid object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
         }
         ];
        [operation start];
    }
    else{
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_reply_skoopid object:nil userInfo:dict];
    }
}



#pragma mark My Skoop
-(void)getSkoopRequestWithUserId:(NSString *)userId skoopId:(NSString*)skoopId pageNo:(NSString*)pageNo pageLImit:(NSString*)pageLimit appToken:(NSString*)appToken andRequestType:(NSString*)requestType{
    if([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_invite_skoop]]];
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_invite_skoop]);
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,skoopId,@"skoop_id",pageNo,@"page",pageLimit,@"limit",appToken,@"token",requestType,@"requestType",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date",[AppHelper getGmtDifference],@"gmt", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             //NSLog(@"%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_mySkoop object:nil userInfo:dict];
        }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_for_mySkoop object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else{
        [AppHelper showAlertViewWithTag:1 title:AppName message:ERROR_INTERNET delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        [AppDelegate dismissGlobalHUD];
    }
}

//****************************
#pragma mark Update user's location on server
-(void)updateUserLocationWithUserId:(NSString*)userId latitude:(NSString*)latitude longitude:(NSString*)longitude andToken:(NSString*)uniqueToken
{
    NSString *gmtDifference = [AppHelper getGmtDifference];
    NSDictionary *param = Nil;
    
//    if(gmtDifference == Nil){
//        param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,@"47.046500",@"latitude",@"21.918943",@"longitude",uniqueToken,@"token",@"0",@"gmt", nil];
//    }
//    else{
//        param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,@"47.046500",@"latitude",@"21.918943",@"longitude",uniqueToken,@"token",gmtDifference,@"gmt", nil];
//    }

    if(gmtDifference == Nil){
        param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,latitude,@"latitude",longitude,@"longitude",uniqueToken,@"token",@"0",@"gmt", nil];
    }
    else{
        param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,latitude,@"latitude",longitude,@"longitude",uniqueToken,@"token",gmtDifference,@"gmt", nil];
    }
    
    AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_update_location]]];
    
    NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
    [request setTimeoutInterval:Timeout_Interval];
    AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSString *decodedString=[[NSString alloc]initWithData:responseObject encoding:NSUTF8StringEncoding];
             NSLog(@"location did update......");
             NSLog(@"string %@",decodedString);
         }
         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
         }
     ];
    [operation start];
}

#pragma mark Reply on skoop
-(void)replyOnSkoopWithUserId:(NSString*)userId skoopId:(NSString*)skoopId replyVideo:(NSData*)videoData andToken:(NSString*)uniqueToken
{
    NSMutableDictionary *paramDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:userId,KUserId,skoopId,@"skoop_id",uniqueToken,@"token",[AppHelper getGmtDifference],@"gmt",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
    NSLog(@"%@",[paramDict JSONRepresentation]);
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        AFHTTPClient *httpClient = [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:BaseURLString]];
        NSDictionary *params = [NSDictionary dictionaryWithDictionary:paramDict];
        
        NSMutableURLRequest *request = [httpClient multipartFormRequestWithMethod:@"POST" path:Method_Reply_on_skoop parameters:params constructingBodyWithBlock: ^(id <AFMultipartFormData>formData){
            if (videoData)
                [formData appendPartWithFileData:videoData name:@"file" fileName:@"Video2.mp4" mimeType:@"video/mpeg4"];
            
        }];
        [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
        
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSError *error;
            
            //NSLog(@"::::%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
            
            NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_reply_on_skoop object:nil userInfo:dict];
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            
            NSLog(@"error = %@", error);
            NSMutableDictionary *dict = nil;
            dict = [[NSMutableDictionary alloc] init];
            [dict setObject:@"1" forKey:@"errorCode"];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_reply_on_skoop object:nil userInfo:dict];
        }];
        [operation start];
        
    }else{
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_reply_on_skoop object:nil userInfo:dict];
    }
}

#pragma mark Upload Video
-(void)replyOnSkoopWithUserId:(NSString*)userId skoopId:(NSString*)skoopId groupId:(NSString *)groupId replyVideo:(NSData*)videoData andToken:(NSString*)uniqueToken
{
    NSMutableDictionary *paramDict;
    if (groupId != nil) {
        paramDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:userId,KUserId,skoopId,@"skoop_id",groupId,@"group_id",uniqueToken,@"token",[AppHelper getGmtDifference],@"gmt",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
    } else {
        paramDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:userId,KUserId,skoopId,@"skoop_id",uniqueToken,@"token",[AppHelper getGmtDifference],@"gmt",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
    }
    
    NSLog(@"%@",[paramDict JSONRepresentation]);
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        AFHTTPClient *httpClient = [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:BaseURLString]];
        NSDictionary *params = [NSDictionary dictionaryWithDictionary:paramDict];
        
        NSMutableURLRequest *request = [httpClient multipartFormRequestWithMethod:@"POST" path:Method_Reply_on_skoop parameters:params constructingBodyWithBlock: ^(id <AFMultipartFormData>formData){
            if (videoData)
                [formData appendPartWithFileData:videoData name:@"file" fileName:@"Video2.mp4" mimeType:@"video/mpeg4"];
            
        }];
        [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
        
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            NSError *error;
            
            NSLog(@"::::%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
            
            NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_reply_on_skoop object:nil userInfo:dict];
        } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
            NSMutableDictionary *dict = nil;
            dict = [[NSMutableDictionary alloc] init];
            [dict setObject:@"1" forKey:@"errorCode"];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_reply_on_skoop object:nil userInfo:dict];
        }];
        [operation start];
        
    }else{
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_reply_on_skoop object:nil userInfo:dict];
    }
}

#pragma mark-GroupMethods

-(void)getFeaturedGroupsWithUserId:(NSString*)userId appToken:(NSString*)appToken pageNumber:(NSString*)pageNumber andPageLimit:(NSString*)pageLimit{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSMutableDictionary *paramDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:userId,KUserId,appToken,@"token", pageNumber,@"page",pageLimit,@"limit", nil];
        NSLog(@"%@",paramDict);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_FeaturedGroupd]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_FeaturedGroupd]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:paramDict];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
        {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_CarouselImages object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_CarouselImages object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_CarouselImages object:nil userInfo:dict];
    }
}

-(void)getCategoryGroupsWithUserId:(NSString*)userId categoryId:(NSString*)categoryId appToken:(NSString*)token pageNumber:(NSString*)pageNumber andPageLimit:(NSString*)pageLimit{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:token,@"token",userId,KUserId,categoryId,@"category_id",pageNumber,@"page", nil];
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Group_By_Category]);
        NSLog(@"%@",[param JSONRepresentation]);
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Group_By_Category]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Group_By_Category object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Group_By_Category object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Group_By_Category object:nil userInfo:dict];
    }
}

-(void)getPopularGroupsWithUserId:(NSString*)userId appToken:(NSString*)appToken pageNumber:(NSString*)pageNumber andPageLimit:(NSString*)pageLimit{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSMutableDictionary *paramDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:userId,KUserId,appToken,@"token", pageNumber,@"page",pageLimit,@"limit", nil];
        NSLog(@"%@",paramDict);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_PopularGroups]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:paramDict];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             NSLog(@"%@",dict);
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Popular_Groups object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Popular_Groups object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Popular_Groups object:nil userInfo:dict];
    }
    
}

-(void)getCelebrityGroupsWithUserId:(NSString*)userId appToken:(NSString*)appToken pageNumber:(NSString*)pageNumber andPageLimit:(NSString*)pageLimit
{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSMutableDictionary *paramDict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:userId,KUserId,appToken,@"token", pageNumber,@"page",pageLimit,@"limit", nil];
        NSLog(@"%@",paramDict);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Celebrity]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:paramDict];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             NSLog(@"%@",dict);
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Celebrity_Groups object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Celebrity_Groups object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Celebrity_Groups object:nil userInfo:dict];
    }
}

-(void)getAllGroupsDetailWithUserId:(NSString *)geoupId appToken:(NSString *)appToken categoryId:(NSString *)categoryId andPageLimit:(NSString *)pageLimit{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token",[AppHelper userDefaultsForKey:KUserId],KUserId,appToken,@"token",categoryId,@"category_id",pageLimit,@"limit", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_AllGroupsData]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_AllGroupsData]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [dict JSONValue];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_AllGroupsData object:nil userInfo:dict];
         }
         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_AllGroupsData object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_AllGroupsData object:nil userInfo:dict];
    }
}

//for create group page
-(void)getCategoryNamesForCreateGroup
{
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString, Method_Get_CategoryNames]]];
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token", nil];
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
            NSError *error;
            NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_CategoryNames object:nil userInfo:dict];
        }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_CategoryNames object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_CategoryNames object:nil userInfo:dict];
    }
}

-(void)getMyGroupDataWithUserId:(NSString*)userId  SearchString: (NSString *)searchString pageNumber:(NSString*)pageNumber limit:(NSString*)limit exGroupId:(NSString*)exGroupId inviteUserId:(NSString *)inviteUserId andIsGetNameList:(BOOL)isGetNameList{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token",userId,@"user_id",searchString,@"searchText",pageNumber,@"page",limit,@"limit",[NSString stringWithFormat:@"%i",isGetNameList],@"list",inviteUserId,@"invite_user_id",exGroupId,@"ex_group_id", nil];
        
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"==%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_MyGroupList]);
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_MyGroupList]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_GetGroupList object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_GetGroupList object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_GetGroupList object:nil userInfo:dict];
    }
}

-(void)sendInviteToGroupWithGroupIds:(NSMutableArray*) group inviteUserId:(NSString *)inviteUserId andGroupId:(NSString*)groupId{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token",[AppHelper userDefaultsForKey:KUserId],@"user_id",[AppHelper userDefaultsForKey:KUserName],@"user_name",group,@"groups",groupId,@"group_id",inviteUserId,@"invite_user_id", nil];
        
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_SendInvitaionTo_Group]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_SendInvitaionTo_Group]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             NSLog(@"%@",dict);
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Send_InviteToGroup object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Send_InviteToGroup object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict =[[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Send_InviteToGroup object:nil userInfo:dict];
    }
}

-(void)getIndividualGroupMembersDataUserId:(NSString*)userId searchText:(NSString*)searchText pageNumber:(NSString*)pageNumber pageLimit:(NSString*)pageLimit andGroupId:(NSString*)groupId
{
    if ([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token",userId,@"user_id",searchText,@"searchText",pageNumber,@"page",pageLimit,@"limit",groupId,@"group_id", nil];
        
        NSLog(@"%@",[param JSONRepresentation]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_IndividalGroupMembers]]];
        
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_IndividalGroupMembers]);
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             NSLog(@"dict = %@", dict);
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_IndividualGroupMembers object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_IndividualGroupMembers object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else{
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_IndividualGroupMembers object:nil userInfo:dict];
    }
}
-(void)sendInviteToMembersWithMemberIds:(NSMutableArray*) membersList andGroupId:(NSString*)groupId{
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token",[AppHelper userDefaultsForKey:KUserId],@"user_id",[AppHelper userDefaultsForKey:KUserName],@"user_name",membersList,@"users",groupId,@"group_id", nil];
        
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Invite_Members]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Invite_Members]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Send_InviteToMember object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error){
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Send_InviteToMember object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else{
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Send_InviteToMember object:nil userInfo:dict];
    }
}

-(void)unJoinGroupWithUserId:(NSString*)userId andGroupId:(NSString*)groupId
{
    if ([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:KAppToken,@"token",userId,@"user_id",groupId,@"group_id", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,
                     Method_UnJoin_Group]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_UnJoin_Group]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             NSLog(@"%@",dict);
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_UnJoinGroup object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_UnJoinGroup object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_UnJoinGroup object:nil userInfo:dict];
    }
}

-(void)joinGroupWithUserId:(NSString*)userId andGroupId:(NSString*)groupId{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:KAppToken,@"token",userId,@"user_id",groupId,@"group_id",[AppHelper userDefaultsForKey:KUserName],@"user_name", nil];
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Join_Group]]];
        
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,
                     Method_Join_Group]);
        NSLog(@"%@",[param JSONRepresentation]);
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             NSLog(@"%@",dict);
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_JoinGroup object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_JoinGroup object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_JoinGroup object:nil userInfo:dict];
    }
}

-(void)getGroupSkoopDataWithGroupId:(NSString*)groupId requestType:(NSString*)requestType pageNumber:(NSString*)pageNumber andLimit:(NSString*)limit{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param = [[NSDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token",[AppHelper userDefaultsDictionaryDataForKey:KUserId],KUserId,groupId,@"group_id",requestType,@"requestType",pageNumber,@"page",limit,@"limit",[AppHelper getGmtDifference],@"gmt",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
        
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"==%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Group_Skoop]);
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Group_Skoop]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             dict = [self getDictionarySortedByDate:dict];
             //NSLog(@"Dict = %@", dict);
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_GetGroupSkoop object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_GetGroupSkoop object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_For_GetGroupSkoop object:nil userInfo:dict];
    }
}

-(NSDictionary *)getDictionarySortedByDate:(NSDictionary *)dict{
    
    NSArray *skoopArray = [[NSArray alloc] initWithArray:[dict objectForKey:@"data"]];
    
    NSMutableArray *arrDate = [[NSMutableArray alloc] init];
    for (int i = 0; i < [skoopArray count]; i++) {
        NSMutableDictionary *tmpDict = [NSMutableDictionary dictionaryWithDictionary:[skoopArray objectAtIndex:i]];
        NSString *strDate = [NSString stringWithFormat:@"%@",[tmpDict valueForKey:@"date"]];;
        if ([tmpDict objectForKey:@"reply"]) {
            strDate = [NSString stringWithFormat:@"%@",[[tmpDict valueForKey:@"reply"] objectForKey:@"date"]];
        }
        NSString *str0 = strDate;
        
        strDate = [strDate stringByReplacingOccurrencesOfString:@" AM" withString:@""];
        strDate = [strDate stringByReplacingOccurrencesOfString:@" PM" withString:@""];
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setDateFormat:@"HH:mm / MMM dd, yyyy"];
        [formatter setTimeZone:[NSTimeZone timeZoneForSecondsFromGMT:60*60* 0]];
        NSDate *date = [formatter dateFromString:strDate];
        
        if ([str0 containsString:@"PM"]) {
            date = [date dateByAddingTimeInterval:60 * 60 * 12];
        }
        [arrDate addObject:date];
        //NSLog(@"dateOfSkoop = %@   ===== %@", str0, date);
    }
    
    int iSum = 0;
    NSMutableArray *arrValue = [[NSMutableArray alloc] init];
    for (int i = 0; i < [skoopArray count]; i++) {
        iSum = 0;
        for (int j = 0; j < [skoopArray count]; j++) {
            if ([[arrDate objectAtIndex:i] compare:[arrDate objectAtIndex:j]] == NSOrderedAscending) {
                iSum++;
            }
        }
        [arrValue addObject:[NSNumber numberWithInt:iSum]];
        //NSLog(@"value = %d", iSum);
    }
        
    NSMutableArray *arrIndex = [[NSMutableArray alloc] init];
    for (int i = 0; i < [skoopArray count]; i++) {
        for (int j = 0; j < [skoopArray count]; j++) {
            if (i == [[arrValue objectAtIndex:j] intValue]) {
                [arrIndex addObject:[NSNumber numberWithInt:j]];
                //NSLog(@"index = %d", j);
            }
        }
    }
    
    NSMutableArray *arrSorted = [[NSMutableArray alloc] init];
    for (int i = 0; i < [skoopArray count]; i++) {
        int j = [[arrIndex objectAtIndex:i] intValue];
        [arrSorted addObject:[skoopArray objectAtIndex:j]];
    }
        
    NSDictionary *dictSorted = [[NSDictionary alloc] initWithObjectsAndKeys:arrSorted,@"data", nil];
    
    return dictSorted;
}

-(void)getAllNotificationsWithUserId:(NSString*)userId pageNumber:(NSString*)pageNumber andLimit:(NSString*)limit{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token",userId,@"user_id",pageNumber,@"page",limit,@"limit",[AppHelper getGmtDifference],@"gmt",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
        
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"==%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_All_Notification]);
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_All_Notification]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             //NSLog(@"::::%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_AllNotifications object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_AllNotifications object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_AllNotifications object:nil userInfo:@{@"error":@"1"}];
    }
}

-(void)blockUnblockUserWithUserId:(NSString*)userId blockUserId:(NSString*)blockUserId groupId:(NSString*)groupId requestType:(NSString*)requestType andReason:(NSString*)reason
{
    if ([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token",userId,@"user_id",blockUserId,@"block_user_id",requestType,@"requestType",reason,@"reason",groupId,@"group_id",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
        
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Block_Unblock_User]);
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Block_Unblock_User]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Block_Unblock_User object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Block_Unblock_User object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Block_Unblock_User object:nil userInfo:dict];
    }
}

-(void)blockUserFromGroupWithUserId:(NSString*)userId blockUserId:(NSString*)blockUserId groupId:(NSString*)groupId andReason:(NSString*)reason{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token",userId,@"owner_id",blockUserId,@"block_user_id",groupId,@"group_id",reason,@"reason",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
        
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Block_User_From_Group]);
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Block_User_From_Group]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Block_User_From_Group object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Block_User_From_Group object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Block_User_From_Group object:nil userInfo:dict];
    }
}

-(void)getBlockedUserWithUserId:(NSString*)userId group:(NSString*)group searchText:(NSString*)searchText pageNumber:(NSString*)pageNo pageLimit:(NSString*)pageLimit andAppToken:(NSString*)appToken
{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,group,@"group",pageNo,@"page",pageLimit,@"limit",searchText,@"searchText", nil];
        
        NSLog(@"%@",[param JSONRepresentation]);
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Block_User]]];
      //  [client cancelAllHTTPOperationsWithMethod:Method_Get_Block_User path:BaseURLString];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];
        
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Block_User object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
        {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Block_User object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Block_User object:nil userInfo:dict];
    }
}

-(void)getNotificationCountWithUserId:(NSString*)userId isGetSyncData:(NSString*)isGetSync andToken:(NSString*)token{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:token,@"token",userId,KUserId,isGetSync,@"isGetSyncData",[AppHelper userDefaultsForKey:Device_Id],Device_Id,Device_Type,@"device_type", nil];
        
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Notification_Count]);
        NSLog(@"===%@",[param JSONRepresentation]);
        AFHTTPClient *client = [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Notification_Count]]];
        
        [client cancelAllHTTPOperationsWithMethod:Method_Reply_on_skoop path:BaseURLString];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Notofication_Count object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Notofication_Count object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Notofication_Count object:nil userInfo:dict];
    }
}

-(void)readNotificationWithUserId:(NSString*)userId notificationId:(NSString*)notificationId notificationType:(NSString*)notificationType andToken:(NSString*)token{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:token,@"token",userId,KUserId,notificationId,@"notification_id",notificationType,@"notification_type", nil];
        
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Read_Notification]);
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Read_Notification]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Read_Notofication object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Read_Notofication object:nil userInfo:dict];
         }
         ];
        [operation start];
        
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Read_Notofication object:nil userInfo:dict];
    }
}

-(void)getUserProfileUserId:(NSString*)userId viewerId:(NSString*)viewerId appToken:(NSString*)appToken andPageLimit:(NSString*)pageLimit{
    
    if([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,viewerId,@"viewer_id",pageLimit,@"limit",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date",[AppHelper getGmtDifference],@"gmt", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_User_Profile]);
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_User_Profile]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_User_Profile object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_User_Profile object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_User_Profile object:nil userInfo:dict];
    }
}

-(void)likeOrDislikeUserProfileWithUserId:(NSString*)userId resoruceId:(NSString*)resoruceId appToken:(NSString*)appToken like:(NSString*)like{
    
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,resoruceId,@"resource_id",like,@"like", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Like_User_Profile]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Like_Dislike_User_Profile object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Like_Dislike_User_Profile object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Like_Dislike_User_Profile object:nil userInfo:dict];
    }
}

-(void)writeCommentWithUserId:(NSString*)userId resoruceId:(NSString*)resoruceId appToken:(NSString*)appToken andCommentText:(NSString*)commentText{
    
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,resoruceId,@"resource_id",commentText,@"body",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Write_Comment]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Write_Comment]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Write_Comment object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Write_Comment object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Write_Comment object:nil userInfo:dict];
    }
}

-(void)getCommentWithUserId:(NSString*)userId andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,[AppHelper getGmtDifference],@"gmt", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_get_Comment]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_get_Comment]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Comment object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Comment object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Comment object:nil userInfo:dict];
    }
}


-(void)getUserSkoopsWithUserId:(NSString*)userId viewerId:(NSString*)viewerId requestType:(NSString*)requestType searchText:(NSString*)searchText pageNo:(NSString*)pageNo pageLimit:(NSString*)pageLimit  buy:(NSString*)buy andAppToken:(NSString*)appToken{
    
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,viewerId,@"viewer_id",requestType,@"requestType",searchText,@"searchText",pageNo,@"page",pageLimit,@"limit",buy,@"buy",[AppHelper getGmtDifference],@"gmt", nil];
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_User_Skoop]);
        NSLog(@"%@",[param JSONRepresentation]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_User_Skoop]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_User_Skoop object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_User_Skoop object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_User_Skoop object:nil userInfo:dict];
    }
}

-(void)getUserSkoopsWithUserId:(NSString*)userId pageNumber:(NSString*)pageNumber pagelimit:(NSString*)pageLimit skoopDate:(NSString*)skoopDate andAppToken:(NSString*)appToken {
    
    if([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,pageNumber,@"page",pageLimit,@"limit",skoopDate,@"skoopDate",[AppHelper getGmtDifference],@"gmt", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Calendar_Skoop]]];
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Calendar_Skoop]);
        
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             NSLog(@"=======%@",dict);
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Calendar_Skoop object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Calendar_Skoop object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Calendar_Skoop object:nil userInfo:dict];
    }
}

-(void)getMonthSkoopsWithUserId:(NSString*)userId skoopMonth:(NSString*)skoopMonth andAppToken:(NSString*)appToken andSkoopdate:(NSString *)skoopDate
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,skoopMonth,@"skoopDate",skoopDate,@"myDateSkoop",[AppHelper getGmtDifference],@"gmt", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@":::123%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Month_Skoop]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Month_Skoop]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Month_Skoop object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Month_Skoop object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Month_Skoop object:nil userInfo:dict];
    }
}

-(void)addSkoopIntoCalendarWithUserId:(NSString*)userId skoopId:(NSString*)skoopId skoopTime:(NSString*)skoopTime andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,skoopId,@"skoop_id",skoopTime,@"reminderTime",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Add_Skoop_Into_Calendar]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Add_Skoop_Into_Calendar]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Add_Skoop_Into_Calendar object:@{@"skoopTime":skoopTime} userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Add_Skoop_Into_Calendar object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Add_Skoop_Into_Calendar object:nil userInfo:dict];
    }
}

-(void)deleteSkoopRequestWithUserId:(NSString*)userId skoopId:(NSString*)skoopId andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,skoopId,@"skoop_id", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Delete_Skoop]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Delete_Skoop]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Delete_Skoop object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Delete_Skoop object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Delete_Skoop object:nil userInfo:dict];
    }
}

-(void)deleteSkoopWithUserId:(NSString*)userId skoopId:(NSString*)skoopId andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:appToken,@"token",userId,KUserId,skoopId,@"skoop_id", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Delete_Skoop_Req]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Delete_Skoop_Req]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Delete_Skoop object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Delete_Skoop object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Delete_Skoop object:nil userInfo:dict];
    }
}

-(void)deleteGroupRequestWithUserId:(NSString*)userId notificationId:(NSString*)notificationId notificationType:(NSString*)notificationType andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId, appToken,@"token",notificationId,@"notification_id",notificationType,@"notification_type", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Delete_Group_Req]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Delete_Group_Req]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Delete_Group_Req object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Delete_Group_Req object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Delete_Group_Req object:nil userInfo:dict];
    }
}

-(void)getSyncSkoopWithUserId:(NSString*)userId andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId, appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Delete_Skoop]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Sync_Skoop]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Sync_Skoop object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Sync_Skoop object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Sync_Skoop object:nil userInfo:dict];
    }
}

-(void)syncSkoopWithUserId:(NSString*)userId skoopIds:(NSString*)skoopIds andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,skoopIds,@"skoop_id", appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Sync_Skoop]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Sync_Skoop]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             //NSLog(@":::%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Sync_Skoop object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Sync_Skoop object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Sync_Skoop object:nil userInfo:dict];
    }
}

-(void)reportCommentWithUserId:(NSString*)userId commentId:(NSString*)commentId description:(NSString*)description andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,commentId,@"comment_id", appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Report_Comment]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Report_Comment]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Report_Comment object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Report_Comment object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Report_Comment object:nil userInfo:dict];
    }
}

-(void)updateUserProfileWithUserId:(NSString*)userId userName:(NSString*)userName email:(NSString*)email dob:(NSString*)dob currentCity:(NSString*)city userProfileImage:(NSData*)image pushNotification:(NSString*)push sound:(NSString*)sound andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,userName,@"name",email,@"email",city,@"city",push,@"notification",sound,@"sound",appToken,@"token",dob,@"dob", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Update_Profile]);
        
        AFHTTPClient *httpClient = [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:BaseURLString]];
        NSDictionary *params = [NSDictionary dictionaryWithDictionary:param];
        
        NSMutableURLRequest *request = [httpClient multipartFormRequestWithMethod:@"POST" path:Method_Update_Profile parameters:params constructingBodyWithBlock: ^(id <AFMultipartFormData>formData){
            if (image)
                [formData appendPartWithFileData:image name:@"profile_image" fileName:@"temp.jpeg" mimeType:@"image/jpeg"];
            
        }];
        [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
        
        AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
            
            NSError *error;
            NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Profile object:nil userInfo:dict];
        }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Profile object:nil userInfo:dict];
         }];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Profile object:nil userInfo:dict];
    }
}

-(void)changePasswordWithUserId:(NSString*)userId password:(NSString*)password oldPassword:(NSString*)oldPassword andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,password,@"password",oldPassword,@"oldpassword", appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Change_Password]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Change_Password]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Change_Password object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Change_Password object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Change_Password object:nil userInfo:dict];
    }
}

-(void)changeUsernameWithUserId:(NSString*)userId username:(NSString*)username oldUsername:(NSString*)oldUsername andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,username,@"userName",oldUsername,@"olduserName", appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Change_Username]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Change_Username]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Change_Username object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Change_Username object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Change_Username object:nil userInfo:dict];
    }
}

-(void)replyOnLivePortalRequestWithUserId:(NSString*)userId requestId:(NSString*)requestId andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,requestId,@"skoop_id", appToken,@"token",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Reply_LivePortal_Req]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Reply_LivePortal_Req]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Reply_LivePortal_Req object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Reply_LivePortal_Req object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Reply_LivePortal_Req object:nil userInfo:dict];
    }
}

-(void)livePortalCallFromUserId:(NSString*)userId skoopId:(NSString *)skoopId toOpponentId:(NSString*)opponentId andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,skoopId,@"skoop_id",opponentId, @"opponent_id", appToken,@"token",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_LivePortal_Call]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_LivePortal_Call]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_LivePortal_Call object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_LivePortal_Call object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_LivePortal_Call object:nil userInfo:dict];
    }
}

-(void)getLivePortalConfirmationWithUserId:(NSString*)userId requestId:(NSString*)requestId andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,requestId,@"skoop_id", appToken,@"token",[AppHelper userDefaultsForKey:KUserName],@"user_name",[AppHelper getGmtDifference],@"gmt", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_LivePortal_Confirmation]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_LivePortal_Confirmation]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_LivePortal_Confirmation object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_LivePortal_Confirmation object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_LivePortal_Confirmation object:nil userInfo:dict];
    }
}

-(void)saveCreditCardInfoWithUserId:(NSString*)userId firstName:(NSString*)firstName lastName:(NSString*)lastName cardNumber:(NSString*)cardNumber cardType:(NSString*)cardType expiryMonth:(NSString*)expiryMonth expiryYear:(NSString*)expiryYear cvvCode:(NSString*)cvvCode paypalEmal:(NSString*)paypalEmal isSaveCard:(NSString*)isSaveCard andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,firstName,@"first_name",lastName,@"last_name",cardNumber,@"card_number",cardType,@"card_type",expiryMonth,@"expire_month",expiryYear,@"expire_year",cvvCode,@"cvv2_code",paypalEmal,@"paypal_mail",isSaveCard,@"card_saved", appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Save_CreditCard_info]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Save_CreditCard_info]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Save_CCInfo object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Save_CCInfo object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Save_CCInfo object:nil userInfo:dict];
    }
}

-(void)getCreditCardInfoWithUserId:(NSString*)userId paymentInfo:(NSString*)paymentInfo andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,paymentInfo,@"payment_info", appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_CreditCard_info]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_CreditCard_info]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_CCInfo object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_CCInfo object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_CCInfo object:nil userInfo:dict];
    }
}

-(void)buySkoopWithUserId:(NSString*)userId amount:(NSString*)amount replyId:(NSString*)replyId sellerId:(NSString*)sellerId skoopId:(NSString*)skoopId andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,amount,@"amount",replyId,@"reply_id",sellerId,@"seller_id", appToken,@"token",[AppHelper userDefaultsForKey:KUserName],@"buyer_name",skoopId,@"skoop_id", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Purchase_Skoop]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Purchase_Skoop]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             NSLog(@"===%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Purchase_Skoop object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Purchase_Skoop object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Purchase_Skoop object:nil userInfo:dict];
    }
}

-(void)rechargeAccountWithUserId:(NSString*)userId amount:(NSString*)amount andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,amount,@"amount", appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Recharge_Acount]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Recharge_Acount]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Recharge_Account object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Recharge_Account object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Recharge_Account object:nil userInfo:dict];
    }
}

-(void)rechargeAccountWithPaypalEmail:(NSString*)email userId:(NSString*)userId amount:(NSString*)amount andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,email,@"email",amount,@"amount", appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Recharge_Acount_paypal]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Recharge_Acount_paypal]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Recharge_Account_Paypal object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Recharge_Account_Paypal object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Recharge_Account_Paypal object:nil userInfo:dict];
    }
}

-(void)redeemYourPointWithUserId:(NSString*)userId redeemAmount:(NSString*)redeemAmount andAppToken:(NSString*)appToken{
    if([[AppDelegate getAppDelegate] checkInternateConnection]){
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,redeemAmount,@"redeem_amount", appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Redeem_Point]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Redeem_Point]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Redeem_Point object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Redeem_Point object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Redeem_Point object:nil userInfo:dict];
    }
}

-(void)livePortalPaymentWithUserId:(NSString*)userId sellerId:(NSString*)sellerId portalId:(NSString*)portalId amount:(NSString *)amount andAppToken:(NSString*)appToken{
    
    if([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,sellerId,@"seller_id",portalId,@"portal_id",amount,@"amount", appToken,@"token", nil];
        NSLog(@"====%@",[param JSONRepresentation]);
        NSLog(@"=====%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Loveportal_payment]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Loveportal_payment]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
             NSError *error;
            NSLog(@"%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Live_Portal_Payment object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error){
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Live_Portal_Payment object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Live_Portal_Payment object:nil userInfo:dict];
    }
}

-(void)reportVideoWithUserId:(NSString*)userId replyId:(NSString*)replyId andAppToken:(NSString*)appToken
{
    if([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId,replyId,@"reply_id", appToken,@"token", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Report_Video]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Report_Video]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Report_Video object:nil userInfo:dict];
         }
                                         failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Report_Video object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Report_Video object:nil userInfo:dict];
    }
}

-(void)getBlockedSkoopWithUserId:(NSString*)userId andAppToken:(NSString*)appToken{
    
    if([[AppDelegate getAppDelegate] checkInternateConnection]){
        
        NSDictionary *param=[[NSDictionary alloc] initWithObjectsAndKeys:userId,KUserId, appToken,@"token",[AppHelper getGmtDateWithGivenDate:[NSDate date]],@"gmt_date",[AppHelper getGmtDifference],@"gmt", nil];
        NSLog(@"%@",[param JSONRepresentation]);
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Blocked_Skoop]);
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_Blocked_Skoop]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Blocked_Skoop object:nil userInfo:dict];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error....%@",[error description]);
             NSMutableDictionary *dict = nil;
             dict = [[NSMutableDictionary alloc] init];
             [dict setObject:@"1" forKey:@"errorCode"];
             [dict setObject:ERROR_SERVICE_HIT forKey:@"errorMessage"];
             [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Blocked_Skoop object:nil userInfo:dict];
         }
         ];
        [operation start];
    }
    else
    {
        NSMutableDictionary *dict = nil;
        dict = [[NSMutableDictionary alloc] init];
        [dict setObject:@"1" forKey:@"errorCode"];
        [dict setObject:ERROR_INTERNET forKey:@"errorMessage"];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Get_Blocked_Skoop object:nil userInfo:dict];
    }
}

@end
