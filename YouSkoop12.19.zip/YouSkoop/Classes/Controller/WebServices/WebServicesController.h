//
//  WebServicesController.h
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SkoopReplyData.h"

@interface WebServicesController : NSObject<UIAlertViewDelegate>
{
    NSManagedObjectContext *_managedObjectContext;
}

+(WebServicesController *)WebServiceMethod;

-(void)deleteFileFromDocumentDirectoryWithFileName:(NSString*)fileName;
-(void)deleteAllVideoFileFromDocumentDirectory;

#pragma mark Coredata methods
-(void)parseSkoopReplyDataWithDataDictionary:(NSDictionary*)skoopReplyDict;
-(SkoopReplyData *)getStoredSkoopWithSkoopId:(NSString *)skoopId;
-(NSArray*)getAllSkoopReplyData;
-(void)deleteSkoopWithSkoopId:(NSString *)skoopId;
- (void) deleteAllObjectsWithEntityName: (NSString *) entityName;

-(void) signIn:(NSDictionary *)dictionary;
-(void) signOutWithUserId:(NSString*)userId deviceId:(NSString *)deviceId andToken:(NSString*)appToken;
-(void) signUpServices:(NSMutableDictionary *)dictSignUpCredentials;
-(void) forgotpasswordServices:(NSMutableDictionary *)dictForgotCredentials;
-(void) changePassword:(NSMutableDictionary *)dictChangeCredentials;
-(void) sendSkoopWithUserId:(NSString *)userId groupId:(NSString*)groupId skoopDate:(NSString*)skoopDate offer:(NSString*)offer searchText:(NSString*)searchText token:(NSString*)token livePortal:(NSString*)livePortal location:(NSString *)location latitude:(NSString *)latitude longitude:(NSString *)longitude andSkoopType:(NSString *)skoopType;
-(void) countUsers:(NSMutableDictionary *)dictoflocation;
-(void) sendGroupSkoopWithUserId:(NSString *)userId groupId:(NSString*)groupId skoopDate:(NSString*)skoopDate offer:(NSString*)offer searchText:(NSString*)searchText token:(NSString*)token livePortal:(NSString*)livePortal andSkoopType:(NSString *)skoopType;

-(void) getSkoopReplyVideoWithSkoopId:(NSString *)skoopId buy:(NSString*)buy andAppToken:(NSString*)appToken andGroupId:(NSString *)groupId;
-(void) myRequests:(NSMutableDictionary *)dictOfRequests;

-(void)updateUserLocationWithUserId:(NSString*)userId latitude:(NSString*)latitude longitude:(NSString*)longitude andToken:(NSString*)uniqueToken;
-(void)replyOnSkoopWithUserId:(NSString*)userId skoopId:(NSString*)skoopId replyVideo:(NSData*)videoData andToken:(NSString*)uniqueToken;

-(void)getAllGroupsDetailWithUserId:(NSString *)geoupId appToken:(NSString *)appToken categoryId:(NSString *)categoryId andPageLimit:(NSString *)pageLimit;
-(void)getCategoryGroupsWithUserId:(NSString*)userId categoryId:(NSString*)categoryId appToken:(NSString*)token pageNumber:(NSString*)pageNumber andPageLimit:(NSString*)pageLimit;
-(void)getFeaturedGroupsWithUserId:(NSString*)userId appToken:(NSString*)appToken pageNumber:(NSString*)pageNumber andPageLimit:(NSString*)pageLimit;
-(void)getPopularGroupsWithUserId:(NSString*)userId appToken:(NSString*)appToken pageNumber:(NSString*)pageNumber andPageLimit:(NSString*)pageLimit;
-(void)getCelebrityGroupsWithUserId:(NSString*)userId appToken:(NSString*)appToken pageNumber:(NSString*)pageNumber andPageLimit:(NSString*)pageLimit;
-(void)getCategoryNamesForCreateGroup;
-(void)getMyGroupDataWithUserId:(NSString*)userId  SearchString: (NSString *)searchString pageNumber:(NSString*)pageNumber limit:(NSString*)limit exGroupId:(NSString*)exGroupId inviteUserId:(NSString *)inviteUserId andIsGetNameList:(BOOL)isGetNameList;
-(void)getIndividualGroupMembersDataUserId:(NSString*)userId searchText:(NSString*)searchText pageNumber:(NSString*)pageNumber pageLimit:(NSString*)pageLimit andGroupId:(NSString*)groupId;

-(void)sendInviteToGroupWithGroupIds:(NSMutableArray*) group inviteUserId:(NSString *)inviteUserId andGroupId:(NSString*)groupId;
-(void)sendInviteToMembersWithMemberIds:(NSMutableArray*) membersList andGroupId:(NSString*)groupId;
-(void)unJoinGroupWithUserId:(NSString*)userId andGroupId:(NSString*)groupId;
-(void)joinGroupWithUserId:(NSString*)userId andGroupId:(NSString*)groupId;
-(void)getGroupSkoopDataWithGroupId:(NSString*)groupId requestType:(NSString*)requestType pageNumber:(NSString*)pageNumber andLimit:(NSString*)limit;
-(void)getAllNotificationsWithUserId:(NSString*)userId pageNumber:(NSString*)pageNumber andLimit:(NSString*)limit;
-(void)blockUnblockUserWithUserId:(NSString*)userId blockUserId:(NSString*)blockUserId groupId:(NSString*)groupId requestType:(NSString*)requestType andReason:(NSString*)reason;
-(void)blockUserFromGroupWithUserId:(NSString*)userId blockUserId:(NSString*)blockUserId groupId:(NSString*)groupId andReason:(NSString*)reason;
-(void)getBlockedUserWithUserId:(NSString*)userId group:(NSString*)group searchText:(NSString*)searchText pageNumber:(NSString*)pageNo pageLimit:(NSString*)pageLimit andAppToken:(NSString*)appToken;

-(void)getNotificationCountWithUserId:(NSString*)userId isGetSyncData:(NSString*)isGetSync andToken:(NSString*)token;
-(void)readNotificationWithUserId:(NSString*)userId notificationId:(NSString*)notificationId notificationType:(NSString*)notificationType andToken:(NSString*)token;
-(void)getSkoopRequestWithUserId:(NSString *)userId skoopId:(NSString*)skoopId pageNo:(NSString*)pageNo pageLImit:(NSString*)pageLimit appToken:(NSString*)appToken andRequestType:(NSString*)requestType;
-(void)getUserProfileUserId:(NSString*)userId viewerId:(NSString*)viewerId appToken:(NSString*)appToken andPageLimit:(NSString*)pageLimit;
-(void)likeOrDislikeUserProfileWithUserId:(NSString*)userId resoruceId:(NSString*)resoruceId appToken:(NSString*)appToken like:(NSString*)like;
-(void)writeCommentWithUserId:(NSString*)userId resoruceId:(NSString*)resoruceId appToken:(NSString*)appToken andCommentText:(NSString*)commentText;
-(void)getCommentWithUserId:(NSString*)userId andAppToken:(NSString*)appToken;
-(void)getUserSkoopsWithUserId:(NSString*)userId viewerId:(NSString*)viewerId requestType:(NSString*)requestType searchText:(NSString*)searchText pageNo:(NSString*)pageNo pageLimit:(NSString*)pageLimit  buy:(NSString*)buy andAppToken:(NSString*)appToken;
-(void)getUserSkoopsWithUserId:(NSString*)userId pageNumber:(NSString*)pageNumber pagelimit:(NSString*)pageLimit skoopDate:(NSString*)skoopDate andAppToken:(NSString*)appToken;
-(void)getMonthSkoopsWithUserId:(NSString*)userId skoopMonth:(NSString*)skoopMonth andAppToken:(NSString*)appToken andSkoopdate:(NSString *)skoopDate;
-(void)addSkoopIntoCalendarWithUserId:(NSString*)userId skoopId:(NSString*)skoopId skoopTime:(NSString*)skoopTime andAppToken:(NSString*)appToken;
-(void)deleteSkoopRequestWithUserId:(NSString*)userId skoopId:(NSString*)skoopId andAppToken:(NSString*)appToken;
-(void)deleteSkoopWithUserId:(NSString*)userId skoopId:(NSString*)skoopId andAppToken:(NSString*)appToken;
-(void)deleteGroupRequestWithUserId:(NSString*)userId notificationId:(NSString*)notificationId notificationType:(NSString*)notificationType andAppToken:(NSString*)appToken;
-(void)getSyncSkoopWithUserId:(NSString*)userId andAppToken:(NSString*)appToken;
-(void)syncSkoopWithUserId:(NSString*)userId skoopIds:(NSString*)skoopIds andAppToken:(NSString*)appToken;
-(void)reportCommentWithUserId:(NSString*)userId commentId:(NSString*)commentId description:(NSString*)description andAppToken:(NSString*)appToken;
-(void)updateUserProfileWithUserId:(NSString*)userId userName:(NSString*)userName email:(NSString*)email dob:(NSString*)dob currentCity:(NSString*)city userProfileImage:(NSData*)image pushNotification:(NSString*)push sound:(NSString*)sound andAppToken:(NSString*)appToken;
-(void)changePasswordWithUserId:(NSString*)userId password:(NSString*)password oldPassword:(NSString*)oldPassword andAppToken:(NSString*)appToken;
-(void)changeUsernameWithUserId:(NSString*)userId username:(NSString*)username oldUsername:(NSString*)oldUsername andAppToken:(NSString*)appToken;
-(void)replyOnLivePortalRequestWithUserId:(NSString*)userId requestId:(NSString*)requestId andAppToken:(NSString*)appToken;
-(void)livePortalCallFromUserId:(NSString*)userId skoopId:(NSString *)skoopId toOpponentId:(NSString*)opponentId andAppToken:(NSString*)appToken;
-(void)getLivePortalConfirmationWithUserId:(NSString*)userId requestId:(NSString*)requestId andAppToken:(NSString*)appToken;
-(void)saveCreditCardInfoWithUserId:(NSString*)userId firstName:(NSString*)firstName lastName:(NSString*)lastName cardNumber:(NSString*)cardNumber cardType:(NSString*)cardType expiryMonth:(NSString*)expiryMonth expiryYear:(NSString*)expiryYear cvvCode:(NSString*)cvvCode paypalEmal:(NSString*)paypalEmal isSaveCard:(NSString*)isSaveCard andAppToken:(NSString*)appToken;
-(void)getCreditCardInfoWithUserId:(NSString*)userId paymentInfo:(NSString*)paymentInfo andAppToken:(NSString*)appToken;
-(void)buySkoopWithUserId:(NSString*)userId amount:(NSString*)amount replyId:(NSString*)replyId sellerId:(NSString*)sellerId skoopId:(NSString*)skoopId andAppToken:(NSString*)appToken;
-(void)rechargeAccountWithUserId:(NSString*)userId amount:(NSString*)amount andAppToken:(NSString*)appToken;
-(void)rechargeAccountWithPaypalEmail:(NSString*)email userId:(NSString*)userId amount:(NSString*)amount andAppToken:(NSString*)appToken;
-(void)redeemYourPointWithUserId:(NSString*)userId redeemAmount:(NSString*)redeemAmount andAppToken:(NSString*)appToken;
-(void)livePortalPaymentWithUserId:(NSString*)userId sellerId:(NSString*)sellerId portalId:(NSString*)portalId amount:(NSString *)amount andAppToken:(NSString*)appToken;
-(void)reportVideoWithUserId:(NSString*)userId replyId:(NSString*)replyId andAppToken:(NSString*)appToken;
-(void)getBlockedSkoopWithUserId:(NSString*)userId andAppToken:(NSString*)appToken;

-(void)replyOnSkoopWithUserId:(NSString*)userId skoopId:(NSString*)skoopId groupId:(NSString *)groupId replyVideo:(NSData*)videoData andToken:(NSString*)uniqueToken;

@end
