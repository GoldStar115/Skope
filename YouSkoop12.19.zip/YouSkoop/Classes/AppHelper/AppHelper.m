//
//  AppHelper.m
//  IntroduceThem
//
//  Created by Aravind Kumar on 13/06/11.
//  Copyright 2011 Tata Consultant Services. All rights reserved.
//

#import "AppHelper.h"
#import "Defines.h"

@implementation AppHelper

+ (UIImage*)appLogoImage
{
    return [UIImage imageNamed:@"appLogo.png"];
}

+(void)stausBarColorChange
{
    if(IS_Greater_Or_Equal_to_IOS_7)
        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
}

//normalize image
+(UIImage *)normalizedImage:(UIImage *)image
{
    if (image.imageOrientation == UIImageOrientationUp) return image;
    
    UIGraphicsBeginImageContextWithOptions(image.size, NO, image.scale);
    [image drawInRect:(CGRect){0, 0, image.size}];
    UIImage *normalizedImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return normalizedImage;
}

+(void)saveToUserDefaults:(id)value withKey:(NSString*)key
{
	NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    
	if (standardUserDefaults) {
		[standardUserDefaults setObject:value forKey:key];
		[standardUserDefaults synchronize];
	}
}

+(NSString*)userDefaultsForKey:(NSString*)key
{
	NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
	NSString *val = nil;
	
	if (standardUserDefaults)
		val = [standardUserDefaults objectForKey:key];
	
	return val;
}

+(NSMutableDictionary*)userDefaultsDictionaryDataForKey:(NSString*)key
{
	NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
	NSMutableDictionary *val = nil;
	if (standardUserDefaults)
		val = (NSMutableDictionary*)[standardUserDefaults objectForKey:key];
	
	return val;
}

+(void)removeFromUserDefaultsWithKey:(NSString*)key
{
    NSUserDefaults *standardUserDefaults = [NSUserDefaults standardUserDefaults];
    [standardUserDefaults removeObjectForKey:key];
    [standardUserDefaults synchronize];
}
+ (NSString *)getCurrentLanguage {
	NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
	NSArray *languages = [defaults objectForKey:@"AppleLanguages"];
    
    
	return [languages objectAtIndex:0];
}
////----- show a alert massage
+ (void) showAlertViewWithTag:(NSInteger)tag title:(NSString*)title message:(NSString*)msg delegate:(id)delegate
            cancelButtonTitle:(NSString*)CbtnTitle otherButtonTitles:(NSString*)otherBtnTitles
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:msg delegate:delegate
                                          cancelButtonTitle:CbtnTitle otherButtonTitles:otherBtnTitles, nil];
    alert.tag = tag;
    [alert show];
}


+(UIColor *)colorFromHexString:(NSString *)hexString {
    //    NSLog(@"%@",hexString);
    unsigned rgbValue = 0;
    NSScanner *scanner = [NSScanner scannerWithString:hexString];
    [scanner setScanLocation:1]; // bypass '#' character
    [scanner scanHexInt:&rgbValue];
    return [UIColor colorWithRed:((rgbValue & 0xFF0000) >> 16)/255.0 green:((rgbValue & 0xFF00) >> 8)/255.0 blue:(rgbValue & 0xFF)/255.0 alpha:1.0];
}


+(NSString *) hexFromUIColor:(UIColor *)color
{
    if (CGColorGetNumberOfComponents(color.CGColor) < 4) {
        const CGFloat *components = CGColorGetComponents(color.CGColor);
        color = [UIColor colorWithRed:components[0] green:components[0] blue:components[0] alpha:components[1]];
    }
    if (CGColorSpaceGetModel(CGColorGetColorSpace(color.CGColor)) != kCGColorSpaceModelRGB) {
        return [NSString stringWithFormat:@"#FFFFFF"];
    }
    return [NSString stringWithFormat:@"#%02X%02X%02X", (int)((CGColorGetComponents(color.CGColor))[0]*255.0), (int)((CGColorGetComponents(color.CGColor))[1]*255.0), (int)((CGColorGetComponents(color.CGColor))[2]*255.0)];
}

#pragma mark Email Validation
+(BOOL)emailValidate:(NSString *)checkString
{
    BOOL stricterFilter = YES; // Discussion http://blog.logichigh.com/2010/09/02/validating-an-e-mail-address/
    NSString *stricterFilterString = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSString *laxString = @".+@.+\\.[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

+(void)getRoundedImageWithImageView:(UIImageView*)imgView
{
    imgView.layer.cornerRadius = imgView.frame.size.height/2.0;
    imgView.clipsToBounds = YES;
    imgView.layer.masksToBounds=YES;
}

+(void)getRoundedRectViewWithView:(UIView*)imgaView withColor:(UIColor*) color andRadius: (CGFloat) radius andWidth: (CGFloat) width
{
    imgaView.layer.cornerRadius = radius;
    imgaView.layer.borderWidth = width;
    imgaView.clipsToBounds = YES;
    imgaView.layer.masksToBounds=YES;
    imgaView.layer.borderColor = color.CGColor;
}

+(void)getRoundedRectImageWithImageView:(UIImageView*)imgaView withColor:(UIColor*) color andRadius: (CGFloat) radius andWidth: (CGFloat) width
{
    imgaView.layer.cornerRadius = radius;
    imgaView.layer.borderWidth = width;
    imgaView.clipsToBounds = YES;
    imgaView.layer.masksToBounds=YES;
    imgaView.layer.borderColor = color.CGColor;
}

+ (CGFloat)getStringBoundingSize:(NSString*)string forWidth:(CGFloat)width withFont:(UIFont*)font
{
    string=[string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    CGFloat result = font.pointSize+4;
    if (string) {
        CGSize textSize = { width, CGFLOAT_MAX };       //Width and height of text area
        CGSize size;
        if (IS_Greater_Or_Equal_to_IOS_7) {
            //iOS 7
            CGRect frame = [string boundingRectWithSize:CGSizeMake(width, CGFLOAT_MAX)
                                              options:NSStringDrawingUsesLineFragmentOrigin
                                           attributes:@{NSFontAttributeName:font}
                                              context:nil];
            size = CGSizeMake(frame.size.width, frame.size.height+1);
        }
        else
        {
            //iOS 6.0
            size = [string sizeWithFont:font constrainedToSize:textSize lineBreakMode:NSLineBreakByWordWrapping];
        }
        result = MAX(size.height, result); //At least one row
    }
    return result;
}

+(NSString *)stringByDecodingURLFormat:(NSString*)str
{
    NSString *result = [str stringByReplacingOccurrencesOfString:@"+" withString:@" "];
    result = [result stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    return result;
}

#pragma mark - Regex for CreditCard
//Finding or Verification Credit Card Numbers

#define kVISA_TYPE          @"^4[0-9]{3}?"
#define kMASTER_CARD_TYPE   @"^5[1-5][0-9]{2}$"
#define kAMEX_TYPE          @"^3[47][0-9]{2}$"
#define kDINERS_CLUB_TYPE	@"^3(?:0[0-5]|[68][0-9])[0-9]$"
#define kDISCOVER_TYPE		@"^6(?:011|5[0-9]{2})$"

+ (CreditCardBrand)checkCardBrandWithNumber:(NSString *)cardNumber
{
    if([cardNumber length] < 4) return CreditCardBrandUnknown;
    
    CreditCardBrand cardType;
    NSRegularExpression *regex;
    NSError *error;
    
    for(NSUInteger i = 0; i < CreditCardBrandUnknown; ++i) {
        
        cardType = i;
		
        switch(i) {
            case CreditCardBrandVisa:
                regex = [NSRegularExpression regularExpressionWithPattern:kVISA_TYPE options:0 error:&error];
                break;
            case CreditCardBrandMasterCard:
                regex = [NSRegularExpression regularExpressionWithPattern:kMASTER_CARD_TYPE options:0 error:&error];
                break;
            case CreditCardBrandAmex:
                regex = [NSRegularExpression regularExpressionWithPattern:kAMEX_TYPE options:0 error:&error];
                break;
            case CreditCardBrandDinersClub:
                regex = [NSRegularExpression regularExpressionWithPattern:kDINERS_CLUB_TYPE options:0 error:&error];
                break;
            case CreditCardBrandDiscover:
                regex = [NSRegularExpression regularExpressionWithPattern:kDISCOVER_TYPE options:0 error:&error];
                break;
		}
        
		NSUInteger matches = [regex numberOfMatchesInString:cardNumber options:0 range:NSMakeRange(0, 4)];
        if(matches == 1) return cardType;
        
	}
    
    return CreditCardBrandUnknown;
}

+ (BOOL)checkCreditCardNumber:(NSString *)cardNumber
{
    NSInteger len = [cardNumber length];
    NSInteger oddDigits = 0;
    NSInteger evenDigits = 0;
    BOOL isOdd = YES;
    
    for (NSInteger i = len - 1; i >= 0; i--) {
        
        NSInteger number = [cardNumber substringWithRange:NSMakeRange(i, 1)].integerValue;
        if (isOdd) {
            oddDigits += number;
        }else{
            number = number * 2;
            if (number > 9) {
                number = number - 9;
            }
            evenDigits += number;
        }
        isOdd = !isOdd;
    }
    
    return ((oddDigits + evenDigits) % 10 == 0);
}

+(NSString *)getGmtDifference{
    
    NSTimeZone* local = [NSTimeZone systemTimeZone];
    long timeInSec = (long)[local secondsFromGMT];
    NSLog(@"GMT time diff: %ld",timeInSec);
    return [NSString stringWithFormat:@"%ld",timeInSec/60];
}

+(NSString *)getGmtDateWithGivenDate:(NSDate *)localDate{
    
    NSDateFormatter *dateFormatter = [NSDateFormatter new];
    dateFormatter.dateFormat = @"yyyy-MM-dd HH:mm:ss";
    NSTimeZone *gmtZone = [NSTimeZone timeZoneWithAbbreviation:@"GMT"];
    [dateFormatter setTimeZone:gmtZone];
    
    NSString *timeStamp = [dateFormatter stringFromDate:localDate];
    return timeStamp;
}
@end
