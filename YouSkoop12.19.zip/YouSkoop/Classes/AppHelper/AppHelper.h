//
//  AppHelper.h
//  IntroduceThem
//
//  Created by Aravind Kumar on 13/06/11.
//  Copyright 2011 Tata Consultant Services. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef NS_ENUM(NSInteger, CreditCardBrand) {
    CreditCardBrandVisa,
    CreditCardBrandMasterCard,
    CreditCardBrandDinersClub,
    CreditCardBrandAmex,
    CreditCardBrandDiscover,
    CreditCardBrandUnknown
};

@interface AppHelper : NSObject

+ (UIImage*)appLogoImage;
+(void)saveToUserDefaults:(id)value withKey:(NSString*)key;
+(NSString*)userDefaultsForKey:(NSString*)key;
+(NSMutableDictionary*)userDefaultsDictionaryDataForKey:(NSString*)key;
+(void)removeFromUserDefaultsWithKey:(NSString*)key;
+ (void) showAlertViewWithTag:(NSInteger)tag title:(NSString*)title message:(NSString*)msg delegate:(id)delegate
            cancelButtonTitle:(NSString*)CbtnTitle otherButtonTitles:(NSString*)otherBtnTitles;
+ (NSString *)getCurrentLanguage;
+(UIImage *)normalizedImage:(UIImage *)image;

//make color code
+(UIColor *)colorFromHexString:(NSString *)hexString ;
+(NSString *)hexFromUIColor:(UIColor *)color;

+(BOOL)emailValidate:(NSString *)checkString;
+(void)getRoundedImageWithImageView:(UIImageView*)imgView;

+(void)getRoundedRectImageWithImageView:(UIImageView*)imgaView withColor:(UIColor*) color andRadius: (CGFloat) radius andWidth: (CGFloat) width;
+(void)getRoundedRectViewWithView:(UIView*)imgaView withColor:(UIColor*) color andRadius: (CGFloat) radius andWidth: (CGFloat) width;
+(void)stausBarColorChange;
+ (CGFloat)getStringBoundingSize:(NSString*)string forWidth:(CGFloat)width withFont:(UIFont*)font;
+(NSString *)stringByDecodingURLFormat:(NSString*)str;

+ (CreditCardBrand)checkCardBrandWithNumber:(NSString *)cardNumber;
+ (BOOL)checkCreditCardNumber:(NSString *)cardNum;

+(NSString *)getGmtDifference;
+(NSString *)getGmtDateWithGivenDate:(NSDate *)localDate;

@end
