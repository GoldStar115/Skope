
#import "AppDelegate.h"
#import "AFNetworking.h"
#import "JSONDictionaryExtensions.h"
#import "SBJSON.h"

#define BaseURLString                                   @"http://youskoop.com/"

#define kTabBarHeight                                   63.0
#define Timeout_Interval                                30.0
#define Search_Time_Interval                            0.5
#define Default_device_token                            @"123"

#define Method_auth_post                                @"auth/post"
#define Method_signup_post                              @"signup/post"
#define Method_logout                                   @"auth/logout"
#define Method_forgot_post                              @"forgot/post"
#define Method_forgot_update                            @"forgot/update"
#define Method_skoop_post                               @"skoop/post"
#define Method_user_get_user                            @"user/get-user"
#define Method_skoop_get_reply                          @"skoop/get-reply"
#define Method_skoop_invite_skoop                       @"skoop/invite-skoop"
#define Method_skoop_my_skoop                           @"skoop/my-skoop"
#define Method_skoop_Group_skoop                        @"skoop/group-skoop"

#define Method_update_location                          @"user/post"
#define Method_Reply_on_skoop                           @"skoop/reply"
#define Method_Create_Group                             @"group/create"

#define Method_Get_CategoryNames                        @"category/post"
#define Method_Get_AllGroupsData                        @"group/home-group"
#define Method_Get_FeaturedGroupd                       @"group/get-featured-group"

#define Method_Get_PopularGroups                        @"group/popular-group"
#define Method_Get_SearchByCategory                     @"group/category-group"
#define Method_Get_Celebrity                            @"group/celeberity-group"

#define Method_Get_MyGroupList                          @"group/post"
#define Method_SendInvitaionTo_Group                    @"group/invite-group"
#define Method_Get_FbFriends                            @"facebook/get-friends"
#define Method_Get_TwitterFriends                       @"twitter/get-friends"
#define Method_Invite_TwitterFriends                    @"twitter/invite-group"
#define Method_Invite_FbFriends                         @"facebook/invite-group"

#define Method_Get_IndividalGroupMembers                @"group/group-member"
#define Method_Invite_Members                           @"group/invite-user"
#define Method_UnJoin_Group                             @"group/reject-request"
#define Method_Join_Group                               @"group/accept-request"
#define Method_Get_Group_Skoop                          @"group/group-skoop"


#define Method_Get_All_Notification                     @"notification/get"
#define Method_Edit_Group                               @"group/update"
#define Method_Block_Unblock_User                       @"user/block-unblock"
#define Method_Block_User_From_Group                    @"group/block"
#define Method_Get_Block_User                           @"user/block-users"
#define Method_Group_By_Category                        @"group/category-group"
#define Method_Get_Notification_Count                   @"notification/count"
#define Method_Read_Notification                        @"notification/post"
#define Method_Get_User_Profile                         @"user/profile"
#define Method_Like_User_Profile                        @"user/like-dislike"
#define Method_Write_Comment                            @"comment/post"
#define Method_get_Comment                              @"comment/get"

#define Method_Get_User_Skoop                           @"skoop/get-skoop"
#define Method_Get_Calendar_Skoop                       @"skoop/calendar-skoop"
#define Method_Get_Month_Skoop                          @"skoop/month-skoop"
#define Method_Add_Skoop_Into_Calendar                  @"skoop/add-calendar"
#define Method_Delete_Skoop                             @"skoop/delete"
#define Method_Delete_Skoop_Req                         @"skoop/delete-skoop"
#define Method_Get_Sync_Skoop                           @"skoop/get-sync-skoop"
#define Method_Sync_Skoop                               @"skoop/sync-skoop"
#define Method_Reply_LivePortal_Req                     @"skoop/liveportal-request"
#define Method_LivePortal_Call                          @"skoop/liveportal-call"
#define Method_Get_LivePortal_Confirmation              @"skoop/get-portal-reply"
#define Method_Purchase_Skoop                           @"skoop/purchase"
#define Method_Recharge_Acount                          @"payment/rechargecredit-card"
#define Method_Recharge_Acount_paypal                   @"payment/recharge-paypal"
#define Method_Redeem_Point                             @"user/redeem-request"
#define Method_Loveportal_payment                       @"skoop/live-portal-payment"
#define Method_Report_Video                             @"skoop/report-video"
#define Method_Get_Blocked_Skoop                        @"skoop/get-block-skoop"

#define Method_Delete_Group_Req                         @"notification/delete"
#define Method_Report_Comment                           @"comment/report"
#define Method_Update_Profile                           @"user/update"
#define Method_Change_Password                          @"user/change-password"
#define Method_Change_Username                          @"user/change-username"

#define Method_Get_Quickblox_info                       @"user/quickblox-user"
#define Method_Get_CreditCard_info                      @"payment/get-payment-info"
#define Method_Save_CreditCard_info                     @"payment/save-card"

#define Device_Token                                    @"device_token"
#define Device_Type                                     @"iPhone"
#define Device_Id                                       @"device_id"

//Twitter Keys
#define TwitterConsumerKey                              @"kgy1icb6B7w4tne1VadZQ"
#define TwitterSecretKey                                @"SldLKOCj03r7lcPBR4T7xkvQZOFvA9JkNdEdFzv78as"

#define KTwitter_id                                     @"twitter_id"
#define KTwitter_token                                  @"TW_AccessToken"
#define KTwitter_secret_token                           @"TW_TokenSecret"

#define Google_API_Key                                  @"AIzaSyC0Gb9LKBRGGQ67GEcumpaZ6tbmYAwVkds"


/*******************************************************************************************************************/
#pragma mark HTTP Request header values

//Facebook Constants
#define KFbAccessToken                                 @"KFbAccessToken"
#define KExpiryDate                                    @"expiry_date"

#define KAppToken                                      @"aw@#$lkj"
#define KUserId                                        @"user_id"
#define KUserImageUrl                      @"KUserImageUrl"
#define KUserName                           @"KUserName"
#define KUserEmail                           @"KUserEmail"
#define KUserProfData                      @"KUserProfData"
#define isSyncData                             @"isSyncData"
#define KQuickBloxCredential            @"KQuickBloxCredential"
#define KQuickBloxId                        @"KQuickBloxId"

#define KPageLimit                             @"10"

#define isGetMonthSkoop                   @"monthskoop"
#define isGetextMonthSkoop              @"isGetextMonthSkoop"

#define KFacebook_id                        @"facebook_id"

#define KFbSwitchStatus                    @"fb_status"
#define KTwSwitchStatus                    @"tw_status"

#define isUpdateGroupProfile              @"isUpdateGroupProfile"
#define isSendGroupSkoop              @"isSendGroupSkoop"

/*******************************************************************************************************************/
#pragma mark - Strings

#define NSSTRING_HAS_DATA(_x) (((_x) != nil) && ( [(_x) length] > 0 ))

//NetManager
#define ERROR_INTERNET                     @"Connection Error. Please check your internet connection and try again."
#define ERROR_TIMEOUT                      @"Timeout error. Please check your internet connection and try again."
#define ERROR_SERVICE_HIT                  @"Oops!Something went wrong please try again."

/*******************************************************************************************************************/

#define kIsLogIn                                    @"kIsLogIn"
#define kSaveCountry                            @"kSaveCountry"
#define kIsSearchFromMap                    @"kIsSearchFromMap"
#define kIsSearchCity                           @"kIsSearchCity"
#define KSaveReqData                            @"KSaveReqData"
#define KSavedCCInfo                            @"KSavedCCInfo"
#define KAvailableCredit                        @"KAvailableCredit"
#define KRedeemAmount                        @"KRedeemAmount"

#define KNotificationCount                      @"KNotificationCount"
#define KSkoopRequestCount                 @"KSkoopRequestCount"
#define KSkoopReplyCount                  @"KSkoopReplyCount"

#define KPriceData                                  @"KPriceData"


/*******************************************************************************************************************/
#pragma mark Push notifications

#define Notification_Refresh_Skoop_Reply_list                    @"Notification_Refresh_Skoop_Reply_list"
#define Notification_Update_Inbox_Count                          @"Notification_Update_Inbox_Count"
#define Notification_Update_Ans_Skoop_Req_Count                  @"Notification_Update_Ans_Skoop_Req_Count"
#define Notification_Create_Quickblox_Session                    @"Notification_Create_Quickblox_Session"
#define Notification_Update_Payment_Status                       @"Notification_Update_Payment_Status"


#pragma mark Push type

#define KPush_For_Get_Skoop_Request                                @"skoop_request"
#define KPush_For_Get_Group_Skoop_Request                    @"group_skoop_request"
#define KPush_For_Get_Skoop_Reply                                    @"skoop_reply"
#define KPush_For_Group_Req                                               @"group_request"
#define KPush_Confirm_Live_Portal                                        @"live_portal_accept"
#define KPush_Block_from_group                                            @"block_group"
#define KPush_Unblock_from_group                                        @"unblock_group"
#define KPush_Block_from_app                                               @"block_app"
#define KPush_Unblock_from_app                                           @"unblock_app"
#define KPush_Verify_celeb_grp                                              @"verify_group"
#define KPush_Join_grp                                                           @"join_group"
#define KPush_User_Comment                                                @"user_comment"
#define KPush_Buy_Skoop                                                       @"buy_skoop"

#define KInboxCount                                                         @"KInboxCount"
#define KSkoopRequest                                                    @"KSkoopRequest"
#define KIsSendToInbox                                                   @"KIsSendToInbox"
#define KIsSendToSkoopReply                                        @"KIsSendToSkoopReply"
#define KPreSelectedTab                                             @"KPreSelectedTab"

//*************************************************************************************************//


#define maxLengthOfTextV            280
#define maxlengthTextFeild            25
#define maxLengthOfaboutMe        150
#define createBubbleMinSlider        15
#define createBubbleMaxSlider       120
#define defaultSlider                         40


#define BaseUrl                       @"http://youskoop.indiatomorrow.in/"

#define AppName                       @"youSKOOP"
#define Error                         @"Error!!!"

#define Alert_Ok                      @"OK"
#define Alert_Cancel                  @"Cancel"
#define Alert_View                    @"View"
#define Alert_Yes                     @"Yes"
#define Alert_No                      @"No"

#define MsgInValidEmail               @"Please enter valid email id."
#define Address_does_not_exist        @"Address does not exist."

//Registation Servise
#define Notification_for_userRegistration                       @"Notification_for_userRegistration"
#define Notification_login                                      @"Notification_login"
#define Notification_logout                                     @"Notification_logout"
#define Notification_For_GetingPassword                         @"Notification_For_GetingPassword"
#define Notification_For_EditProfile                            @"Notification_For_EditProfile"
#define Notification_for_Request                                @"Notification_for_Request"
#define Notification_for_Group_Skoop_Request                    @"Notification_for_Group_Skoop_Request"

#define Notification_for_PostFriendWall                         @"Notification_for_PostFriendWall"
#define Notification_For_ChangePassword                         @"Notification_For_ChangePassword"
#define Notification_for_ForgotPassword                         @"Notification_for_ForgotPassword"
#define Notification_for_Count_Users                            @"Notification_for_Count_Users"
//Inbox
#define Notification_for_myrequests                             @"Notification_for_myrequests"
#define Notification_for_reply_skoopid                          @"Notification_for_reply_skoopid"
#define Notification_for_mySkoop                                @"Notification_for_mySkoop "

//Reply on skoop
#define Notification_reply_on_skoop                             @"Notification_reply_on_skoop "
#define Notification_Send_to_tab_root                           @"Notification_Send_to_tab_root"

//Group
#define Notification_For_GetGroupList                           @"Notification_For_GetGroupList"
#define Notification_For_GetGroupSkoop                          @"Notification_For_GetGroupSkoop"
#define Notification_For_UnJoinGroup                            @"Notification_For_UnJoinGroup"
#define Notification_For_JoinGroup                              @"Notification_For_JoinGroup"

#define Notification_GetNews                                    @"Notification_GetNews"
#define Notification_GetMore                                    @"Notification_GetMore"
#define Notification_Facebook_Photo_Sharing                     @"Notification_Facebook_Photo_Sharing"
#define Notification_Facebook_Did_Login                         @"Notification_Facebook_Did_Login"
#define Notification_Facebook_Did_Logout                        @"Notification_Facebook_Did_Logout"
#define Notification_Facebook_User_Loaded                       @"Notification_Facebook_User_Loaded"
#define Notification_Facebook_User_Detail_Did_Load              @"Notification_Facebook_User_Detail_Did_Load"
#define Notification_Facebook_Friends_Loaded                    @"Notification_Facebook_Friends_Loaded"
#define Notification_Facebook_Friends_FromFB                    @"Notification_Facebook_Friends_FromFB"

#define GetFacebookUserInfoNotification                         @"GetFacebookUserInfoNotification"
#define GetFacebookAccessToken                                  @"GetFacebookAccessToken"

#define NOTIFICATION_getid                                      @"NOTIFICATION_getid"

#define Notification_Did_Purchase_Success                       @"Notification_Did_Purchase_Success"
#define Notification_Did_Purchase_UnSuccess                     @"Notification_Did_Purchase_UnSuccess"
#define NOTIFICATION_posttoWall                                 @"NOTIFICATION_posttoWall"

#define Notification_Get_My_Scoop_Success                       @"Notification_Get_My_Scoop_Success"
#define Notification_Facebook_User_Cancled                      @"Notification_Facebook_User_Cancled"

#define Notification_Did_Update_Location                        @"Notification_Did_Update_Location"
#define Notification_Did_Update_Location_on_server              @"Notification_Did_Update_Location_on_server"

#define Notification_Get_AllGroupsData                          @"Notification_Get_AllGroupsData"
#define Notification_Get_CarouselImages                         @"Notification_Get_CarouselImages"

#define Notification_Send_InviteToGroup                         @"Notification_Send_InviteToGroup"
#define Notification_Send_InviteToMember                        @"Notification_Send_InviteToMember"

#define Notification_Get_Popular_Groups                         @"Notification_Get_Popular_Groups"
#define Notification_Get_Celebrity_Groups                       @"Notification_Get_Celebrity_Groups"
#define Notification_Get_ByCategory                             @"Notification_Get_ByCategory"
#define Notification_Get_CategoryNames                          @"Notification_Get_CategoryNames"
#define Notification_Get_IndividualGroupMembers                 @"Notification_Get_IndividualGroupMembers"

#define Notification_Get_AllNotifications                       @"Notification_Get_AllNotifications"
#define Notification_Edit_Group                                 @"Notification_Edit_Group"
#define Notification_Block_Unblock_User                         @"Notification_Block_Unblock_User"
#define Notification_Block_User_From_Group                      @"Notification_Block_User_From_Group"
#define Notification_Get_Block_User                             @"Notification_Get_Block_User"
#define Notification_Group_By_Category                          @"Notification_Group_By_Category"
#define Notification_Get_Notofication_Count                     @"Notification_Get_Notofication_Count"
#define Notification_Read_Notofication                          @"Notification_Read_Notofication"
#define Notification_Get_User_Profile                           @"Notification_Get_User_Profile"
#define Notification_Like_Dislike_User_Profile                  @"Notification_Like_Dislike_User_Profile"
#define Notification_Write_Comment                              @"Notification_Write_Comment"
#define Notification_Get_Comment                                @"Notification_Get_Comment"
#define Notification_Get_Blocked_Skoop                          @"Notification_Get_Blocked_Skoop"

#define Notification_Get_User_Skoop                             @"Notification_Get_User_Skoop"
#define Notification_Get_Calendar_Skoop                         @"Notification_Get_Calendar_Skoop"
#define Notification_Get_Month_Skoop                            @"Notification_Get_Month_Skoop"
#define Notification_Add_Skoop_Into_Calendar                    @"Notification_Add_Skoop_Into_Calendar"
#define Notification_Update_Notofication_Count                  @"Notification_Update_Notofication_Count"
#define Notification_Update_Count                               @"Notification_Update_Count"


#define Notification_Update_Only_Notofication_Count             @"Notification_Update_Only_Notofication_Count"
#define Notification_Delete_Skoop                               @"Notification_Delete_Skoop"
#define Notification_Delete_Group_Req                           @"Notification_Delete_Group_Req"
#define Notification_Get_Sync_Skoop                             @"Notification_Get_Sync_Skoop"
#define Notification_Sync_Skoop                                 @"Notification_Sync_Skoop"
#define Notification_Purchase_Skoop                             @"Notification_Purchase_Skoop"
#define Notification_Recharge_Account                           @"Notification_Recharge_Account"
#define Notification_Recharge_Account_Paypal                    @"Notification_Recharge_Account_Paypal"
#define Notification_Redeem_Point                               @"Notification_Redeem_Point"
#define Notification_Live_Portal_Payment                        @"Notification_Live_Portal_Payment"
#define Notification_Report_Video                               @"Notification_Report_Video"

#define Notification_Report_Comment                             @"Notification_Report_Comment"
#define Notification_Update_Profile                             @"Notification_Update_Profile"
#define Notification_Change_Password                            @"Notification_Change_Password"
#define Notification_Change_Username                            @"Notification_Change_Username"
#define Notification_Reply_LivePortal_Req                       @"Notification_Reply_LivePortal_Req"
#define Notification_LivePortal_Call                            @"live_portal_call"
#define Notification_Get_LivePortal_Confirmation                @"Notification_Get_LivePortal_Confirmation"
#define Notification_Update_LivePortal_Count                    @"Notification_Update_LivePortal_Count"
#define Notification_Update_Notification_List                   @"Notification_Update_Notification_List"

#define Notification_Refresh_Calendar                           @"Notification_Refresh_Calendar"
#define Notification_Refresh_UserImage                          @"Notification_Refresh_UserImage"
#define Notification_Refresh_GroupMembers                       @"Notification_Refresh_GroupMembers"
#define Notification_Refresh_SkoopList                          @"Notification_Refresh_SkoopList"
#define Notification_Refresh_UpcomingSkoopList                  @"Notification_Refresh_UpcomingSkoopList"
#define Notification_Refresh_BuysSkoopList                      @"Notification_Refresh_BuysSkoopList"

#define Notification_Get_CCInfo                                 @"Notification_Get_CCInfo"
#define Notification_Save_CCInfo                                @"Notification_Save_CCInfo"
#define Notification_Twitter_USER_DETAIL                        @"Notification_Twitter_USER_DETAIL"

//Check device and version
#define IS_IPHONE5 ([UIScreen mainScreen].bounds.size.height==568)
#define IS_IPHONE_5 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 ) < DBL_EPSILON )
#define IS_IOS_7   ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0 && [[[UIDevice currentDevice] systemVersion] floatValue]<8.0)
#define IS_Greater_Or_Equal_to_IOS_7   ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)
#define IS_Greater_Or_Equal_to_IOS_8   ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)

/*  System Versioning Preprocessor Macros
 */

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN_OR_EQUAL_TO(v)     ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedDescending)


#define predicateFormatForEmailID           @"\\b([a-zA-Z0-9%_.+\\-]+)@([a-zA-Z0-9.\\-]+?\\.[a-zA-Z]{2,6})\\b"
#define predicateFormatFordate              @"^(?!0{2})(1[0-2]|0[1-9])/(?!0{4})[0-9]{4}$"
#define predicateFormatForCardNumber       @"(?!0{14})(?!0{2})[0-9][0-9]{13}([0-9]{2})?"
#define predicateFormatForCVVNumber       @"(?!0{3})(?!0{1})[0-9]{3}([0-9]{1})?"
#define predicateFormatForMobileNumber    @"(?!0{13})"
#define predicateFormatForvehical         @"(?!0+$)"
#define predicateFormatForusername        @"^[ A-Za-z0-9]%_$"

#define KTextColor                          [UIColor colorWithRed:14.0/255.0 green:34.0/255.0 blue:95.0/255.0 alpha:1.0]
#define KTextColor_Green                    [UIColor colorWithRed:30.0/255.0 green:222.0/255.0 blue:49.0/255.0 alpha:1.0]


#define ooVooToken @"MDAxMDAxAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADsbfy1wAR%2FedUGvCvezK1LCi8QsEXLb7aJQObiirEGXBxo07nY7sLStAWIamf%2F4iyutKJfXx640hUgg6Amn1k4n5YHubBbcpH8KG%2BjPtBhrJij1VhE8lCBdcdZOwUZltU%3D"
#define ooVooBlankTime 3

