//
//  SkoopReplyData.m
//  youskoop
//
//  Created by Shitesh Patel on 02/06/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "SkoopReplyData.h"


@implementation SkoopReplyData

@dynamic message;
@dynamic name;
@dynamic paymentStatus;
@dynamic replyDate;
@dynamic skoopId;
@dynamic thumbImage;
@dynamic userImageUrl;
@dynamic videoLength;
@dynamic videoNsdata;
@dynamic videoUrl;
@dynamic isUpload;

@end
