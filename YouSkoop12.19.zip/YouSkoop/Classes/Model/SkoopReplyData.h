//
//  SkoopReplyData.h
//  youskoop
//
//  Created by Shitesh Patel on 02/06/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>


@interface SkoopReplyData : NSManagedObject

@property (nonatomic, retain) NSString * message;
@property (nonatomic, retain) NSString * name;
@property (nonatomic, retain) NSString * paymentStatus;
@property (nonatomic, retain) NSString * replyDate;
@property (nonatomic, retain) NSString * skoopId;
@property (nonatomic, retain) id thumbImage;
@property (nonatomic, retain) NSString * userImageUrl;
@property (nonatomic, retain) NSString * videoLength;
@property (nonatomic, retain) NSData * videoNsdata;
@property (nonatomic, retain) NSString * videoUrl;
@property (nonatomic, retain) NSString * isUpload;

@end
