//
//  SliderSwitch.m
//  Slider Switch Demo
//  Created by Torry Harris on 21/01/13.
//  Copyright (c) 2014 Torry Harris's Mac . All rights reserved.
//  Modified by Torry Harris on 6th March, 2014.
//

#import "SliderSwitch.h"

@implementation SliderSwitch
{
    NSInteger startXValue;
}

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        _selectedIndex = 0;
        _selectedFont = [UIFont boldSystemFontOfSize:18];
        _selectedColor = [UIColor whiteColor];
        _unSelectedFont = [UIFont systemFontOfSize:14];
        _unSelectedColor = [UIColor blackColor];
        
        _labelOne = [[UILabel alloc] init];
        _labelTwo = [[UILabel alloc] init];
    }
    return self;
}

-(id)init{
    self = [super init];
    if (self) {
        // Initialization code
        _selectedIndex = 0;
        _selectedFont = [UIFont boldSystemFontOfSize:18];
        _selectedColor = [UIColor whiteColor];
        _unSelectedFont = [UIFont systemFontOfSize:14];
        _unSelectedColor = [UIColor blackColor];
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        // Initialization code
        _selectedIndex = 0;
        _selectedFont = [UIFont boldSystemFontOfSize:18];
        _selectedColor = [UIColor whiteColor];
        _unSelectedFont = [UIFont systemFontOfSize:14];
        _unSelectedColor = [UIColor blackColor];
    }
    return self;
}

-(void)changeSelectedLayer{
    
    if (_selectedIndex == 0) {
        _labelOne.textColor = _selectedColor;
        _labelOne.font = _selectedFont;
        _labelTwo.textColor = _unSelectedColor;
        _labelTwo.font = _unSelectedFont;
        
    } else if(_selectedIndex == 1) {
        _labelOne.textColor = _unSelectedColor;
        _labelOne.font = _unSelectedFont;
        _labelTwo.textColor = _selectedColor;
        _labelTwo.font = _selectedFont;
    } else {
        _labelOne.textColor = _unSelectedColor;
        _labelOne.font = _unSelectedFont;
        _labelTwo.textColor = _unSelectedColor;
        _labelTwo.font = _unSelectedFont;
    }
}


//override hitTest to interact with current sub view
-(UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    NSEnumerator *reverseE = [self.subviews reverseObjectEnumerator];
    UIView *iSubView;
    
    while ((iSubView = [reverseE nextObject])) {
        
        UIView *viewWasHit = [iSubView hitTest:[self convertPoint:point toView:iSubView] withEvent:event];
        if(viewWasHit) {
            return viewWasHit;
        }
    }
    return [super hitTest:point withEvent:event];
}

//create a horizontal slider switch where frame passed is the frame for switch,numberOfFields is the number of available option
- (void)setFrameHorizontal:(CGRect)frame numberOfFields:(NSUInteger)number withCornerRadius:(CGFloat)cornerRadius
{
    //divide frame width by numberOfFields to decide width of each option
    _selectedIndex = 0;
    startXValue=58;
    float width;
    int n=number;
    _numberOflabels=n;
    float f=(float)frame.size.width;    
    width=f/n;    
    
    //Prepare frame For two Options
    if (number==2) {
        _labelOne.frame = CGRectMake(frame.origin.x, frame.origin.y, width, frame.size.height);
        _labelOne.textAlignment=NSTextAlignmentCenter;
        [_labelOne.layer setBorderColor:[[UIColor darkGrayColor] CGColor]];
        CAShapeLayer *maskLayerLeft = [CAShapeLayer layer];
        UIBezierPath *maskPathLeft=[UIBezierPath bezierPathWithRoundedRect:_labelOne.bounds byRoundingCorners:(UIRectCornerTopLeft | UIRectCornerBottomLeft) cornerRadii:CGSizeMake(cornerRadius,cornerRadius)];
        maskLayerLeft.path = maskPathLeft.CGPath;
        _labelOne.layer.mask = maskLayerLeft;
        [self addSubview:_labelOne];
        _labelTwo.frame = CGRectMake(frame.origin.x+width, frame.origin.y, width, frame.size.height);
        _labelTwo.textAlignment=NSTextAlignmentCenter;
        CAShapeLayer *maskLayerRight = [CAShapeLayer layer];
        UIBezierPath *maskPathRight=[UIBezierPath bezierPathWithRoundedRect:_labelTwo.bounds byRoundingCorners:(UIRectCornerBottomRight | UIRectCornerTopRight) cornerRadii:CGSizeMake(cornerRadius,cornerRadius)];
        maskLayerRight.path = maskPathRight.CGPath;
        _labelTwo.layer.mask = maskLayerRight;
        [self addSubview:_labelTwo];
        _labelOne.userInteractionEnabled=YES;
        _labelTwo.userInteractionEnabled=YES;
        UITapGestureRecognizer *tapGestureLabelone =[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapGesture:)];
        [_labelOne addGestureRecognizer:tapGestureLabelone];
        UITapGestureRecognizer *tapGestureLabelTwo =[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(didTapGesture:)];
        [_labelTwo addGestureRecognizer:tapGestureLabelTwo];
    }
    
    //Add Switch button to the frame and place it at first option
    _toggleButton = [UIButton buttonWithType:UIButtonTypeCustom];
//	[_toggleButton setTitle:@"Skoop" forState:UIControlStateNormal];
//    [_toggleButton setTitle:@"Skoop" forState:UIControlStateHighlighted];
//    [_toggleButton setTitle:@"Skoop" forState:UIControlStateSelected];
	// add drag listener
	[_toggleButton addTarget:self action:@selector(wasDraggedHorizontal:withEvent:)
           forControlEvents:UIControlEventTouchDragInside];    
    [_toggleButton addTarget:self action:@selector(finishedDraggingHorizontal:withEvent:)
           forControlEvents:UIControlEventTouchUpInside];
   	_toggleButton.frame = CGRectMake(frame.origin.x, frame.origin.y, width, frame.size.height);
    _toggleButton.backgroundColor=[UIColor clearColor];
    
    [_toggleButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    [_toggleButton setTitleColor:[UIColor whiteColor] forState:UIControlStateSelected];
    [_toggleButton setTitleColor:[UIColor whiteColor] forState:UIControlStateHighlighted];
    
    _toggleButton.titleLabel.font=[UIFont systemFontOfSize:12.0];
    
    [_toggleButton setBackgroundImage:[UIImage imageNamed:@"Skoop_select.png"] forState:UIControlStateHighlighted];
    [_toggleButton setBackgroundImage:[UIImage imageNamed:@"Skoop_select.png"] forState:UIControlStateNormal];
    [_toggleButton setBackgroundImage:[UIImage imageNamed:@"Skoop_select.png"] forState:UIControlStateSelected];
    [self addSubview:_toggleButton];
}

//To set the border width of switch button
-(void)setSwitchBorderWidth:(CGFloat)width
{
   [_toggleButton.layer setBorderWidth:width];
}

//To set the background color of options
- (void)setFrameBackgroundColor:(UIColor *)color
{
    _labelOne.backgroundColor=color;
    _labelTwo.backgroundColor=color;
}

//To set the color of transparent switch button
- (void)setSwitchFrameColor:(UIColor *)color
{
    [_toggleButton.layer setBorderColor:[color CGColor]];
}

//First option is tapped

- (void)didTapGesture:(UITapGestureRecognizer *)tapGesture {
    
    if([tapGesture.view isEqual:_labelOne]){
        _selectedIndex = 0;
    } else if ([tapGesture.view isEqual:_labelTwo]) {
        _selectedIndex = 1;
    }
    
    [UIView animateWithDuration:0.6
                     animations:^{
                         [_toggleButton setFrame:tapGesture.view.frame];
                     }
                     completion:^(BOOL finished){
//                         if(_selectedIndex==0){
//                             [_toggleButton setTitle:@"Skoop" forState:UIControlStateNormal];
//                             [_toggleButton setTitle:@"Skoop" forState:UIControlStateHighlighted];
//                             [_toggleButton setTitle:@"Skoop" forState:UIControlStateSelected];
//                         } else if (_selectedIndex==1) {
//                             [_toggleButton setTitle:@"Live Portal" forState:UIControlStateNormal];
//                             [_toggleButton setTitle:@"Live Portal" forState:UIControlStateHighlighted];
//                             [_toggleButton setTitle:@"Live Portal" forState:UIControlStateSelected];
//                         }
                     }
     ];
    
    [self changeSelectedLayer];
    [_delegate switchChangedSliderSwitch:self];
}

//Button has been finshed horizontally dragging
//This method finds out the shortest distance between switch button and the all the options and then animate the button to move to the nearest option.
- (void)finishedDraggingHorizontal:(UIButton *)button withEvent:(UIEvent *)event
{
    float diffone,difftwo;
    diffone=fabsf(button.frame.origin.x-_labelOne.frame.origin.x);
    difftwo=fabsf(_labelTwo.frame.origin.x-button.frame.origin.x);
    
    if (_numberOflabels==2) {
        
        if (diffone==difftwo) {
            [UIView animateWithDuration:0.6
                             animations:^{
                                 [button setFrame:_labelOne.frame];
                                 
                             }
                             completion:^(BOOL finished) {
                                 
                             }
             ];
            
        }
        
        if(diffone>difftwo)
        {
            [UIView animateWithDuration:0.6
                             animations:^{
                                 [button setFrame:_labelTwo.frame];
                                 
                             }
                             completion:^(BOOL finished) {
                                 
                             }
             ];
        }
        else
        {
            [UIView animateWithDuration:0.6
                             animations:^{
                                 
                                 [button setFrame:_labelOne.frame];
                             }
                             completion:^(BOOL finished) {
                                 
                             }
             ];
        }
    }
    
    if(button.frame.origin.x==_labelOne.frame.origin.x)
    {
        _selectedIndex = 0;
    } else if (button.frame.origin.x==_labelTwo.frame.origin.x)
    {
        _selectedIndex = 1;
    }
    [self changeSelectedLayer];
    [_delegate switchChangedSliderSwitch:self];
}

//butoon is dragging horizontally

- (void)wasDraggedHorizontal:(UIButton *)button withEvent:(UIEvent *)event
{
    UITouch *touch = [[event touchesForView:button] anyObject];
    
    // get delta
    CGPoint previousLocation = [touch previousLocationInView:button];
    CGPoint location = [touch locationInView:button];
    CGFloat delta_x = location.x - previousLocation.x;
    // move button at x axis
    button.center = CGPointMake(button.center.x + delta_x,
                                button.center.y );
    
    startXValue=(NSInteger)button.frame.origin.x;
    
//    if(startXValue>=58 && startXValue<=107)
//    {
//        [_toggleButton setTitle:@"Skoop" forState:UIControlStateNormal];
//        [_toggleButton setTitle:@"Skoop" forState:UIControlStateHighlighted];
//        [_toggleButton setTitle:@"Skoop" forState:UIControlStateSelected];
//    }
//    else if(startXValue<=158 && startXValue>=107)
//    {
//        [_toggleButton setTitle:@"Live Portal" forState:UIControlStateNormal];
//        [_toggleButton setTitle:@"Live Portal" forState:UIControlStateHighlighted];
//        [_toggleButton setTitle:@"Live Portal" forState:UIControlStateSelected];
//    }
    
    
    if (_numberOflabels==2) {
        if (button.frame.origin.x>_labelTwo.frame.origin.x) {
            [button setFrame:_labelTwo.frame];
        }
        if (button.frame.origin.x<_labelOne.frame.origin.x) {
            [button setFrame:_labelOne.frame];
        }
    }
    
    if(button.frame.origin.x==_labelOne.frame.origin.x)
    {
        _selectedIndex = 0;
    } else if (button.frame.origin.x==_labelTwo.frame.origin.x)
    {
        _selectedIndex = 1;
    }
    [self changeSelectedLayer];
    [self.delegate switchChangedSliderSwitch:self];
}

@end
