//
//  TWAccessTokenGenerator.m
//  Dubit
//
//  Created by Ritesh Verma on 04/06/13.
//  Copyright (c) 2013 Ishan Gupta. All rights reserved.
//

#import "TWAccessTokenGenerator.h"
#import <Accounts/Accounts.h>
#import <Twitter/Twitter.h>
#import "OAuth+Additions.h"
#import "TWAPIManager.h"
#import "AppDelegate.h"
#import "TWSignedRequest.h"
#import "STTwitterAPIWrapper.h"

#define ERROR_NO_ACCOUNTS @"Please configure your Twitter account in Settings."
#define ERROR_PERM_ACCESS @"We weren't granted access to the user's accounts"
#define ERROR_NO_KEYS @"You need to add your Twitter app keys to Info.plist to use this demo.\nPlease see README.md for more info."
#define ERROR_OK @"OK"

@interface TWAccessTokenGenerator()

@property (nonatomic, strong) ACAccountStore *accountStore;
@property (nonatomic, strong) TWAPIManager *apiManager;
@property (nonatomic, strong) NSArray *accounts;
//@property (nonatomic, strong) UIButton *reverseAuthBtn;

@end
@implementation TWAccessTokenGenerator
@synthesize view;
+(TWAccessTokenGenerator*)sharedAccessTokenGenerator
{
    static TWAccessTokenGenerator* singleton;
    if(!singleton)
    {
        singleton = [[TWAccessTokenGenerator alloc] init];
    }
    
    return singleton;
}
-(void)initialize
{
    _accountStore = [[ACAccountStore alloc] init];
    _apiManager = [[TWAPIManager alloc] init];
    
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshTwitterAccounts) name:ACAccountStoreDidChangeNotification object:nil];
}
- (void)refreshTwitterAccounts
{
    if (![TWAPIManager hasAppKeys])
    {
        [AppHelper showAlertViewWithTag:1 title:AppName message:ERROR_NO_KEYS delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
    else if (![TWAPIManager isLocalTwitterAccountAvailable])
    {
        [AppHelper showAlertViewWithTag:1 title:AppName message:ERROR_NO_ACCOUNTS delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
    else
    {
        [self obtainAccessToAccountsWithBlock:^(BOOL granted)
         {
             dispatch_async(dispatch_get_main_queue(), ^{
                 if (!granted)
                 {
                     [AppHelper showAlertViewWithTag:1 title:AppName message:ERROR_PERM_ACCESS delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
                 }
             });
         }];
    }
}

- (void)obtainAccessToAccountsWithBlock:(void (^)(BOOL))block
{
    ACAccountType *twitterType = [_accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    
    ACAccountStoreRequestAccessCompletionHandler handler = ^(BOOL granted, NSError *error) {
        if (granted)
        {
            self.accounts = [_accountStore accountsWithAccountType:twitterType];
            
            if(self.accounts.count>0)
            {
                dispatch_async(dispatch_get_main_queue(), ^{
                    
                    //[[DubitAppDelegate getAppDelegate] hideActivityViewer];
                    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Select a Twitter account:"
                                                                             delegate:self
                                                                    cancelButtonTitle:nil
                                                               destructiveButtonTitle:nil
                                                                    otherButtonTitles:nil];
                    actionSheet.actionSheetStyle = UIActionSheetStyleBlackOpaque;
                    for (int i = 0; i < [self.accounts count]; i++) {
                        [actionSheet addButtonWithTitle:[[self.accounts objectAtIndex:i] valueForKey:@"username"]];
                    }
                    
                    [actionSheet addButtonWithTitle:@"Cancel"];
                    actionSheet.cancelButtonIndex = self.accounts.count;
                    [actionSheet showInView:[AppDelegate getAppDelegate].window];
                });
            }
        }
        
        block(granted);
    };
    
    //  This method changed in iOS6. If the new version isn't available, fall back to the original (which means that we're running on iOS5+).
    if ([_accountStore respondsToSelector:@selector(requestAccessToAccountsWithType:options:completion:)]) {
        [_accountStore requestAccessToAccountsWithType:twitterType options:nil completion:handler];
    }
    else {
        //[_accountStore requestAccessToAccountsWithType:twitterType withCompletionHandler:handler];
        [_accountStore requestAccessToAccountsWithType:twitterType options:nil completion:handler];
    }
}

/**
 *  Handles the button press that initiates the token exchange.
 *
 *  We check the current configuration inside -[UIViewController viewDidAppear].
 */



#pragma mark -UIActionSheet Delegate Methods
- (void)actionSheet:(UIActionSheet *)myActionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (buttonIndex!=self.accounts.count){

        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [_apiManager performReverseAuthForAccount:_accounts[buttonIndex] withHandler:^(NSData *responseData, NSError *error)
         {
             if (responseData)
             {
                 NSString *responseStr = [[NSString alloc] initWithData:responseData encoding:NSUTF8StringEncoding];
                 
                 NSArray *parts = [responseStr componentsSeparatedByString:@"&"];
                 if(parts.count>0)
                 {
                    // NSLog(@"%@",parts);
                     [AppHelper saveToUserDefaults:[[parts objectAtIndex:0] stringByReplacingOccurrencesOfString:@"oauth_token=" withString:@""] withKey:KTwitter_token];
                     
                     [AppHelper saveToUserDefaults:[[parts objectAtIndex:1] stringByReplacingOccurrencesOfString:@"oauth_token_secret=" withString:@""] withKey:KTwitter_secret_token];
                     
                     [AppHelper saveToUserDefaults:[[parts objectAtIndex:2] stringByReplacingOccurrencesOfString:@"user_id=" withString:@""] withKey:KTwitter_id];
                     
                     [AppHelper saveToUserDefaults:[[parts objectAtIndex:3] stringByReplacingOccurrencesOfString:@"screen_name=" withString:@""] withKey:@"screen_Name"];
                     
                     [self getUesrDetail];
                    
                 }
                 else{
                     
                     dispatch_async(dispatch_get_main_queue(), ^{
                         
                         [AppDelegate dismissGlobalHUD];
                     });
                 }
             }
             else{
                 
                 dispatch_async(dispatch_get_main_queue(), ^{
                     
                     [AppDelegate dismissGlobalHUD];
                 });
             }
             
         }];
    }
}

-(void)getUesrDetail{
    
    STTwitterAPIWrapper *twitter =[STTwitterAPIWrapper twitterAPIWithOAuthConsumerName:@"YouSkoop App" consumerKey:TwitterConsumerKey consumerSecret:TwitterSecretKey oauthToken:[AppHelper userDefaultsForKey:KTwitter_token] oauthTokenSecret:[AppHelper userDefaultsForKey:KTwitter_secret_token]];
    
    [twitter getUserInformationFor:[AppHelper userDefaultsForKey:@"screen_Name"] successBlock:^(NSDictionary *dict)
     {
         NSLog(@"::::data sent");
         [self sendResponse:dict];
         
     }errorBlock:^(NSError* error)
     {
         [self sendResponse:nil];
         NSLog(@"Twitter verify credentials error %@",error);
     }];
    
}

-(void)sendResponse:(NSDictionary*)dict
{
    dispatch_async(dispatch_get_main_queue(), ^{
        
        [AppDelegate dismissGlobalHUD];
    });
    NSLog(@"send respose");
    if([[AppHelper userDefaultsForKey:@"POST"] isEqualToString:@"YES"])
        [[NSNotificationCenter defaultCenter] postNotificationName:@"Twitter_Tokens_Rvcd" object:dict];
}

- (void)dealloc
{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
   // [super dealloc];
}

@end
