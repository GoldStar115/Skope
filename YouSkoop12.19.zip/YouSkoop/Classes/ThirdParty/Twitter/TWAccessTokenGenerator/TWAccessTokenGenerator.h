//
//  TWAccessTokenGenerator.h
//  Dubit
//
//  Created by Ritesh Verma on 04/06/13.
//  Copyright (c) 2013 Ishan Gupta. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TWAccessTokenGenerator : NSObject<UIActionSheetDelegate>
{
    
}
@property(nonatomic,retain)UIView *view;
+(TWAccessTokenGenerator*)sharedAccessTokenGenerator;
- (void)refreshTwitterAccounts;
-(void)initialize;
@end
