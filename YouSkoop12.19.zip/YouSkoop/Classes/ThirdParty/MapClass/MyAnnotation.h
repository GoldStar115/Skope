//
//  MyAnnotation.h
//  GPSGoogleMapApp
//
//  Created by Ajay Kumar on 24/04/10.
//  Copyright 2010 TechAhead. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MKAnnotation.h>
//#import "RegexKitLite.h"

typedef enum 
{
	iCodeBlogAnnotationTypeCurrentLocation,
	
} iCodeMapAnnotationType;

@interface MyAnnotation : NSObject <MKAnnotation> 
{
	
	CLLocationCoordinate2D coordinate;
	NSString *title;
	NSString *subtitle;
	UIImageView *imageview;
	UIImage *image;
	iCodeMapAnnotationType annotationType;
	NSString* userData;
	NSInteger ann_tag;
}

@property (nonatomic, assign) CLLocationCoordinate2D coordinate;
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *subtitle;
@property (nonatomic, copy) UIImageView *imageview;
@property (nonatomic, copy) UIImage *image;
@property (nonatomic, assign) iCodeMapAnnotationType annotationType;
@property (nonatomic,copy) NSString* userData;
@property (nonatomic,assign)	NSInteger ann_tag;
@property (nonatomic,retain) UIView *view1;

-(id)initWithCoordinate:(CLLocationCoordinate2D) coordinate;





@end