//
//  MyAnnotation.m
//  GPSGoogleMapApp
//
//  Created by Ajay Kumar on 24/04/10.
//  Copyright 2010 TechAhead. All rights reserved.
//

#import "MyAnnotation.h"
@implementation MyAnnotation

@synthesize coordinate, title, subtitle,imageview,image,ann_tag,view1;
@synthesize annotationType;
@synthesize userData ; 

-init
{
	return self;
}

-initWithCoordinate:(CLLocationCoordinate2D)inCoord
{
	coordinate = inCoord;
	return self;
}

@end
