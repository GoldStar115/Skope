

#import <UIKit/UIKit.h>
#import "Party.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "AFHTTPClient.h"

@class AVCamCaptureManager, AVCamPreviewView, AVCaptureVideoPreviewLayer;

@interface AVCamViewController : UIViewController <UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    
    IBOutlet UIView *bottomView;
    IBOutlet UIImageView *capturedImageView;
   // IBOutlet UIView *titleView;
    IBOutlet UIButton *cameraButton;
    IBOutlet UIButton *flashButton;
   
    IBOutlet UILabel *eventName;
    IBOutlet UIButton *camrollButton;
    
    bool rotate;
    CGRect rectVideo;
    
//    IBOutlet UIView *bottomSaveView;
    bool IsUploadAllPhoto;
    IBOutlet UIView *activityIndicatorView;
    bool isAutoUpload;
    bool isPartyEnded;
   
    
    
    IBOutlet UILabel *eventCapcityLabel;
    IBOutlet UILabel *photoCountLabel;
    IBOutlet UILabel *eventPasswordLabel;
    
    
    bool isPostPoneUpload;
    bool uploadholdImages;

    
    IBOutlet UIButton *homeButton;
    IBOutlet UIButton *viewButton;
    IBOutlet UIButton *postPoneButton;
    UIImagePickerController* imgPickerCamera;
    int counter;

    IBOutlet UIView *partyInfoView;
    
    IBOutlet UIImageView *upperImage;
    IBOutlet UIImageView *lowerImage;
    
    bool isPartyInfoVisible;
    bool isUploadFromCameraRoll;
    
    AFHTTPRequestOperation *operation111;
    
   // IBOutlet UIView *AddPictureOption;
    IBOutlet UIButton *showEventdataBtn;
    IBOutlet UITextField *_emailTextField;
    IBOutlet UITextField *passTextField;
    IBOutlet UITextField *nameTextField;
    
    
    IBOutlet UIView *guestPasswordView;
    IBOutlet UITextField *guestPassword;

    
    
    IBOutlet UITextField *changeGuestPassword;
    
    bool isChangeGuestPassword;
    
    IBOutlet UIImageView *cameraLayerImage;
    
    IBOutlet UIView *uploadingView;
}


@property (nonatomic,retain) AVCamCaptureManager *captureManager;
@property (nonatomic,retain) IBOutlet UIView *videoPreviewView;
@property (nonatomic,retain) AVCaptureVideoPreviewLayer *captureVideoPreviewLayer;
@property(nonatomic,retain) Party *selectedParty;
//@property (retain, nonatomic) IBOutlet UIButton *showEventdataBtn;
@property (strong, atomic) ALAssetsLibrary* customlibrary;
//@property(nonatomic,retain) UIImagePickerController* imgPickerCamera;
@property(nonatomic,retain) NSData *_picData;
@property(nonatomic,retain) UIImage *_imageTaken;

#pragma mark  Actions

- (IBAction)viewAlbumAction:(id)sender;


- (IBAction)captureStillImage:(id)sender;
- (IBAction)toggleCamera:(id)sender;
- (IBAction)setFlash:(id)sender;
-(IBAction)ViewClicked:(id)sender;
-(IBAction)homeClicked:(id)sender;
-(IBAction)camRollClicked:(id)sender;
-(IBAction)saveClickedImage:(id)sender;
-(IBAction)cancelClickedImage:(id)sender;
-(IBAction)postPoneImageClicked:(id)sender;
- (IBAction)uploadCancel:(id)sender;
-(void)getImageFromLib;

// Show party Info
- (IBAction)partyInfoButton:(id)sender;
-(void)startIndicator;
-(void)hideIndicator;
-(void)startCameraSession;
-(void)currentEvenHasEnded;
-(void)stopSession;

@end

