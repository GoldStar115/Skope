
#import "AVCamViewController.h"
#import "AVCamCaptureManager.h"
#import <AVFoundation/AVFoundation.h>
#import "PartyPhotoGridVC.h"
#import "AFHTTPClient.h"
#import "AFHTTPRequestOperation.h"
#import "JSON1.h"
#import "RBVolumeButtons.h"
#import "PendingImages.h"
#import "Facebook.h"
#import "FaceBookEngine.h"
#import "UpgradeOptionVC.h"
@interface UIImage (fixOrientation)

- (UIImage *)fixOrientation;

@end

@implementation UIImage (fixOrientation)
// Fix orientation to prevent the image to rotate by 90 degree..

- (UIImage *)fixOrientation
{
    
    // No-op if the orientation is already correct
    if (self.imageOrientation == UIImageOrientationUp) return self;
    // We need to calculate the proper transformation to make the image upright.
    // We do it in 2 steps: Rotate if Left/Right/Down, and then flip if Mirrored.
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (self.imageOrientation)
    {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, self.size.width, self.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, self.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, self.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
    }
    
    switch (self.imageOrientation)
    {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, self.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, self.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, self.size.width, self.size.height,
                                             CGImageGetBitsPerComponent(self.CGImage), 0,
                                             CGImageGetColorSpace(self.CGImage),
                                             CGImageGetBitmapInfo(self.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (self.imageOrientation)
    {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,self.size.height,self.size.width), self.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,self.size.width,self.size.height), self.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *img = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    return img;
}

@end

static void *AVCamFocusModeObserverContext = &AVCamFocusModeObserverContext;

@interface AVCamViewController () <UIGestureRecognizerDelegate>
@end

@interface AVCamViewController (InternalMethods)

@end

@interface AVCamViewController (AVCamCaptureManagerDelegate) <AVCamCaptureManagerDelegate>
@end

@implementation AVCamViewController

@synthesize captureManager;
@synthesize videoPreviewView;
@synthesize captureVideoPreviewLayer;
@synthesize selectedParty;
@synthesize _picData;
@synthesize customlibrary;
@synthesize _imageTaken;

- (void)dealloc
{

	[captureManager release];
    [videoPreviewView release];
	[captureVideoPreviewLayer release];
    [selectedParty release];
    [captureManager release];
    [_picData release];
    [_imageTaken release];
    [cameraLayerImage release];
    [super dealloc];
    
}

- (void)viewDidLoad
{
    //upperImage.frame=CGRectMake(0, 0, 320, 240);
    //lowerImage.frame=CGRectMake(0, 195, 320, [[ UIScreen mainScreen ] bounds].size.height-195);

    NSLog(@"%@",self.selectedParty);
    
    self.navigationController.navigationBarHidden=YES;
    bottomView.frame=CGRectMake(0, [[ UIScreen mainScreen ] bounds].size.height-85, 320, 80);
   // bottomSaveView.frame=CGRectMake(0, self.view.frame.size.height-60, 320, 60);
    
    
       
    showEventdataBtn.frame=CGRectMake(142, 10, 33, 33);
    cameraButton.frame=CGRectMake(230, 10, 33, 33);
    flashButton.frame=CGRectMake(52, 10, 33, 33);
    eventName.text=self.selectedParty.partyName;
    
    
    [self.view addSubview:capturedImageView];
    [self.view addSubview:bottomView];
    [self.view addSubview:showEventdataBtn];
    [self.view addSubview:flashButton];

    self.view.backgroundColor=[UIColor blackColor];
    
    capturedImageView.hidden=YES;
    
    NSString *str=[AppHelper userDefaultsForKey:@"PostPoneUpload"];
    if([str isEqualToString:@"YES"])
    {
        postPoneButton.selected=YES;
        
    }
    
    [self performSelector:@selector(getUpdatedPartyInfo) withObject:nil afterDelay:0.1];

    rotate=NO;
    
    camrollButton.layer.cornerRadius = 3.0;
    camrollButton.layer.borderColor = [UIColor clearColor].CGColor;
    camrollButton.layer.borderWidth = 2.0;
    camrollButton.clipsToBounds = YES;
    
    if([AppHelper is4InchRetina])
    {
        cameraLayerImage.image=[UIImage imageNamed:@"camerabg4_latest.png"];
    }
    else
    {
        cameraLayerImage.image=[UIImage imageNamed:@"camerabg5_latest.png"];
    }

    cameraLayerImage.frame=CGRectMake(0, 44, 320, self.view.frame.size.height+44);
    
    [super viewDidLoad];
}


-(void)openShutter
{
    
    upperImage.frame=CGRectMake(0, 0, 320, 240);
    lowerImage.frame=CGRectMake(0, 195, 320, [[ UIScreen mainScreen ] bounds].size.height-195);
    
    [UIView animateWithDuration:0.3
                     animations:^{
                         upperImage.frame=CGRectMake(0, -240, 320, 240);
                         lowerImage.frame=CGRectMake(0, [[ UIScreen mainScreen ] bounds].size.height, 320, [[ UIScreen mainScreen ] bounds].size.height-195);
                         
                         
                     }];
}


-(void)viewWillAppear:(BOOL)animated
{
    [[UIApplication sharedApplication] setStatusBarHidden:YES];

    [[UIDevice currentDevice] setOrientation:UIInterfaceOrientationPortrait];

    UIView *view=(UIView*)[[AppDelegate getAppDelegate].window viewWithTag:21];
    view.hidden=YES;
    ALAssetsLibrary *asset=[[ALAssetsLibrary alloc] init];
    self.customlibrary=asset;
    [asset release];
    
    [self getImageFromLib];
    [self startCameraSession];
    
        
}



-(void)getUpdatedPartyInfo
{
    
    NSString *serviceName = Method_Party_Image_Count;
    NSString *urlString =[NSString stringWithFormat:@"%@%@",BaseUrl,serviceName];
    urlString =[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
    [param setObject:self.selectedParty.partyId forKey:@"party_id"];
    
    AFHTTPClient *client= [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:urlString]];
    
    [client getPath:@"" parameters:param success:
     ^(AFHTTPRequestOperation *opration,id responseObject)
     {
         
         [[AppDelegate getAppDelegate] hideIndicator];
         NSString *decodedString = [[[NSString alloc] initWithData:[opration responseData] encoding:NSUTF8StringEncoding] autorelease];
         NSDictionary *jsonDictD = [decodedString JSONValue];
         
         if(([self.selectedParty.partyType isEqualToString:@"Instant"])&&(![[jsonDictD objectForKey:@"partyType"] isEqualToString:@"Instant"]))
         {
         
             [AppHelper saveToUserDefaults:[jsonDictD objectForKey:@"password"] withKey:@"ChangedPassword"];
             [AppHelper saveToUserDefaults:self.selectedParty.partyId withKey:@"ChangePasswordEventID"];
             
             NSLog(@"Make private");
             
         }
         
        
         
     }
            failure:
     ^(AFHTTPRequestOperation *opration,NSError *error)
     {
         [[AppDelegate getAppDelegate] hideIndicator];
         
         [AppHelper showAlertViewWithTag:1 title:APP_NAME message:ERROR_INTERNET delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
     }];
    [param release];
    



}


-(void)startCameraSession
{
    

    if ([self captureManager] == nil)
    {
		AVCamCaptureManager *manager = [[AVCamCaptureManager alloc] init];
		[self setCaptureManager:manager];
		[manager release];
		
		[[self captureManager] setDelegate:self];
        
		if ([[self captureManager] setupSession])
        {
            // Create video preview layer and add it to the UI
			AVCaptureVideoPreviewLayer *newCaptureVideoPreviewLayer = [[AVCaptureVideoPreviewLayer alloc] initWithSession:[[self captureManager] session]];
            videoPreviewView.frame=CGRectMake(0, 0, 320, [[ UIScreen mainScreen ] bounds].size.height);
			
            
            UIView *view = [self videoPreviewView];
			CALayer *viewLayer = [view layer];
			[viewLayer setMasksToBounds:NO];
			
			CGRect bounds = [view bounds];
            // NSLog(@"view------%@--%f----%f",view,bounds.size.width,bounds.size.height);
            rectVideo=bounds;
			[newCaptureVideoPreviewLayer setFrame:bounds];
            
            capturedImageView.frame=bounds;
            
			if ([newCaptureVideoPreviewLayer isOrientationSupported])
            {
				[newCaptureVideoPreviewLayer setOrientation:AVCaptureVideoOrientationPortrait];
			}
			
			[newCaptureVideoPreviewLayer setVideoGravity:AVLayerVideoGravityResizeAspectFill];
			
			[viewLayer insertSublayer:newCaptureVideoPreviewLayer below:[[viewLayer sublayers] objectAtIndex:0]];
            self.captureVideoPreviewLayer.backgroundColor=[UIColor redColor].CGColor;
			[self setCaptureVideoPreviewLayer:newCaptureVideoPreviewLayer];
            [newCaptureVideoPreviewLayer release];
			
            // Start the session. This is done asychronously since -startRunning doesn't return until the session is running.
			dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                
                
                [[[self captureManager] session] startRunning];
                NSLog(@"session started......................");
                
			});
			
			
		}
	}


}



-(void)stopSession
{
    self.captureManager=nil;
}

#pragma mark Toolbar Actions
- (IBAction)toggleCamera:(id)sender
{
    NSLog(@"toggle camera");
    
    //[[AppDelegate getAppDelegate] playButtonClickSound];

    [[self captureManager] toggleCamera];
}


- (IBAction)setFlash:(id)sender
{
    //[[AppDelegate getAppDelegate] playButtonClickSound];

    UIButton *switchBtn=(UIButton*)sender;
    if(!switchBtn.selected)
    {
        
        NSLog(@"switch on");
        [AppHelper saveToUserDefaults:@"ON" withKey:@"Flash"];
        switchBtn.selected=YES;
        
    }
    else
    {
        NSLog(@"switch off");
        [AppHelper saveToUserDefaults:@"OFF" withKey:@"Flash"];
        switchBtn.selected=NO;
        
    }
    [[self captureManager] setFlash];


}


- (IBAction)viewAlbumAction:(id)sender
{
    
    
    UIButton *btn=(UIButton*)sender;
    if(btn.tag!=452)
    {
        
        
        bottomView.hidden=NO;
        capturedImageView.hidden=YES;
    
        cameraButton.hidden=NO;
        flashButton.hidden=NO;
        showEventdataBtn.hidden=NO;
        
        camrollButton.hidden=NO;
        postPoneButton.hidden=NO;
        
        self._picData=nil;
        capturedImageView.image=nil;
        
        homeButton.tag=451;
        viewButton.tag=452;
    
        [homeButton setImage:[UIImage imageNamed:@"home_btn_unpresed_latest.png"] forState:UIControlStateNormal];
        [homeButton setImage:[UIImage imageNamed:@"home_btn_presed_latest.png"] forState:UIControlStateHighlighted];
        [viewButton setImage:[UIImage imageNamed:@"view_btn_unpresed_latest.png"] forState:UIControlStateNormal];
        [viewButton setImage:[UIImage imageNamed:@"view_btn_presed_latest.png"] forState:UIControlStateHighlighted];
    
    }
    else
    {
    NSString *ChangedPassword=nil;
    NSString *ChangePasswordEventID=nil;
    
    ChangedPassword=[AppHelper userDefaultsForKey:@"ChangedPassword"];
    ChangePasswordEventID=[AppHelper userDefaultsForKey:@"ChangePasswordEventID"];
    
    NSString *blockUser=nil;
    NSString *blockUserEventID=nil;
    
    blockUser=[AppHelper userDefaultsForKey:@"BlockUser"];
    blockUserEventID=[AppHelper userDefaultsForKey:@"BlockUserEventID"];
    
    
    if(([selectedParty.partyId isEqualToString:blockUserEventID])&&([blockUser isEqualToString:@"YES"]))
    {
        
        [AppHelper showAlertViewWithTag:1 title:APP_NAME message:@"Sorry, the host of this event has blocked you from participating." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
    }
    else
    {
    
    
    
    if(([selectedParty.partyId isEqualToString:ChangePasswordEventID])&&(ChangedPassword.length!=0))
    {
        
        isChangeGuestPassword=YES;
        UIAlertView *alertView1 = [[UIAlertView alloc]
                                   initWithTitle:@""
                                   message:@"This event has become private. Please ask your host for the password.\n\n      "
                                   delegate:self
                                   cancelButtonTitle:@"OK"
                                   otherButtonTitles:nil];
        alertView1.tag=5001;
        changeGuestPassword.frame=CGRectMake(18, 93, 250, 30);
        [alertView1 addSubview:changeGuestPassword];
        [alertView1 show];
        [alertView1 release];
        changeGuestPassword.text=nil;
        
        [changeGuestPassword becomeFirstResponder];
        
    }
    else
    {
    
    
//    if([[AppHelper userDefaultsForKey:@"EmailRegister"] isEqualToString:@"YES"])
//    {
        //[[AppDelegate getAppDelegate] playButtonClickSound];
        Party *party11=selectedParty;;
        NSLog(@"%@",party11.imageCount);
        
        NSString *str=[AppHelper userDefaultsForKey:@"Zorba300"];
        
        if(str.length==0&&[party11.imageCount intValue]>70)
        {
            UIAlertView *alertView = [[UIAlertView alloc]
                                      initWithTitle:APP_NAME
                                      message:@"This album exceeds 70 photo free capacity. Please purchase Zorba 300 for extra capacity."
                                      delegate:self
                                      cancelButtonTitle:@"OK"
                                      otherButtonTitles:@"Not now",nil];
            
            
            alertView.tag=8000;
            [alertView show];
            [alertView release];
            
        }
        else
        {
                PartyPhotoGridVC *photoGrid=[[PartyPhotoGridVC alloc]initWithNibName:@"PartyPhotoGridVC" bundle:nil];
                photoGrid.selectedParty=self.selectedParty;
                [self.navigationController pushViewController:photoGrid animated:YES];
                [photoGrid release];
            
        }
        
        

    }
    }
    }
}

- (IBAction)captureStillImage:(id)sender
{
    //[[AppDelegate getAppDelegate] playCameraClickSound];
    
    Party *party=self.selectedParty;
    
    
    NSString *ChangedPassword=nil;
    NSString *ChangePasswordEventID=nil;
    
    ChangedPassword=[AppHelper userDefaultsForKey:@"ChangedPassword"];
    ChangePasswordEventID=[AppHelper userDefaultsForKey:@"ChangePasswordEventID"];
    
    NSString *blockUser=nil;
    NSString *blockUserEventID=nil;
    
    blockUser=[AppHelper userDefaultsForKey:@"BlockUser"];
    blockUserEventID=[AppHelper userDefaultsForKey:@"BlockUserEventID"];
    
    
    if(([party.partyId isEqualToString:blockUserEventID])&&([blockUser isEqualToString:@"YES"]))
    {
        
        [AppHelper showAlertViewWithTag:1 title:APP_NAME message:@"Sorry, the host of this event has blocked you from participating." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        
    }
    else
    {
    
    
    if(([party.partyId isEqualToString:ChangePasswordEventID])&&(ChangedPassword.length!=0))
    {
        
        changeGuestPassword.text=nil;
        isChangeGuestPassword=YES;
        UIAlertView *alertView1 = [[UIAlertView alloc]
                                   initWithTitle:@""
                                   message:@"This event has become private. Please ask your host for the password.\n\n      "
                                   delegate:self
                                   cancelButtonTitle:@"OK"
                                   otherButtonTitles:nil];
        alertView1.tag=5001;
        changeGuestPassword.frame=CGRectMake(18, 93, 250, 30);
        [alertView1 addSubview:changeGuestPassword];
        [alertView1 show];
        [alertView1 release];
        changeGuestPassword.text=nil;
        
        [changeGuestPassword becomeFirstResponder];
        
    }
    else
    {
    
    
    NSDate *todaydate = [NSDate date];
    NSTimeInterval interval = [party.partyExpireTime timeIntervalSinceDate:todaydate];
    
    int active=[party.isActive intValue];
    
    
    if(interval >0 && active)
    {
        if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
        {
            [[self captureManager] captureStillImage];
        }
        else
        {
            [AppHelper showAlertViewWithTag:0 title:APP_NAME message:@"Camera Not Available" delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK"];
        }
    }
    else
    {
        NSString* str=[NSString stringWithFormat:@"%@%@%@",@"Sorry, the event \"",party.partyName,@"\" has ended. Please start a new event to upload more photos."];
        
        [AppHelper showAlertViewWithTag:1 title:APP_NAME message:str delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    }


    
}
    }

}

//-(IBAction)ViewClicked:(id)sender
//{
//    
//    
//    
//    UIButton *btn=(UIButton*)sender;
//    NSLog(@"------%@",btn);
//
//    if(btn.tag==452)
//    {
//        NSLog(@"view clicked");
//        // [self dismissModalViewControllerAnimated:NO];
//        NSString *ChangedPassword=nil;
//        NSString *ChangePasswordEventID=nil;
//        ChangedPassword=[AppHelper userDefaultsForKey:@"ChangedPassword"];
//        ChangePasswordEventID=[AppHelper userDefaultsForKey:@"ChangePasswordEventID"];
//        
//        if(([selectedParty.partyId isEqualToString:ChangePasswordEventID])&&(ChangedPassword.length!=0))
//        {
//            
//            changeGuestPassword.text=nil;
//            isChangeGuestPassword=YES;
//            UIAlertView *alertView = [[UIAlertView alloc]
//                                      initWithTitle:@""
//                                      message:@"This event has become private. Please ask your host for the password."
//                                      delegate:self
//                                      cancelButtonTitle:@"OK"
//                                      otherButtonTitles:nil];
//            alertView.tag=5001;
//            changeGuestPassword.frame=CGRectMake(20, 20, 258, 40);
//            [alertView addSubview:changeGuestPassword];
//            [alertView show];
//            [alertView release];
//            
//            [changeGuestPassword becomeFirstResponder];
//            
//        }
//        else
//        {
//            NSLog(@"%@",self.navigationController);
//            PartyPhotoGridVC *photoGrid=[[PartyPhotoGridVC alloc]initWithNibName:@"PartyPhotoGridVC" bundle:nil];
//            photoGrid.selectedParty=self.selectedParty;
//            [self.navigationController pushViewController:photoGrid animated:NO];
//            [photoGrid release];
//        }
//
//    }
//    else
//    {
//        bottomView.hidden=NO;
//        capturedImageView.hidden=YES;
//       
////        showEventdataBtn.hidden=NO;
////        cameraButton.hidden=NO;
////        flashButton.hidden=NO;
//        
//        self._picData=nil;
//        capturedImageView.image=nil;
//        homeButton.tag=451;
//        viewButton.tag=452;
//            
//        [homeButton setImage:[UIImage imageNamed:@"home_btn_unpresed_latest.png"] forState:UIControlStateNormal];
//        [homeButton setImage:[UIImage imageNamed:@"home_btn_presed_latest.png"] forState:UIControlStateNormal];
//        [viewButton setImage:[UIImage imageNamed:@"view_btn_unpresed_latest.png"] forState:UIControlStateNormal];
//        [viewButton setImage:[UIImage imageNamed:@"view_btn_presed_latest.png"] forState:UIControlStateNormal];
//          
//     }
//    
//
//   // [[AppDelegate getAppDelegate] viewPartyList:self.selectedParty];
//    
//}

-(IBAction)homeClicked:(id)sender
{
    UIButton *btn=(UIButton*)sender;
    
    if(btn.tag==451)
    {
        [[AppDelegate getAppDelegate] showHomePage];
    }
    else
    {
        capturedImageView.hidden=YES;
        
        homeButton.tag=451;
        viewButton.tag=452;
               
        [homeButton setImage:[UIImage imageNamed:@"home_btn_unpresed_latest.png"] forState:UIControlStateNormal];
        [homeButton setImage:[UIImage imageNamed:@"home_btn_presed_latest.png"] forState:UIControlStateHighlighted];
        
        [viewButton setImage:[UIImage imageNamed:@"view_btn_unpresed_latest.png"] forState:UIControlStateNormal];
        [viewButton setImage:[UIImage imageNamed:@"view_btn_presed_latest.png"] forState:UIControlStateHighlighted];
        
        
        cameraButton.hidden=NO;
        flashButton.hidden=NO;
        showEventdataBtn.hidden=NO;
        
        camrollButton.hidden=NO;
        postPoneButton.hidden=NO;
        
        [self saveClickedImage];
    
    }
    
}

-(IBAction)camRollClicked:(id)sender
{
    //[[AppDelegate getAppDelegate] playButtonClickSound];

    Party *party=self.selectedParty;
    
    
    NSString *ChangedPassword=nil;
    NSString *ChangePasswordEventID=nil;
    
    ChangedPassword=[AppHelper userDefaultsForKey:@"ChangedPassword"];
    ChangePasswordEventID=[AppHelper userDefaultsForKey:@"ChangePasswordEventID"];
    

     
    NSString *blockUser=nil;
    NSString *blockUserEventID=nil;
    
    blockUser=[AppHelper userDefaultsForKey:@"BlockUser"];
    blockUserEventID=[AppHelper userDefaultsForKey:@"BlockUserEventID"];
    
    
    if(([party.partyId isEqualToString:blockUserEventID])&&([blockUser isEqualToString:@"YES"]))
    {
        
        [AppHelper showAlertViewWithTag:1 title:APP_NAME message:@"Sorry, the host of this event has blocked you from participating." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    
    }
    else
    {
    if(([party.partyId isEqualToString:ChangePasswordEventID])&&(ChangedPassword.length!=0))
    {
        
        isChangeGuestPassword=YES;
        UIAlertView *alertView1 = [[UIAlertView alloc]
                                   initWithTitle:@""
                                   message:@"This event has become private. Please ask your host for the password.\n\n      "
                                   delegate:self
                                   cancelButtonTitle:@"OK"
                                   otherButtonTitles:nil];
        alertView1.tag=5001;
        changeGuestPassword.frame=CGRectMake(18, 93, 250, 30);
        [alertView1 addSubview:changeGuestPassword];
        [alertView1 show];
        [alertView1 release];
        changeGuestPassword.text=nil;

        [changeGuestPassword becomeFirstResponder];
        
    }
    else
    {
    
    
        NSDate *todaydate = [NSDate date];
        NSTimeInterval interval = [party.partyExpireTime timeIntervalSinceDate:todaydate];
    
        int active=[party.isActive intValue];
    
    
        if(interval >0 && active)
        {
            
            [self selectPhotoGallery];
        
        }
        else
        {
            NSString* str=[NSString stringWithFormat:@"%@%@%@",@"Sorry, the event \"",party.partyName,@"\" has ended. Please start a new event to upload more photos."];
        
            [AppHelper showAlertViewWithTag:1 title:APP_NAME message:str delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }

    }
}
}

#pragma mark RegistrationProcess

-(void)showRegistrationAlert
{
    UIAlertView *createNewAlert =[[UIAlertView alloc] initWithTitle:@"Please enter Email to Register" message:@"                                                                               "delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
    createNewAlert.tag=80;
    
    
    
    nameTextField.frame= CGRectMake(20.0, 55.0, 258, 40.0);
    passTextField.text=nil;
    [createNewAlert addSubview:nameTextField];
    
    
    
    
    _emailTextField.frame= CGRectMake(20.0, 110.0, 258, 40.0);
    _emailTextField.text=nil;
    [createNewAlert addSubview:_emailTextField];
    
    
    passTextField.frame= CGRectMake(20, 165.0, 258, 40.0);
    passTextField.text=nil;
    [createNewAlert addSubview:passTextField];
    
    [createNewAlert show];
    [createNewAlert release];
}


-(void)loginWithFacebook
{
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(facebookDidLogin:)
                                                 name:Notification_Facebook_Did_Login
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(facebookLogincancled:)
                                                 name:Notification_Facebook_User_Cancled
                                               object:nil];
    [[FaceBookEngine sharedInstance] login];
    
}

-(void)emailRegisterResponse:(NSNotification*)note
{
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:Notification_Email_Register object:nil];
   
    if (note.userInfo)
    {
        id error = [[note userInfo] valueForKey:@"error"];
        if (error)
        {
            
        }
        else
        {
            
            if([[[note.userInfo valueForKey:@"EmailResult"] valueForKey:@"errcode"] intValue]==0)
            {
                [AppHelper saveToUserDefaults:@"YES" withKey:@"EmailRegister"];
                
                UIAlertView *createNewAlert =[[UIAlertView alloc] initWithTitle:APP_NAME message:@"Registration successful."delegate:self cancelButtonTitle:nil otherButtonTitles:@"OK", nil];
                createNewAlert.tag=8001;
                [createNewAlert show];
                [createNewAlert release];

                
                                
            }
            else
            {
                
                [AppHelper showAlertViewWithTag:1 title:APP_NAME message:[[note.userInfo valueForKey:@"EmailResult"] valueForKey:@"errstr"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                
                
            }
            
        }
    }
    [[AppDelegate getAppDelegate] hideIndicator];

    
}



#pragma mark FaceBook  Callback Notification

-(void)facebookLogincancled:(NSNotification*)note
{
    
    [[AppDelegate getAppDelegate] hideIndicator];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:Notification_Facebook_User_Cancled object:nil];
    
}


-(void)facebookDidLogin:(NSNotification *)note
{
    [[AppDelegate getAppDelegate] startIndicator];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:Notification_Facebook_Did_Login object:nil];
    
    if ([[FaceBookEngine sharedInstance] checkInternateConnection])
    {
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(userInfoGet:) name:Notification_Facebook_User_Loaded object:nil];
        [[FaceBookEngine sharedInstance]getUserDetails];
    }
    
}
-(void)userInfoGet:(NSNotification *)note
{
    [[AppDelegate getAppDelegate] hideIndicator];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:Notification_Facebook_User_Loaded object:nil];
    
    if(![[[[note userInfo] objectForKey:@"data"]objectForKey:@"email"]isKindOfClass:[NSNull class]])
    {
        if ([[[note userInfo] objectForKey:@"data"]objectForKey:@"email"])
        {
            
            [[AppDelegate getAppDelegate] startIndicator];
            [[NSNotificationCenter defaultCenter] addObserver:self
                                                     selector:@selector(emailRegisterResponse:)
                                                         name:Notification_Email_Register
                                                       object:nil];
            
            [[Services sharedInstance] registerEmailForAlbum:_emailTextField.text andpassword:@""];
            
        }
        
        
        
    }
    else
    {
        [AppHelper showAlertViewWithTag:0 title:APP_NAME message:@"No Email attached with your account!" delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok_Button];
        
    }
    
    
}





// to set the alertView frame size.
- (void)willPresentAlertView:(UIAlertView *)alertView
{
    if(alertView.tag==80)
    {
        [alertView setFrame:CGRectMake(10, 50, 300, 290)];
        for ( UIView *views in [alertView subviews]) {
            NSLog(@"%@",views);
            if (views.tag == 1 || views.tag == 2) {
                [views setFrame:CGRectMake(views.frame.origin.x+8, views.frame.origin.y+140, views.frame.size.width, views.frame.size.height)];
            }
        }
    }
}








-(void)selectPhotoGallery
{

    //[[AppDelegate getAppDelegate] playButtonClickSound];
    
    imgPickerCamera = [[UIImagePickerController alloc] init];
    imgPickerCamera.delegate =self;
    imgPickerCamera.allowsEditing = NO;
    //imgPickerCamera.showsCameraControls = NO;
    imgPickerCamera.navigationBar.barStyle = UIBarStyleBlackOpaque;
    UIImagePickerControllerSourceType sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    if ([UIImagePickerController isSourceTypeAvailable: sourceType])
    {
        imgPickerCamera.sourceType = sourceType;
        [self presentViewController:imgPickerCamera animated:YES completion:nil];
    }
    [imgPickerCamera release];
    

}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info

{
    [picker dismissViewControllerAnimated:YES completion:nil];
    NSLog(@"info------%@",info);
    
    UIImage *image=[info objectForKey:@"UIImagePickerControllerOriginalImage"];
    capturedImageView.hidden=NO;
    
    NSLog(@"-widht---%f",image.size.width);
    NSLog(@"-widht---%f",image.size.height);
    CGSize size;
    if(image.size.height>image.size.width)
        size=CGSizeMake(320, 428);
    else
        size=CGSizeMake(428,320);
    
    UIImage* imageNew = [self imageWithImage:image convertToSize:size];
   
    if(image.size.height>image.size.width)
    {
        NSLog(@"no rotation");
        if(rotate)
        {
            capturedImageView.transform = CGAffineTransformMakeRotation( 0 );
            rotate=NO;
        }
        capturedImageView.frame=CGRectMake(0, 0, 320, 428);
        
        
    }
    else
    {
        NSLog(@"----rotation");
        
        capturedImageView.transform = CGAffineTransformMakeRotation( M_PI/2 );
        capturedImageView.frame=CGRectMake(0, 0, 320, [[ UIScreen mainScreen ] bounds].size.height);
        rotate=YES;
    }

    capturedImageView.image=imageNew;
    capturedImageView.hidden=NO;
   
    
    homeButton.tag=951;
    viewButton.tag=952;
    
    [homeButton setImage:[UIImage imageNamed:@"tick_btn_unpresed_latest.png"] forState:UIControlStateNormal];
    [homeButton setImage:[UIImage imageNamed:@"tick_btn_presed_latest.png"] forState:UIControlStateNormal];
  
    [viewButton setImage:[UIImage imageNamed:@"X_btn_unpresed_latest.png"] forState:UIControlStateNormal];
    [viewButton setImage:[UIImage imageNamed:@"X_btn_presed_latest.png"] forState:UIControlStateNormal];
    
    
    cameraButton.hidden=YES;
    flashButton.hidden=YES;
    showEventdataBtn.hidden=YES;
    
    
    camrollButton.hidden=YES;
    postPoneButton.hidden=YES;
    
    
  
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        CGSize size;
        size=CGSizeMake(640,856);
        UIImage *imageNew=[self imageWithImage:image convertToSize:size];
        self._picData=UIImageJPEGRepresentation(imageNew, 0.6);
        
        
    });
}

- (void) imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    
    [picker dismissModalViewControllerAnimated:YES];
    capturedImageView.hidden=YES;
    NSLog(@"cancal");
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo {
    UIAlertView *alert;
    //NSLog(@"Image:%@", image);
    if (error) {
        alert = [[UIAlertView alloc] initWithTitle:@"Error!"
                                           message:[error localizedDescription]
                                          delegate:nil
                                 cancelButtonTitle:@"OK"
                                 otherButtonTitles:nil];
        [alert show];
        [alert release];
    }
    
}

-(void)saveClickedImage
{
   
    
    capturedImageView.hidden=YES;
    bottomView.hidden=NO;
    
    
    NSString *ChangedPassword=nil;
    NSString *ChangePasswordEventID=nil;
    
    ChangedPassword=[AppHelper userDefaultsForKey:@"ChangedPassword"];
    ChangePasswordEventID=[AppHelper userDefaultsForKey:@"ChangePasswordEventID"];
    
    NSLog(@"ChangedPassword---%@",ChangedPassword);
    NSLog(@"ChangePasswordEventID-----%@",ChangePasswordEventID);
    
    if(([self.selectedParty.partyId isEqualToString:ChangePasswordEventID])&&(ChangedPassword.length!=0))
    {
        
        isChangeGuestPassword=YES;
        UIAlertView *alertView1 = [[UIAlertView alloc]
                                   initWithTitle:@""
                                   message:@"This event has become private. Please ask your host for the password.\n\n      "
                                   delegate:self
                                   cancelButtonTitle:@"OK"
                                   otherButtonTitles:nil];
        alertView1.tag=5001;
        changeGuestPassword.frame=CGRectMake(18, 93, 250, 30);
        [alertView1 addSubview:changeGuestPassword];
        [alertView1 show];
        [alertView1 release];
        changeGuestPassword.text=nil;
        
        [changeGuestPassword becomeFirstResponder];
        
    }
    else
    {
    
            [self uploadImage];
    }

}

- (IBAction)partyInfoButton:(id)sender
{
   
    if(!isPartyInfoVisible)
    {
        [[AppDelegate getAppDelegate] startIndicator];
        //[[AppDelegate getAppDelegate] playButtonClickSound];
        
        NSString *serviceName = Method_Party_Image_Count;
        NSString *urlString =[NSString stringWithFormat:@"%@%@",BaseUrl,serviceName];
        urlString =[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
        [param setObject:self.selectedParty.partyId forKey:@"party_id"];
        
        AFHTTPClient *client= [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:urlString]];
        
        [client getPath:@"" parameters:param success:
         ^(AFHTTPRequestOperation *opration,id responseObject)
         {
             
             [[AppDelegate getAppDelegate] hideIndicator];
             NSString *decodedString = [[[NSString alloc] initWithData:[opration responseData] encoding:NSUTF8StringEncoding] autorelease];
             //decodedString = [StringTransformer transformDecodedString:decodedString];
            // NSLog(@"%@",decodedString);
             NSDictionary *jsonDictD = [decodedString JSONValue];
             NSLog(@"jsonDictD------%@",jsonDictD);
             [jsonDictD objectForKey:@"total_images"];
             
             
             eventName.text=[NSString stringWithFormat:@"%@",self.selectedParty.partyName];
            
             
             
             if([[jsonDictD objectForKey:@"partyType"] isEqualToString:@"Instant"])
             {
                 eventPasswordLabel.text=[NSString stringWithFormat:@"%@",@"None"];
             }
             else
             {
                 eventPasswordLabel.text=[NSString stringWithFormat:@"%@",[jsonDictD objectForKey:@"password"]];
             
             }
             
             photoCountLabel.text=[NSString stringWithFormat:@"%@",[jsonDictD objectForKey:@"total_images"]];
             
             eventCapcityLabel.text=[NSString stringWithFormat:@"%@",[jsonDictD objectForKey:@"capacity"]];
             
             partyInfoView.backgroundColor=[UIColor colorWithRed:00.00 green:00.00 blue:00.00 alpha:0.5];
             partyInfoView.layer.cornerRadius = 10.0;
             partyInfoView.layer.borderColor = [UIColor clearColor].CGColor;
             partyInfoView.layer.borderWidth = 2.0;
             partyInfoView.clipsToBounds = YES;

             
             partyInfoView.frame=CGRectMake(30, 50, 260, 260);
             [self.view addSubview:partyInfoView];
             isPartyInfoVisible=YES;
             [self performSelector:@selector(removePartyInfo) withObject:nil afterDelay:5.0];
             
         }
                failure:
         ^(AFHTTPRequestOperation *opration,NSError *error)
         {
             [[AppDelegate getAppDelegate] hideIndicator];
             
             [AppHelper showAlertViewWithTag:1 title:APP_NAME message:ERROR_INTERNET delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
         }];
        [param release];
        
    }
    else
    {
        [partyInfoView removeFromSuperview];
        isPartyInfoVisible=NO;
    }

}


-(void)removePartyInfo
{
    [partyInfoView removeFromSuperview];
    isPartyInfoVisible=NO;

}

-(IBAction)cancelClickedImage:(id)sender
{
    //[AddPictureOption removeFromSuperview];
    //[[AppDelegate getAppDelegate] playButtonClickSound];

    capturedImageView.hidden=YES;
    
    bottomView.hidden=NO;
    
//    flashButton.hidden=NO;
//    cameraButton.hidden=NO;
//    showEventdataBtn.hidden=NO;
    capturedImageView.image=nil;

   }

-(void)uploadImage
{
    
   // [AddPictureOption removeFromSuperview];

    NSString *str=[AppHelper userDefaultsForKey:@"PostPoneUpload"];
    if([str isEqualToString:@"YES"])
    {
        [self savePendingImage];
        capturedImageView.hidden=YES;
        bottomView.hidden=NO;
//        flashButton.hidden=NO;
//        cameraButton.hidden=NO;
//        showEventdataBtn.hidden=NO;

    }
    else
    {
        BOOL wifiReachable = [[[AppDelegate getAppDelegate]netManager]WiFinetworkReachable];
        BOOL netReachable = [[[AppDelegate getAppDelegate]netManager] networkReachable];
        if(netReachable)
        {
            
            if(wifiReachable)
            {
                
                
                //You can add POST parameteres here
                NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
                [parameters setObject:self.selectedParty.partyId forKey:@"party_id"];
                [parameters setObject:[AppDelegate getAppDelegate].pickUpAddres forKey:@"location"];
                [parameters setObject:self.selectedParty.guestPassword forKey:@"guest_pass"];
                
                
                [self saveImageInsharedAlbum:parameters];
                [parameters release];
                
                
            }
            else
            {
                
                [AppHelper saveToUserDefaults:@"Off" withKey:@"WiFi"];
                
                NSString *str=[AppHelper userDefaultsForKey:@"uploadOnNetWork"];
                if([str isEqualToString:@"YES"])
                {
                    
                    //[[AppDelegate getAppDelegate] startIndicator];
                    
                    
                    NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
                    
                    [parameters setObject:self.selectedParty.partyId forKey:@"party_id"];
                    [parameters setObject:[AppDelegate getAppDelegate].pickUpAddres forKey:@"location"];
                    [parameters setObject:self.selectedParty.guestPassword forKey:@"guest_pass"];
                    
                    
                    [self saveImageInsharedAlbum:parameters];
                    [parameters release];
                    
                    
                }
                else
                {
                    UIAlertView *alert = [[UIAlertView alloc]
                                           initWithTitle:APP_NAME
                                           message:@""
                                           delegate:self
                                           cancelButtonTitle:@""
                                           otherButtonTitles:@"Upload over cellular network", @"Wait until wifi available",
                                           nil]
                                          ;
                    [[alert viewWithTag:1] removeFromSuperview];
                    [alert show];
                    [alert release];
                }
                
            }
            
        }
        else
        {
            bottomView.hidden=NO;
            //  bottomSaveView.hidden=YES;
            
//            homeButton.tag=451;
//            viewButton.tag=452;
//            
//            [homeButton setImage:[UIImage imageNamed:@"home-normal-camera.png"] forState:UIControlStateNormal];
//            [viewButton setImage:[UIImage imageNamed:@"View-normal-camera.png"] forState:UIControlStateNormal];
//            
//            [homeButton setImage:[UIImage imageNamed:@"home-active-camera.png"] forState:UIControlStateHighlighted];
//            [viewButton setImage:[UIImage imageNamed:@"View-active-camera.png"] forState:UIControlStateHighlighted];
            
            capturedImageView.hidden=YES;
          //  showEventdataBtn.hidden=NO;
            
            capturedImageView.image=nil;
//            cameraButton.hidden=NO;
//            flashButton.hidden=NO;
            
            [AppHelper saveToUserDefaults:@"Off" withKey:@"WiFi"];
            
            [self savePendingImage];
            [AppHelper showAlertViewWithTag:1 title:APP_NAME message:@"No cellular network or wifi available. Photos will be stored on device, and uploaded later." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
            
        }

    }
        
    
    
}
-(void)saveImageInsharedAlbum:(NSMutableDictionary*)mDict
{
    
    NSMutableDictionary *parameters=mDict;
    [self showUploading];
    [self performSelector:@selector(removeUploadingImage) withObject:nil afterDelay:1.0];
    
    AFHTTPClient *client= [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:BaseUrl]];
    
    NSDate *destinationDate = [NSDate date];
    NSTimeZone* currentTimeZone = [NSTimeZone localTimeZone];
    NSInteger currentGMTOffset = [currentTimeZone secondsFromGMT];
    [destinationDate dateByAddingTimeInterval:currentGMTOffset];
    [parameters setObject:[NSString stringWithFormat:@"%@",destinationDate] forKey:@"date"];
    
    #if TARGET_IPHONE_SIMULATOR
            [parameters setObject:@"211466" forKey:@"device_id"];
    #else
        if([AppHelper userDefaultsForKey:@"Token"])
            [parameters setObject:[AppHelper userDefaultsForKey:@"Token"] forKey:@"device_id"];
    #endif
        NSLog(@"---%@",parameters);

    
     NSMutableURLRequest *request = [client multipartFormRequestWithMethod:@"POST" path:Method_Add_Image parameters:parameters constructingBodyWithBlock: ^(id <AFMultipartFormData>formData)
    {
        
        if(self._picData)
            NSLog(@"-----data found----");
        
        [formData appendPartWithFileData:self._picData name:@"image" fileName:@"zorba.jpg" mimeType:@"image/jpg"];
                                          
    }];
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     
     {
         
        // [[AppDelegate getAppDelegate]hideIndicator];
         self._picData=nil;
         NSString *response = [operation responseString];
         NSLog(@"response: %@",response);
         NSDictionary *jsonDictD = [response JSONValue];
         NSLog(@"jsonDictD: %@",jsonDictD);
         
//         if([[jsonDictD valueForKey:@"errcode"] intValue]==0)
//         {
//             NSLog(@"image Uploaded");
//             Party *par=self.selectedParty;
//             NSManagedObjectContext *context = [[AppDelegate getAppDelegate] managedObjectContext];
//             NSFetchRequest *fetchRequest = [[NSFetchRequest alloc] init];
//             NSEntityDescription *entity = [NSEntityDescription entityForName:@"Party" inManagedObjectContext:context];
//             NSPredicate *predicate = [NSPredicate predicateWithFormat:@"partyId == %i", [par.partyId intValue]];
//             NSError *error;
//             [fetchRequest setPredicate:predicate];
//             [fetchRequest setEntity:entity];
//             [fetchRequest release];
//             
//             NSString *str11=[[[jsonDictD objectForKey:@"result"]objectForKey:@"total_img"]valueForKey:@"total_img"];
//             NSLog(@"%@",str11);
//             
//             par.imageCount=str11;
//             
//             if (![context save:&error])
//             {
//             }
//             
//             bottomView.hidden=NO;
//             capturedImageView.hidden=YES;
//             showEventdataBtn.hidden=NO;
//             flashButton.hidden=NO;
//             cameraButton.hidden=NO;
//             capturedImageView.image=nil;
//             NSString *str=[AppHelper userDefaultsForKey:@"photoCount"];
//            
//             if([str intValue]==2)
//             {
//                 
//                 IsUploadAllPhoto=YES;
//                 [AppHelper showAlertViewWithTag:1 title:APP_NAME message:@"Done! Do you wish to automatically add all photos to the event album? " delegate:self cancelButtonTitle:@"No" otherButtonTitles:@"Yes"];
//                 
//             }
//             else
//             {
//             
//                 [AppHelper showAlertViewWithTag:1 title:APP_NAME message:@"Image uploaded successfully." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//                 
//             }
//             NSString *strNew=[NSString stringWithFormat:@"%d",[str intValue]+1];
//             [AppHelper saveToUserDefaults:strNew withKey:@"photoCount"];
//         }
//         else if ([[jsonDictD valueForKey:@"errcode"] intValue]==1)
//         {
//             
//             NSString* str=[NSString stringWithFormat:@"%@%@%@",@"Sorry, the event \"",selectedParty.partyName,@"\" has ended. Please start a new event."];
//             [[Services sharedInstance] endMyActiveParty:self.selectedParty.partyId];
//
//            [AppHelper showAlertViewWithTag:12345 title:APP_NAME message:str delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//         }
//         else if([[jsonDictD valueForKey:@"errcode"] intValue]==2)
//         {
//             
//             [AppHelper showAlertViewWithTag:1 title:APP_NAME message:[jsonDictD valueForKey:@"errstr"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             
//                       
//         }
//         else if([[jsonDictD valueForKey:@"errcode"] intValue]==3)
//         {
//             isPartyEnded=YES;
//             [AppHelper showAlertViewWithTag:1 title:APP_NAME message:[jsonDictD valueForKey:@"errstr"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             
//             guestPassword.text=nil;
//             UIAlertView *alertView = [[UIAlertView alloc]
//                                       initWithTitle:@""
//                                       message:@" "
//                                       delegate:self
//                                       cancelButtonTitle:nil
//                                       otherButtonTitles:@"OK",nil];
//             alertView.tag=8001;
//             guestPassword.frame=CGRectMake(20, 20, 258, 40);
//             [alertView addSubview:guestPassword];
//             [alertView show];
//             [alertView release];
//             [guestPassword becomeFirstResponder];
//         }
//         else
//         {
//             
//             [AppHelper showAlertViewWithTag:1 title:APP_NAME message:[jsonDictD valueForKey:@"errstr"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
//             
//         }
         
     }
    failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         
         [AppHelper showAlertViewWithTag:1 title:APP_NAME message:ERROR_INTERNET delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
         
         [[AppDelegate getAppDelegate]hideIndicator];
         
         NSLog(@"error: %@", [operation error]);
         
         [self hideIndicator];
         
     }];
    [operation start];
    [operation release];
    
    
    
}

-(void)savePendingImage
{
//    NSString*  documentFolderPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents"];
//    documentFolderPath = [documentFolderPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@%@",@"pending",self.selectedParty.partyId]];
//    //documentFolderPath = [documentFolderPath stringByAppendingPathComponent:self.selectedParty.partyId];
    NSDate *dt=[NSDate date];
//    NSString *filePath = [documentFolderPath stringByAppendingPathComponent:[NSString stringWithFormat:@"%@%@",dt,@".jpg"]];
    
    
    NSLog(@"self.selectedParty.partyPendingImages---------%@",[self.selectedParty.partyPendingImage allObjects]);
       
    [[Services sharedInstance] insertPendingImage:self.selectedParty.partyId
                                    imageName:[NSString stringWithFormat:@"%@%@",dt,@".jpg"]
                                imageLocation:[AppDelegate getAppDelegate].pickUpAddres
                                    imageDate:[NSString stringWithFormat:@"%@",dt]
                                    imageData:self._picData];
    
    
    NSLog(@"self.selectedParty.partyPendingImages-count--------%d",[self.selectedParty.partyPendingImage allObjects].count);

//    NSMutableArray *marr=[AppDelegate getAppDelegate].pendingArray;
//    NSLog(@"marr------%@",marr);
//    NSMutableArray *arr;
//    if(marr.count!=0)
//    {
//        arr=marr;
//        NSLog(@"first time");
//    }
//    else
//    {
//        NSLog(@"aasdasdasdasdSA");
//        arr=[[[NSMutableArray alloc]init]autorelease];
//    }
//    NSLog(@"arr------%@",arr);
//    
//    NSMutableDictionary *dict=[[NSMutableDictionary alloc]init];
//    [dict setObject:[NSString stringWithFormat:@"%@%@",dt,@".jpg"] forKey:@"image"];
//    [dict setObject:[AppDelegate getAppDelegate].pickUpAddres forKey:@"location"];
//    [dict setObject:dt forKey:@"date"];
//    
//    
//    [arr addObject:dict];
//    [dict release];
//    [AppDelegate getAppDelegate].pendingArray=arr;
//    
//    
//    
//    
//    NSLog(@"[AppDelegate getAppDelegate].pendingArray---%@",[AppDelegate getAppDelegate].pendingArray);
//    NSLog(@"filePath-------------------%@",filePath);
//    
//    
//    
//    NSFileManager *fileManager = [NSFileManager defaultManager];
//    BOOL isDir;
//    
//    if (([fileManager fileExistsAtPath:documentFolderPath isDirectory:&isDir] && isDir) == FALSE)
//    {
//        
//        [[NSFileManager defaultManager]createDirectoryAtPath:documentFolderPath withIntermediateDirectories:NO attributes:nil error:noErr];
//        
//    }
//    [self._picData writeToFile:filePath atomically:YES];
    self._picData=nil;
    
    
}




- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    //[[AppDelegate getAppDelegate] playButtonClickSound];
    if(alertView.tag==50&&buttonIndex==1)
    {
        [self showRegistrationAlert];
    }
    
    if(alertView.tag==50&&buttonIndex==2)
    {
        if ([[FaceBookEngine sharedInstance] checkInternateConnection])
        {
            
            [self performSelector:@selector(loginWithFacebook) withObject:nil afterDelay:0.5];
            
        }
        else
        {
            [AppHelper showAlertViewWithTag:0 title:APP_NAME message:ERROR_INTERNET delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok_Button];
        }
    }
    if(alertView.tag==80&&buttonIndex==1)
    {
        NSString *emailRegEx = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
        NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
        if ([_emailTextField.text length]>0 && [emailTest evaluateWithObject:_emailTextField.text] == YES)
        {
            
            [[AppDelegate getAppDelegate] startIndicator];
            [[NSNotificationCenter defaultCenter] addObserver:self
                                                     selector:@selector(emailRegisterResponse:)
                                                         name:Notification_Email_Register
                                                       object:nil];
            
            [[Services sharedInstance] registerEmailForAlbum:_emailTextField.text andpassword:passTextField.text];
            
        }
        else
        {
            [AppHelper showAlertViewWithTag:0 title:APP_NAME message:@"Enter Email in valid Format" delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok_Button];
        }
        
    }
    
    if (alertView.tag==8000)
    {
        if(buttonIndex==0)
        {
            UpgradeOptionVC *upgrade=[[UpgradeOptionVC alloc]initWithNibName:@"UpgradeOptionVC" bundle:nil];
            upgrade.isfromcamera=YES;
            [self.navigationController pushViewController:upgrade animated:YES];
            [upgrade release];
        }
        else
        {
            PartyPhotoGridVC *photoGrid=[[PartyPhotoGridVC alloc]initWithNibName:@"PartyPhotoGridVC" bundle:nil];
            photoGrid.selectedParty=self.selectedParty;
            [self.navigationController pushViewController:photoGrid animated:YES];
            [photoGrid release];
            
        }
    }
    if (alertView.tag==8001)
    {
        
            PartyPhotoGridVC *photoGrid=[[PartyPhotoGridVC alloc]initWithNibName:@"PartyPhotoGridVC" bundle:nil];
            photoGrid.selectedParty=self.selectedParty;
            [self.navigationController pushViewController:photoGrid animated:YES];
            [photoGrid release];
        
        
    }
    if(alertView.tag==12345)
    {
    
        [[AppDelegate getAppDelegate] showHomePage];
        
    }
    if(alertView.tag==4000)
    {
        
        if(buttonIndex==0)
        {
            postPoneButton.selected=NO;
            uploadholdImages=NO;
            [AppHelper saveToUserDefaults:@"NO" withKey:@"PostPoneUpload"];

        }
        
    }
    if(alertView.tag!=4000&alertView.tag!=50&alertView.tag!=80&alertView.tag!=8000&alertView.tag!=8001)
    {
    switch (buttonIndex)
    {
        case 0:
        {
            if(IsUploadAllPhoto)
            {
                IsUploadAllPhoto=NO;
                [AppHelper saveToUserDefaults:@"0" withKey:@"photoCount"];
            }
            else if(isPostPoneUpload)
            {
                isPostPoneUpload=NO;
                postPoneButton.selected=YES;
                [AppHelper saveToUserDefaults:@"YES" withKey:@"PostPoneUpload"];
            }
            else if(uploadholdImages)
            {
                postPoneButton.selected=NO;
                uploadholdImages=NO;
                 [self uploadAllHoldImage];            
            }
            else if(isPartyEnded)
            {
                isPartyEnded=NO;
                [[Services sharedInstance] endMyActiveParty:self.selectedParty.partyId];
                [[AppDelegate getAppDelegate] showHomePage];
            }
            else if(isUploadFromCameraRoll)
            {
                isUploadFromCameraRoll=NO;
                [self selectPhotoGallery];

            }

        }
            break;
        case 1:
        {
            
            if(IsUploadAllPhoto)
            {
                IsUploadAllPhoto=NO;
                isAutoUpload=YES;
                [AppHelper saveToUserDefaults:@"YES" withKey:@"autoUpload"];
                
            }
            else if(isPostPoneUpload)
            {
                isPostPoneUpload=NO;
                postPoneButton.selected=NO;
            }
            else if(isUploadFromCameraRoll)
            {
                isUploadFromCameraRoll=NO;
            }
            else
            {
                
                NSLog(@"upload over network");
                [AppHelper saveToUserDefaults:@"YES" withKey:@"uploadOnNetWork"];
                NSMutableDictionary *parameters = [[NSMutableDictionary alloc] init];
                [parameters setObject:self.selectedParty.partyId forKey:@"party_id"];
                [parameters setObject:[AppDelegate getAppDelegate].pickUpAddres forKey:@"location"];
                [parameters setObject:self.selectedParty.guestPassword forKey:@"guest_pass"];
                [self saveImageInsharedAlbum:parameters];
                [parameters release];
                
            }
            
            
        }
            break;
        case 2:
        {
            
            
            NSLog(@"no upload");
            [self savePendingImage];
            bottomView.hidden=NO;

            
            capturedImageView.hidden=YES;
//            showEventdataBtn.hidden=NO;
//            flashButton.hidden=NO;
//            cameraButton.hidden=NO;
            capturedImageView.image=nil;
            
        }
        break;
    }
    }
    if (alertView.tag==5001)
    {
        
        isChangeGuestPassword=NO;
        NSString *ChangedPassword=[AppHelper userDefaultsForKey:@"ChangedPassword"];
        if([ChangedPassword isEqualToString:changeGuestPassword.text])
        {
            [AppHelper saveToUserDefaults:nil withKey:@"ChangedPassword"];
            [AppHelper saveToUserDefaults:nil withKey:@"ChangePasswordEventID"];
            [[Services sharedInstance] updateEventLocally:self.selectedParty.partyId password:guestPassword.text eventType:@"Private"];
        }
        
    }
}


-(void)currentEvenHasEnded
{

    NSString *Str=[NSString stringWithFormat:@"%@ %@",self.selectedParty.partyName,@"has ended. Please start a new event to upload more photos"];

    [[Services sharedInstance] endMyActiveParty:self.selectedParty.partyId];

    [AppHelper showAlertViewWithTag:12345 title:APP_NAME message:Str delegate:self
              cancelButtonTitle:@"OK" otherButtonTitles:nil];

}




-(void)uploadAllHoldImage
{
    [self startIndicator];

    NSArray *arr=[self.selectedParty.partyPendingImage allObjects];
    AFHTTPClient *httpclient= [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:BaseUrl]];
    
  //  NSLog(@"-----httpclient-----%@",httpclient);
    
    NSMutableDictionary *parameters=[[NSMutableDictionary alloc]init];
    [parameters setObject:[NSString stringWithFormat:@"%d",arr.count] forKey:@"image_count"];
    [parameters setObject:self.selectedParty.partyId forKey:@"party_id"];
    [parameters setObject:self.selectedParty.guestPassword forKey:@"guest_pass"];
    for(int i=0;i<arr.count;i++)
    {
        PendingImages *pImage=[arr objectAtIndex:i];
        [parameters setObject:pImage.imageDate forKey:[NSString stringWithFormat:@"%@%d",@"date_",i+1]];
        [parameters setObject:pImage.imagelocation forKey:[NSString stringWithFormat:@"%@%d",@"location_",i+1]];
        
    }
    
    
    #if TARGET_IPHONE_SIMULATOR
        [parameters setObject:@"211466" forKey:@"device_id"];
    #else
        if([AppHelper userDefaultsForKey:@"Token"])
                [parameters setObject:[AppHelper userDefaultsForKey:@"Token"] forKey:@"device_id"];
    #endif
    
    
        NSMutableURLRequest *request = [httpclient multipartFormRequestWithMethod:@"POST" path:Method_Load_Pending_Image parameters:parameters constructingBodyWithBlock: ^(id <AFMultipartFormData>formData)
          {
              
              
             for(int i=0;i<arr.count;i++)
             {
                 PendingImages *pImage=[arr objectAtIndex:i];
                 NSString *key=[NSString stringWithFormat:@"%@%d",@"image_",i+1];
                 NSLog(@"key----%@",key);
                 [formData appendPartWithFileData:pImage.imageData name:key fileName:pImage.imageDate mimeType:@"image/jpg"];
             }
                                        
                                        
             
         }];
    
        operation111 = [[AFHTTPRequestOperation alloc] initWithRequest:request];
        [operation111 setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
        {
         
            [self hideIndicator];
            NSString *response = [operation responseString];
            NSLog(@"response: %@",response);
            NSDictionary *jsonDictD = [response JSONValue];
            NSLog(@"jsonDictD: %@",jsonDictD);
            if([[jsonDictD valueForKey:@"errcode"] intValue]==0)
            {
                postPoneButton.selected=NO;
                [AppHelper saveToUserDefaults:@"NO" withKey:@"PostPoneUpload"];
                [AppHelper showAlertViewWithTag:1 title:APP_NAME message:@"Image uploaded successfully." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [[Services sharedInstance] deletePendingImage:self.selectedParty.partyId];
             
            }
         
        }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             [self hideIndicator];
             postPoneButton.selected=YES;
             [AppHelper showAlertViewWithTag:1 title:APP_NAME message:ERROR_INTERNET delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
             NSLog(@"error: %@", [operation error]);
         
         
         }];
        [operation111 start];
        [operation111 release];

}


- (IBAction)uploadCancel:(id)sender
{
    [self hideIndicator];
    [operation111 pause];
    [operation111 cancel];

    postPoneButton.selected=NO;
    [AppHelper saveToUserDefaults:@"NO" withKey:@"PostPoneUpload"];
    
    [[Services sharedInstance] deletePendingImage:selectedParty.partyId];
    
    [AppHelper showAlertViewWithTag:1 title:APP_NAME message:@"Upload cancelled. You can upload remaining photos at any time." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
   
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{

}



//-(void)startIndicator
//{
//    
//    
//    if([activityIndicatorView superview] == nil)
//    {
//        activityIndicatorView.frame = CGRectMake(120, 190, 80, 80);
//        [self.view addSubview:activityIndicatorView];
//        
//        CALayer *layer = [activityIndicatorView layer];
//        [layer setMasksToBounds:YES];
//        [layer setCornerRadius:0.0];
//        [layer setBorderWidth:0.0];
//        if ([layer respondsToSelector:@selector(setShouldRasterize:)])
//        {
//            [layer setShouldRasterize:YES];
//        }
//    }
//}

/// Remove indicator view from screen..
//
//-(void)hideIndicator
//{
//    [activityIndicatorView removeFromSuperview];
//    
//}
//
//
//


#pragma mark - pop up lifecycle

-(void)initialDelayEnded:(UIView*)popView
{
    
    popView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.001, 0.001);
    popView.alpha = 1.0;
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:.4];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(bounce1AnimationStopped:)];
    popView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 1.0, 1.0);
    [UIView commitAnimations];
}

- (void)bounce1AnimationStopped:(UIView*)popView
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationDidStopSelector:@selector(bounce2AnimationStopped:)];
    popView.transform = CGAffineTransformScale(CGAffineTransformIdentity, 0.9, 0.9);
    [UIView commitAnimations];
}

- (void)bounce2AnimationStopped:(UIView*)popView
{
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:0.2];
    popView.transform = CGAffineTransformIdentity;
    [UIView commitAnimations];
    
}

// hide indicator view form screen...

-(void)hideIndicator
{
    [activityIndicatorView removeFromSuperview];
    self.view.userInteractionEnabled=YES;
    //headerView.userInteractionEnabled=YES;
    
}
-(void)startIndicator
{
    
    if([activityIndicatorView superview] == nil)
    {
        activityIndicatorView.frame = CGRectMake(0, 0, 320, 480);
        activityIndicatorView.backgroundColor=[UIColor colorWithRed:00.00/256.00 green:00.00/256.00 blue:00.00/256.00 alpha:0.8];
        [self.view addSubview:activityIndicatorView];
        
        //CALayer *layer = [activityIndicatorView layer];
        //[layer setMasksToBounds:YES];
        // [layer setCornerRadius:8.0];
        // [layer setBorderWidth:1.0];
        //        if ([layer respondsToSelector:@selector(setShouldRasterize:)])
        //        {
        //            [layer setShouldRasterize:YES];
        //        }
        
    }
    // self.view.userInteractionEnabled=NO;
    
    
    
    
}


-(void)showUploading
{

    if([uploadingView superview] == nil)
    {
        uploadingView.frame = CGRectMake(110, self.view.frame.size.height/2-50, 100, 100);
        [self.view addSubview:uploadingView];
        
        CALayer *layer = [activityIndicatorView layer];
        [layer setMasksToBounds:YES];
         [layer setCornerRadius:8.0];
         [layer setBorderWidth:1.0];
                if ([layer respondsToSelector:@selector(setShouldRasterize:)])
                {
                    [layer setShouldRasterize:YES];
                }
        
    }
    [AppDelegate getAppDelegate].window.userInteractionEnabled=NO;


}

-(void)removeUploadingImage
{
    [AppDelegate getAppDelegate].window.userInteractionEnabled=YES;
    [uploadingView removeFromSuperview];
}

-(BOOL)shouldAutorotate
{
    NSLog(@"gasjfhgjdfgjdsjfgsdgfgdsjgfjhdsfghdsfsd");
    return NO;
}

//#ifndef SYSTEM_VERSION_LESS_THAN(6.0)

- (NSUInteger)supportedInterfaceOrientations
{
    NSLog(@"gasjfhgjdfgjd1234455sjfgsdgfgdsjgfjhdsfghdsfsd");
    
    return UIDeviceOrientationPortrait;
}


//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
//{
//
//    //    if (interfaceOrientation==UIDeviceOrientationPortrait || interfaceOrientation==UIDeviceOrientationPortraitUpsideDown)
//    //        return YES;
//     NSLog(@"below 6,0");
//
//    return NO;
//
//}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    NSLog(@"hsdhadkhakdhasdasdasd");
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    NSLog(@"%f---%f--%f---%f",self.captureVideoPreviewLayer.frame.origin.x,self.captureVideoPreviewLayer.frame.origin.y,self.captureVideoPreviewLayer.frame.size.width,self.captureVideoPreviewLayer.frame.size.height);
    NSLog(@"will rotate...");
    NSLog(@"-------%@",self.videoPreviewView);
    self.captureVideoPreviewLayer.frame=self.videoPreviewView.frame;
    NSLog(@"%@",bottomView);
    NSLog(@"%f---%f--%f---%f",self.captureVideoPreviewLayer.frame.origin.x,self.captureVideoPreviewLayer.frame.origin.y,self.captureVideoPreviewLayer.frame.size.width,self.captureVideoPreviewLayer.frame.size.height);
    NSLog(@"self.view----%@",self.view);
    self.captureVideoPreviewLayer.backgroundColor=[UIColor redColor].CGColor;
    //currntOrientation=toInterfaceOrientation;
    // NSLog(@"noRecordFound--%@",noRecordFound);
    // [self setUIControls:toInterfaceOrientation];
    
    
    
}

-(IBAction)postPoneImageClicked:(id)sender
{
    //[[AppDelegate getAppDelegate] playButtonClickSound];
    
    NSString *str=[AppHelper userDefaultsForKey:@"PostPoneUpload"];
    if([str isEqualToString:@"YES"])
    {
        NSLog(@"having some pending images");
        NSArray *arr=[self.selectedParty.partyPendingImage allObjects];
        if(arr.count!=0)
        {
            uploadholdImages=YES;
            [AppHelper showAlertViewWithTag:1 title:APP_NAME message:@"Uploading of photos will recommence." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
        else
        {
            postPoneButton.selected=NO;
            uploadholdImages=NO;
            [AppHelper saveToUserDefaults:@"NO" withKey:@"PostPoneUpload"];
            //[AppHelper showAlertViewWithTag:4000 title:APP_NAME message:@"You have no photo pending uploading for this event." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
        }
    }
    else
    {
    
        isPostPoneUpload=YES;
        [AppHelper showAlertViewWithTag:1 title:APP_NAME message:@"Do you want to postpone upload of your photos until later?" delegate:self cancelButtonTitle:@"Yes" otherButtonTitles:@"No"];
    }
}



- (void)viewDidUnload
{
    [upperImage release];
    upperImage = nil;
    [lowerImage release];
    lowerImage = nil;
    [partyInfoView release];
    partyInfoView = nil;
    [eventPasswordLabel release];
    eventPasswordLabel = nil;
    [photoCountLabel release];
    photoCountLabel = nil;
    [eventCapcityLabel release];
    eventCapcityLabel = nil;
    _emailTextField=nil;
    nameTextField=nil;
    passTextField=nil;
    [cameraLayerImage release];
    cameraLayerImage = nil;
    [super viewDidUnload];
}
@end

@implementation AVCamViewController (InternalMethods)

@end

@implementation AVCamViewController (AVCamCaptureManagerDelegate)

- (void)captureManager:(AVCamCaptureManager *)captureManager didFailWithError:(NSError *)error
{
//    CFRunLoopPerformBlock(CFRunLoopGetMain(), kCFRunLoopCommonModes, ^(void) {
//        UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:[error localizedDescription]
//                                                            message:[error localizedFailureReason]
//                                                           delegate:nil
//                                                  cancelButtonTitle:NSLocalizedString(@"OK", @"OK button title")
//                                                  otherButtonTitles:nil];
//        [alertView show];
//        [alertView release];
//    });
}

- (void)captureManagerRecordingBegan:(AVCamCaptureManager *)captureManager
{
    NSLog(@"mmmmmmmmmmmmmaghsdhjasgdjgasjdgjasda");
}

- (void)captureManagerRecordingFinished:(AVCamCaptureManager *)captureManager
{

}
- (UIImage*)imageByCropping:(UIImage *)imageToCrop toRect:(CGRect)rect
{
    CGImageRef imageRef = CGImageCreateWithImageInRect([imageToCrop CGImage], rect);
    UIImage *cropped = [UIImage imageWithCGImage:imageRef];
    return cropped;
    
    
}
- (void)captureManagerStillImageCaptured:(AVCamCaptureManager *)captureManager
{
   
    NSLog(@"-width--%f",[self captureManager].capturedImage.size.width);
    NSLog(@"--height-%f",[self captureManager].capturedImage.size.height);

        
    UIImage *image=[self captureManager].capturedImage;

    [self setImage:image];
    cameraButton.hidden=YES;
    flashButton.hidden=YES;
    showEventdataBtn.hidden=YES;
    
    camrollButton.hidden=YES;
    postPoneButton.hidden=YES;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        CGSize size;
        if(image.size.height>image.size.width)
            size=CGSizeMake(640, 856);
        else
            size=CGSizeMake(856,640);
        
         UIImage *imageNew=[self imageWithImage:image convertToSize:size];
        self._picData=UIImageJPEGRepresentation(imageNew, 0.6);
        
        
    });
    
   
    
}





-(void)setImage:(UIImage*)image
{
    CGSize size;
    if(image.size.height>image.size.width)
        size=CGSizeMake(320, 428);
    else
        size=CGSizeMake(428,320);
    
    UIImage* imageNew = [self imageWithImage:image convertToSize:size];    
    if(image.size.height>image.size.width)
    {
        
        UIInterfaceOrientation toInterfaceOrientation = [[UIDevice currentDevice] orientation];
        capturedImageView.transform = CGAffineTransformMakeRotation( 0 );
        
        NSLog(@"portriat...");
        if (toInterfaceOrientation == UIInterfaceOrientationPortrait)
        {
            NSLog(@"portriat..IN.");
            
            capturedImageView.transform = CGAffineTransformMakeRotation( 0 );
            if(rotate)
            {
                rotate=NO;
            }
        }
        else
        {
            NSLog(@"portriat..Out.");
            
            //capturedImageView.transform = CGAffineTransformMakeRotation(- M_PI );
            
        }
        
        if([AppHelper is4InchRetina])
        {
            capturedImageView.frame=CGRectMake(0, 0, 320, [[ UIScreen mainScreen ] bounds].size.height);
            
        }
        else
        {
            capturedImageView.frame=CGRectMake(0, 0, 320, 428);
            
        }
        
        NSLog(@"capturedImageView----%@",capturedImageView);
        
    }
    else
    {
        UIInterfaceOrientation toInterfaceOrientation = [[UIDevice currentDevice] orientation];
        
        if (toInterfaceOrientation == UIInterfaceOrientationLandscapeLeft)
        {
            NSLog(@"----Landscape Left");
            capturedImageView.transform = CGAffineTransformMakeRotation(-M_PI/2 );
            
            
        }
        else
        {
            NSLog(@"----Landscape right");
            capturedImageView.transform = CGAffineTransformMakeRotation( M_PI/2 );
            
        }
        
        if([AppHelper is4InchRetina])
        {
            capturedImageView.frame=CGRectMake(0, 0, 320, [[ UIScreen mainScreen ] bounds].size.height);
        }
        else
        {
            capturedImageView.frame=CGRectMake(0, 0, 320, 428);
            
        }
        rotate=YES;
    }
    
    capturedImageView.backgroundColor=[UIColor blackColor];
    capturedImageView.contentMode=UIViewContentModeScaleAspectFit;
    capturedImageView.image=imageNew;
    capturedImageView.hidden=NO;
    bottomView.hidden=NO;
    
    homeButton.tag=951;
    viewButton.tag=952;
    
    [homeButton setImage:[UIImage imageNamed:@"tick_btn_unpresed_latest.png"] forState:UIControlStateNormal];
    [homeButton setImage:[UIImage imageNamed:@"tick_btn_presed_latest.png"] forState:UIControlStateNormal];
    
    [viewButton setImage:[UIImage imageNamed:@"X_btn_unpresed_latest.png"] forState:UIControlStateNormal];
    [viewButton setImage:[UIImage imageNamed:@"X_btn_presed_latest.png"] forState:UIControlStateNormal];
    


}

- (UIImage *)imageWithImage:(UIImage *)image convertToSize:(CGSize)size
{
    UIGraphicsBeginImageContext(size);
    [image drawInRect:CGRectMake(0, 0, size.width, size.height)];
    UIImage *destImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return destImage;
}


- (void)captureManagerDeviceConfigurationChanged:(AVCamCaptureManager *)captureManager
{
    NSLog(@"cccccccc");
}

-(void)getImageFromLib
{
    
    
    ALAssetsLibrary *library = [[ALAssetsLibrary alloc] init];
    
    // Enumerate just the photos and videos group by using ALAssetsGroupSavedPhotos.
    [library enumerateGroupsWithTypes:ALAssetsGroupSavedPhotos usingBlock:^(ALAssetsGroup *group, BOOL *stop) {
        
        // Within the group enumeration block, filter to enumerate just photos.
        [group setAssetsFilter:[ALAssetsFilter allPhotos]];
        
        NSLog(@"no os asset%i",group.numberOfAssets);
        
        if(group.numberOfAssets>0)
        {
        // Chooses the photo at the last index
        [group enumerateAssetsAtIndexes:[NSIndexSet indexSetWithIndex:([group numberOfAssets] - 1)] options:0 usingBlock:^(ALAsset *alAsset, NSUInteger index, BOOL *innerStop)
        {
            
            // The end of the enumeration is signaled by asset == nil.
            if (alAsset)
            {
                ALAssetRepresentation *representation = [alAsset defaultRepresentation];
                UIImage *latestPhoto = [UIImage imageWithCGImage:[representation fullScreenImage]];
                
                // Do something interesting with the AV asset.
//                [self sendTweet:latestPhoto];
                 [camrollButton setBackgroundImage:latestPhoto forState:UIControlStateNormal];
            }
            
        }];
        }
        else
        {
            [cameraButton setBackgroundImage:nil forState:UIControlStateNormal];
  
        }
    }
    failureBlock: ^(NSError *error)
     {
        // Typically you should handle an error more gracefully than this.
        NSLog(@"No groups");
    }];
    

}




@end
