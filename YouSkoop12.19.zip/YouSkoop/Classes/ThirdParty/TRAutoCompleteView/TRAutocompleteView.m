//
// Copyright (c) 2013, Taras Roshko
// All rights reserved.
//
// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:
//
// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer.
// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.
//
// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR
// ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
// (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
// LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
// ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
// (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
// SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
//
// The views and conclusions contained in the software and documentation are those
// of the authors and should not be interpreted as representing official policies,
// either expressed or implied, of the FreeBSD Project.
//

#import "TRAutocompleteView.h"
#import "TRAutocompleteItemsSource.h"
#import "TRAutocompletionCellFactory.h"
#import "TRGoogleMapsSuggestion.h"

@interface TRAutocompleteView () <UITableViewDelegate, UITableViewDataSource>

@property(readwrite) id <TRSuggestionItem> selectedSuggestion;
@property(readwrite) NSArray *suggestions;
@property(readwrite) NSMutableArray *searchArray;

@end

@implementation TRAutocompleteView

{
    BOOL _visible;
    
    __weak UITextField *_queryTextField;
    //__strong UIViewController *_contextController;
    
    UITableView *_table;
    id <TRAutocompleteItemsSource> _itemsSource;
    id <TRAutocompletionCellFactory> _cellFactory;
}
//@synthesize isKeyBoardVisible;
@synthesize sugstn;
@synthesize _contextController;
+ (TRAutocompleteView *)autocompleteViewBindedTo:(UITextField *)textField
                                     usingSource:(id <TRAutocompleteItemsSource>)itemsSource
                                     cellFactory:(id <TRAutocompletionCellFactory>)factory
                                    presentingIn:(UIViewController *)controller
{
    
   
    return [[TRAutocompleteView alloc] initWithFrame:CGRectZero
                                           textField:textField
                                         itemsSource:itemsSource
                                         cellFactory:factory
                                          controller:controller];
}

- (id)initWithFrame:(CGRect)frame
          textField:(UITextField *)textField
        itemsSource:(id <TRAutocompleteItemsSource>)itemsSource
        cellFactory:(id <TRAutocompletionCellFactory>)factory
         controller:(UIViewController *)controller
{
    self = [super initWithFrame:frame];
    if (self)
    {
        
        [self loadDefaults];
        
        _queryTextField = textField;
        _itemsSource = itemsSource;
        _cellFactory = factory;
        self._contextController = controller;
        
        _table = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
        _table.backgroundColor = [UIColor clearColor];
        _table.separatorColor = self.separatorColor;
        _table.separatorStyle = self.separatorStyle;
        _table.delegate = self;
        _table.dataSource = self;
        
        [[NSNotificationCenter defaultCenter]
         addObserver:self
         selector:@selector(queryChanged:)
         name:UITextFieldTextDidChangeNotification
         object:_queryTextField];
        
//        [[NSNotificationCenter defaultCenter] addObserver:self
//                                                 selector:@selector(keyboardWasShown:)
//                                                     name:UIKeyboardDidShowNotification
//                                                   object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(keyboardWillHide:)
                                                     name:UIKeyboardWillHideNotification
                                                   object:nil];
        
        [self keyboardWasShown:nil];
        
        [self addSubview:_table];
    }
    
    return self;
}
- (void)loadDefaults
{
    self.backgroundColor = [UIColor clearColor];
    
    self.separatorColor = [UIColor lightGrayColor];
    self.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    self.topMargin = 0;
}

- (void)keyboardWasShown:(NSNotification *)notification
{
    self.isKeyBoardVisible=YES;
    NSDictionary *info = [notification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    
    CGFloat contextViewHeight = 0;
    CGFloat kbHeight = 0;
    if (UIInterfaceOrientationIsPortrait([UIApplication sharedApplication].statusBarOrientation))
    {
        contextViewHeight = self._contextController.view.frame.size.height;
        kbHeight = kbSize.height;
    }
    else if (UIInterfaceOrientationIsLandscape([UIApplication sharedApplication].statusBarOrientation))
    {
        contextViewHeight = self._contextController.view.frame.size.width;
        kbHeight = kbSize.width;
    }
    
    CGPoint textPosition = [_queryTextField convertPoint:_queryTextField.bounds.origin toView:nil]; //Taking in account Y position of queryTextField relatively to it's Window
    
    CGFloat calculatedY = textPosition.y + _queryTextField.frame.size.height + self.topMargin;
    CGFloat calculatedHeight = contextViewHeight - calculatedY - kbHeight;
    
    calculatedHeight += self._contextController.tabBarController.tabBar.frame.size.height; //keyboard is shown over it, need to compensate
    calculatedHeight -= 50;
    
    self.frame = CGRectMake(_queryTextField.frame.origin.x,
                            calculatedY,
                            _queryTextField.frame.size.width,
                            calculatedHeight);
    
    //change
    self.backgroundColor=[UIColor clearColor];
    
    if(IS_Greater_Or_Equal_to_IOS_7){
        if([AppHelper userDefaultsForKey:kIsSearchCity]){
             _table.frame = CGRectMake(15, 2, self.frame.size.width+33, self.frame.size.height);
        }
        else{
            if([AppHelper userDefaultsForKey:kIsSearchFromMap]){
                _table.frame = CGRectMake(-2, 2, self.frame.size.width+53, self.frame.size.height);
            }
            else{
                _table.frame = CGRectMake(-8, 2, self.frame.size.width+52, self.frame.size.height);
            }
        }
    }
    else{
        if([AppHelper userDefaultsForKey:kIsSearchCity]){
            _table.frame = CGRectMake(15, 2, self.frame.size.width+33, self.frame.size.height);
        }
        else{
            if([AppHelper userDefaultsForKey:kIsSearchFromMap])
                _table.frame = CGRectMake(-2, -20, self.frame.size.width+53, self.frame.size.height);
            else
                _table.frame = CGRectMake(-13, -20, self.frame.size.width+57, self.frame.size.height);
        }
    }
}

- (void)keyboardWillHide:(NSNotification *)notification{
    self.isKeyBoardVisible=NO;
    [self removeFromSuperview];
    _visible = NO;
}

- (void)queryChanged:(id)sender{
      if ([_queryTextField.text length] >= _itemsSource.minimumCharactersToTrigger){
        [_itemsSource itemsFor:_queryTextField.text whenReady:
         ^(NSArray *suggestions){
             self.searchArray=[[NSMutableArray alloc]init];
             if (_queryTextField.text.length
                 < _itemsSource.minimumCharactersToTrigger){
                 self.suggestions = nil;
                 self.sugstn=nil;
                 [_table reloadData];
             }
             else{
                 self.suggestions = suggestions;
                 self.sugstn=self.suggestions;
                                 
                 for (TRGoogleMapsSuggestion *obj in self.suggestions) {
                     [self.searchArray addObject:obj.address];
                 }
                 [_table reloadData];
                 
                 if (self.suggestions.count > 0 && !_visible){
                     if(self.isKeyBoardVisible){
                         [self._contextController.view addSubview:self];
                         _visible = YES;
                     }
                 }
             }
         }];
    }
    else{
        self.suggestions = nil;
        self.sugstn=nil;
        [_table reloadData];
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if(self.isKeyBoardVisible)
        return self.sugstn.count;
    else
        return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyIdentifier"];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"MyIdentifier"] ;
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UILabel *lblAddress=[[UILabel alloc] initWithFrame:CGRectMake(5.0, cell.frame.origin.y, cell.frame.size.width-65, cell.frame.size.height)];
        lblAddress.backgroundColor=[UIColor clearColor];
        lblAddress.font=[UIFont systemFontOfSize:12.0];
        lblAddress.textAlignment=NSTextAlignmentLeft;
        lblAddress.lineBreakMode=NSLineBreakByWordWrapping;
        lblAddress.numberOfLines=2;
        lblAddress.textColor=[UIColor grayColor];
        lblAddress.tag=1234;
        [cell.contentView addSubview:lblAddress];
    }
    
    cell.tag=indexPath.row;
    id suggestion = self.sugstn[(NSUInteger) indexPath.row];
    NSAssert([suggestion conformsToProtocol:@protocol(TRSuggestionItem)], @"Suggestion item must conform TRSuggestionItem");
    
    self.selectedSuggestion = (id <TRSuggestionItem>) suggestion;
    
    UILabel *lblAddress=(UILabel*)[cell.contentView viewWithTag:1234];
     lblAddress.text=[self.selectedSuggestion completionText];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    id suggestion = self.suggestions[(NSUInteger) indexPath.row];
    NSAssert([suggestion conformsToProtocol:@protocol(TRSuggestionItem)], @"Suggestion item must conform TRSuggestionItem");
    
    self.selectedSuggestion = (id <TRSuggestionItem>) suggestion;
    
    _queryTextField.text = self.selectedSuggestion.completionText;
    [_queryTextField resignFirstResponder];
    
    if (self.didAutocompleteWith)
        self.didAutocompleteWith(self.selectedSuggestion);
}

- (void)dealloc{
    [[NSNotificationCenter defaultCenter]
     removeObserver:self
     name:UITextFieldTextDidChangeNotification
     object:nil];
    [[NSNotificationCenter defaultCenter]
     removeObserver:self
     name:UIKeyboardDidShowNotification
     object:nil];
    [[NSNotificationCenter defaultCenter]
     removeObserver:self
     name:UIKeyboardWillHideNotification
     object:nil];
}

@end