//
//  FacebookControllar.m
//  Archoreo
//
//  Created by Sarthak Gupta on 02/04/14.
//  Copyright (c) 2014 Sarthak Gupta. All rights reserved.
//

#import "FacebookControllar.h"
#import "AppDelegate.h"
#import "Defines.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

@implementation FacebookControllar
@synthesize requestType;

+(FacebookControllar *) sharedFacebookControllar
{
    static FacebookControllar *singelton = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        singelton = [[FacebookControllar alloc] init];
    });
    return singelton;
}
//
//#pragma mark- Login With Facebook
//
//-(void) LoginWithFacebookWithFacebookPermission:(NSArray *)permission
//{
////    FBSession *session=[FBSession activeSession];
////    if(session)
////    {
////        NSLog(@":::%i",session.state);
////        switch (session.state)
////        {
////            case FBSessionStateCreated:
////            {
////                NSLog(@"FBSessionStateCreated12");
////                [self LoginWithFacebookWithPermissionArray:permission];
////            }
////                break;
////            case FBSessionStateClosedLoginFailed:
////            {
////                NSLog(@"FBSessionStateClosedLoginFailed");
////                [self LoginWithFacebookWithPermissionArray:permission];
////            }
////                break;
////            case FBSessionStateCreatedTokenLoaded:
////            {
////                NSLog(@"FBSessionStateCreatedTokenLoaded");
////                NSURL *url = [NSURL URLWithString:@"fb://"];
////                if([[UIApplication sharedApplication] canOpenURL:url])
////                {
////                    [session openWithBehavior:FBSessionLoginBehaviorUseSystemAccountIfPresent completionHandler:^(FBSession *session1,FBSessionState status, NSError *error)
////                     {
////                         [AppHelper saveToUserDefaults:[NSString stringWithFormat:@"%@",[session.accessTokenData accessToken]] withKey:KFbAccessToken];
////                         [self sessionStateChanged:session state:status error:error];
////                     }];
////                }
////                else
////                {
////                    [session openWithBehavior:FBSessionLoginBehaviorForcingWebView completionHandler:^(FBSession *session1,FBSessionState status, NSError *error)
////                     {
////                         [AppHelper saveToUserDefaults:[NSString stringWithFormat:@"%@",[session.accessTokenData accessToken]] withKey:KFbAccessToken];
////                         [self sessionStateChanged:session state:status error:error];
////                     }];
////                }
////            }
////                break;
////            case FBSessionStateOpen:
////            {
////                NSLog(@"FBSessionStateOpen");
////                [self sessionStateChanged:session state:FBSessionStateOpen error:nil];
////            }
////                break;
////                
////            default:
////                break;
////        }
////    }
//}
//
//-(void) LoginWithFacebookWithPermissionArray:(NSArray *)permission
//{
////    NSURL *url = [NSURL URLWithString:@"fb://"];
////    if([[UIApplication sharedApplication] canOpenURL:url])
////    {
////        [FBSession openActiveSessionWithPublishPermissions:permission defaultAudience:FBSessionDefaultAudienceOnlyMe allowLoginUI:YES completionHandler:^(FBSession *session, FBSessionState status, NSError *error)
////         {
////             if (!error && status == FBSessionStateOpen)
////             {
////                 [self sessionStateChanged:session state:status error:error];
////             }
////             else
////             {
////                 NSLog(@"error %@",error.localizedDescription);
////             }
////         }];
////    }
////    else
////    {
////        FBSession *session = [[FBSession alloc] initWithPermissions:permission];
////        [FBSession setActiveSession:session];
////        [session openWithBehavior:FBSessionLoginBehaviorForcingWebView completionHandler:^(FBSession *session1,FBSessionState status, NSError *error)
////         {
////             if (!error)
////             {
////                 [self sessionStateChanged:session1 state:status error:error];
////             }
////             else
////             {
////                 if(self.requestType==RequestFacebookUserDetails)
////                 {
////                     [[NSNotificationCenter defaultCenter] postNotificationName:GetFacebookUserInfoNotification object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Some error occured",@"error",@"No",@"isSuccess", nil]];
////                 }
////                 if(self.requestType==RequestForPostingAccessToken)
////                 {
////                     [[NSNotificationCenter defaultCenter] postNotificationName:GetFacebookAccessToken object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Some error occured",@"error",@"No",@"isSuccess",session,@"session", nil]];
////                 }
////             }
////         }];
////    }
//}
//
////- (void)sessionStateChanged:(FBSession *)session state:(FBSessionState) state error:(NSError *)error
////{
////    switch (state)
////    {
////        case FBSessionStateOpen:
////        {
////            [[FBRequest requestForMe] startWithCompletionHandler:
////             ^(FBRequestConnection *connection,
////               NSDictionary<FBGraphUser> *user,
////               NSError *error)
////             {
////                 if(self.requestType==RequestFacebookUserDetails)
////                 {
////                     if(error)
////                     {                         
////                         [[NSNotificationCenter defaultCenter] postNotificationName:GetFacebookUserInfoNotification object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:error,@"error",@"No",@"isSuccess", nil]];
////                     }
////                     else
////                     {
////                         [[NSNotificationCenter defaultCenter] postNotificationName:GetFacebookUserInfoNotification object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:user,@"data",@"Yes",@"isSuccess", nil]];
////                     }
////                 }
////                 
////                 if(self.requestType==RequestForPostingAccessToken)
////                 {
////                     if(error)
////                     {
////                         [[NSNotificationCenter defaultCenter] postNotificationName:GetFacebookAccessToken object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"Some error occured",@"error",@"No",@"isSuccess",session,@"session", nil]];
////                     }
////                     else
////                     {
////                         [AppHelper saveToUserDefaults:[NSString stringWithFormat:@"%@",[[FBSession activeSession].accessTokenData accessToken]] withKey:KFbAccessToken];
////                         [[NSNotificationCenter defaultCenter] postNotificationName:GetFacebookAccessToken object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:user,@"data",@"Yes",@"isSuccess",session,@"session", nil]];
////                     }
////                 }
////             }];
////        }
////            break;
////        case FBSessionStateClosed:
////        {
////            [AppDelegate dismissGlobalHUD];
////        }
////            break;
////        case FBSessionStateClosedLoginFailed:
////        {
////            [AppDelegate dismissGlobalHUD];
////        }
////            break;
////        default:
////            break;
////    }
////    
////    if (error)
////    {
////        [AppDelegate dismissGlobalHUD];
////        if ([error.localizedDescription isEqualToString:@"The operation couldn’t be completed. (com.facebook.sdk error 2.)"])
////        {
////            
////        }
////    }
////}
//
//#pragma mark-
//#pragma mark- GetPosting Access Token
//
//-(void) getFacebookPostinAccessTokenWithPostingPermission:(NSArray *)permission
////{
////    FBSession *session=[FBSession activeSession];
////    if(session)
////    {
////        switch (session.state)
////        {
////            case FBSessionStateCreated:
////            {
////                NSLog(@"Created");
////                [self LoginWithFacebookWithPermissionArray:permission];
////            }
////                break;
////            case FBSessionStateClosedLoginFailed:
////            {
////                NSLog(@"Failed");
////                [self LoginWithFacebookWithPermissionArray:permission];
////            }
////                break;
////            case FBSessionStateCreatedTokenLoaded:
////            {
////                NSLog(@"Loaded");
////                NSURL *url = [NSURL URLWithString:@"fb://"];
////                if([[UIApplication sharedApplication] canOpenURL:url])
////                {
////                    [session openWithBehavior:FBSessionLoginBehaviorWithFallbackToWebView completionHandler:^(FBSession *session1,FBSessionState status, NSError *error)
////                     {
////                         if (!error && status == FBSessionStateOpen)
////                         {
////                             [self sessionStateChanged:session state:status error:error];
////                         }
////                         else
////                         {
////                             NSLog(@"error %@",error.localizedDescription);
////                         }
////                     }];
////                }
////                else
////                {
////                    [session openWithBehavior:FBSessionLoginBehaviorForcingWebView completionHandler:^(FBSession *session1,FBSessionState status, NSError *error)
////                     {
////                         if([self checkForFacebookPermision:@"publish_actions" andSesscion:session])
////                         {
////                             [self sessionStateChanged:session1 state:status error:error];
////                         }
////                         else
////                         {
////                             [self LoginWithFacebookWithPermissionArray:permission];
////                         }
////                     }];
////                }
////            }
////                break;
////            case FBSessionStateOpen:
////            {
////                NSLog(@"Open");
////                if([self checkForFacebookPermision:@"publish_actions" andSesscion:session])
////                {
////                    [self sessionStateChanged:session state:FBSessionStateOpen error:nil];
////                }
////                else
////                {
////                    [self LoginWithFacebookWithPermissionArray:permission];
////                }
////            }
////                break;
////            case FBSessionStateOpenTokenExtended:
////            {
////                NSLog(@"Extended");
////                if([self checkForFacebookPermision:@"publish_actions" andSesscion:session])
////                {
////                    [self sessionStateChanged:session state:FBSessionStateOpen error:nil];
////                }
////                else
////                {
////                    [self LoginWithFacebookWithPermissionArray:permission];
////                }
////            }
////                break;
////            default:
////                break;
////        }
////    }
//}
//
//-(BOOL) checkForFacebookPermision:(NSString *)permission andSesscion:(FBSession *)session
//{
//    if([session.permissions containsObject:permission])
//    {
//        return YES;
//    }
//    return NO;
//}
//
//
//-(void) LogoutFromFacebook
//{
//    [[FBSession activeSession] closeAndClearTokenInformation];
//    [AppHelper removeFromUserDefaultsWithKey:@"facebookID"];
//    [[FBSession activeSession] close];
//    [FBSession setActiveSession:nil];
//}

@end
