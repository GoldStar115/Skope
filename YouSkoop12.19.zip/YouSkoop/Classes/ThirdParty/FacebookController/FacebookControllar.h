//
//  FacebookControllar.h
//  Archoreo
//
//  Created by Sarthak Gupta on 02/04/14.
//  Copyright (c) 2014 Sarthak Gupta. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum{
    
    RequestFacebookUserDetails=1,
    RequestForPostingAccessToken,
    
} RequestType;

@interface FacebookControllar : NSObject

@property (nonatomic, assign) RequestType requestType;

#pragma mark-
#pragma mark- Facebook Initialization

+(FacebookControllar *) sharedFacebookControllar;

#pragma mark- Login With Facebook

-(void) LoginWithFacebookWithFacebookPermission:(NSArray *)permission;

#pragma mark-
#pragma mark- GetPosting Access Token
-(void) getFacebookPostinAccessTokenWithPostingPermission:(NSArray *)postingPermission;
-(void) LogoutFromFacebook;

@end
