//
//  SignInView.m
//  youskoop
//
//  Created by user on 3/7/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "SignInView.h"
#import "WebServicesController.h"
#include "FacebookLoginInfo.h"
#import "Twitter/Twitter.h"
#import "TWAccessTokenGenerator.h"
#import "Social/Social.h"
#import "CLController.h"
#import "FacebookControllar.h"

@interface SignInView (){
    
    NSString *access_token;
}

@end

@implementation SignInView


@synthesize imgviewLogo,outletLogin,dictUserCredentials,txtUserEmail,txtUserPassword,scrollview;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIImageView *navImage = (UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image = [UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame = CGRectMake(0, 0, 320, 44);
        navImage.image = [UIImage imageNamed:@"statusbar_6.png"];
    }
    
    dictUserCredentials = [[NSMutableDictionary alloc] init ];
    
    //ScrollView
    [self.scrollview setContentSize:CGSizeMake(295, 180)];
    self.scrollview.delegate = self;
    self.scrollview.scrollEnabled = FALSE;
    [self.view bringSubviewToFront:self.scrollview];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(keyboardwillShowNotification:)
     name:UIKeyboardDidShowNotification
     object:nil];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(keyboardwillHideNotification:)
     name:UIKeyboardDidHideNotification
     object:nil];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Button action methods
//Login button action
- (IBAction)btnlogin:(id)sender
{
    [self.txtUserEmail resignFirstResponder];
    [self.txtUserPassword resignFirstResponder];
    [self.scrollview setContentOffset:CGPointMake(0,0) animated:NO];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSignedIn:) name:Notification_login object:nil];
    if([self checkMandatoryFields]){
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [dictUserCredentials setValue:@"" forKey:@"facebook_uid"];
        [dictUserCredentials setValue:@"" forKey:@"twitter_uid"];
        [dictUserCredentials setValue:txtUserEmail.text forKey:@"userName"];
        [dictUserCredentials setValue:txtUserPassword.text forKey:@"password"];
        [dictUserCredentials setValue:KAppToken forKey:@"token"];
        [dictUserCredentials setValue:@"0" forKey:@"login_attempt"];
        [[WebServicesController WebServiceMethod] signIn:dictUserCredentials];
    }
}

#pragma mark Receive notofications
//Receive notofication when user sign in
-(void)userDidSignedIn:(NSNotification *)note{
    
      NSLog(@"Login Notification======%@",note.userInfo);
        [AppDelegate dismissGlobalHUD];
        [[NSNotificationCenter defaultCenter]removeObserver:self name:Notification_login object:nil];
        if (note.userInfo){
            if([[note.userInfo objectForKey:@"errorCode"] intValue] == 0){
                
                //[[AppDelegate getAppDelegate] configureVideoChatCredentials];
                [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:KUserId] withKey:KUserId];
                [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"name"] withKey:KUserName];
                [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"email"] withKey:KUserEmail];
                [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"image"] withKey:KUserImageUrl];
                [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"quick_blox_login"] withKey:KQuickBloxCredential];
                [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"quick_blox_id"] withKey:KQuickBloxId];
                
                NSMutableDictionary *profData=[[NSMutableDictionary alloc] init];
                [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"name"] forKey:@"name"];
                [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"image"] forKey:@"image"];
                [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"email"] forKey:@"email"];
                [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"dob"] forKey:@"dob"];
                [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"city"] forKey:@"city"];
                [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"notification"] forKey:@"notification"];
                [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"sound"] forKey:@"sound"];
                [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"username"] forKey:@"username"];
                [AppHelper saveToUserDefaults:profData withKey:KUserProfData];
                
                NSDictionary *dataInfo = [[note.userInfo objectForKey:@"data"] objectForKey:@"payment_info"];
                NSMutableDictionary *creditInfoDict = [NSMutableDictionary dictionary];
                //Save credit card info
                if([dataInfo valueForKey:@"card_number"] && [[dataInfo valueForKey:@"card_number"] length] > 0)
                    [creditInfoDict setValue:[dataInfo valueForKey:@"card_number"] forKey:@"ccno"];
                if([dataInfo valueForKey:@"first_name"] && [[dataInfo valueForKey:@"first_name"] length] > 0)
                    [creditInfoDict setValue:[dataInfo valueForKey:@"first_name"] forKey:@"fname"];
                if([dataInfo valueForKey:@"last_name"] && [[dataInfo valueForKey:@"last_name"] length] > 0)
                    [creditInfoDict setValue:[dataInfo valueForKey:@"last_name"] forKey:@"lname"];
                if([dataInfo valueForKey:@"card_type"] && [[dataInfo valueForKey:@"card_type"] length] > 0)
                    [creditInfoDict setValue:[dataInfo valueForKey:@"card_type"] forKey:@"cardtype"];
                if([dataInfo valueForKey:@"expire_month"] && [[dataInfo valueForKey:@"expire_month"] length] > 0)
                    [creditInfoDict setValue:[dataInfo valueForKey:@"expire_month"] forKey:@"expmonth"];
                if([dataInfo valueForKey:@"expire_year"] && [[dataInfo valueForKey:@"expire_year"] length] > 0)
                    [creditInfoDict setValue:[dataInfo valueForKey:@"expire_year"] forKey:@"expyear"];
                if([dataInfo valueForKey:@"ccv2"] && [[dataInfo valueForKey:@"ccv2"] length] > 0)
                    [creditInfoDict setValue:[dataInfo valueForKey:@"ccv2"] forKey:@"cvc"];
                
                if([[note.userInfo valueForKey:@"data"] valueForKey:@"paypal_mail"]){
                    [creditInfoDict setValue:[[note.userInfo valueForKey:@"data"] valueForKey:@"paypal_mail"]
                                      forKey:@"email"];
                    [creditInfoDict setValue:[[note.userInfo valueForKey:@"data"] valueForKey:@"paypal_mail"]
                                      forKey:@"cemail"];
                }
                
                [AppHelper saveToUserDefaults:[[note.userInfo valueForKey:@"data"] valueForKey:@"total_amount"] withKey:KAvailableCredit];
                [AppHelper saveToUserDefaults:creditInfoDict withKey:KSavedCCInfo];
                [self performSegueWithIdentifier:@"Pushfromlogin" sender:nil];
            }
            else if ([[note.userInfo objectForKey:@"errorCode"] intValue] == 1){
                self.txtUserPassword.text=nil;
                [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            }
            else if ([[note.userInfo objectForKey:@"errorCode"] intValue] == 2){
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"This user is already logged in on another device.By clicking on \"Yes\" you will be logged out from all other devices.\nDo you want to login?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
            }
        }
}

#pragma mark Alertview deligate method
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
//    if (alertView.tag==67890){
//        [self performSegueWithIdentifier:@"LoginSuccess" sender:nil];
//    }
    if (alertView.tag==1){
        if(buttonIndex == 0){
            [dictUserCredentials setValue:@"1" forKey:@"login_attempt"];
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSignedIn:) name:Notification_login object:nil];
            [[WebServicesController WebServiceMethod] signIn:dictUserCredentials];
        }
    }
}

//Check mandatory fields and show alert
-(BOOL)checkMandatoryFields
{
    if([txtUserEmail.text isEqualToString:@""])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Error!!!" message:@"Please enter user name" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        alert.tag=1;
        [alert show];
        return FALSE;
    }
    if([txtUserPassword.text isEqualToString:@""])
    {
        UIAlertView *alert=[[UIAlertView alloc] initWithTitle:@"Error!!!" message:@"Please enter password" delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
        alert.tag=2;
        [alert show];
        return FALSE;
    }
    return TRUE;
}


//*****************************************************Facebook*****************************************************

- (void)loginWithFacebook {
    
    if (![FBSDKAccessToken currentAccessToken]) {
        
        FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
        [login logInWithReadPermissions:@[@"email"] fromViewController:self handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
            
            if (error) {
                
            } else if (result.isCancelled) {
                
                
            } else {
                // If you ask for multiple permissions at once, you
                // should check if specific permissions missing
                if ([result.grantedPermissions containsObject:@"email"]) {
                    
                    [self loginWithFacebook];
                }
            }
        }];
        return;
    }
    
    access_token= [NSString stringWithFormat:@"%@",[FBSDKAccessToken currentAccessToken].tokenString];
        NSLog(@"FBAccessToken = %@",access_token);
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:@"id, first_name, last_name, email" forKey:@"fields"];
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    
    [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:params] startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id user, NSError *error){
        
        [AppDelegate dismissGlobalHUD];
        if (!error) {
            [AppHelper saveToUserDefaults:[user valueForKey:@"id"] withKey:KFacebook_id];
            NSLog(@"%@",user);
            [dictUserCredentials setValue:KAppToken forKey:@"token"];
            [dictUserCredentials setValue:[user objectForKey:@"id"] forKey:@"facebook_uid"];
            [dictUserCredentials setValue:access_token forKey:@"fb_token"];
            [dictUserCredentials setValue:@"0" forKey:@"login_attempt"];
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSignedIn:) name:Notification_login object:nil];
            [[WebServicesController WebServiceMethod] signIn:dictUserCredentials];
        }
        else{
            NSLog(@"Error:%@", error);
        }
    }];
}

#pragma mark-FACEBOOK SIGNIN
//Login througn facebook
- (IBAction)facebookLogin:(id)sender
{
    [self.txtUserEmail resignFirstResponder];
    [self.txtUserPassword resignFirstResponder];
    [self.scrollview setContentOffset:CGPointMake(0,0) animated:NO];

    //[AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [self loginWithFacebook];
 }

////Check facebook session and get user info
//-(void)facebookSession
//{
//    if (FBSession.activeSession.isOpen)
//    {
//        [[FBRequest requestForMe] startWithCompletionHandler:^(FBRequestConnection *connection,NSDictionary<FBGraphUser> *user,NSError *error)
//         {
//             if (!error)
//             {
//                 [AppDelegate dismissGlobalHUD];
//                 NSLog(@"%@",user);
//                 [AppHelper saveToUserDefaults:[user valueForKey:@"id"] withKey:KFacebook_id];
//                 [dictUserCredentials setValue:KAppToken forKey:@"token"];
//                 [dictUserCredentials setValue:[user objectForKey:@"id"] forKey:@"facebook_uid"];
//                 [dictUserCredentials setValue:access_token forKey:@"fb_token"];
//                 [dictUserCredentials setValue:@"0" forKey:@"login_attempt"];
//                 
//                 [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
//                 [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSignedIn:) name:Notification_login object:nil];
//                 [[WebServicesController WebServiceMethod] signIn:dictUserCredentials];
//             }
//             else
//             {
//                 [AppDelegate dismissGlobalHUD];
//                 NSLog(@"Error");
//             }
//         }];
//        
//        NSLog(@"FB Session already created");
//    }
//    else
//    {
//        NSLog(@"**********");
//        // if the session is closed, then we open it here, and establish a handler for state changes
//        
//        //NSArray *permissions = [[NSArray alloc]initWithObjects:@"publish_stream",@"publish_actions",@"user_hometown",@"user_location",@"friends_location",@"friends_hometown", nil];
//        NSArray *permissions = [[NSArray alloc]initWithObjects:@"public_profile",@"email",@"user_friends", nil];
//        [FBSession openActiveSessionWithPublishPermissions:permissions defaultAudience:FBSessionDefaultAudienceFriends allowLoginUI:YES completionHandler:^(FBSession *session,
//                                                                                                                                                            FBSessionState status,
//                                                                                                                                                            NSError *error) {
//            if (error)
//            {
//                [AppHelper showAlertViewWithTag:1 title:AppName message:error.localizedDescription delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
//            }
//            else if (session.isOpen)
//            {
//                access_token= [NSString stringWithFormat:@"%@",session.accessTokenData.accessToken];
//                NSLog(@"%@",access_token);
//                
//                [[FBRequest requestForMe] startWithCompletionHandler:^(FBRequestConnection *connection,NSDictionary<FBGraphUser> *user,NSError *error)
//                 {
//                     if (!error)
//                     {
//                         [AppDelegate dismissGlobalHUD];
//                         [AppHelper saveToUserDefaults:[user valueForKey:@"id"] withKey:KFacebook_id];
//                         NSLog(@"%@",user);
//                         [dictUserCredentials setValue:KAppToken forKey:@"token"];
//                         [dictUserCredentials setValue:[user objectForKey:@"id"] forKey:@"facebook_uid"];
//                         [dictUserCredentials setValue:access_token forKey:@"fb_token"];
//                         [dictUserCredentials setValue:@"0" forKey:@"login_attempt"];
//                         
//                         [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
//                         [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSignedIn:) name:Notification_login object:nil];
//                         [[WebServicesController WebServiceMethod] signIn:dictUserCredentials];
//                     }
//                     else
//                     {
//                         [AppDelegate dismissGlobalHUD];
//                         NSLog(@"Error");
//                     }
//                 }];
//            }
//        }];
//    }
//}

//*****************************************************TWITTER*****************************************************
#pragma mark-TWITTER SIGNIN
//Login through twitter button action
- (IBAction)twitterLogin:(id)sender
{
    [self.txtUserEmail resignFirstResponder];
    [self.txtUserPassword resignFirstResponder];
    [self.scrollview setContentOffset:CGPointMake(0,0) animated:NO];
    
    [self loginViaTwitter];
}

-(void) loginViaTwitter
{
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[TWAccessTokenGenerator sharedAccessTokenGenerator] initialize];
    
    ACAccountStore *accountStore = [[ACAccountStore alloc] init];
    ACAccountType *accountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    [accountStore requestAccessToAccountsWithType:accountType options:nil completion:^(BOOL granted, NSError *error)
     {
         if (granted)
         {
             NSArray *accounts = [accountStore accountsWithAccountType:accountType];
             // Check if the users has setup at least one Twitter account
             if (accounts.count > 0)
             {
                 ACAccount *twitterAccount = [accounts objectAtIndex:0];//Getting first account
                 
                 NSString *temp =[[twitterAccount.description componentsSeparatedByString:@"\"user_id\" = "] lastObject];
                 NSArray *temparr=[temp componentsSeparatedByString:@";"];
                 if ([temparr count]>0)
                 {
                     NSString *userName=[temparr objectAtIndex:0];
                     
                     // Creating a request to get the info about a user on Twitter
                     SLRequest *twitterInfoRequest = [SLRequest requestForServiceType:SLServiceTypeTwitter requestMethod:SLRequestMethodGET URL:[NSURL URLWithString:@"https://api.twitter.com/1.1/users/lookup.json"] parameters:[NSDictionary dictionaryWithObject:userName forKey:@"screen_name"]];
                     [twitterInfoRequest setAccount:twitterAccount];
                     // Making the request
                     [twitterInfoRequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
                      {
                          dispatch_async(dispatch_get_main_queue(), ^
                                         {
                                             // Check if there was an error
                                             if (error)
                                             {
                                                 
                                                 return;
                                             }
                                             // Check if there is some response data
                                             if (responseData)
                                             {
                                                 [self getTwitterTokens];
                                             }
                                             [AppDelegate dismissGlobalHUD];
                                         });
                      }];
                 }
             }
             else
             {
                 
                 dispatch_async(dispatch_get_main_queue(), ^
                                {
                                    [AppDelegate dismissGlobalHUD];
                                    [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please ensure that you have at least one twitter account setup and have internet connectivity. You can setup a twitter account in the iOS Settings > Twitter > login." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                                });
                 
             }
         }
         else
         {
            
             dispatch_async(dispatch_get_main_queue(), ^
                            {
                                 [AppDelegate dismissGlobalHUD];
                                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please ensure that you have permission to access twitter account. You can turn on permission in the iOS Settings > Twitter." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                            });
         }
         if (error)
         {
             [AppDelegate dismissGlobalHUD];
             //[MessageView showMessageView:@"ERROR_INTERNET_CONNECTION" onView:self.view];
         }
     }];
}

-(void)getTwitterTokens
{
    [TWAccessTokenGenerator sharedAccessTokenGenerator].view=self.view;
    [[TWAccessTokenGenerator sharedAccessTokenGenerator] refreshTwitterAccounts];
    [AppHelper saveToUserDefaults:@"YES" withKey:@"POST"];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(userDidGetTwitterUserInfo) name:@"Twitter_Tokens_Rvcd" object:nil];
}

- (void)userDidGetTwitterUserInfo
{
    [AppHelper saveToUserDefaults:@"" withKey:@"POST"];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"Twitter_Tokens_Rvcd" object:nil];
    
    [dictUserCredentials setValue:[AppHelper userDefaultsForKey:KTwitter_token] forKey:@"twitter_token"];
    [dictUserCredentials setValue:KAppToken forKey:@"token"];
    [dictUserCredentials setValue:[AppHelper userDefaultsForKey:KTwitter_id] forKey:@"twitter_uid"];
    [dictUserCredentials setValue:@"0" forKey:@"login_attempt"];
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSignedIn:) name:Notification_login object:nil];
    [[WebServicesController WebServiceMethod] signIn:dictUserCredentials];
}

- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


#pragma mark - Text Field Delegate
-(void)keyboardwillShowNotification:(NSNotification*)note
{
    if(IS_IPHONE5)
          scrollview.scrollEnabled=NO;
    else{
        self.scrollview.scrollEnabled=YES;
        [self.scrollview setContentSize:CGSizeMake(244,180)];
    }
}

-(void)keyboardwillHideNotification:(NSNotification*)note
{
    self.scrollview.scrollEnabled=NO;
    
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"******Touch detect*****");
    [self.txtUserEmail resignFirstResponder];
    [self.txtUserPassword resignFirstResponder];
    [self.scrollview setContentOffset:CGPointMake(0,0) animated:NO];
    [super touchesBegan:touches withEvent:event];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    if (textField==self.txtUserEmail)
    {
        [self.txtUserEmail resignFirstResponder];
        [self.txtUserPassword becomeFirstResponder];
        
    }
      else if (textField==self.txtUserPassword)
    {
        
        [self.txtUserPassword resignFirstResponder];
        if (!IS_IPHONE5)
            [self.scrollview setContentOffset:CGPointMake(0,0) animated:NO];
        
    }
    return YES;
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}

@end
