//
//  ForgotPasswordView.m
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "ForgotPasswordView.h"
#import "WebServicesController.h"
#import "PasswordRetrieveView.h"
@interface ForgotPasswordView ()

@end

@implementation ForgotPasswordView
@synthesize  dictForgotCredentials,txtUserEmail;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    UILabel *lblEnterEmail=(UILabel*)[self.view viewWithTag:5];
    lblEnterEmail.textColor=KTextColor;
    
    [AppHelper stausBarColorChange];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Button action methods
- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnSendMail:(id)sender
{
    
    [self.txtUserEmail resignFirstResponder];
    
    NSString*str=nil;
    
    //Validations
    if([self.txtUserEmail.text length]==0)
        str=@"Please enter email address.";
    else if([self validateEmail:self.txtUserEmail.text]==NO)
        str=@"Please enter the valid email.";
    
    if(str)
    {
        [AppHelper showAlertViewWithTag:670 title:AppName message:str delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    }
    else
    {
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(userForgotPassword:)
                                                     name:Notification_for_ForgotPassword
                                                   object:nil];
        dictForgotCredentials=[NSMutableDictionary dictionary];
                [dictForgotCredentials setValue:txtUserEmail.text forKey:@"email"];
                [dictForgotCredentials setValue:KAppToken forKey:@"token"];
                [[WebServicesController WebServiceMethod]forgotpasswordServices:dictForgotCredentials];
        
    }

}

#pragma mark Receive notofications
-(void)userForgotPassword:(NSNotification *)note
{
    NSLog(@"Notification_for_ForgotPassword======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:Notification_for_ForgotPassword object:nil];
    if (note.userInfo)
    {
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0)
        {
            [AppHelper showAlertViewWithTag:67890 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1)
        {
            self.txtUserEmail.text=nil;
            [AppHelper showAlertViewWithTag:690 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
    }
}

#pragma mark Alertview deligate methods
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==67890)
    {
        [self performSegueWithIdentifier:@"verify_change_password" sender:nil];
    }
}

#pragma mark Segue method
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqual:@"verify_change_password"])
    {
          PasswordRetrieveView *passwordView=[segue destinationViewController];
        passwordView.dictforgotinfo=dictForgotCredentials;
    }
}

//Check email is valid or not
-(BOOL)validateEmail: (NSString *)str
{
    NSString *emailRegEx = @"[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}";
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
    return [emailTest evaluateWithObject:str];
}

//Detect touch
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [self.txtUserEmail resignFirstResponder];
    [super touchesBegan:touches withEvent:event];
}

#pragma mark Textfield deligate methods
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    if (textField==self.txtUserEmail)
    {
        [self.txtUserEmail resignFirstResponder];
    }
    return YES;
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField==self.txtUserEmail)
    {
        self.txtUserEmail.keyboardType=UIKeyboardTypeEmailAddress;
        self.txtUserEmail.returnKeyType=UIReturnKeyNext;
    }
      return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.text.length==0 && [string isEqualToString:@" "])
    {
        return NO;
    }
    return YES;
}


@end
