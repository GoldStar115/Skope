//
//  FacebookLoginInfo.m
//  InviteAndMeet
//
//  Created by Sunil Maurya on 3/3/14.
//  Copyright (c) 2014 appstudioz. All rights reserved.
//

#import "FacebookLoginInfo.h"
#import "AppDelegate.h"
@implementation FacebookLoginInfo
@synthesize _dictFacebookInfo=dictFacebookInfo;
NSString *token;


#pragma mark
//MARK:- WebService Singleton object

+(FacebookLoginInfo *) getFacebookLoginInfo
{
    static FacebookLoginInfo *singleton;
    if(!singleton)
    {
        singleton=[[FacebookLoginInfo alloc] init];
    }
    return singleton;
}


#pragma mark
//MARK:- Facebook login INFO. Open session and get user info
//-(void)openSession
//{
//        if (!FBSession.activeSession.isOpen)
//        {
//            NSArray *permission=[NSArray arrayWithObjects:@"email", nil];
//            [FBSession openActiveSessionWithReadPermissions:permission
//                                               allowLoginUI:YES
//                                          completionHandler:^(FBSession *session,
//                                                              FBSessionState status,
//                                                              NSError *error) {
//                                              
//                                              [self sessionStateChanged:session state:status error:error];
//                                          }];
//        }
//}
//
//- (void)sessionStateChanged:(FBSession *)session state:(FBSessionState ) state error:(NSError *)error
//{
//    NSLog(@"State=%u",state);
//   // [[AppDelegate getAppDelegate]showLoadingActivityView:@"Please_wait"];
//    switch (state)
//    {
//        case FBSessionStateOpen:
//        {
//            if (FBSession.activeSession.isOpen)
//            {
//                
//                [[FBRequest requestForMe] startWithCompletionHandler:^(FBRequestConnection *connection,NSDictionary<FBGraphUser> *user,NSError *error)
//                 {
//                     if (!error)
//                     {
//                         
//                         dictFacebookInfo=[[NSMutableDictionary alloc]init];
//                         [dictFacebookInfo setObject:[[FBSession.activeSession accessTokenData] accessToken] forKey:@"token"];
//                         [dictFacebookInfo setObject:[user objectForKey:@"first_name"] forKey:@"first_name"];
//                         [dictFacebookInfo setObject:[user objectForKey:@"last_name"] forKey:@"last_name"];
//                         [dictFacebookInfo setObject:[user objectForKey:@"email"] forKey:@"email"];
//                         NSLog(@"ID= %@",[user objectForKey:@"id"]);
//                         [dictFacebookInfo setObject:[user objectForKey:@"id"]forKey:@"id"];
//                         
//                         [dictFacebookInfo setObject:[NSString stringWithFormat:@"http://graph.facebook.com/%@/picture?type=large", [user objectForKey:@"id"]] forKey:@"imageUrl"];
//                         // Post notification
//                         [[NSNotificationCenter defaultCenter] postNotificationName:@"FBInfoNotification" object:nil userInfo:dictFacebookInfo];
//                     }
//                     else
//                     {
//                         NSLog(@":::%@",error);
//                     }
//                 }];
//                
//                
//            }
//        }
//        break;
//        case FBSessionStateClosed:
//            //
//            NSLog(@"Session close...");
//            [[AppDelegate getAppDelegate ].session closeAndClearTokenInformation];
//            [AppDelegate getAppDelegate ].session=nil;
//           // [FBSession setActiveSession:nil];
//            break;
//        case FBSessionStateClosedLoginFailed:
//            // Once the user has logged in, we want them to
//            // be looking at the root view.
//            NSLog(@"Failed...");
//            [[AppDelegate getAppDelegate ].session closeAndClearTokenInformation];
//            [AppDelegate getAppDelegate ].session=nil;
////            [FBSession.activeSession closeAndClearTokenInformation];
////            [FBSession.activeSession closeAndClearTokenInformation];
//            break;
//        default:
//            NSLog(@"default...");
//            break;
//    }
//    
//    if (error)
//    {
//      //
//    }
//}
-(NSDictionary *)getUserInfo
{
    return dictFacebookInfo;
}
@end
