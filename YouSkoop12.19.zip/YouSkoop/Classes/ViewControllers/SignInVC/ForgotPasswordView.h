//
//  ForgotPasswordView.h
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ForgotPasswordView : UIViewController<UITextFieldDelegate>
{
    NSMutableDictionary *dictForgotCredentials ;
}

@property (weak, nonatomic) IBOutlet UITextField *txtUserEmail;
@property(strong,nonatomic)NSMutableDictionary *dictForgotCredentials ;

- (IBAction)btnSendMail:(id)sender;
- (IBAction)btnBack:(id)sender;

@end
