//
//  SignInView.h
//  youskoop
//
//  Created by user on 3/7/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>

@interface SignInView : UIViewController <UITextFieldDelegate,UIScrollViewDelegate>
{
    NSMutableDictionary *dictUserCredentials;
}

@property (weak, nonatomic) IBOutlet UIButton *outletLogin;
@property (weak, nonatomic) IBOutlet UIImageView *imgviewLogo;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollview;
@property (weak, nonatomic) IBOutlet UITextField *txtUserPassword;
@property (weak, nonatomic) IBOutlet UITextField *txtUserEmail;
@property(strong,nonatomic)NSMutableDictionary *dictUserCredentials;

- (IBAction)btnBack:(id)sender;
- (IBAction)facebookLogin:(id)sender;
- (IBAction)twitterLogin:(id)sender;
- (IBAction)btnlogin:(id)sender;

@end
