//
//  FacebookLoginInfo.h
//  InviteAndMeet
//
//  Created by Sunil Maurya on 3/3/14.
//  Copyright (c) 2014 appstudioz. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
@interface FacebookLoginInfo : NSObject
{
    NSMutableDictionary *dictFacebookInfo;
}
@property NSMutableDictionary *_dictFacebookInfo;
+(FacebookLoginInfo *) getFacebookLoginInfo;
//-(void)openSession;
//- (void)sessionStateChanged:(FBSession *)session state:(FBSessionState) state error:(NSError *)error;
-(NSDictionary *)getUserInfo;
@end
