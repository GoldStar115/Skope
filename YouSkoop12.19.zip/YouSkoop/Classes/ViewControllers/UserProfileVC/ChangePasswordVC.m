//
//  ChangePasswordVC.m
//  youskoop
//
//  Created by Shitesh Patel on 10/07/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "ChangePasswordVC.h"

@interface ChangePasswordVC ()

@end

@implementation ChangePasswordVC
{
    __weak IBOutlet UILabel *_lblNavTitle;
    __weak IBOutlet UITextField *_txtConfirmPswd;
    __weak IBOutlet UITextField *_txtNewPswd;
    __weak IBOutlet UITextField *_txtOldPswd;
}

@synthesize isChangeUserName;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    if(isChangeUserName)
    {
        _txtOldPswd.placeholder=@"Enter Old Username";
        _txtOldPswd.secureTextEntry=NO;
        _txtNewPswd.placeholder=@"Enter New Username";
        _txtNewPswd.secureTextEntry=NO;
        _txtConfirmPswd.placeholder=@"Confirm New Username";
        _txtConfirmPswd.secureTextEntry=NO;
        _lblNavTitle.text=@"Change User Name";
        NSMutableDictionary *profDict=[AppHelper userDefaultsDictionaryDataForKey:KUserProfData];
        _txtOldPswd.text=[profDict valueForKey:@"username"];
    }
}
-(void)viewWillAppear:(BOOL)animated{
    //Hide tabbar
    [[AppDelegate getAppDelegate] hideTabBar:self.tabBarController];
}
-(void)viewWillDisappear:(BOOL)animated{
    //Show tabbar
    [[AppDelegate getAppDelegate] showTabBar:self.tabBarController];
}

#pragma mark button action methods
-(IBAction)onClickBackButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)onClickSaveButton:(id)sender
{
    if(isChangeUserName)
    {
        if([self checkUserNameField])
        {
            [self resignKeyBoard];
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidChangeUserName:) name:Notification_Change_Username object:nil];
            [[WebServicesController WebServiceMethod] changeUsernameWithUserId:[AppHelper userDefaultsForKey:KUserId] username:_txtNewPswd.text oldUsername:_txtOldPswd.text andAppToken:KAppToken];
        }
    }
    else if([self checkPasswordField])
    {
        [self resignKeyBoard];
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidChangePassword:) name:Notification_Change_Password object:nil];
        [[WebServicesController WebServiceMethod] changePasswordWithUserId:[AppHelper userDefaultsForKey:KUserId] password:_txtNewPswd.text oldPassword:_txtOldPswd.text andAppToken:KAppToken];
    }
}

-(BOOL)checkPasswordField
{
    NSString *errorMessage=@"";
    if([_txtOldPswd.text length]==0)
        errorMessage=@"Please enter old password.";
    else if([_txtNewPswd.text length]==0)
        errorMessage=@"Please enter new password.";
    else if([_txtConfirmPswd.text length]==0)
        errorMessage=@"Please enter new confirm password.";
    else if(![_txtNewPswd.text isEqualToString:_txtConfirmPswd.text])
        errorMessage=@"New password and confirm password does not match.";
    else if([_txtNewPswd.text isEqualToString:_txtOldPswd.text])
        errorMessage=@"Old password and new password can't be same.";
    
    if([errorMessage length]>0)
    {
        [AppHelper showAlertViewWithTag:1 title:AppName message:errorMessage delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        return NO;
    }
    else
        return YES;
}

-(BOOL)checkUserNameField
{
    NSString *errorMessage=@"";
    if([_txtOldPswd.text length]==0)
        errorMessage=@"Please enter old username.";
    else if([_txtNewPswd.text length]==0)
        errorMessage=@"Please enter new username.";
    else if([_txtConfirmPswd.text length]==0)
        errorMessage=@"Please enter new confirm username.";
    else if(![_txtNewPswd.text isEqualToString:_txtConfirmPswd.text])
        errorMessage=@"New username and confirm username does not match.";
    else if([_txtNewPswd.text isEqualToString:_txtOldPswd.text])
        errorMessage=@"Old username and new username can't be same.";
    if([errorMessage length]>0)
    {
        [AppHelper showAlertViewWithTag:1 title:AppName message:errorMessage delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        return NO;
    }
    else
        return YES;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    [self resignKeyBoard];
}

-(void)resignKeyBoard
{
    if([_txtOldPswd isFirstResponder])
        [_txtOldPswd resignFirstResponder];
    else if([_txtNewPswd isFirstResponder])
        [_txtNewPswd resignFirstResponder];
    else if([_txtConfirmPswd isFirstResponder])
        [_txtConfirmPswd resignFirstResponder];
}

#pragma mark Services response
-(void)userDidChangePassword:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Change_Password object:nil];
    
    if(note.userInfo)
    {
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
            [AppHelper showAlertViewWithTag:100 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:self cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        else
            [AppHelper showAlertViewWithTag:103 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

-(void)userDidChangeUserName:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Change_Username object:nil];
    
    if(note.userInfo)
    {
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
            [AppHelper showAlertViewWithTag:100 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:self cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        else
            [AppHelper showAlertViewWithTag:103 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

#pragma mark-Textfield deligate methods
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.text.length==0 && [string isEqualToString:@" "])
        return NO;
    
    return YES;
}

#pragma mark Alertview deligate method
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
