//
//  ChangePasswordVC.h
//  youskoop
//
//  Created by Shitesh Patel on 10/07/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChangePasswordVC : UIViewController
@property BOOL isChangeUserName;
@end
