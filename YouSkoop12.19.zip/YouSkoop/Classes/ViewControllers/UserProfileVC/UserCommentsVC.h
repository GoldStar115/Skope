//
//  UserCommentsVC.h
//  youskoop
//
//  Created by Shitesh Patel on 02/07/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UserCommentsVC : UIViewController

@end
