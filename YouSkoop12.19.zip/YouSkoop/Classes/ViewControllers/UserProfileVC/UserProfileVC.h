//
//  UserProfileVC.h
//  youskoop
//
//  Created by Shitesh Patel on 23/05/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import<MediaPlayer/MediaPlayer.h>

@interface UserProfileVC : UIViewController<UITableViewDelegate,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>
{
    
}

@property (strong, nonatomic) MPMoviePlayerController *moviePlayer;
@property BOOL isShowingUserProfile;
@property (strong,nonatomic) NSString *name;
@property (strong,nonatomic) NSString *imgUrl;
@property (strong,nonatomic) NSString *blockUserId;
@property (strong,nonatomic) NSString *groupId;
@property (strong,nonatomic) NSString *groupOwnerId;
@end
