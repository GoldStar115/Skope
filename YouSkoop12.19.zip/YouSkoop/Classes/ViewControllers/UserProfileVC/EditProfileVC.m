//
//  EditProfileVC.m
//  youskoop
//
//  Created by Shitesh Patel on 04/07/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "EditProfileVC.h"
#import "ChangePasswordVC.h"
#import "BlockedUserVC.h"
#import "NSDate+convenience.h"

#import "VPImageCropperViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <MobileCoreServices/MobileCoreServices.h>
#import "CreditCardCV.h"
#import "WelcomeView.h"
#import "CLController.h"

//////
#import "TRTextFieldExtensions.h"
#import "TRGoogleMapsAutocompletionCellFactory.h"

#define ORIGINAL_MAX_WIDTH 640.0f

@interface EditProfileVC ()<VPImageCropperDelegate,UIImagePickerControllerDelegate>
{
    NSMutableDictionary *profDataDict;
    __weak IBOutlet UITableView *_tableView;
    __weak IBOutlet UIView *_headerView;
    __weak IBOutlet UIImageView *_imgProfile;
    __weak IBOutlet UIView *_viewPickerBase;
    __weak IBOutlet UIDatePicker *_datePicker;
    __weak IBOutlet UIView *_viewCropImage;
    __weak IBOutlet UIButton *_btnCancelCropImage;
    __weak IBOutlet UIButton *_btnCropImage;
    __weak IBOutlet UIView *_viewSelectImage;
    __weak IBOutlet UIView *_viewSelectAvatar;
    __weak IBOutlet UILabel *_lblChoosePicture;
    __weak IBOutlet UILabel *_lblChooseAvatar;
    __weak IBOutlet UIView *_viewSelectImageOption;
    UITextField *currentSelectedTxtField;
    NSData *profImageData;
    BOOL isPushNotificationEnable;
    BOOL isSoundEnable;
    NSString *dob;
}
@property (strong, nonatomic) UIImageView *cropImage;
@property (weak, nonatomic) UILabel *_lblDob;
@end

@implementation EditProfileVC
@synthesize cropImage,_lblDob;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    _viewCropImage.frame=self.view.bounds;
    profDataDict=[[NSMutableDictionary alloc] init];
    currentSelectedTxtField=[[UITextField alloc] init];
    CGRect frameRect=_viewPickerBase.frame;
    frameRect.origin.y=self.view.frame.size.height;
    _viewPickerBase.frame=frameRect;
    _tableView.tableHeaderView=_headerView;
    
    _lblChooseAvatar.textColor=KTextColor;
    _lblChoosePicture.textColor=KTextColor;
    _viewSelectImageOption.hidden=YES;
    
    _datePicker.backgroundColor=[UIColor whiteColor];
    [AppHelper getRoundedRectImageWithImageView:_imgProfile withColor:[UIColor whiteColor] andRadius:_imgProfile.frame.size.width/2 andWidth:2.0];
    
    UITapGestureRecognizer *coverTapGesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(userProfileImageHandleTap:)];
    coverTapGesture.numberOfTapsRequired=1;
    coverTapGesture.numberOfTouchesRequired=1;
    coverTapGesture.delegate=self;
    _imgProfile.userInteractionEnabled=YES;
    [_imgProfile addGestureRecognizer:coverTapGesture];
    
    UITapGestureRecognizer *tapGesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(userProfileImageHandleTap:)];
    tapGesture.numberOfTapsRequired=1;
    tapGesture.numberOfTouchesRequired=1;
    tapGesture.delegate=self;
    _headerView.userInteractionEnabled=YES;
    [_headerView addGestureRecognizer:tapGesture];
    
    NSMutableDictionary *profDict=[AppHelper userDefaultsDictionaryDataForKey:KUserProfData];
    if([profDict valueForKey:@"name"])
        [profDataDict setValue:[profDict valueForKey:@"name"] forKey:@"name"];
    else
        [profDataDict setValue:@"" forKey:@"name"];
    
    if([profDict valueForKey:@"email"])
        [profDataDict setValue:[profDict valueForKey:@"email"] forKey:@"email"];
    else
        [profDataDict setValue:@"" forKey:@"email"];
    
    if([profDict valueForKey:@"dob"] && [[profDict valueForKey:@"dob"] length] > 5){
        dob=[profDict valueForKey:@"dob"];
        NSDateFormatter *dateFormater=[[NSDateFormatter alloc] init];
        [dateFormater setDateFormat:@"yyyy-MM-dd"];
        NSDate *date=[dateFormater dateFromString:dob];
        [dateFormater setDateFormat:@"MMM dd yyyy"];
        [profDataDict setValue:[dateFormater stringFromDate:date] forKey:@"dob"];
        [_datePicker setDate:date animated:NO];
    }
    else
        [profDataDict setValue:@"" forKey:@"dob"];
    
    if([profDict valueForKey:@"city"])
        [profDataDict setValue:[profDict valueForKey:@"city"] forKey:@"city"];
    else
        [profDataDict setValue:@"" forKey:@"city"];
    
    if([profDict valueForKey:@"notification"])
        [profDataDict setValue:[profDict valueForKey:@"notification"] forKey:@"notification"];
    else
        [profDataDict setValue:@"1" forKey:@"notification"];
    
    if([profDict valueForKey:@"sound"])
        [profDataDict setValue:[profDict valueForKey:@"sound"] forKey:@"sound"];
    else
        [profDataDict setValue:@"1" forKey:@"sound"];
    
    if([[profDict valueForKey:@"notification"] integerValue]==1)
        isPushNotificationEnable=YES;
    if([[profDict valueForKey:@"sound"] integerValue]==1)
        isSoundEnable=YES;
    
    if([profDict valueForKey:@"image"] && [[profDict valueForKey:@"image"] length]>0)
        [_imgProfile setImageWithURL:[NSURL URLWithString:[profDict valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    [self performSelector:@selector(initializeAutocompleteApi) withObject:nil afterDelay:0.2];
}

-(void)viewWillAppear:(BOOL)animated{
    //hide tabbar
    [[AppDelegate getAppDelegate] hideTabBar:self.tabBarController];
}
-(void)viewWillDisappear:(BOOL)animated{
    //Show tabbar
    [[AppDelegate getAppDelegate] showTabBar:self.tabBarController];
}
#pragma mark Tap gesture methods
- (void)userProfileImageHandleTap:(UITapGestureRecognizer *)recognizer
{
    if([currentSelectedTxtField isFirstResponder])
        [currentSelectedTxtField resignFirstResponder];
    else if(recognizer.view==_imgProfile)
    {
        _viewSelectImageOption.hidden=NO;
        _viewSelectAvatar.hidden=YES;
        _viewSelectImage.hidden=NO;
    }
}

//Initialize autocomplete api for location searching
-(void)initializeAutocompleteApi
{
    [AppHelper saveToUserDefaults:@"1" withKey:kIsSearchCity];
    if(!_itemSource){
        NSLog(@"Initialize====TRGoogleMapsAutocompleteItemsSource");
        _itemSource=[[TRGoogleMapsAutocompleteItemsSource alloc] initWithMinimumCharactersToTrigger:1 apiKey:Google_API_Key withLati:[CLController sharedInstance].userCurrentLocation.coordinate.latitude withLongi:[CLController sharedInstance].userCurrentLocation.coordinate.longitude];
    }
}

#pragma mark Button action methods
- (IBAction)onClickBackButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)onClickSaveButton:(id)sender
{
    NSLog(@"%@",profDataDict);
    if([self isAllMandaroryFieldAreFilled])//Check mandatory fields
    {
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidChangeProfileInfo:) name:Notification_Update_Profile object:nil];
        [[WebServicesController WebServiceMethod] updateUserProfileWithUserId:[AppHelper userDefaultsForKey:KUserId] userName:[profDataDict valueForKey:@"name"] email:[profDataDict valueForKey:@"email"] dob:dob currentCity:[profDataDict valueForKey:@"city"] userProfileImage:profImageData pushNotification:[NSString stringWithFormat:@"%i",isPushNotificationEnable] sound:[NSString stringWithFormat:@"%i",isSoundEnable] andAppToken:KAppToken];
    }
}

- (IBAction)onClickGalleryButton:(id)sender
{
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    imagePicker.delegate = self;
    imagePicker.allowsEditing = NO;
    
    UIImagePickerControllerSourceType sourcetype =UIImagePickerControllerSourceTypePhotoLibrary;
    if ([UIImagePickerController isSourceTypeAvailable: sourcetype]){
        imagePicker.sourceType = sourcetype;
        [self presentViewController:imagePicker animated:YES completion:nil];
    }
}
- (IBAction)onClickCameraButton:(id)sender
{
    NSLog(@"camera");
    UIImagePickerController *image_picker=nil;
    image_picker = [[UIImagePickerController alloc] init];
    image_picker.delegate =self;
    image_picker.allowsEditing = NO;
    image_picker.navigationBar.barStyle = UIBarStyleBlackOpaque;
    UIImagePickerControllerSourceType sourceType =UIImagePickerControllerSourceTypeCamera;
    if ([UIImagePickerController isSourceTypeAvailable: sourceType]){
        image_picker.sourceType = sourceType;
        [self presentViewController:image_picker animated:YES completion:nil];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Device has no camera." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
}
- (IBAction)onClickAvtarButton:(id)sender
{
    _viewSelectImage.hidden=YES;
    _viewSelectAvatar.hidden=NO;
}
- (IBAction)onClickMaleButton:(id)sender
{
    _imgProfile.image=[UIImage imageNamed:@"male_selected.png"];
    _viewSelectImageOption.hidden=YES;
    profImageData=UIImageJPEGRepresentation(_imgProfile.image, 0.6);
}
- (IBAction)onClickFemaleButton:(id)sender
{
    _imgProfile.image=[UIImage imageNamed:@"female_selected.png"];
    _viewSelectImageOption.hidden=YES;
    profImageData=UIImageJPEGRepresentation(_imgProfile.image, 0.6);
}

- (IBAction)onClickCrossButton:(id)sender
{
    _viewSelectImage.hidden=NO;
    _viewSelectAvatar.hidden=YES;
}

- (void)selectDateOfBirth
{
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect=self.view.bounds;
                         frameRect.origin.y=0;
                         _viewPickerBase.frame=frameRect;
                     }completion:nil];
}

- (IBAction)pickerDoneAction:(id)sender{
    
    if([[NSDate date] year] - [_datePicker.date year] >= 1){
        NSDateFormatter *dateFormater=[[NSDateFormatter alloc] init];
        [dateFormater setDateFormat:@"MMM dd yyyy"];
        [profDataDict setValue:[dateFormater stringFromDate:_datePicker.date] forKey:@"dob"];
        
        self._lblDob.text=[profDataDict valueForKey:@"dob"];
        self._lblDob.textColor=[UIColor blackColor];
        
        [dateFormater setDateFormat:@"yyyy-MM-dd"];
        dob=[dateFormater stringFromDate:_datePicker.date];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Date of birth is invalid." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect=_viewPickerBase.frame;
                         frameRect.origin.y=self.view.frame.size.height;
                         _viewPickerBase.frame=frameRect;
                     }
                     completion:nil];
}
- (IBAction)pickerCancelAction:(id)sender
{
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect=_viewPickerBase.frame;
                         frameRect.origin.y=self.view.frame.size.height;
                         _viewPickerBase.frame=frameRect;
                     }
                     completion:nil];
}

- (IBAction)cancelSelectedImage:(id)sender
{
    [_viewCropImage removeFromSuperview];
}

- (IBAction)cropSelectedImage:(id)sender
{
    //_imgProfile.image = [self.cropImage getCroppedImage];
    profImageData=UIImageJPEGRepresentation(_imgProfile.image, 0.6);
    [_viewCropImage removeFromSuperview];
}

-(void)onClickSwitchPushNotification:(id)sender
{
    UIButton *button=(UIButton*)sender;
    if([button isSelected])
    {
        [button setSelected:NO];
        isPushNotificationEnable=NO;
    }
    else
    {
        [button setSelected:YES];
        isPushNotificationEnable=YES;
    }
}

-(void)onClickSwitchSound:(id)sender
{
    UIButton *button=(UIButton*)sender;
    if([button isSelected])
    {
        [button setSelected:NO];
        isSoundEnable=NO;
    }
    else
    {
        [button setSelected:YES];
        isSoundEnable=YES;
    }
}

-(BOOL)isAllMandaroryFieldAreFilled
{
    NSString *erroeMessage=@"";
    if([[profDataDict valueForKey:@"name"] length]==0)
        erroeMessage=@"Please enter name.";
    else if([[profDataDict valueForKey:@"email"] length]>0)
    {
        if(![AppHelper emailValidate:[profDataDict valueForKey:@"email"]])
            erroeMessage=@"Please enter email in valid format.";
    }
    else if([[profDataDict valueForKey:@"email"] length]==0)
            erroeMessage=@"Please enter email.";
    else if([[profDataDict valueForKey:@"dob"] length]==0)
        erroeMessage=@"Please select date of birth.";
    else if([[profDataDict valueForKey:@"city"] length]==0)
        erroeMessage=@"Please enter your current city.";
    if([erroeMessage length]>0)
    {
        [AppHelper showAlertViewWithTag:1 title:AppName message:erroeMessage delegate:self cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        return NO;
    }
    else
        return YES;
}

#pragma mark Webservices response
-(void)userDidChangeProfileInfo:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Update_Profile object:nil];
    
    if(note.userInfo)
    {
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
        {
            [AppHelper saveToUserDefaults:[profDataDict valueForKey:@"name"] withKey:KUserName];
            [profDataDict setValue:[NSString stringWithFormat:@"%i",isPushNotificationEnable] forKey:@"notification"];
            [profDataDict setValue:[NSString stringWithFormat:@"%i",isSoundEnable] forKey:@"sound"];
            
            if([profDataDict valueForKey:@"dob"] && [[profDataDict valueForKey:@"dob"] length]>0)
            {
                NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
                [dateFormatter setDateFormat:@"MMM dd yyyy"];
                NSDate *BDate=[dateFormatter dateFromString:[profDataDict valueForKey:@"dob"]];
                [dateFormatter setDateFormat:@"yyyy-MM-dd"];
                NSString *date=[dateFormatter stringFromDate:BDate];
                if(date)
                    [profDataDict setValue:date forKey:@"dob"];
            }
            
            if([[note.userInfo valueForKey:@"data"] valueForKey:@"image"] && [[[note.userInfo valueForKey:@"data"] valueForKey:@"image"] length]>15)
            {
                [profDataDict setValue:[[note.userInfo valueForKey:@"data"] valueForKey:@"image"] forKey:@"image"];
                [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"image"] withKey:KUserImageUrl];
                [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_UserImage object:nil userInfo:nil];
            }
            else
            {
                NSMutableDictionary *savedDict=[AppHelper userDefaultsDictionaryDataForKey:KUserProfData];
                [profDataDict setValue:[savedDict valueForKey:@"image"] forKey:@"image"];
            }
            NSLog(@"%@",profDataDict);
            [AppHelper saveToUserDefaults:profDataDict withKey:KUserProfData];
        }
        [AppHelper showAlertViewWithTag:103 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

-(void)userDidLoggedOut:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_logout object:nil];
    
    if(note.userInfo)
    {
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
        {
            [[AppDelegate getAppDelegate] loggedOutFromApp];
        }
        else
            [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}


#pragma mark VPImageCropperDelegate
- (void)imageCropper:(VPImageCropperViewController *)cropperViewController didFinished:(UIImage *)editedImage originalImage:(UIImage *)originalImage
{
    self.cropImage.image=editedImage;
    _imgProfile.image=editedImage;
    profImageData=UIImageJPEGRepresentation(editedImage, 1.0);
    [cropperViewController dismissViewControllerAnimated:YES completion:^{
        // TO DO
    }];
}

- (void)imageCropperDidCancel:(VPImageCropperViewController *)cropperViewController
{
    [cropperViewController dismissViewControllerAnimated:YES completion:^{
    }];
}

#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    [picker dismissViewControllerAnimated:NO completion:^() {
        
        _viewSelectImageOption.hidden=YES;
         [AppHelper stausBarColorChange];
        UIImage *portraitImg = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        portraitImg = [self imageByScalingToMaxSize:portraitImg];
        
        // present the cropper view controller
        VPImageCropperViewController *imgCropperVC = nil;
        imgCropperVC = [[VPImageCropperViewController alloc] initWithImage:portraitImg cropFrame:CGRectMake(self.view.bounds.size.width/2-75, 100.0f, 150, 150) limitScaleRatio:3.0];
        imgCropperVC.delegate = self;
        imgCropperVC.isCircularCropper = YES;
        [self presentViewController:imgCropperVC animated:NO completion:^{
            // TO DO
        }];
        
    }];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:^(){
    }];
}

#pragma mark image scale utility
- (UIImage *)imageByScalingToMaxSize:(UIImage *)sourceImage
{
    if (sourceImage.size.width < ORIGINAL_MAX_WIDTH) return sourceImage;
    CGFloat btWidth = 0.0f;
    CGFloat btHeight = 0.0f;
    if (sourceImage.size.width > sourceImage.size.height) {
        btHeight = ORIGINAL_MAX_WIDTH;
        btWidth = sourceImage.size.width * (ORIGINAL_MAX_WIDTH / sourceImage.size.height);
    } else {
        btWidth = ORIGINAL_MAX_WIDTH;
        btHeight = sourceImage.size.height * (ORIGINAL_MAX_WIDTH / sourceImage.size.width);
    }
    CGSize targetSize = CGSizeMake(btWidth, btHeight);
    return [self imageByScalingAndCroppingForSourceImage:sourceImage targetSize:targetSize];
}

- (UIImage *)imageByScalingAndCroppingForSourceImage:(UIImage *)sourceImage targetSize:(CGSize)targetSize
{
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor > heightFactor)
            scaleFactor = widthFactor; // scale to fit height
        else
            scaleFactor = heightFactor; // scale to fit width
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }
        else
            if (widthFactor < heightFactor)
            {
                thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
            }
    }
    UIGraphicsBeginImageContext(targetSize); // this will crop
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width  = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil) NSLog(@"could not scale image");
    
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    return newImage;
}

#pragma mark Tableview deligate methods

- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50.0;
}

//asks the data source to return the number of rows in a given section of a table view
//we are returning the number of countries in a given continent
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 11;
}

//asks the data source for a cell to insert in a particular location of the table view
- (UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *myCellView = nil;
    
    NSString *TableViewCellIdentifier = [NSString stringWithFormat:@"cellIdentifier%i",(int)indexPath.row];
    
    //this method dequeues an existing cell if one is available or creates a new one
    //if no cell is available for reuse, this method returns nil
    myCellView = [tableView dequeueReusableCellWithIdentifier:TableViewCellIdentifier];
    if (myCellView == nil)
    {
        myCellView = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:TableViewCellIdentifier];
        myCellView.backgroundColor=[UIColor clearColor];
        myCellView.selectionStyle=UITableViewCellSelectionStyleNone;
        
        UIImageView *imgBase=[[UIImageView alloc] initWithFrame:CGRectMake(0, 5, 260, 40)];
        imgBase.backgroundColor=[UIColor clearColor];
        imgBase.tag=100;
        [myCellView.contentView addSubview:imgBase];
        
        if(indexPath.row==0 || indexPath.row==1 || indexPath.row==3)
        {
            UITextField *txtField=[[UITextField alloc] initWithFrame:CGRectMake(6, 9, 248, 34)];
            txtField.backgroundColor=[UIColor clearColor];
            txtField.clearButtonMode=UITextFieldViewModeWhileEditing;
            txtField.autocorrectionType=UITextAutocapitalizationTypeNone;
            txtField.tag=200+indexPath.row;
            txtField.delegate=self;
            txtField.font=[UIFont systemFontOfSize:16.0];
            [myCellView.contentView addSubview:txtField];
        }
        else
        {
            if(indexPath.row==2)
            {
                UILabel *label=[[UILabel alloc] initWithFrame:CGRectMake(6, 9, 248, 34)];
                label.tag=301;
                label.backgroundColor=[UIColor clearColor];
                label.textColor=[UIColor lightGrayColor];
                self._lblDob=label;
                [myCellView.contentView addSubview:label];
            }
            else
            {
                UILabel *label=[[UILabel alloc] initWithFrame:CGRectMake(6, 9, 248, 34)];
                label.tag=300;
                label.backgroundColor=[UIColor clearColor];
                label.textColor=[UIColor lightGrayColor];
                [myCellView.contentView addSubview:label];
            }
            
            if(indexPath.row==4)//Push notification
            {
                UIButton *btnPushSwitch=[UIButton buttonWithType:UIButtonTypeCustom];
                [btnPushSwitch addTarget:self action:@selector(onClickSwitchPushNotification:) forControlEvents:UIControlEventTouchUpInside];
                [btnPushSwitch setImage:[UIImage imageNamed:@"off.png"] forState:UIControlStateNormal];
                [btnPushSwitch setImage:[UIImage imageNamed:@"on.png"] forState:UIControlStateSelected];
                if(isPushNotificationEnable)
                    [btnPushSwitch setSelected:YES];
                else
                    [btnPushSwitch setSelected:NO];
                btnPushSwitch.frame=CGRectMake(186, 12, 69, 26);
                btnPushSwitch.tag=400;
                [myCellView.contentView addSubview:btnPushSwitch];
            }
            else if(indexPath.row==5)//Sound
            {
                UIButton *btnSoundSwitch=[UIButton buttonWithType:UIButtonTypeCustom];
                [btnSoundSwitch addTarget:self action:@selector(onClickSwitchSound:) forControlEvents:UIControlEventTouchUpInside];
                [btnSoundSwitch setImage:[UIImage imageNamed:@"off.png"] forState:UIControlStateNormal];
                [btnSoundSwitch setImage:[UIImage imageNamed:@"on.png"] forState:UIControlStateSelected];
                if(isSoundEnable)
                    [btnSoundSwitch setSelected:YES];
                else
                    [btnSoundSwitch setSelected:NO];
                btnSoundSwitch.frame=CGRectMake(186, 12, 69, 26);
                btnSoundSwitch.tag=401;
                [myCellView.contentView addSubview:btnSoundSwitch];
            }
        }
    }
    
    UIImageView *baseImage=(UIImageView*)[myCellView.contentView viewWithTag:100];
    if(indexPath.row<6)
        baseImage.image=[UIImage imageNamed:@"map_input.png"];
    else
        baseImage.image=[UIImage imageNamed:@"managed_btn.png"];
    
    if(indexPath.row==0)//Name
    {
        UITextField *txtFieldName=(UITextField*)[myCellView.contentView viewWithTag:200];
        txtFieldName.placeholder=@"Name";
        txtFieldName.autocorrectionType=UITextAutocorrectionTypeDefault;
        txtFieldName.autocapitalizationType=UITextAutocapitalizationTypeWords;
        if([profDataDict valueForKey:@"name"] && [[profDataDict valueForKey:@"name"] length]>0)
            txtFieldName.text=[profDataDict valueForKey:@"name"];
    }
    else if(indexPath.row==1)//Email
    {
        UITextField *txtFieldEmail=(UITextField*)[myCellView.contentView viewWithTag:201];
        txtFieldEmail.placeholder=@"Email";
        txtFieldEmail.autocorrectionType=UITextAutocorrectionTypeNo;
        txtFieldEmail.autocapitalizationType=UITextAutocapitalizationTypeNone;
        if([profDataDict valueForKey:@"email"] && [[profDataDict valueForKey:@"email"] length]>0)
            txtFieldEmail.text=[profDataDict valueForKey:@"email"];
    }
    else if(indexPath.row==2)//Date of birth
    {
        UILabel *lblDob=(UILabel*)[myCellView.contentView viewWithTag:301];
        if([[profDataDict valueForKey:@"dob"] length]>0)
        {
            lblDob.text=[profDataDict valueForKey:@"dob"];
            lblDob.textColor=[UIColor blackColor];
        }
        else
        {
            lblDob.text=@"Date of Birth";
            lblDob.textColor=[UIColor lightGrayColor];
        }
    }
    else if(indexPath.row==3)//Current City
    {
        UITextField *txtFieldCity=(UITextField*)[myCellView.contentView viewWithTag:203];
        txtFieldCity.placeholder=@"Current City (optional)";
        if([profDataDict valueForKey:@"city"] && [[profDataDict valueForKey:@"city"] length]>0)
            txtFieldCity.text=[profDataDict valueForKey:@"city"];
    }
    else if(indexPath.row==4)//Push Notification
    {
        UILabel *lblPushNotification=(UILabel*)[myCellView.contentView viewWithTag:300];
        lblPushNotification.text=@"Push Notifications";
        lblPushNotification.textAlignment=NSTextAlignmentLeft;
        lblPushNotification.textColor=[UIColor lightGrayColor];
    }
    else if(indexPath.row==5)//Sound
    {
        UILabel *lblSound=(UILabel*)[myCellView.contentView viewWithTag:300];
        lblSound.text=@"Sound";
        lblSound.textAlignment=NSTextAlignmentLeft;
        lblSound.textColor=[UIColor lightGrayColor];
    }
    else if(indexPath.row==6)//Payment info
    {
        UILabel *lblPaymentInfo=(UILabel*)[myCellView.contentView viewWithTag:300];
        lblPaymentInfo.text=@"Payment Info";
        lblPaymentInfo.textAlignment=NSTextAlignmentCenter;
        lblPaymentInfo.textColor=[UIColor whiteColor];
    }
    else if(indexPath.row==7)//Change Password
    {
        UILabel *lblChangePassword=(UILabel*)[myCellView.contentView viewWithTag:300];
        lblChangePassword.text=@"Change Password";
        lblChangePassword.textAlignment=NSTextAlignmentCenter;
        lblChangePassword.textColor=[UIColor whiteColor];
    }
    else if(indexPath.row==8)//Change User Name
    {
        UILabel *lblUserName=(UILabel*)[myCellView.contentView viewWithTag:300];
        lblUserName.text=@"Change Username";
        lblUserName.textAlignment=NSTextAlignmentCenter;
        lblUserName.textColor=[UIColor whiteColor];
    }
    else if(indexPath.row==9)//Manage Blocked Users
    {
        UILabel *lblBlockUser=(UILabel*)[myCellView.contentView viewWithTag:300];
        lblBlockUser.text=@"Manage Blocked Users";
        lblBlockUser.textAlignment=NSTextAlignmentCenter;
        lblBlockUser.textColor=[UIColor whiteColor];
    }
    else if(indexPath.row==10)//Log out
    {
        UILabel *lblBlockUser=(UILabel*)[myCellView.contentView viewWithTag:300];
        lblBlockUser.text=@"Log Out";
        lblBlockUser.textAlignment=NSTextAlignmentCenter;
        lblBlockUser.textColor=[UIColor whiteColor];
    }
        
    return myCellView;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([currentSelectedTxtField isFirstResponder])
        [currentSelectedTxtField resignFirstResponder];
    if(indexPath.row==2)//Date of borth
    {
        [self selectDateOfBirth];
    }
    else if(indexPath.row==6)//Payment info
    {
        [self performSegueWithIdentifier:@"creditcard" sender:nil];
    }
    else if(indexPath.row==7)//Change Password
    {
        [self performSegueWithIdentifier:@"changepswd" sender:@"0"];
    }
    else if(indexPath.row==8)//Change User Name
    {
        [self performSegueWithIdentifier:@"changepswd" sender:@"1"];
    }
    else if(indexPath.row==9)//Manage Blocked Users
    {
        [self performSegueWithIdentifier:@"manageblockuser" sender:nil];
    }
    else if(indexPath.row==10)//Log out
    {
        [AppHelper showAlertViewWithTag:101 title:AppName message:@"Are you sure you want to log out now?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
    }
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag==101){
        if(buttonIndex==0){
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidLoggedOut:) name:Notification_logout object:nil];
            [[WebServicesController WebServiceMethod] signOutWithUserId:[AppHelper userDefaultsForKey:KUserId] deviceId:[AppHelper userDefaultsForKey:Device_Id] andToken:KAppToken];
        }
    }
}

#pragma mark Date picker deligate
- (void)selectRow:(NSInteger)row inComponent:(NSInteger)component animated:(BOOL)animated
{
    
}

#pragma mark-Textfield deligate methods

-(void)keyboardwillShowNotification:(NSNotification*)note
{
    
}

-(void)keyboardwillHideNotification:(NSNotification*)note
{
    
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    currentSelectedTxtField=textField;
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    if(textField.tag==203)//City textfield
    {
        [_tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:8 inSection:0] atScrollPosition:UITableViewScrollPositionTop animated:NO];
        [self performSelector:@selector(intializeCitySearchWithTextField:) withObject:textField afterDelay:1.0];
    }
}

-(void)intializeCitySearchWithTextField:(UITextField*)txtCity{
    NSLog(@"Initialize****************");
    _autocompleteView = [TRAutocompleteView autocompleteViewBindedTo:txtCity
                                                         usingSource:_itemSource   cellFactory:[[TRGoogleMapsAutocompletionCellFactory alloc]
                                                                                                initWithCellForegroundColor:[UIColor whiteColor]                                                                                                                                                                fontSize:12]
                                                        presentingIn:self];
    [txtCity setLeftPadding:0];
    _autocompleteView.topMargin = 0;
    _autocompleteView.backgroundColor = [UIColor clearColor];
    _autocompleteView.didAutocompleteWith = ^(id<TRSuggestionItem> item){
    };
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if(textField.tag==200)
        [profDataDict setValue:textField.text forKey:@"name"];
    else if(textField.tag==201)
        [profDataDict setValue:textField.text forKey:@"email"];
    else if(textField.tag==203)
        [profDataDict setValue:textField.text forKey:@"city"];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.text.length==0 && [string isEqualToString:@" "])
        return NO;
    
    return YES;
}

#pragma mark Touch method
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    if (touch.view.tag==345)//Touched view is category picker view
    {
        //hide category picker
        [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                         animations:^{
                             CGRect frameRect=_viewPickerBase.frame;
                             frameRect.origin.y=568;
                             _viewPickerBase.frame=frameRect;
                         }
                         completion:nil];
    }
    else if(![_viewSelectImageOption isHidden])
        _viewSelectImageOption.hidden=YES;
    //Here I want the object of particular view on which user touched.
    if([currentSelectedTxtField isFirstResponder])
        [currentSelectedTxtField resignFirstResponder];
}

#pragma mark Prepare for segue
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if ([segue.identifier isEqualToString:@"changepswd"]){
        ChangePasswordVC *destViewController = segue.destinationViewController;
        destViewController.isChangeUserName=[(NSString*)sender integerValue];
    }
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
