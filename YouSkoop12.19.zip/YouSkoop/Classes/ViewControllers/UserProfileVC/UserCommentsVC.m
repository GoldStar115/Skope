//
//  UserCommentsVC.m
//  youskoop
//
//  Created by Shitesh Patel on 02/07/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "UserCommentsVC.h"
#import "RequestViewViewController.h"

@interface UserCommentsVC ()
{
    NSInteger selectedIndex;
    NSMutableArray *commentsArray;
    __weak IBOutlet UITableView *_tableView;
    NSDateFormatter *dateFormatter;
    NSDateFormatter *finalDateFormatter;
}

@end

@implementation UserCommentsVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    dateFormatter = [[NSDateFormatter alloc] init];
    finalDateFormatter = [[NSDateFormatter alloc] init];
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetComment:) name:Notification_Get_Comment object:nil];
    [[WebServicesController WebServiceMethod] getCommentWithUserId:[AppHelper userDefaultsForKey:KUserId] andAppToken:KAppToken];
}

-(void)viewWillAppear:(BOOL)animated{
    //hide tabbar
    [[AppDelegate getAppDelegate] hideTabBar:self.tabBarController];
}
-(void)viewWillDisappear:(BOOL)animated{
    //Show tabbar
    [[AppDelegate getAppDelegate] showTabBar:self.tabBarController];
}

-(IBAction)onClickBackButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)onClickSendSkoopButton:(id)sender
{
    [self performSegueWithIdentifier:@"sendskooprequest" sender:nil];
}

-(IBAction)onClickReportButton:(id)sender
{
    UITableViewCell *tableVewCell=nil;
    if(IS_IOS_7)
        tableVewCell=(UITableViewCell*)[[[sender superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[sender superview] superview];
    
    NSIndexPath *indexPath=[_tableView indexPathForCell:tableVewCell];
    selectedIndex=indexPath.row;
    NSDictionary *dataDict=[commentsArray objectAtIndex:indexPath.row];
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReportComment:) name:Notification_Report_Comment object:nil];
    [[WebServicesController WebServiceMethod] reportCommentWithUserId:[AppHelper userDefaultsForKey:KUserId] commentId:[dataDict valueForKey:@"comment_id"] description:@"" andAppToken:KAppToken];
}

#pragma mark Receive webservices response and notifications
-(void)userDidGetComment:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Comment object:nil];
    
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
    {
        NSMutableArray *array=(NSMutableArray*)[note.userInfo valueForKey:@"data"];
        if(array.count>0)
        {
            commentsArray=[[NSMutableArray alloc] initWithArray:array];
            [_tableView reloadData];
        }
    }
}

-(void)userDidReportComment:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Report_Comment object:nil];
    
    if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
    {
        NSMutableDictionary *dataDict=[NSMutableDictionary dictionaryWithDictionary:[commentsArray objectAtIndex:selectedIndex]];
        [dataDict setValue:@"1" forKey:@"report_status"];
        [commentsArray replaceObjectAtIndex:selectedIndex withObject:dataDict];
        [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
    }
    
    [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

#pragma mark Tableview deligate methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return commentsArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 10;
}
- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UILabel *lblHeader=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 10)];
    lblHeader.backgroundColor=[UIColor clearColor];
    return lblHeader;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dataDict=[commentsArray objectAtIndex:indexPath.row];
    float cellHeight=[AppHelper getStringBoundingSize:[dataDict valueForKey:@"body"] forWidth:230 withFont:[UIFont systemFontOfSize:14.0]];
    return cellHeight+55;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell;
    NSString *CellIdentifier =@"comment";
    cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell.layer.borderColor=[UIColor grayColor].CGColor;
    cell.backgroundColor=[UIColor clearColor];
    
    NSDictionary *dataDict=[commentsArray objectAtIndex:indexPath.row];
    
    UIButton *btnReport=(UIButton *)[cell.contentView viewWithTag:99];
    UIImageView *baseImg=(UIImageView *)[cell.contentView viewWithTag:100];
    UIImageView *profImg=(UIImageView *)[cell.contentView viewWithTag:101];
    
    CBAutoScrollLabel *lblCommentHeader=(CBAutoScrollLabel *)[cell.contentView viewWithTag:102];
    [lblCommentHeader setLabelSettingForObject:@"name"];
    UILabel *lblComment=(UILabel *)[cell.contentView viewWithTag:103];
    UILabel *lblCommentDate=(UILabel *)[cell.contentView viewWithTag:104];
    
    btnReport.layer.cornerRadius=4.0;
    
    if([[dataDict valueForKey:@"report_status"] integerValue]==1)
    {
        [btnReport setBackgroundColor:[UIColor colorWithRed:197.0/255.0 green:66.0/255.0 blue:230.0/255.0 alpha:1.0]];
        [btnReport setTitle:@"Comment Reported" forState:UIControlStateNormal];
    }
    else
    {
        [btnReport setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        [btnReport setTitle:@"Report Comment" forState:UIControlStateNormal];
    }
    
    float cellHeight=[AppHelper getStringBoundingSize:[dataDict valueForKey:@"body"] forWidth:230 withFont:[UIFont systemFontOfSize:14.0]];
    
    CGRect frameRect=baseImg.frame;
    frameRect.size.height=cellHeight+40;
    baseImg.frame=frameRect;
    
    baseImg.image= [[UIImage imageNamed:@"right_chat_box1.png"] stretchableImageWithLeftCapWidth:frameRect.size.width topCapHeight:60];
    
    CGRect frameRect1=lblComment.frame;
    frameRect1.size.height=cellHeight;
    lblComment.frame=frameRect1;
    lblComment.text=[dataDict valueForKey:@"body"];
    
    [AppHelper getRoundedImageWithImageView:profImg];
    NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dataDict objectForKey:@"image"]]];
    NSString *groupImageUrL=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:groupImageUrL];
    
    if([urlString length]>0)
        [profImg setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    else
        profImg.image=[UIImage imageNamed:@"defaultuser.png"];
    
    lblCommentHeader.text=[dataDict valueForKey:@"name"];
    
    CGRect frameRect2=lblCommentDate.frame;
    frameRect2.origin.y=lblComment.frame.origin.y+lblComment.frame.size.height+10;
    lblCommentDate.frame=frameRect2;
    
    //create the formatter for parsing
    [dateFormatter setTimeZone:[NSTimeZone timeZoneWithAbbreviation:@"UTC"]];
    [dateFormatter setDateFormat:@"dd MMM yyyy /hh:mm a"];
    
    //parsing the string and converting it to NSDate
    NSDate *myDate = [dateFormatter dateFromString: [dataDict valueForKey:@"date"]];
    
    //create the formatter for the output
    [finalDateFormatter setDateFormat:@"dd MMM yyyy /hh:mm a"];
    if([finalDateFormatter stringFromDate:myDate])
        lblCommentDate.text=[finalDateFormatter stringFromDate:myDate];
    else
        lblCommentDate.text=[dataDict valueForKey:@"date"];
    
    lblCommentDate.textColor=KTextColor;
    
    CGRect frameRect3=btnReport.frame;
    frameRect3.origin.y=lblComment.frame.origin.y+lblComment.frame.size.height+5;
    btnReport.frame=frameRect3;
    
    return  cell;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
