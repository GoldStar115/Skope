//
//  UserProfileVC.m
//  youskoop
//
//  Created by Shitesh Patel on 23/05/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "UserProfileVC.h"
#import "GroupProfileVC.h"
#import "youSKOOPVC.h"
#import "SAMTextView.h"
#import "RequestViewViewController.h"
#import <MediaPlayer/MediaPlayer.h>
#import "UserCommentsVC.h"
#import "AppcustomTabbar.h"
#import "EditProfileVC.h"
#import "ReplyOnSkoopVC.h"
#import "CellSelectionView.h"
#import "VideoUploaderVC.h"
#import "VideoPlayerVC.h"


@interface UserProfileVC ()<updateMyProfileData,upDateSkoopListDeligate,saveDataProtocol>
{
    __weak IBOutlet UILabel *_lblNavTitle;
    __weak IBOutlet UIButton *_btnSkoop;
    __weak IBOutlet UIButton *_btnBuy;
    __weak IBOutlet UIButton *_btnRequest;
    __weak IBOutlet UIImageView *_imgUser;
    __weak IBOutlet UILabel *_lblUserName;
    __weak IBOutlet UILabel *_lblJoinDate;
    __weak IBOutlet UILabel *_lblMember;
    __weak IBOutlet UILabel *_lblUserRating;
    __weak IBOutlet UILabel *_lblRateUser;
    __weak IBOutlet UIButton *_btnThumbsUp;
    __weak IBOutlet UIButton *_btnThumbsDown;
    __weak IBOutlet UILabel *_lblGroups;
    __weak IBOutlet UICollectionView *_collectionView;
     __weak IBOutlet UIButton *_btnBlockUser;
    __weak IBOutlet UIButton *_btnComment;
    __weak IBOutlet UIView *_viewGroup;
    __weak IBOutlet UIButton *_btnSettings;
    __weak IBOutlet SAMTextView *_txtViewComment;
    __weak IBOutlet UIView *_viewComment;
    __weak IBOutlet UITableView *_tableView;
    __weak IBOutlet UITableView *_tableViewComment;
    __weak IBOutlet UIView *_viewlist;
    __weak IBOutlet UILabel *_lblUserReviews;
    
    NSMutableArray *userGroupArray;
    NSMutableArray *arrayForIncomingScoops;
    int pageNumber;
    int pageNoForSkoops;
    
    int requestCount;
    int skoopCount;
    int buysCount;
    NSInteger selectedIndex;
    
    BOOL isHitServiceForMoreGroups;
    BOOL isShowReplierProfile;
    BOOL isHasNextPage;
    
    UILabel *lblFooter;
    UIView *tblFooterView;
    
    NSMutableArray *arrayForSendScoops;
    NSMutableArray *arrayForReplyScoops;
    NSMutableArray *arrayForBuysScoops;
}

@property (nonatomic, strong) NSMutableArray *arrayForComment;
@property (nonatomic, strong) MPMoviePlayerController *_moviePlayer;

@end

#define PageLimit           @"30"

@implementation UserProfileVC
@synthesize name,imgUrl,blockUserId,groupId,groupOwnerId;
@synthesize isShowingUserProfile;
@synthesize moviePlayer;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    arrayForSendScoops = [[NSMutableArray alloc] init];
    arrayForReplyScoops = [[NSMutableArray alloc] init];
    arrayForBuysScoops = [[NSMutableArray alloc] init];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateCountFromPushNotification:) name:Notification_Update_Count object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateUpcomingSkoopList:) name:Notification_Refresh_UpcomingSkoopList object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateBuysSkoopList:) name:Notification_Refresh_BuysSkoopList object:nil];
    
    _viewlist.hidden=YES;
    
    if([self.blockUserId isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
        isShowingUserProfile=YES;
    else
        isShowingUserProfile=NO;
    
    _lblUserReviews.textColor=KTextColor;
    
    //If user is viewing own profile
    if(isShowingUserProfile){
        
        _lblNavTitle.text = @"My Profile";
        _lblUserReviews.text = @"Upcoming Skoop Requests";
        
        UIButton *btnInvite = (UIButton*)[_viewGroup viewWithTag:104];
        btnInvite.hidden = YES;
        UIImageView *imgPlusIcon = (UIImageView*)[_viewGroup viewWithTag:1004];
        imgPlusIcon.hidden = YES;
        
        CGRect frameRect = _lblRateUser.frame;
        frameRect.origin.y = 40;
        _lblRateUser.frame = frameRect;
        _lblRateUser.textColor=[UIColor whiteColor];
        _lblRateUser.text=@"Settings";
        
        _btnThumbsDown.hidden=YES;
        _btnThumbsUp.hidden=YES;
        _btnBlockUser.hidden=YES;
        
        CGRect frameRect1 = _btnComment.frame;
        frameRect1.origin.y = 70;
        
        _btnComment.frame = CGRectMake(frameRect.origin.x - 4, 64, 85, 35);
        _btnComment.titleLabel.font = [UIFont systemFontOfSize:10];
        [_btnComment setTitle:@"User Reviews" forState:UIControlStateNormal];
        [_btnComment setTitle:@"User Reviews" forState:UIControlStateSelected];
    }
    else{ //If user is viewing any group member profile
        if([self.name length]>0)
            _lblNavTitle.text = [NSString stringWithFormat:@"%@'s Profile",[[self.name componentsSeparatedByString:@" "] objectAtIndex:0]];
        _btnSettings.hidden = YES;
        _lblUserReviews.text = @"User Reviews";
    }
    
    _viewComment.hidden = YES;
    _txtViewComment.placeholder = @"Write comment";
    UITapGestureRecognizer *uiTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnCommentView:)];
    uiTap.numberOfTapsRequired = 1;
    _viewComment.userInteractionEnabled = YES;
    [_viewComment addGestureRecognizer:uiTap];
    
    isHitServiceForMoreGroups = YES;
    pageNumber = 1;
    pageNoForSkoops = 1;
    
    userGroupArray = [[NSMutableArray alloc] init];
    
    _lblGroups.textColor = KTextColor;
    _lblUserName.text = self.name;
    
    UITapGestureRecognizer *uiTap1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnUserProfileImage:)];
    uiTap1.numberOfTapsRequired = 1;
    _imgUser.userInteractionEnabled = YES;
    [_imgUser addGestureRecognizer:uiTap1];
    
    _lblJoinDate.textColor = KTextColor;
    _lblMember.textColor = KTextColor;
    [_btnRequest setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [_btnSkoop setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [_btnBuy setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    
    _tableViewComment.tableHeaderView = _viewGroup;

    if(isShowingUserProfile){
        if(IS_Greater_Or_Equal_to_IOS_7){
            _tableViewComment.frame = CGRectMake(0, 206, self.view.frame.size.width, self.view.bounds.size.height-186-63);
        }
        else{
            if(IS_IPHONE_5)
                _tableViewComment.frame = CGRectMake(0, 176, self.view.frame.size.width, self.view.bounds.size.height-176-63);
            else
                _tableViewComment.frame = CGRectMake(0, 176, self.view.frame.size.width, self.view.bounds.size.height-180);
        }
    }
    else{
        if(IS_Greater_Or_Equal_to_IOS_7){
            _tableViewComment.frame = CGRectMake(0, 206, self.view.frame.size.width, self.view.bounds.size.height-206-63-30);
        }
        else{
            if(IS_IPHONE_5)
                _tableViewComment.frame = CGRectMake(0, 176, self.view.frame.size.width, self.view.bounds.size.height-176-63-30);
            else
                _tableViewComment.frame = CGRectMake(0, 176, self.view.frame.size.width, self.view.bounds.size.height-176);
        }
    }
    
    [_tableViewComment bringSubviewToFront:self.view];
    [self performSelector:@selector(getUserProfileData) withObject:nil afterDelay:0.5];
}

-(void)viewWillAppear:(BOOL)animated
{
    [AppHelper getRoundedRectImageWithImageView:_imgUser withColor:[UIColor clearColor] andRadius:_imgUser.frame.size.width/2.0 andWidth:0.0];
    if(isShowingUserProfile){
        if([AppHelper userDefaultsForKey:KUserImageUrl] && [[AppHelper userDefaultsForKey:KUserImageUrl] length]>0){
            [_imgUser setImageWithURL:[NSURL URLWithString:[AppHelper userDefaultsForKey:KUserImageUrl]] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
        }
        else{
            _imgUser.image=[UIImage imageNamed:@"defaultuser.png"];
        }
    }
    else if([self.imgUrl length]>0){
        [_imgUser setImageWithURL:[NSURL URLWithString:self.imgUrl] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    }
    else{
        _imgUser.image=[UIImage imageNamed:@"defaultuser.png"];
    }
    
    //Reload tableview and collectionview visible cells for re-initialize marque label
    NSArray *visibleCellsArray = [_tableView indexPathsForVisibleRows];
    if(visibleCellsArray && visibleCellsArray.count)
        [_tableView reloadRowsAtIndexPaths:visibleCellsArray withRowAnimation:UITableViewRowAnimationNone];
    NSArray *visibleCellsArray1 = [_tableViewComment indexPathsForVisibleRows];
    if(visibleCellsArray1 && visibleCellsArray1.count)
        [_tableViewComment reloadRowsAtIndexPaths:visibleCellsArray1 withRowAnimation:UITableViewRowAnimationNone];
    NSArray *visibleCells = [_collectionView indexPathsForVisibleItems];
    if(visibleCells && visibleCells.count)
        [_collectionView reloadItemsAtIndexPaths:visibleCells];
}

#pragma mark receive notifications
-(void)updateCountFromPushNotification:(NSNotification*)noti{
    
    NSLog(@"====%@",noti.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Update_Count object:nil];
    
    NSDictionary *dataDict = noti.userInfo;
    
    if([[dataDict valueForKey:@"req_type"] isEqualToString:@"requests"]){
        
        requestCount++;
        NSString *request=@"Requests";
        if(requestCount == 1)
            request=@"Request";
        
        [_btnRequest setTitle:[NSString stringWithFormat:@"%i %@",requestCount,request] forState:UIControlStateNormal];
        [_btnRequest setTitle:[NSString stringWithFormat:@"%i %@",requestCount,request] forState:UIControlStateSelected];
    }
    else if([[dataDict valueForKey:@"req_type"] isEqualToString:@"skoops"]){
        
        skoopCount++;
        NSString *request=@"Skoops";
        if(skoopCount == 1)
            request=@"Skoop";
        
        [_btnSkoop setTitle:[NSString stringWithFormat:@"%i %@",skoopCount,request] forState:UIControlStateNormal];
        [_btnSkoop setTitle:[NSString stringWithFormat:@"%i %@",skoopCount,request] forState:UIControlStateSelected];
    }
    else if([[dataDict valueForKey:@"req_type"] isEqualToString:@"buys"]){
        
        buysCount++;
        NSString *request=@"Buys";
        if(buysCount ==1)
            request=@"Buy";
        
        [_btnBuy setTitle:[NSString stringWithFormat:@"%i %@",buysCount,request] forState:UIControlStateNormal];
        [_btnBuy setTitle:[NSString stringWithFormat:@"%i %@",buysCount,request] forState:UIControlStateSelected];
    }
    
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateCountFromPushNotification:) name:Notification_Update_Count object:nil];
}

-(void)updateUpcomingSkoopList:(NSNotification *)noti{
    
    NSLog(@"updateUpcomingSkoopList::::%@",noti.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Refresh_UpcomingSkoopList object:nil];
    
    if(noti.object){//Update upcoming skoop when any skoop gets deleted
        
        if(arrayForIncomingScoops.count){
           
            for (NSDictionary *dataDict in arrayForIncomingScoops) {
                
                if([[dataDict valueForKey:@"skoop_id"] isEqualToString:(NSString *)noti.object]){
                    
                    [self getUserProfileData];
                    break;
                }
            }
        }
    }
    else if(noti.userInfo){//Update upcoming skoop when any skoop gets added into calendar
        
        if(arrayForIncomingScoops.count){
            
            NSDictionary *dataDict = (NSDictionary *)noti.userInfo;
            
            NSDateFormatter *dateFor = [[NSDateFormatter alloc] init];
            [dateFor setDateFormat:@"hh:mm a / MMM dd, yyyy"];
            
            NSDate *lastUpcomingSkoopDate= [dateFor dateFromString:[[arrayForIncomingScoops objectAtIndex:arrayForIncomingScoops.count-1] valueForKey:@"date"]];
            NSDate *skoopDate= [dateFor dateFromString:[dataDict valueForKey:@"date"]];
            NSInteger timeDiff = [lastUpcomingSkoopDate timeIntervalSinceDate:skoopDate];
            if(timeDiff>0)
                [self getUserProfileData];
        }
        else
            [self getUserProfileData];
    }
    else{
        
        [self getUserProfileData];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateUpcomingSkoopList:) name:Notification_Refresh_UpcomingSkoopList object:nil];
}

-(void)updateBuysSkoopList:(NSNotification *)noti{
    
    NSLog(@"updateBuysSkoopList::::%@",noti.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Refresh_BuysSkoopList object:nil];
    
    //Increase buys count
    buysCount++;
    NSString *buy = @"Buy";
    if(buysCount>1)
        buy = @"Buys";
    [_btnBuy setTitle:[NSString stringWithFormat:@"%i %@",buysCount,buy] forState:UIControlStateNormal];
    [_btnBuy setTitle:[NSString stringWithFormat:@"%i %@",buysCount,buy] forState:UIControlStateSelected];
    if([_btnBuy isSelected]){
        
        //Remove all old data for getting fresh data
        if(arrayForBuysScoops.count)
            [arrayForBuysScoops removeAllObjects];
        
        isHasNextPage = YES;
        pageNoForSkoops = 1;
        [self getUserSkoopsDataWithPageNumber:[NSString stringWithFormat:@"%i",pageNoForSkoops]];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateBuysSkoopList:) name:Notification_Refresh_BuysSkoopList object:nil];
}


#pragma mark Deligate methods
-(void)updateMyProfileDataWithUpdateType:(NSInteger)updateType{
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetProfileData:) name:Notification_Get_User_Profile object:nil];
    //If user is viewing self profile
    if(isShowingUserProfile){
        [[WebServicesController WebServiceMethod] getUserProfileUserId:[AppHelper userDefaultsForKey:KUserId] viewerId:[AppHelper userDefaultsForKey:KUserId] appToken:KAppToken andPageLimit:PageLimit];
    }
    else{//If user is viewing group member profile
        [[WebServicesController WebServiceMethod] getUserProfileUserId:self.blockUserId viewerId:[AppHelper userDefaultsForKey:KUserId] appToken:KAppToken andPageLimit:PageLimit];
    }
}

#pragma mark General methods

//Hit webservice for getting user profile detail and group
-(void)getUserProfileData{
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetProfileData:) name:Notification_Get_User_Profile object:nil];
    
    //If user is viewing self profile
    if(isShowingUserProfile){
        
        [[WebServicesController WebServiceMethod] getUserProfileUserId:[AppHelper userDefaultsForKey:KUserId] viewerId:[AppHelper userDefaultsForKey:KUserId] appToken:KAppToken andPageLimit:PageLimit];
    }
    else{//If user is viewing group member profile
        
        [[WebServicesController WebServiceMethod] getUserProfileUserId:self.blockUserId viewerId:[AppHelper userDefaultsForKey:KUserId] appToken:KAppToken andPageLimit:PageLimit];
    }
    
    if(!isShowingUserProfile){
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetComment:) name:Notification_Get_Comment object:nil];
        [[WebServicesController WebServiceMethod] getCommentWithUserId:self.blockUserId andAppToken:KAppToken];
    }
}

//Hit web service for getting groups
-(void)getUserGroupDataWithPageNumber:(NSString *)pageNo{
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        //If user is viewing self profile
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetGroupData:) name: Notification_For_GetGroupList object:nil];
        if(isShowingUserProfile){
            [[WebServicesController WebServiceMethod] getMyGroupDataWithUserId:[AppHelper userDefaultsForKey:KUserId] SearchString:@"" pageNumber:pageNo limit:PageLimit exGroupId:@"" inviteUserId:@"0" andIsGetNameList:NO];
        }
        else{//If user is viewing group member profile
            [[WebServicesController WebServiceMethod] getMyGroupDataWithUserId:self.blockUserId SearchString:@"" pageNumber:pageNo limit:PageLimit exGroupId:@"" inviteUserId:@"0" andIsGetNameList:NO];
        }
    });
}

//Hit web service for getting skoops
-(void)getUserSkoopsDataWithPageNumber:(NSString *)pageNo{
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetSkoops:) name:Notification_Get_User_Skoop object:nil];
        if([_btnRequest isSelected]){
            
            [[WebServicesController WebServiceMethod] getUserSkoopsWithUserId:self.blockUserId viewerId:[AppHelper userDefaultsForKey:KUserId] requestType:@"request" searchText:@"" pageNo:pageNo pageLimit:PageLimit buy:@"0" andAppToken:KAppToken];
            
        }
        else if([_btnSkoop isSelected]){
            
            [[WebServicesController WebServiceMethod] getUserSkoopsWithUserId:self.blockUserId viewerId:[AppHelper userDefaultsForKey:KUserId] requestType:@"skoop" searchText:@"" pageNo:pageNo pageLimit:PageLimit buy:@"0" andAppToken:KAppToken];
        }
        else if([_btnBuy isSelected]){
            
            [[WebServicesController WebServiceMethod] getUserSkoopsWithUserId:self.blockUserId viewerId:[AppHelper userDefaultsForKey:KUserId] requestType:@"skoop" searchText:@"" pageNo:pageNo pageLimit:PageLimit buy:@"1" andAppToken:KAppToken];
        }
    });
}

-(void)updateSkoopReplyDataWithDataDict:(NSDictionary*)dataDict{
    NSLog(@"===%@",dataDict);
   // prevSelectedIndex=selectedIndex;
    
//    NSMutableDictionary *dict=nil;
//    
//    if(requestType==Current)
//        dict=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:selectedIndex]];
//    else
//        dict=[NSMutableDictionary dictionaryWithDictionary:[arrayForFutureScoops objectAtIndex:selectedIndex]];
//    
//    
//    [dict setValue:@"0" forKey:@"upload"];
//    [dict setValue:dataDict forKey:@"reply"];
//    
//    if(requestType==Current)
//        [arrayForCurrentScoops replaceObjectAtIndex:selectedIndex withObject:dict];
//    else
//        [arrayForFutureScoops replaceObjectAtIndex:selectedIndex withObject:dict];
//    
//    [self._uiTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
//    
//    [[WebServicesController WebServiceMethod] parseSkoopReplyDataWithDataDictionary:dataDict];
}

#pragma mark Change date formate method
-(NSString*)convertDateFormat:(NSString*)dateString{
    
    NSString *time=dateString;
    NSDate *now=[NSDate date];
    
    NSDateFormatter *formatter1 = [[NSDateFormatter alloc] init];
    [formatter1 setDateFormat:@"dd MMM yyyy /hh:mm a"];
    NSTimeInterval timeZoneOffset=[[NSTimeZone systemTimeZone] secondsFromGMTForDate:now];
    NSDate *firstDate=[[formatter1 dateFromString:time] dateByAddingTimeInterval:timeZoneOffset];
    time=[formatter1 stringFromDate:firstDate];
    
    return time;
}

#pragma mark Tap gesture method
-(void)tapOnUserProfileImage:(UITapGestureRecognizer*)tapGesture{
    
    if(![_viewlist isHidden]){
        
        _tableViewComment.hidden = NO;
        _viewlist.hidden = YES;
        [_btnRequest setSelected:NO];
        [_btnSkoop setSelected:NO];
        [_btnBuy setSelected:NO];
        [_btnRequest setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        [_btnSkoop setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        [_btnBuy setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    }
}

-(void)tapOnCommentView:(UITapGestureRecognizer*)tapGesture{
    [_txtViewComment resignFirstResponder];
    _viewComment.hidden = YES;
}

-(void)tapOnSenderSkoopProfileImage:(UITapGestureRecognizer*)tapGesture
{
    UITableViewCell *tableVewCell = nil;
    if(IS_IOS_7)
        tableVewCell = (UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell = (UITableViewCell*)[[tapGesture.view superview] superview];
    
    NSIndexPath *indexPath = [_tableView indexPathForCell:tableVewCell];
    NSDictionary *dataDict=nil;
    if([_btnRequest isSelected])
        dataDict = [arrayForSendScoops objectAtIndex:indexPath.row];
    else if([_btnSkoop isSelected])
        dataDict = [arrayForReplyScoops objectAtIndex:indexPath.row];
    else
        dataDict = [arrayForBuysScoops objectAtIndex:indexPath.row];
    isShowReplierProfile=NO;
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

-(void)tapOnReplierSkoopProfileImage:(UITapGestureRecognizer*)tapGesture{
    
    UITableViewCell *tableVewCell = nil;
    if(IS_IOS_7)
        tableVewCell = (UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[tapGesture.view superview] superview];
    
    NSIndexPath *indexPath=[_tableView indexPathForCell:tableVewCell];
    NSDictionary *dataDict=nil;
    if([_btnRequest isSelected])
        dataDict=[arrayForSendScoops objectAtIndex:indexPath.row];
    else if([_btnSkoop isSelected])
        dataDict=[arrayForReplyScoops objectAtIndex:indexPath.row];
    else
        dataDict=[arrayForBuysScoops objectAtIndex:indexPath.row];
    
    isShowReplierProfile=YES;
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

#pragma mark Receive webservices response and notifications

-(void)userDidGetProfileData:(NSNotification*)note{
    
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_User_Profile object:nil];
    
    if(note.userInfo){
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0){
            NSArray *groupArray=[[note.userInfo valueForKey:@"data"] valueForKey:@"group"];
            if(groupArray.count>0){
                for (int i=0; i<groupArray.count; i++)
                    [userGroupArray addObject:[groupArray objectAtIndex:i]];
                [_collectionView reloadData];
            }
            else
                isHitServiceForMoreGroups=NO;
            
            if([[note.userInfo valueForKey:@"data"] valueForKey:@"skoop"]){
                arrayForIncomingScoops = [NSMutableArray arrayWithArray:[[note.userInfo valueForKey:@"data"] valueForKey:@"skoop"]];
            }
            else{
                arrayForIncomingScoops = nil;
            }
            [_tableViewComment reloadData];
            
            if([[note.userInfo valueForKey:@"data"] valueForKey:@"user"]){
                
                _lblUserRating.text=[NSString stringWithFormat:@"Rating: %i%%",[[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"like"] intValue]];
                
                if([[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"like_status"] length]>0 &&  [[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"like_status"] integerValue]==1)
                    [_btnThumbsUp setSelected:YES];
                else if([[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"like_status"] length]>0 &&  [[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"like_status"] integerValue]==0)
                    [_btnThumbsDown setSelected:YES];
                
                if([[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"block_status"] length]>0 &&  [[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"block_status"] integerValue]==1){
                    [_btnBlockUser setTitle:@"Unblock User" forState:UIControlStateNormal];
                    [_btnBlockUser setTitle:@"Unblock User" forState:UIControlStateSelected];
                }
                else{
                    [_btnBlockUser setTitle:@"Block User" forState:UIControlStateNormal];
                    [_btnBlockUser setTitle:@"Block User" forState:UIControlStateSelected];
                }
                
                if([[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"buys_count"]){
                    
                    buysCount=[[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"buys_count"] intValue];
                    NSString *request=@"Buys";
                    if([[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"buys_count"] integerValue]==1)
                        request=@"Buy";
                    
                    [_btnBuy setTitle:[NSString stringWithFormat:@"%@ %@",[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"buys_count"],request] forState:UIControlStateNormal];
                    [_btnBuy setTitle:[NSString stringWithFormat:@"%@ %@",[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"buys_count"],request] forState:UIControlStateSelected];
                }
                
                if([[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"request_count"])
                {
                    requestCount=[[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"request_count"] intValue];
                    NSString *request=@"Requests";
                    if([[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"request_count"] integerValue]==1)
                        request=@"Request";
                    
                    [_btnRequest setTitle:[NSString stringWithFormat:@"%@ %@",[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"request_count"],request] forState:UIControlStateNormal];
                    [_btnRequest setTitle:[NSString stringWithFormat:@"%@ %@",[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"request_count"],request] forState:UIControlStateSelected];
                }
                
                if([[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"skoop_count"]){
                    skoopCount=[[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"skoop_count"] intValue];
                    NSString *request=@"Skoops";
                    if([[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"skoop_count"] integerValue]==1)
                        request=@"Skoop";
                    
                    [_btnSkoop setTitle:[NSString stringWithFormat:@"%@ %@",[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"skoop_count"],request] forState:UIControlStateNormal];
                    [_btnSkoop setTitle:[NSString stringWithFormat:@"%@ %@",[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"skoop_count"],request] forState:UIControlStateSelected];
                }
                
                if([[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"member_since"])
                    _lblJoinDate.text=[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"member_since"];
                
                if([[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"image"] length]>5)
                    [_imgUser setImageWithURL:[NSURL URLWithString:[[[note.userInfo valueForKey:@"data"] valueForKey:@"user"] valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
                else
                    _imgUser.image=[UIImage imageNamed:@"defaultuser.png"];
                
            }
            pageNumber++;
        }
        else
            [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

-(void)userDidBlockOrUnblock:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Block_Unblock_User object:nil];
    
    if(note.userInfo)
    {
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
        {
            if([_btnBlockUser.titleLabel.text isEqualToString:@"Block User"])
            {
                [_btnBlockUser setTitle:@"Unblock User" forState:UIControlStateNormal];
                [_btnBlockUser setTitle:@"Unblock User" forState:UIControlStateSelected];
            }
            else
            {
                [_btnBlockUser setTitle:@"Block User" forState:UIControlStateNormal];
                [_btnBlockUser setTitle:@"Block User" forState:UIControlStateSelected];
            }
            [AppHelper showAlertViewWithTag:103 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
    }
}

-(void)userDidGetSkoops:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_User_Skoop object:nil];
    
    if(note.userInfo)
    {
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0) 
        {
            if(!tblFooterView)
            {
                tblFooterView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 50)];
                tblFooterView.backgroundColor=[UIColor clearColor];
                
                lblFooter=[[UILabel alloc] initWithFrame:CGRectMake(0, 5, 320, 30)];
                lblFooter.backgroundColor=[UIColor clearColor];
                lblFooter.textAlignment=NSTextAlignmentCenter;
                lblFooter.textColor=[UIColor whiteColor];
                lblFooter.font=[UIFont boldSystemFontOfSize:14.0];
                [tblFooterView addSubview:lblFooter];
            }
            
            NSArray *skoopDataArray = [note.userInfo valueForKey:@"data"];
            
            if([_btnRequest isSelected])
            {
                for (int i=0; i<skoopDataArray.count; i++) {
                    
                    [arrayForSendScoops addObject:[skoopDataArray objectAtIndex:i]];
                }
                
                if(!skoopDataArray.count || skoopDataArray.count < [PageLimit integerValue]){
                    
                    if(requestCount > 0 && arrayForSendScoops.count == 0)
                        lblFooter.text = @"All of these interactions were private.";
                    else if(requestCount > arrayForSendScoops.count)
                        lblFooter.text = @"All other interactions were private.";
                    else
                        tblFooterView = nil;
                }
            }
            else if([_btnSkoop isSelected])
            {
                
                for (int i=0; i<skoopDataArray.count; i++) {
                    
                    [arrayForReplyScoops addObject:[skoopDataArray objectAtIndex:i]];
                }
                
                if(!skoopDataArray.count || skoopDataArray.count < [PageLimit integerValue]){
                    
                    if(skoopCount>0 && arrayForReplyScoops.count==0)
                        lblFooter.text=@"All interactions were private.";
                    else if(skoopCount>arrayForReplyScoops.count)
                        lblFooter.text=@"All other interactions were private.";
                    else
                        tblFooterView=nil;
                }
            }
            else
            {
                for (int i=0; i<skoopDataArray.count; i++) {
                    
                    [arrayForBuysScoops addObject:[skoopDataArray objectAtIndex:i]];
                }
                
                if(!skoopDataArray.count || skoopDataArray.count < [PageLimit integerValue]){
                    
                    if(buysCount>0 && arrayForBuysScoops.count==0)
                        lblFooter.text=@"All interactions were private.";
                    else if(buysCount>arrayForBuysScoops.count)
                        lblFooter.text=@"All other interactions were private.";
                    else
                        tblFooterView=nil;
                }
            }
            
            if(!skoopDataArray.count || skoopDataArray.count < [PageLimit integerValue]){
             
                isHasNextPage = NO;
                _tableView.tableFooterView = tblFooterView;
            }
            
            pageNoForSkoops++;
            _viewlist.hidden=NO;
            [_tableView reloadData];
        }
        else
            [AppHelper showAlertViewWithTag:103 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

-(void)userDidLikeOrDislikeUserProfile:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Like_Dislike_User_Profile object:nil];
    
    if(note.userInfo)
    {
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
        {
            if([[note.userInfo valueForKey:@"like"] integerValue]==1)
            {
                [_btnThumbsUp setSelected:YES];
                [_btnThumbsDown setSelected:NO];
            }
            else if([[note.userInfo valueForKey:@"like"] integerValue]==0)
            {
                [_btnThumbsDown setSelected:YES];
                [_btnThumbsUp setSelected:NO];
            }
            _lblUserRating.text=[NSString stringWithFormat:@"Rating: %i%%",[[note.userInfo valueForKey:@"like_percentage"] integerValue]];
        }
    }
}

-(void)userDidGetGroupData:(NSNotification*)note{
    
    [AppDelegate dismissGlobalHUD];
   // NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_For_GetGroupList object:nil];
    
    if(note.userInfo)
    {
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
        {
            NSArray *groupArray=[note.userInfo valueForKey:@"data"];
            if(groupArray.count>0){
                
                for (int i=0; i<groupArray.count; i++)
                    [userGroupArray addObject:[groupArray objectAtIndex:i]];
                [_collectionView reloadData];
            }
            else
                isHitServiceForMoreGroups=NO;
            pageNumber++;
        }
        else
            [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

-(void)userDidWriteComment:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Write_Comment object:nil];
    
    if(note.userInfo)
    {
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
        {
            _viewComment.hidden=YES;
            NSDateFormatter *dateFormater=[[NSDateFormatter alloc] init];
            [dateFormater setDateFormat:@"hh:mm a / MMM dd, yyyy"];
            NSString *dateString=[dateFormater stringFromDate:[NSDate date]];
            
            NSDictionary *commentDict=[[NSDictionary alloc] initWithObjectsAndKeys:_txtViewComment.text,@"body",[AppHelper userDefaultsForKey:KUserName],@"name",[AppHelper userDefaultsForKey:KUserImageUrl],@"image",dateString,@"date",@"1",@"isdate", nil];
            [self.arrayForComment insertObject:commentDict atIndex:0];
            [_tableViewComment reloadData];
        }
        
        [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

-(void)userDidGetComment:(NSNotification*)note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Comment object:nil];
    
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
    {
        NSMutableArray *array=(NSMutableArray*)[note.userInfo valueForKey:@"data"];
        self.arrayForComment = [NSMutableArray arrayWithArray:array];
        [_tableViewComment reloadData];
    }
}


#pragma mark Button action methods
- (IBAction)onClickBackButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)onClickSendRequestButton:(id)sender
{
    [self performSegueWithIdentifier:@"sendskooprequest" sender:nil];
}

- (IBAction)onClickSettingsButton:(id)sender
{
    [self performSegueWithIdentifier:@"editprofile" sender:nil];
}

- (IBAction)onClickThumbsUpButton:(id)sender
{
    if([_btnThumbsUp isSelected])
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have already liked this user." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    else
    {
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidLikeOrDislikeUserProfile:) name:Notification_Like_Dislike_User_Profile object:nil];
        [[WebServicesController WebServiceMethod] likeOrDislikeUserProfileWithUserId:[AppHelper userDefaultsForKey:KUserId] resoruceId:self.blockUserId appToken:KAppToken like:@"1"];
    }
}

- (IBAction)onClickThumbsDownButton:(id)sender
{
    if([_btnThumbsDown isSelected])
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have already disliked this user." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidLikeOrDislikeUserProfile:) name:Notification_Like_Dislike_User_Profile object:nil];
    [[WebServicesController WebServiceMethod] likeOrDislikeUserProfileWithUserId:[AppHelper userDefaultsForKey:KUserId] resoruceId:self.blockUserId appToken:KAppToken like:@"0"];
}

- (IBAction)onClickRequestsButton:(id)sender{
    
    if(![_btnRequest isSelected]){
        
        _tableViewComment.hidden=YES;
        
        [_btnRequest setSelected:YES];
        [_btnSkoop setSelected:NO];
        [_btnBuy setSelected:NO];
        
        [_btnRequest setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
        [_btnSkoop setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        [_btnBuy setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        
        //Remove all old data for getting fresh data
        if(arrayForSendScoops.count)
            [arrayForSendScoops removeAllObjects];
        
        isHasNextPage = YES;
        pageNoForSkoops = 1;
        [self getUserSkoopsDataWithPageNumber:[NSString stringWithFormat:@"%i",pageNoForSkoops]];
    }
}

- (IBAction)onClickSkoopsButton:(id)sender{
    
    if(![_btnSkoop isSelected]){
        
        _tableViewComment.hidden=YES;
        
        [_btnRequest setSelected:NO];
        [_btnSkoop setSelected:YES];
        [_btnBuy setSelected:NO];
        
        [_btnRequest setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        [_btnSkoop setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
        [_btnBuy setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        
        //Remove all old data for getting fresh data
        if(arrayForReplyScoops.count)
            [arrayForReplyScoops removeAllObjects];
        
        isHasNextPage = YES;
        pageNoForSkoops = 1;
        [self getUserSkoopsDataWithPageNumber:[NSString stringWithFormat:@"%i",pageNoForSkoops]];
    }
}

- (IBAction)onClickBuysButton:(id)sender{
    
    if(![_btnBuy isSelected]){
        
        _tableViewComment.hidden=YES;
        
        [_btnRequest setSelected:NO];
        [_btnSkoop setSelected:NO];
        [_btnBuy setSelected:YES];
        
        [_btnRequest setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        [_btnSkoop setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        [_btnBuy setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
        
        //Remove all old data for getting fresh data
        if(arrayForBuysScoops.count)
            [arrayForBuysScoops removeAllObjects];
        
        isHasNextPage = YES;
        pageNoForSkoops = 1;
        [self getUserSkoopsDataWithPageNumber:[NSString stringWithFormat:@"%i",pageNoForSkoops]];
    }
}

- (IBAction)onClickInvitiUserToGroupButton:(id)sender
{
    [self performSegueWithIdentifier:@"grouplist" sender:nil];
}

//Autoscroll collectionview on left
- (IBAction)onClickLeftArrowButton:(id)sender{
    
    if(userGroupArray.count>0){
        
        NSArray *visibleItems = [_collectionView indexPathsForVisibleItems];
        NSIndexPath *currentItem = [visibleItems objectAtIndex:0];
        
        //Manage auto scrolls(For overcome the Issue for showing visible cells ordering)
        for (int i=0; i<visibleItems.count-1; i++) {
            NSIndexPath *indexPath1=[visibleItems objectAtIndex:i];
            NSIndexPath *indexPath2=[visibleItems objectAtIndex:i+1];
            if(indexPath1.row>indexPath2.row)
            {
                currentItem = [visibleItems objectAtIndex:i+1];
                break;
            }
        }
        
        NSIndexPath *prevItem = [NSIndexPath indexPathForItem:currentItem.item - 1 inSection:0];
        if(prevItem && prevItem.row>=0)
            [_collectionView scrollToItemAtIndexPath:prevItem atScrollPosition:UICollectionViewScrollPositionRight animated:YES];
    }
}

//Autoscroll collectionview on right
- (IBAction)onClickRightArrowtButton:(id)sender{
    
    if(userGroupArray.count>0){
        
        NSArray *visibleItems = [_collectionView indexPathsForVisibleItems];
        NSIndexPath *currentItem = [visibleItems objectAtIndex:visibleItems.count-1];
        
        //Manage auto scrolls(For overcome the Issue for showing visible cells ordering)
        for (int i=0; i<visibleItems.count-1; i++) {
            NSIndexPath *indexPath1=[visibleItems objectAtIndex:i];
            NSIndexPath *indexPath2=[visibleItems objectAtIndex:i+1];
            if(indexPath1.row>indexPath2.row){
                currentItem = [visibleItems objectAtIndex:i];
                break;
            }
        }
        
        NSIndexPath *nextItem = [NSIndexPath indexPathForItem:currentItem.item + 1 inSection:0];
        
        //Check array of bounds
        if(nextItem && nextItem.row<userGroupArray.count)
            [_collectionView scrollToItemAtIndexPath:nextItem atScrollPosition:UICollectionViewScrollPositionLeft animated:YES];
    }
}

- (IBAction)onClickBlockUserButton:(id)sender
{
    if([_btnBlockUser.titleLabel.text isEqualToString:@"Block User"])
        [AppHelper showAlertViewWithTag:101 title:AppName message:@"Do you want to block this user from any interactions with you?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
    else
        [AppHelper showAlertViewWithTag:102 title:AppName message:@"Do you want to unblock this user?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
}

- (IBAction)onClickCommentButton:(id)sender
{
    if(isShowingUserProfile)
    {
        [self performSegueWithIdentifier:@"seecomment" sender:nil];
    }
    else
    {
        _viewComment.hidden=NO;
        _txtViewComment.text=@"";
        [_txtViewComment becomeFirstResponder];
    }
}

- (IBAction)onClickCrossButton:(id)sender
{
    [_txtViewComment resignFirstResponder];
    _viewComment.hidden=YES;
}

- (IBAction)onClickSendCommentButton:(id)sender
{
    if([_txtViewComment.text length]>0)
    {
        [_txtViewComment resignFirstResponder];
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidWriteComment:) name:Notification_Write_Comment object:nil];
        [[WebServicesController WebServiceMethod] writeCommentWithUserId:[AppHelper userDefaultsForKey:KUserId] resoruceId:self.blockUserId appToken:KAppToken andCommentText:_txtViewComment.text];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please write some text." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

#pragma mark Tableview deligate methods.......

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView==_tableView)
    {
        UILabel *lblNoData=(UILabel*)[self.view viewWithTag:123];
        NSLog(@"%@",lblNoData);
        int dataCount=0;
        int totalCount = 0;
        NSString *message=@"";
        
        if([_btnRequest isSelected]){
            totalCount = requestCount;
            dataCount= (int)arrayForSendScoops.count;
            message=@"The user hasn’t sent any requests yet.";
        }
        else if([_btnSkoop isSelected]){
            totalCount = skoopCount;
            dataCount = (int)arrayForReplyScoops.count;
            message=@"The user hasn’t replied with any Skoops yet.";
        }
        else if([_btnBuy isSelected]){
            totalCount = buysCount;
            dataCount = (int)arrayForBuysScoops.count;
            message=@"The user hasn’t purchased any Skoops yet.";
        }
        
        NSLog(@"%i========%i",dataCount,totalCount);
        
        if(dataCount == 0 && totalCount == 0){
            NSLog(@"*************%@",lblNoData);
            if(!lblNoData){
                lblNoData=[[UILabel alloc] initWithFrame:CGRectMake(0, _tableView.frame.size.height/2.0-15.0, 320, 30.0)];
                lblNoData.textAlignment=NSTextAlignmentCenter;
                lblNoData.backgroundColor=[UIColor clearColor];
                lblNoData.textColor=[UIColor whiteColor];
                lblNoData.font=[UIFont boldSystemFontOfSize:14.0];
                lblNoData.tag=123;
                [_tableView addSubview:lblNoData];
            }
            lblNoData.text = message;
        }
        else
            [lblNoData removeFromSuperview];
        
        return dataCount;
    }
    else
    {
        if(isShowingUserProfile)
            return arrayForIncomingScoops.count;
        else
            return self.arrayForComment.count;
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(tableView==_tableView){//Skoop table
        NSDictionary *dictOfScoop=nil;
        CGFloat cellHeight ;
        int totalRowCount =0;
        if([_btnRequest isSelected] && indexPath.row<arrayForSendScoops.count){
            dictOfScoop=[arrayForSendScoops objectAtIndex:indexPath.row];
            totalRowCount = (int)arrayForSendScoops.count;
        }
        else if([_btnSkoop isSelected] && indexPath.row<arrayForReplyScoops.count){
            dictOfScoop=[arrayForReplyScoops objectAtIndex:indexPath.row];
            totalRowCount = (int)arrayForReplyScoops.count;
        }
        else if(indexPath.row<arrayForBuysScoops.count){
            dictOfScoop=[arrayForBuysScoops objectAtIndex:indexPath.row];
            totalRowCount = (int)arrayForBuysScoops.count;
        }
        
        if(([_btnRequest isSelected] || [_btnBuy isSelected]) && isShowingUserProfile)
            cellHeight = 103;
        else{
            if([dictOfScoop objectForKey:@"reply"])
                cellHeight = 185;
            else
                cellHeight = 97;
        }
        if(indexPath.row == totalRowCount-1)
            return cellHeight + 20;
        else
            return cellHeight;
    }
    else{
        
        if(isShowingUserProfile){//For self profile
        
            if(arrayForIncomingScoops.count-1 == indexPath.row)
                return 117;
            else
                return 97;
        }
        else
        {
            NSDictionary *dataDict=[self.arrayForComment objectAtIndex:indexPath.row];
            float cellHeight=[AppHelper getStringBoundingSize:[dataDict valueForKey:@"body"] forWidth:230 withFont:[UIFont systemFontOfSize:14.0]];
            return cellHeight+55;
        }
    }
}

//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
//{
//    return 30.0;
//}

//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
//{
//    UILabel *lblHeader=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 30)];
//    lblHeader.backgroundColor=[UIColor clearColor];
//    lblHeader.text=@"All other interactions were private.";
//    return lblHeader;
//}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell;
    
    if(tableView==_tableView){
        
        NSDictionary *dictOfScoop=nil;
        
        if([_btnRequest isSelected]){
            
            if(arrayForSendScoops && indexPath.row < arrayForSendScoops.count)
                dictOfScoop=[arrayForSendScoops objectAtIndex:indexPath.row];
        }
        else if([_btnSkoop isSelected]){
            
            if(arrayForReplyScoops && indexPath.row < arrayForReplyScoops.count)
                dictOfScoop=[arrayForReplyScoops objectAtIndex:indexPath.row];
        }
        else{
            
            if(arrayForBuysScoops && indexPath.row < arrayForBuysScoops.count)
                dictOfScoop=[arrayForBuysScoops objectAtIndex:indexPath.row];
        }
        
        if(([_btnRequest isSelected] && isShowingUserProfile) || ([_btnBuy isSelected] && isShowingUserProfile)){
            
            cell = [tableView dequeueReusableCellWithIdentifier:@"SendSkoopReq"];
        }
        else{
            
            if([dictOfScoop objectForKey:@"reply"]){
                
                cell = [tableView dequeueReusableCellWithIdentifier:@"SkoopReqRep"];
            }
            else{
                
                cell = [tableView dequeueReusableCellWithIdentifier:@"SkoopRequest"];
            }
        }
        
        if (cell == nil){
            
            NSLog(@"****************nil*********************");
            NSArray *topLevelObjects = nil;
            if(([_btnRequest isSelected] && isShowingUserProfile) || ([_btnBuy isSelected] && isShowingUserProfile)){
                
                topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SendSkoopReq" owner:self options:nil];
            }
            else{
                
                if([dictOfScoop objectForKey:@"reply"]){
                    topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SkoopReqRep" owner:self options:nil];
                }
                else{
                    topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SkoopRequest" owner:self options:nil];
                }
            }
                
            // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
            cell = [topLevelObjects objectAtIndex:0];
            cell.layer.borderColor=[UIColor grayColor].CGColor;
            cell.backgroundColor=[UIColor clearColor];
            
//            if([dictOfScoop objectForKey:@"reply"])
//            {
//                UIImageView *replyProfileImage=(UIImageView *)[cell.contentView viewWithTag:219];
//                UITapGestureRecognizer *uiTap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnReplierSkoopProfileImage:)];
//                uiTap1.numberOfTapsRequired=1;
//                replyProfileImage.userInteractionEnabled=YES;
//                [replyProfileImage addGestureRecognizer:uiTap1];
//            }
//            else
//            {
//                UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:208];
//                UITapGestureRecognizer *uiTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnSenderSkoopProfileImage:)];
//                uiTap.numberOfTapsRequired=1;
//                profileImage.userInteractionEnabled=YES;
//                [profileImage addGestureRecognizer:uiTap];
//            }
        }
        
        if(isHasNextPage && (([_btnRequest isSelected] && indexPath.row == arrayForSendScoops.count-1) || ([_btnSkoop isSelected] && indexPath.row == arrayForReplyScoops.count-1) || ([_btnBuy isSelected] && indexPath.row == arrayForBuysScoops.count-1))){
            
            [self getUserSkoopsDataWithPageNumber:[NSString stringWithFormat:@"%i",pageNoForSkoops]];
        }
        
        if(([_btnRequest isSelected] && isShowingUserProfile) || ([_btnBuy isSelected] && isShowingUserProfile)){
            
            CBAutoScrollLabel *lblSkoopName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:101];
            [lblSkoopName setLabelSettingForObject:@"skoop"];
            lblSkoopName.text=[dictOfScoop valueForKey:@"searchText"];
            
            UILabel *lblLocation=(UILabel *)[cell.contentView viewWithTag:102];
            if([dictOfScoop valueForKey:@"group_name"] && [[dictOfScoop valueForKey:@"group_name"] length]>0)
                lblLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfScoop valueForKey:@"group_name"]];
            else
                lblLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfScoop valueForKey:@"location"]];
            
            UILabel *lblDate=(UILabel *)[cell.contentView viewWithTag:103];
            lblDate.text=[NSString stringWithFormat:@"Time: %@",[dictOfScoop valueForKey:@"date"]];
            
            UILabel *lblCost=(UILabel *)[cell.contentView viewWithTag:104];
            
            if([[dictOfScoop valueForKey:@"price"] floatValue]>0)
                lblCost.text=[NSString stringWithFormat:@"$%@",[dictOfScoop valueForKey:@"price"]];
            else
                lblCost.text=@"Favor";
            
            UIImageView *imgRedCircle=(UIImageView *)[cell.contentView viewWithTag:105];
            UILabel *lblReplies=(UILabel *)[cell.contentView viewWithTag:107];
            if([[dictOfScoop valueForKey:@"live_portal"] integerValue] == 1){
                imgRedCircle.image=[UIImage imageNamed:@"noti_lp.png"];
                lblReplies.text = @"Users";
            }
            else{
                imgRedCircle.image=[UIImage imageNamed:@"notification_number.png"];
                lblReplies.text = @"Replies";
            }
            
            UILabel *lblReplyCount=(UILabel*)[cell.contentView viewWithTag:106];
            lblReplyCount.text=[dictOfScoop valueForKey:@"replyCount"];
            
            return cell;
        }
        
        UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:208];
        [AppHelper getRoundedImageWithImageView:profileImage];
        
        UILabel *lblLikeCount=(UILabel *)[cell.contentView viewWithTag:210];
        lblLikeCount.backgroundColor=[UIColor clearColor];
        lblLikeCount.text=[NSString stringWithFormat:@"%i",[[dictOfScoop valueForKey:@"like"] intValue]];
        
        CBAutoScrollLabel *lblName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:212];
        [lblName setLabelSettingForObject:@"name"];
        
        CBAutoScrollLabel *lblsearchText=(CBAutoScrollLabel *)[cell.contentView viewWithTag:205];
        [lblsearchText setLabelSettingForObject:@"skoop"];
        
        UILabel *lblLocation=(UILabel *)[cell.contentView viewWithTag:206];
        UILabel *lblDate=(UILabel *)[cell.contentView viewWithTag:207];
        UILabel *lblCost=(UILabel *)[cell.contentView viewWithTag:209];
        lblCost.textColor=KTextColor;
        
        NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfScoop objectForKey:@"image"]]];
        NSString *groupImageUrL=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url=[NSURL URLWithString:groupImageUrL];
        
        if([urlString length]>0)
            [profileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
        else
            profileImage.image=[UIImage imageNamed:@"defaultuser.png"];
        
        lblName.text=[dictOfScoop valueForKey:@"name"];
        lblsearchText.text=[dictOfScoop valueForKey:@"searchText"];
        
        if([dictOfScoop valueForKey:@"group_name"] && [[dictOfScoop valueForKey:@"group_name"] length]>0)
            lblLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfScoop valueForKey:@"group_name"]];
        else
            lblLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfScoop valueForKey:@"location"]];
        
        lblDate.text=[NSString stringWithFormat:@"%@",[dictOfScoop valueForKey:@"date"]];
        if([[dictOfScoop valueForKey:@"price"] floatValue] >0)
            lblCost.text = [NSString stringWithFormat:@"$ %@",[dictOfScoop valueForKey:@"price"]];
        else
            lblCost.text = @"Favor";
        
        UIButton *btnLense=(UIButton*)[cell.contentView viewWithTag:425];
       // [btnLense addTarget:self action:@selector(lenseButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        
        if([[dictOfScoop valueForKey:@"live_portal"] integerValue]==1){
            if([[dictOfScoop valueForKey:@"reply_status"] integerValue]==0)
                [btnLense setImage:[UIImage imageNamed:@"live_poratl_small.png"] forState:UIControlStateNormal];
            else
                [btnLense setImage:[UIImage imageNamed:@"live_green.png"] forState:UIControlStateNormal];
            
            btnLense.frame=CGRectMake(275, 25, 40, 40);
        }
        else{
            [btnLense setImage:[UIImage imageNamed:@"lens_icon.png"] forState:UIControlStateNormal];
            [btnLense setImage:[UIImage imageNamed:@"lens_icon.png"] forState:UIControlStateHighlighted];
            btnLense.frame=CGRectMake(278, 27, 35, 35);
        }
        
        if([dictOfScoop objectForKey:@"reply"]){
            
            NSDictionary *dictOfReply=[dictOfScoop objectForKey:@"reply"];
            UIImageView *replyVideoImageView=(UIImageView *)[cell.contentView viewWithTag:202];
            
            if([[dictOfReply valueForKey:@"paymentStatus"] isEqualToString:@"1"])
                lblCost.textColor=KTextColor_Green;
            
            UIImageView *replyProfileImage=(UIImageView *)[cell.contentView viewWithTag:219];
            replyProfileImage.backgroundColor=[UIColor lightGrayColor];
            [AppHelper getRoundedImageWithImageView:replyProfileImage];
            
            UIImageView *imgLock=(UIImageView *)[cell.contentView viewWithTag:225];
            if([[dictOfReply valueForKey:@"paymentStatus"] integerValue] == 1 || ([_btnSkoop isSelected] && isShowingUserProfile) || ([_btnRequest isSelected] && !isShowingUserProfile) || ([_btnBuy isSelected] && !isShowingUserProfile))
                imgLock.hidden = YES;
            else
                imgLock.hidden = NO;
                        
            NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfReply objectForKey:@"image"]]];
            NSString *skoopimgUrl=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            NSURL *url=[NSURL URLWithString:skoopimgUrl];
            if([urlString length]>5)
                [replyProfileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
            else
                replyProfileImage.image=[UIImage imageNamed:@"defaultuser.png"];
            
            if([dictOfReply objectForKey:@"thumbnail"]){
                NSString *urlString1 = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfReply objectForKey:@"thumbnail"]]];
                NSString *imgUrl1=[urlString1  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                NSURL *url1=[NSURL URLWithString:imgUrl1];
                [replyVideoImageView setImageWithURL:url1 placeholderImage:[UIImage imageNamed:@"thumbimage"]];
            }
            else
                replyVideoImageView.image=[dictOfReply valueForKey:@"thumbimage"];
            
            CBAutoScrollLabel *lblReplyName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:214];
            [lblReplyName setLabelSettingForObject:@"name"];
            lblReplyName.text=[dictOfReply valueForKey:@"name"];
            
            CBAutoScrollLabel *lblReplysearchText=(CBAutoScrollLabel *)[cell.contentView viewWithTag:1210];
            [lblReplysearchText setLabelSettingForObject:@"skoop"];
            lblReplysearchText.text = [NSString stringWithFormat:@"%@(%@ Sec)",[dictOfScoop valueForKey:@"searchText"],[[dictOfScoop valueForKey:@"reply"] valueForKey:@"duration"]];
            
            UILabel *lblReplyLocation=(UILabel *)[cell.contentView viewWithTag:211];
            if([dictOfScoop valueForKey:@"group_name"] && [[dictOfScoop valueForKey:@"group_name"] length]>0)
                lblReplyLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfScoop valueForKey:@"group_name"]];
            else
                lblReplyLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfScoop valueForKey:@"location"]];
            
            UILabel *lblReplyDate=(UILabel *)[cell.contentView viewWithTag:215];
            lblReplyDate.text=[NSString stringWithFormat:@"%@",[dictOfReply valueForKey:@"date"]];
        }
    }
    else{
        if(isShowingUserProfile){//For self profile
            
            NSDictionary *dictOfScoop=[arrayForIncomingScoops objectAtIndex:indexPath.row];
            cell = [tableView dequeueReusableCellWithIdentifier:@"SkoopRequest"];
            
            if (cell == nil){
                NSLog(@"****************nil*********************");
                NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SkoopRequest" owner:self options:nil];
                // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
                cell = [topLevelObjects objectAtIndex:0];
                cell.layer.borderColor=[UIColor grayColor].CGColor;
                cell.backgroundColor=[UIColor clearColor];
                
//                UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:208];
//                UITapGestureRecognizer *uiTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnSenderSkoopProfileImage:)];
//                uiTap.numberOfTapsRequired=1;
//                profileImage.userInteractionEnabled=YES;
//                [profileImage addGestureRecognizer:uiTap];
            }
            
            UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:208];
            [AppHelper getRoundedImageWithImageView:profileImage];
            
            UILabel *lblLikeCount=(UILabel *)[cell.contentView viewWithTag:210];
            lblLikeCount.backgroundColor=[UIColor clearColor];
            lblLikeCount.text=[NSString stringWithFormat:@"%i",[[dictOfScoop valueForKey:@"like"] intValue]];
            
            CBAutoScrollLabel *lblName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:212];
            [lblName setLabelSettingForObject:@"name"];
            
            CBAutoScrollLabel *lblsearchText=(CBAutoScrollLabel *)[cell.contentView viewWithTag:205];
            [lblsearchText setLabelSettingForObject:@"skoop"];
            
            UILabel *lblLocation=(UILabel *)[cell.contentView viewWithTag:206];
            UILabel *lblDate=(UILabel *)[cell.contentView viewWithTag:207];
            UILabel *lblCost=(UILabel *)[cell.contentView viewWithTag:209];
            lblCost.textColor=KTextColor;
            
            UIButton *btnLense=(UIButton *)[cell.contentView viewWithTag:425];
            btnLense.userInteractionEnabled=NO;
            
            NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfScoop objectForKey:@"image"]]];
            NSString *imageUrl=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            NSURL *url=[NSURL URLWithString:imageUrl];
            
            if([urlString length]>0)
                [profileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
            else
                profileImage.image=[UIImage imageNamed:@"defaultuser.png"];
            
            lblName.text=[dictOfScoop valueForKey:@"name"];
            lblsearchText.text=[dictOfScoop valueForKey:@"searchText"];
            
            
            if([dictOfScoop valueForKey:@"group_name"] && [[dictOfScoop valueForKey:@"group_name"] length]>0)
                lblLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfScoop valueForKey:@"group_name"]];
            else
                lblLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfScoop valueForKey:@"location"]];
            
            lblDate.text=[NSString stringWithFormat:@"%@",[dictOfScoop valueForKey:@"date"]];
            
            if([[dictOfScoop valueForKey:@"offer"] floatValue]>0)
                lblCost.text=[NSString stringWithFormat:@"$%@",[dictOfScoop valueForKey:@"offer"]];
            else
                lblCost.text=@"Favor";
        }
        else{
            
            NSString *CellIdentifier =@"comment";
            cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            cell.layer.borderColor=[UIColor grayColor].CGColor;
            cell.backgroundColor=[UIColor clearColor];
            
            NSDictionary *dataDict=[self.arrayForComment objectAtIndex:indexPath.row];
            
            UIImageView *baseImg=(UIImageView *)[cell.contentView viewWithTag:100];
            UIImageView *profImg=(UIImageView *)[cell.contentView viewWithTag:101];
            
            CBAutoScrollLabel *lblCommentHeader=(CBAutoScrollLabel *)[cell.contentView viewWithTag:102];
            [lblCommentHeader setLabelSettingForObject:@"name"];
            
            UILabel *lblComment=(UILabel *)[cell.contentView viewWithTag:103];
            UILabel *lblCommentDate=(UILabel *)[cell.contentView viewWithTag:104];
            
            if([[dataDict valueForKey:@"body"] isKindOfClass:[NSNull class]]){
                lblComment.text=@"Comment";
            }
            else{
                
                float cellHeight=[AppHelper getStringBoundingSize:[dataDict valueForKey:@"body"] forWidth:230 withFont:[UIFont systemFontOfSize:14.0]];
                
                CGRect frameRect=baseImg.frame;
                frameRect.size.height=cellHeight+40;
                baseImg.frame=frameRect;
                baseImg.image= [[UIImage imageNamed:@"right_chat_box1.png"] stretchableImageWithLeftCapWidth:frameRect.size.width topCapHeight:60];
                
                CGRect frameRect1=lblComment.frame;
                frameRect1.size.height=cellHeight;
                lblComment.frame=frameRect1;
                lblComment.text=[dataDict valueForKey:@"body"];
            }
            
                        
            [AppHelper getRoundedImageWithImageView:profImg];
            NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dataDict objectForKey:@"image"]]];
            NSString *groupImageUrL=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            NSURL *url=[NSURL URLWithString:groupImageUrL];
            
            if([urlString length]>0)
                [profImg setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
            else
                profImg.image=[UIImage imageNamed:@"defaultuser.png"];
            
            lblCommentHeader.text=[dataDict valueForKey:@"name"];
            
            CGRect frameRect2=lblCommentDate.frame;
            frameRect2.origin.y=lblComment.frame.origin.y+lblComment.frame.size.height+10;
            lblCommentDate.frame=frameRect2;
            if([dataDict valueForKey:@"isdate"])//Add date at our end
                lblCommentDate.text=[dataDict valueForKey:@"date"];
            else
                lblCommentDate.text = [dataDict valueForKey:@"date"];
                //lblCommentDate.text=[self convertDateFormat:[dataDict valueForKey:@"date"]];
            lblCommentDate.textColor=KTextColor;
        }
    }
    return  cell;
}

-(void)replyOnSkoop:(id)sender{
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(tableView==_tableView){
        
        if([_btnSkoop isSelected] || ([_btnRequest isSelected] && !isShowingUserProfile) || ([_btnBuy isSelected] && !isShowingUserProfile)){
            
            NSDictionary *selectedData = Nil;
            if([_btnSkoop isSelected]){
                selectedData = [arrayForReplyScoops objectAtIndex:indexPath.row];
            }
            else if([_btnRequest isSelected]){
                selectedData = [arrayForSendScoops objectAtIndex:indexPath.row];
            }
            else if([_btnBuy isSelected]){
                selectedData = [arrayForBuysScoops objectAtIndex:indexPath.row];
            }
            
            UITableViewCell *tblCell=[_tableView cellForRowAtIndexPath:indexPath];
            NSLog(@"=====%i",tblCell.tag);
            
            if(tblCell.tag == 200){
                
                VideoPlayerVC *videoPlayerVC = [self.storyboard instantiateViewControllerWithIdentifier:@"VideoPlayerVC"];
                videoPlayerVC.videoURL =[[selectedData valueForKey:@"reply"] valueForKey:@"video_path"];
                if(([_btnSkoop isSelected] && isShowingUserProfile) || ([_btnRequest isSelected] && !isShowingUserProfile) || ([_btnBuy isSelected] && !isShowingUserProfile))
                    videoPlayerVC.isShowingOwnVideo = YES;
                videoPlayerVC.selecteDataDict = [NSMutableDictionary dictionaryWithDictionary:selectedData];
                [self.navigationController pushViewController:videoPlayerVC animated:NO];
            }
        }
        else if([_btnRequest isSelected]){
            [self performSegueWithIdentifier:@"skoop_reply" sender:[arrayForSendScoops objectAtIndex:indexPath.row]];
        }
        else if([_btnBuy isSelected]){
            [self performSegueWithIdentifier:@"skoop_reply" sender:[arrayForBuysScoops objectAtIndex:indexPath.row]];
        }
    }
    else if(tableView==_tableViewComment){
        
        if(isShowingUserProfile){
            
            NSDictionary *dataDict=[arrayForIncomingScoops objectAtIndex:indexPath.row];
            [self performSegueWithIdentifier:@"skoop_req" sender:dataDict];
        }
    }
}

#pragma mark Textview deligates
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    NSString *str=[NSString stringWithFormat:@"%@%@",textView.text,text];
    if(str.length>0 && [[str substringToIndex:1] isEqualToString:@" "])
        return NO;
    
    return YES;
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag==101 || alertView.tag==102){
        if(buttonIndex==0){
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidBlockOrUnblock:) name:Notification_Block_Unblock_User object:nil];
            if(alertView.tag==101)
                [[WebServicesController WebServiceMethod] blockUnblockUserWithUserId:[AppHelper userDefaultsForKey:KUserId] blockUserId:self.blockUserId groupId:@"0" requestType:@"block" andReason:@"Block this user"];
            else
                [[WebServicesController WebServiceMethod] blockUnblockUserWithUserId:[AppHelper userDefaultsForKey:KUserId] blockUserId:self.blockUserId groupId:@"0" requestType:@"unblock" andReason:@"Unblock this user"];;
        }
    }
    else if(alertView.tag==103){
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark-CollectionViewDelegates

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [userGroupArray count];
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell *cell =[collectionView dequeueReusableCellWithReuseIdentifier:@"cellId" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor clearColor];
    
    UIImageView *image_view = (UIImageView *)[cell.contentView viewWithTag:102];
    CBAutoScrollLabel *lblGroupName=(CBAutoScrollLabel*)[cell.contentView viewWithTag:103];
    [lblGroupName setLabelSettingForObject:@"name"];
    [AppHelper getRoundedRectImageWithImageView:image_view withColor:[UIColor clearColor] andRadius:9.0 andWidth:0.0];
    
    if([[[userGroupArray objectAtIndex:indexPath.row] valueForKey:@"profile_image"] length]>0)
        [image_view setImageWithURL:[NSURL URLWithString:[[userGroupArray objectAtIndex:indexPath.row] valueForKey:@"profile_image"]] placeholderImage:[UIImage imageNamed:@"user_default.png"]];
    else
        image_view.image=[UIImage imageNamed:@"user_default.png"];
    
    lblGroupName.text=[[userGroupArray objectAtIndex:indexPath.row] valueForKey:@"group_name"];
    
    if(isHitServiceForMoreGroups && indexPath.row==userGroupArray.count-1){
        
        [self getUserGroupDataWithPageNumber:[NSString stringWithFormat:@"%i",pageNumber]];
    }
    
    return cell;
}

#pragma mark Collection view layout things
// Layout: Set cell size
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    //SETTING SIZE FOR ITEM AT INDEX PATH
    CGSize mElementSize = CGSizeMake(85.0, 85.0);
    return mElementSize;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 3.0;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 3.0;
}

// Layout: Set Edges
- (UIEdgeInsets)collectionView:
(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    // return UIEdgeInsetsMake(0,8,0,8);  // top, left, bottom, right
    return UIEdgeInsetsMake(0,0,0,0);  // top, left, bottom, right
}


- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary *dataDict=[userGroupArray objectAtIndex:indexPath.row];
    [self performSegueWithIdentifier:@"groupprofile" sender:dataDict];
}

#pragma mark Video control methods
-(void)movieLoadStateDidChange:(id)sender{
    NSLog(@"STATE CHANGED");
    if(MPMovieLoadStatePlaythroughOK ) {
        [AppDelegate dismissGlobalHUD];
        NSLog(@"State is Playable OK");
        NSLog(@"Enough data has been buffered for playback to continue uninterrupted..");
    }
}

#pragma mark Detect view touch
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    //Check video player view and remove it
    if (touch.view.tag==4444) {
        UIView *baseVideoView=(UIView*)[self.view viewWithTag:4444];
        if(baseVideoView){
            if(self._moviePlayer)
                [self._moviePlayer stop];
            [baseVideoView removeFromSuperview];
        }
    }
}

-(void)removeRunningVideoView{
    UIView *baseVideoView=(UIView*)[self.view viewWithTag:4444];
    if(baseVideoView){
        if(self._moviePlayer)
            [self._moviePlayer stop];
        [baseVideoView removeFromSuperview];
    }
}

#pragma mark Prepare for segue
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqualToString:@"groupprofile"]){
        GroupProfileVC *grpProfile=segue.destinationViewController;
        //grpProfile.updateListProtocol=self;
        NSDictionary *dataDict=(NSDictionary*)sender;
        NSLog(@"%@",dataDict);
        grpProfile.name=[dataDict valueForKey:@"group_name"];
        grpProfile.imgUrl=[dataDict valueForKey:@"cover_image"];
        grpProfile.groupImageUrl=[dataDict valueForKey:@"profile_image"];
        grpProfile.groupDescription=[dataDict valueForKey:@"group_description"];
        grpProfile.groupId=[dataDict valueForKey:@"group_id"];
        grpProfile.categoryName=[dataDict valueForKey:@"category_name"];
        grpProfile.categoryId=[dataDict valueForKey:@"category_id"];
        if([dataDict valueForKey:@"pr_email"])
            grpProfile.prEmail=[dataDict valueForKey:@"pr_email"];
        
        if([[dataDict valueForKey:@"group_type"] integerValue]==2)
            grpProfile.groupType=@"Celebrity";
        else
            grpProfile.groupType=[dataDict valueForKey:@"group_type"];
        grpProfile.ownerId=[dataDict valueForKey:@"owner_id"];
    }
    else if ([segue.identifier isEqualToString:@"grouplist"]){
        youSKOOPVC *youskoopGroup=segue.destinationViewController;
        youskoopGroup.isHideNavigationBar = NO;
        youskoopGroup.isInviteUser = YES;
        youskoopGroup.userId = self.blockUserId;
        youskoopGroup.groupId = self.groupId;
    }
    else if([segue.identifier isEqualToString:@"userprofile"]){
        NSDictionary *dataDict=(NSDictionary*)sender;
        UserProfileVC *userProfileObj=segue.destinationViewController;
        userProfileObj.groupId=@"";
        userProfileObj.groupOwnerId=@"";
        
        if(isShowReplierProfile){
            userProfileObj.name=[[dataDict valueForKey:@"reply"] valueForKey:@"name"];
            userProfileObj.imgUrl=[[dataDict valueForKey:@"reply"] valueForKey:@"image"];
            userProfileObj.blockUserId=[AppHelper userDefaultsForKey:KUserId];
        }
        else{
            userProfileObj.name = [dataDict valueForKey:@"name"];
            userProfileObj.imgUrl = [dataDict valueForKey:@"image"];
            userProfileObj.blockUserId = [dataDict valueForKey:@"user_id"];
        }
    }
    else if ([segue.identifier isEqualToString:@"skoop_req"]){
        
        NSDictionary *dataDict=(NSDictionary*)sender;
        ReplyOnSkoopVC *destViewController = segue.destinationViewController;
        destViewController.isShowFutureSkoop = [[dataDict valueForKey:@"skoop_type"] integerValue];
        destViewController.skoopId = [dataDict valueForKey:@"skoop_id"];
        destViewController.isUpdateUpcomingSkoop = YES;
        destViewController.deligate = self;
    }
    else if ([segue.identifier isEqualToString:@"skoop_reply"]){
        
        NSDictionary *dataDict = (NSDictionary*)sender;
        CellSelectionView *cellselectionobj = segue.destinationViewController;
        if([_btnBuy isSelected])
            cellselectionobj.isGetBuyVideos = YES;
        else
            cellselectionobj.isGetBuyVideos = NO;
        if([_btnBuy isSelected])
            cellselectionobj.navTitle = @"Buys";
        else
            cellselectionobj.navTitle = @"Requests";
        cellselectionobj.getInfoRequest = [NSMutableDictionary dictionaryWithDictionary:dataDict];
    }
    if([segue.identifier isEqual:@"goforreply"]){
        
        NSDictionary *dataDict=(NSDictionary*)sender;
        NSLog(@"::::%@",dataDict);
        VideoUploaderVC *videoObj=segue.destinationViewController;
        videoObj.videoLoaderDelegate = self;
        videoObj.skoopId=[dataDict valueForKey:@"skoop_id"];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
