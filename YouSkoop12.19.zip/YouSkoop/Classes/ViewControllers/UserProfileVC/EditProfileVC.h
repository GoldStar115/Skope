//
//  EditProfileVC.h
//  youskoop
//
//  Created by Shitesh Patel on 04/07/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRAutocompleteView.h"
#import "TRGoogleMapsAutocompleteItemsSource.h"

@interface EditProfileVC : UIViewController<UITextFieldDelegate,UIActionSheetDelegate,UIGestureRecognizerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    TRGoogleMapsAutocompleteItemsSource *_itemSource;
    TRAutocompleteView *_autocompleteView;
}

@end
