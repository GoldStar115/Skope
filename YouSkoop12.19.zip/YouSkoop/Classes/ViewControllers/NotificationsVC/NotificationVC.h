//
//  NotificationVC.h
//  youskoop
//
//  Created by Shitesh Patel on 23/05/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupProfileVC.h"

@interface NotificationVC : UIViewController<updateMyGroupListProtocol>

@property (strong, nonatomic) NSString *notificationId;
@end
