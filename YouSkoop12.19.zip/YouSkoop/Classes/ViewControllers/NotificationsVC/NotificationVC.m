//
//  NotificationVC.m
//  youskoop
//
//  Created by Shitesh Patel on 23/05/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "NotificationVC.h"
#import "CellSelectionView.h"
#import "ReplyOnSkoopVC.h"
#import "UserProfileVC.h"
#import "RequestViewViewController.h"

#define PageLimit                          @"50"

@interface NotificationVC (){
    
    __weak IBOutlet UITableView *_tableView;
    int pageNumber;
    NSInteger selectedRow;
    BOOL isHitWebservice;
}

@property (strong, nonatomic) NSMutableArray *notificationArray;
@property (strong, nonatomic) UIRefreshControl *refreshControl;
@end

@implementation NotificationVC
@synthesize notificationId;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    self.refreshControl.attributedTitle = [[NSAttributedString alloc] initWithString:@"Refreshing data..."];
    self.refreshControl.tintColor = [UIColor grayColor];
    [self.refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
    [_tableView addSubview:self.refreshControl];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNotificationListWithPush:) name:Notification_Update_Notification_List object:nil];
}

-(void)viewWillAppear:(BOOL)animated{
    
    isHitWebservice = YES;
    pageNumber = 1;
    [self performSelector:@selector(hitWebserviceForGettingNotifications) withObject:nil afterDelay:0.2];
}

#pragma mark Page refresh method
- (void)refresh:(id)sender{
    
    // do your refresh here and reload the tablview
    pageNumber=1;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetNotifications:) name: Notification_Get_AllNotifications object:nil];
        [[WebServicesController WebServiceMethod] getAllNotificationsWithUserId:[AppHelper userDefaultsForKey:KUserId] pageNumber:[NSString stringWithFormat:@"%i",pageNumber] andLimit:PageLimit];
    });
    
}

-(void)refreshNotificationListWithPush:(NSNotification*)noti{
    
    NSLog(@"***********NotificationVC*************");
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Update_Notification_List object:nil];
    
    self.notificationId=[noti.userInfo valueForKey:@"notification_id"];
    pageNumber=1;
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetNotifications:) name: Notification_Get_AllNotifications object:nil];
        [[WebServicesController WebServiceMethod] getAllNotificationsWithUserId:[AppHelper userDefaultsForKey:KUserId] pageNumber:[NSString stringWithFormat:@"%i",pageNumber] andLimit:PageLimit];
    });
    
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNotificationListWithPush:) name:Notification_Update_Notification_List object:nil];
}

#pragma mark Impliment protocol methods
-(void)updateMyGroupList
{
    
}

-(void)markAsReadNotification
{
    [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedRow inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark Tap gesture method
-(void)tapOnUserProfileImage:(UITapGestureRecognizer*)tapGesture
{
    UITableViewCell *tableVewCell=nil;
    if(IS_IOS_7)
        tableVewCell=(UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[tapGesture.view superview] superview];
    
    NSIndexPath *indexPath=[_tableView indexPathForCell:tableVewCell];
    NSDictionary *dataDict=[self.notificationArray objectAtIndex:indexPath.row];
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

#pragma mark Button action methods
-(IBAction)onClickBackButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)onClickSendSkoopRequestButton:(id)sender
{
    [self performSegueWithIdentifier:@"sendskooprequest" sender:nil];
}

-(void)hitWebserviceForGettingNotifications{
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetNotifications:) name: Notification_Get_AllNotifications object:nil];
        [[WebServicesController WebServiceMethod] getAllNotificationsWithUserId:[AppHelper userDefaultsForKey:KUserId] pageNumber:[NSString stringWithFormat:@"%i",pageNumber] andLimit:PageLimit];
    });
    
}

#pragma mark Receive notifications
-(void)userDidGetNotifications:(NSNotification*)notification{
    
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",notification.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_AllNotifications object:nil];
    if(notification.userInfo){
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            
            NSArray *dataArray = [notification.userInfo valueForKey:@"data"];
            [self.refreshControl endRefreshing];
            
            if(dataArray.count > 0){
                
                if(pageNumber == 1){
                    
                    if(self.notificationArray.count>0)
                        [self.notificationArray removeAllObjects];
                    self.notificationArray = [NSMutableArray arrayWithArray:dataArray];
                }
                else{
                    
                    for (int i = 0 ; i < dataArray.count ; i++) {
                        [self.notificationArray addObject:[dataArray objectAtIndex:i]];
                    }
                    
                    if(self.notificationArray.count && self.notificationId){
                        
                        for (int i=0 ; i<self.notificationArray.count; i++){
                            
                            NSDictionary *dataDict=[self.notificationArray objectAtIndex:i];
                            if([self.notificationId isEqualToString:[dataDict valueForKey:@"notification_id"]]){
                                
                                [self performSelector:@selector(scrollTableViewWithIndexPath:) withObject:[NSIndexPath indexPathForRow:i inSection:0] afterDelay:0.5];
                                break;
                            }
                        }
                    }
                }
                pageNumber++;
                [_tableView reloadData];
            }
            else{
                isHitWebservice = NO;
            }
        });
    }
}

-(void)scrollTableViewWithIndexPath:(NSIndexPath*)indexPath{
    
    [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationMiddle];
}

-(void)userDidDeleteNotifications:(NSNotification*)notification{
    
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",notification.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Delete_Group_Req object:nil];
    if(notification.userInfo){
        
        if([[notification.userInfo valueForKey:@"errorCode"] integerValue] == 0){
            
            [self.notificationArray removeObjectAtIndex:selectedRow];
            [_tableView reloadData];
        }
        else
            [AppHelper showAlertViewWithTag:1 title:AppName message:[notification.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

#pragma mark table view delegates

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    UILabel *lblNoData=(UILabel*)[self.view viewWithTag:123];
    if(self.notificationArray.count==0){
        
        if(!lblNoData){
            lblNoData=[[UILabel alloc] initWithFrame:CGRectMake(0, _tableView.frame.size.height/2.0-15.0, 320, 30.0)];
            lblNoData.backgroundColor=[UIColor clearColor];
            lblNoData.textColor=KTextColor;
            lblNoData.tag=123;
            lblNoData.textAlignment=NSTextAlignmentCenter;
            lblNoData.text=@"No data available";
            [_tableView addSubview:lblNoData];
        }
    }
    else
        [lblNoData removeFromSuperview];
    
    return [self.notificationArray count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if(self.notificationArray.count-1 == indexPath.row)
        return 95.0;
    else
        return 81.0;
}

-(UITableViewCell *)tableView:(UITableView *)table_View cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [table_View dequeueReusableCellWithIdentifier:@"NotificationCell"];
    if(cell == nil){
        
        NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"NotificationCell" owner:self options:nil];
        cell = [topLevelObjects objectAtIndex:0];
        
        if(!IS_Greater_Or_Equal_to_IOS_7){
            UIImageView *imgView = [[UIImageView alloc] initWithFrame:cell.frame];
            imgView.image = [UIImage imageNamed:@"unread_notify_bg.png"];
            imgView.tag = 777;
            [cell.contentView addSubview:imgView];
        }
        
        UIImageView *image_view = (UIImageView *)[cell.contentView viewWithTag:801];
        UITapGestureRecognizer *uiTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnUserProfileImage:)];
        uiTap.numberOfTapsRequired = 1;
        image_view.userInteractionEnabled = YES;
        [image_view addGestureRecognizer:uiTap];
    }
    
    NSMutableDictionary *dict = [self.notificationArray objectAtIndex:indexPath.row];
    
    if(IS_Greater_Or_Equal_to_IOS_7){
        if((![[dict valueForKey:@"read_status"] isKindOfClass:[NSNull class]] && [[dict valueForKey:@"read_status"] integerValue]==1))
            cell.backgroundColor = [UIColor clearColor];
        else
            cell.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"unread_notify_bg.png"]];
    }
    else{
        UIImageView *imgView = (UIImageView *)[cell.contentView viewWithTag:777];
        if((![[dict valueForKey:@"read_status"] isKindOfClass:[NSNull class]] && [[dict valueForKey:@"read_status"] integerValue]==1))
            imgView.hidden = YES;
        else
            imgView.hidden = NO;
    }
    
    if(indexPath.row == self.notificationArray.count -1 && isHitWebservice){
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetNotifications:) name: Notification_Get_AllNotifications object:nil];
            [[WebServicesController WebServiceMethod] getAllNotificationsWithUserId:[AppHelper userDefaultsForKey:KUserId] pageNumber:[NSString stringWithFormat:@"%i",pageNumber] andLimit:PageLimit];
        });
    }
    
    UIImageView *profImage = (UIImageView *)[cell.contentView viewWithTag:801];
    [AppHelper getRoundedImageWithImageView:profImage];
    if([[dict valueForKey:@"notification_type"] isEqualToString:@"group_verified"]){
        profImage.userInteractionEnabled = NO;
    }
    else{
        profImage.userInteractionEnabled = YES;
    }
    
    UILabel *lblName = (UILabel *)[cell.contentView viewWithTag:802];
    lblName.textColor = KTextColor;
    lblName.text = [dict valueForKey:@"name"];
    
    UILabel *lblMessage = (UILabel *)[cell.contentView viewWithTag:803];
    lblMessage.font = [UIFont systemFontOfSize:14.0];
    if([[dict valueForKey:@"notification_type"] isEqualToString:@"group_request"])
        lblMessage.text = [NSString stringWithFormat:@"Invited you to join \"%@\".",[dict valueForKey:@"group_name"]];
    else if([[dict valueForKey:@"notification_type"] isEqualToString:@"group_skoop_request"])
        lblMessage.text = [NSString stringWithFormat:@"sent a Skoop request to \"%@\".",[dict valueForKey:@"group_name"]];
    else if([[dict valueForKey:@"notification_type"] isEqualToString:@"user_unblock"])
        lblMessage.text = @"has allowed interactions with you again. Nice!";
    else if([[dict valueForKey:@"notification_type"] isEqualToString:@"user_block"])
        lblMessage.text = @"has blocked interactions with you.";
    else if([[dict valueForKey:@"notification_type"] isEqualToString:@"group_verified"]){
        lblMessage.text = [NSString stringWithFormat:@"Your Official Celebrity Group \"%@\" has been verified. Way to go!",[dict valueForKey:@"group_name"]];
        lblMessage.font = [UIFont systemFontOfSize:12.0];
    }
    else if([[dict valueForKey:@"notification_type"] isEqualToString:@"group_user_block"])
        lblMessage.text = [NSString stringWithFormat:@"blocked you from \"%@\".",[dict valueForKey:@"group_name"]];
    else if([[dict valueForKey:@"notification_type"] isEqualToString:@"group_user_unblock"])
        lblMessage.text = [NSString stringWithFormat:@"just unblocked you from \"%@\".",[dict valueForKey:@"group_name"]];
    else if([[dict valueForKey:@"notification_type"] isEqualToString:@"join_group"])
        lblMessage.text = [NSString stringWithFormat:@"%@ has joined the group \"%@\".",[dict valueForKey:@"name"],[dict valueForKey:@"group_name"]];
    
    UILabel *lblDate = (UILabel*)[cell.contentView viewWithTag:804];
    if([[dict valueForKey:@"notification_type"] isEqualToString:@"group_skoop_request"])
        lblDate.text = [dict valueForKey:@"skoop_date"];
    else
        lblDate.text = [dict valueForKey:@"date"];
    
    if([[dict valueForKey:@"profile_image"] length]>0)
        [profImage setImageWithURL:[NSURL URLWithString:[dict valueForKey:@"profile_image"]] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    else
        profImage.image = [UIImage imageNamed:@"defaultuser.png"];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    selectedRow=indexPath.row;
    NSMutableDictionary *dataDict = [NSMutableDictionary dictionaryWithDictionary:[self.notificationArray objectAtIndex:selectedRow]];
    NSLog(@"%@",dataDict);
    if([[dataDict valueForKey:@"notification_type"] isEqualToString:@"group_skoop_request"]){
        NSMutableDictionary *dataDict = [NSMutableDictionary dictionaryWithDictionary:[self.notificationArray objectAtIndex:selectedRow]];
        [dataDict setValue:@"1" forKey:@"join_status"];
        [self performSegueWithIdentifier:@"groupprofile" sender:dataDict];
    }
    else if ([[dataDict valueForKey:@"notification_type"] isEqualToString:@"group_verified"]){
        [self performSegueWithIdentifier:@"groupprofile" sender:[self.notificationArray objectAtIndex:selectedRow]];
    }
    else  if([[dataDict valueForKey:@"notification_type"] isEqualToString:@"group_request"] || [[dataDict valueForKey:@"notification_type"] isEqualToString:@"group_user_unblock"]){
        if([[dataDict valueForKey:@"join_status"] integerValue] == 3){
            [AppHelper showAlertViewWithTag:1 title:AppName message:[NSString stringWithFormat:@"You can't access this group because the admin has blocked you."] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
        else{
            [self performSegueWithIdentifier:@"groupprofile" sender:[self.notificationArray objectAtIndex:selectedRow]];
        }
    }
    else{
        if([[dataDict valueForKey:@"read_status"] integerValue]==0)
            [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[dataDict valueForKey:@"notification_id"] notificationType:@"group_request" andToken:KAppToken];
    }
    
    [dataDict setValue:@"1" forKey:@"read_status"];
    [self.notificationArray replaceObjectAtIndex:selectedRow withObject:dataDict];
    [self performSelector:@selector(reloadTableviewAfterDelayWithIndexPath:) withObject:indexPath afterDelay:0.3];
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete){
        //add code here for when you hit delete
        selectedRow = indexPath.row;
        [AppHelper showAlertViewWithTag:101 title:AppName message:@"Are you sure you want to delete this request?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
    }
}

-(void)reloadTableviewAfterDelayWithIndexPath:(NSIndexPath*)indexPath{
    [_tableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag==101){
        if(buttonIndex==0){
            NSDictionary *dataDict = [self.notificationArray objectAtIndex:selectedRow];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidDeleteNotifications:) name:Notification_Delete_Group_Req object:nil];
            [[WebServicesController WebServiceMethod] deleteGroupRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[dataDict valueForKey:@"notification_id"] notificationType:[dataDict valueForKey:@"notification_type"] andAppToken:KAppToken];
        }
    }
}

#pragma mark Prepare for segue
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if ([segue.identifier isEqualToString:@"groupprofile"]){
        
        GroupProfileVC *grpProfile = segue.destinationViewController;
        grpProfile.updateListProtocol = self;
        grpProfile.isFromNotification = YES;
        
        NSDictionary *dataDict=(NSDictionary*)sender;
        
        grpProfile.name = [dataDict valueForKey:@"group_name"];
        grpProfile.imgUrl = [dataDict valueForKey:@"cover_image"];
        grpProfile.groupImageUrl = [dataDict valueForKey:@"image"];
        grpProfile.groupDescription = [dataDict valueForKey:@"group_description"];
        if([dataDict valueForKey:@"group_id"]){
            grpProfile.groupId = [dataDict valueForKey:@"group_id"];
        }
        else if([dataDict valueForKey:@"object_id"]){
            grpProfile.groupId = [dataDict valueForKey:@"object_id"];
        }
        
        grpProfile.categoryName = [dataDict valueForKey:@"category_name"];
        grpProfile.groupType = [dataDict valueForKey:@"group_type"];
        grpProfile.ownerId = [dataDict valueForKey:@"owner_id"];
        grpProfile.groupStatus = [dataDict valueForKey:@"status"];
        
        if([dataDict valueForKey:@"skoop_type"] && [[dataDict valueForKey:@"skoop_type"] integerValue]==1)
            grpProfile.reqType = @"future";
        else if([dataDict valueForKey:@"skoop_type"] && [[dataDict valueForKey:@"skoop_type"] integerValue]==0)
            grpProfile.reqType = @"current";
        
        if([dataDict valueForKey:@"skoop_id"])
            grpProfile.skoopId = [dataDict valueForKey:@"skoop_id"];
        else
            grpProfile.skoopId = @"0";
        
        [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[dataDict valueForKey:@"notification_id"] notificationType:@"group_request" andToken:KAppToken];
    }
    else if ([segue.identifier isEqualToString:@"skooprequest"]){
        
        ReplyOnSkoopVC *replySkoop = segue.destinationViewController;
        NSDictionary *dataDict=(NSDictionary*)sender;
        replySkoop.isShowFutureSkoop = [[dataDict valueForKey:@"skoop_type"] integerValue];
        
        [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[dataDict valueForKey:@"notification_id"] notificationType:@"group_request" andToken:KAppToken];
    }
    else if([segue.identifier isEqualToString:@"userprofile"]){
        
        NSDictionary *dataDict = (NSDictionary*)sender;
        NSLog(@"%@",dataDict);
        UserProfileVC *userProfileObj=segue.destinationViewController;
        userProfileObj.groupId = @"";
        userProfileObj.groupOwnerId = @"";
        userProfileObj.name = [dataDict valueForKey:@"name"];
        userProfileObj.imgUrl = [dataDict valueForKey:@"profile_image"];
        userProfileObj.blockUserId = [dataDict valueForKey:KUserId];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
