//
//  WelcomeView.h
//  youskoop
//
//  Created by user on 3/7/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WelcomeView : UIViewController

@property (weak, nonatomic) IBOutlet UIImageView *logoimgview;

@end
