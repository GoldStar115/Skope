//
//  BlockedUserVC.m
//  youskoop
//
//  Created by Shitesh Patel on 25/06/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "BlockedUserVC.h"
#import "UserProfileVC.h"

#define PageLimit       @"10"

@interface BlockedUserVC ()
{
    __weak IBOutlet UITableView *_tableView;
    __weak IBOutlet UITextField *_txtSearch;
    __weak IBOutlet UIView *_viewSearch;
    __weak IBOutlet UIButton *_btnBlockUser;
    __weak IBOutlet UIButton *_btnGroupBlock;
    
    NSMutableArray *arrayOfBlockedUsers;
    NSMutableArray *afterSearchData;
    NSDictionary *selectedUserDict;
    
    int pageNo;
    BOOL isHitWebService;
    BOOL isSearching;
}
//@property (strong, nonatomic) NSMutableArray *afterSearchData;
@end

@implementation BlockedUserVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7)
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    [_btnBlockUser setSelected:YES];
    [_btnBlockUser setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
    [_btnGroupBlock setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    
    _tableView.userInteractionEnabled=YES;
    CGRect frameRect=_tableView.frame;
    if(IS_Greater_Or_Equal_to_IOS_7)
        frameRect.size.height=self.view.bounds.size.height-frameRect.origin.y;
    else
        frameRect.size.height=self.view.bounds.size.height-frameRect.origin.y-12;
    _tableView.frame=frameRect;
    
    arrayOfBlockedUsers=[[NSMutableArray alloc] init];
    afterSearchData=[[NSMutableArray alloc] init];
    pageNo=1;
    [self getBlockedUsersWithText:@"" andIsShowIndicator:YES];
}

-(void)viewWillAppear:(BOOL)animated{
    //Hide tabbar
    [[AppDelegate getAppDelegate] hideTabBar:self.tabBarController];
}
-(void)viewWillDisappear:(BOOL)animated{
    //Show tabbar
    [[AppDelegate getAppDelegate] showTabBar:self.tabBarController];
}

//Method for getting blocked users list through webservice
-(void)getBlockedUsersWithText:(NSString*)searchText andIsShowIndicator:(BOOL)showIndicator
{
    if(showIndicator)
    {
        [AppDelegate dismissGlobalHUD];
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    }
    else
    {
        UIImageView *imgView=(UIImageView*)[_viewSearch viewWithTag:906];
        imgView.hidden=YES;
        
        UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[_viewSearch viewWithTag:1001];
        
        if(activityIndicator)
            [activityIndicator startAnimating];
        else
        {
            activityIndicator= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            activityIndicator.backgroundColor=[UIColor clearColor];
            activityIndicator.alpha = 1.0;
            activityIndicator.tag=1001;
            activityIndicator.center = imgView.center;
            activityIndicator.hidesWhenStopped = YES;
            [_viewSearch addSubview:activityIndicator];
            [activityIndicator startAnimating];
        }
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetBlockedUsers:) name:Notification_Get_Block_User object:nil];
    
    if([searchText length]>0)
    {
        if([_btnBlockUser isSelected])
            [[WebServicesController WebServiceMethod] getBlockedUserWithUserId:[AppHelper userDefaultsForKey:KUserId] group:@"0" searchText:searchText pageNumber:[NSString stringWithFormat:@"%i",pageNo] pageLimit:@"0" andAppToken:KAppToken];
        else
            [[WebServicesController WebServiceMethod] getBlockedUserWithUserId:[AppHelper userDefaultsForKey:KUserId] group:@"1" searchText:searchText pageNumber:[NSString stringWithFormat:@"%i",pageNo] pageLimit:@"0" andAppToken:KAppToken];
    }
    else
    {
        if([_btnBlockUser isSelected])
            [[WebServicesController WebServiceMethod] getBlockedUserWithUserId:[AppHelper userDefaultsForKey:KUserId] group:@"0" searchText:searchText pageNumber:[NSString stringWithFormat:@"%i",pageNo] pageLimit:PageLimit andAppToken:KAppToken];
        else
             [[WebServicesController WebServiceMethod] getBlockedUserWithUserId:[AppHelper userDefaultsForKey:KUserId] group:@"1" searchText:searchText pageNumber:[NSString stringWithFormat:@"%i",pageNo] pageLimit:PageLimit andAppToken:KAppToken];
    }
}

#pragma mark Button action methods

-(IBAction)onClickBackButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)onClickBlockedUserButton:(id)sender
{
    if(![_btnBlockUser isSelected])
    {
        [_btnBlockUser setSelected:YES];
        [_btnGroupBlock setSelected:NO];
        [_btnBlockUser setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
        [_btnGroupBlock setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        
        [self getBlockedUsersWithText:@"" andIsShowIndicator:YES];
    }
}

-(IBAction)onClickGroupBlockedUserButton:(id)sender
{
    if(![_btnGroupBlock isSelected])
    {
        [_btnGroupBlock setSelected:YES];
        [_btnBlockUser setSelected:NO];
        [_btnGroupBlock setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
        [_btnBlockUser setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        
        [self getBlockedUsersWithText:@"" andIsShowIndicator:YES];
    }
}

-(IBAction)onClickUnblockButton:(id)sender
{
    if([_txtSearch isFirstResponder])
    {
        [_txtSearch resignFirstResponder];
        return;
    }
    UITableViewCell *tblcell=nil;
    if(IS_IOS_7)
        tblcell=(UITableViewCell*)[[[sender superview] superview] superview];
    else
        tblcell=(UITableViewCell*)[[sender superview] superview];
    NSIndexPath *indexPath=[_tableView indexPathForCell:tblcell];
    
    if(isSearching)
        selectedUserDict=[afterSearchData objectAtIndex:indexPath.row];
    else
        selectedUserDict=[arrayOfBlockedUsers objectAtIndex:indexPath.row];
    
    [AppHelper showAlertViewWithTag:1 title:AppName message:@"Are you sure you want to unblock this user?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
}

#pragma mark tableView Delegate methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    UILabel *lblNoData=(UILabel*)[self.view viewWithTag:123];
    BOOL isNoData=NO;
    if(isSearching && afterSearchData.count==0)
        isNoData=YES;
    else if(arrayOfBlockedUsers.count==0)
        isNoData=YES;
    
    if(isNoData){
        if(!lblNoData){
            lblNoData=[[UILabel alloc] initWithFrame:CGRectMake(0, _tableView.frame.size.height/2.0-15.0, 320, 30.0)];
            lblNoData.textAlignment=NSTextAlignmentCenter;
            lblNoData.backgroundColor=[UIColor clearColor];
            lblNoData.textColor = KTextColor;
            lblNoData.tag=123;
            lblNoData.text=@"No data available";
            [_tableView addSubview:lblNoData];
        }
    }
    else
        [lblNoData removeFromSuperview];
    
    if(isSearching)
        return [afterSearchData count];
    else
        return [arrayOfBlockedUsers count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"cellIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    cell.backgroundColor=[UIColor clearColor];
    
//    if(indexPath.row==arrayOfBlockedUsers.count-1 && isHitWebService && !isSearching){
//        [self getBlockedUsersWithText:@"" andIsShowIndicator:YES];
//    }
    
    NSDictionary *dictOfBlockUser;
    if(isSearching)
        dictOfBlockUser=[afterSearchData objectAtIndex:indexPath.row];
    else
        dictOfBlockUser=[arrayOfBlockedUsers objectAtIndex:indexPath.row];
    
    UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:100];
    [AppHelper getRoundedImageWithImageView:profileImage];
    UITapGestureRecognizer *uiTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnSenderSkoopProfileImage:)];
    uiTap.numberOfTapsRequired=1;
    profileImage.userInteractionEnabled=YES;
    [profileImage addGestureRecognizer:uiTap];
    
    NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfBlockUser objectForKey:@"image"]]];
    NSString *imgUrl=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:imgUrl];
    
    if([urlString length]>0)
        [profileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    else
        profileImage.image=[UIImage imageNamed:@"defaultuser.png"];
    
    UILabel *lblLikeCount=(UILabel *)[cell.contentView viewWithTag:101];
    lblLikeCount.backgroundColor=[UIColor clearColor];
    lblLikeCount.text=[NSString stringWithFormat:@"%i",[[dictOfBlockUser valueForKey:@"like"] intValue]];
    
    UILabel *lblName=(UILabel *)[cell viewWithTag:102];
    lblName.text=[dictOfBlockUser valueForKey:@"name"];
    
    UILabel *lblBlockedUser=(UILabel *)[cell viewWithTag:103];
    if([_btnBlockUser isSelected])
        lblBlockedUser.text=@"blocked from 'App'";
    else
        lblBlockedUser.text=[NSString stringWithFormat:@"blocked from '%@'",[dictOfBlockUser valueForKey:@"group_name"]];
    lblBlockedUser.textColor = KTextColor;
    
    UILabel *lblJoinDate=(UILabel *)[cell viewWithTag:104];
    lblJoinDate.textColor = KTextColor;
    lblJoinDate.text=[NSString stringWithFormat:@"Member Since: %@",[dictOfBlockUser valueForKey:@"member_since"]];
    
    return  cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([_txtSearch isFirstResponder])
        [_txtSearch resignFirstResponder];
}

#pragma mark Tap gesture method
-(void)tapOnSenderSkoopProfileImage:(UITapGestureRecognizer*)tapGesture
{
    UITableViewCell *tableVewCell=nil;
    if(IS_IOS_7)
        tableVewCell=(UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[tapGesture.view superview] superview];
    
    NSIndexPath *indexPath=[_tableView indexPathForCell:tableVewCell];
    NSDictionary *dataDict=nil;
    
    if(isSearching)
        dataDict=[afterSearchData objectAtIndex:indexPath.row];
    else
        dataDict=[arrayOfBlockedUsers objectAtIndex:indexPath.row];
    
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}


#pragma mark Textfield deligates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    isSearching=YES;
    NSString *searchText = [textField.text stringByReplacingCharactersInRange:range withString:string];
    [self getBlockedUsersWithText:searchText andIsShowIndicator:NO];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSString *searchString=[textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if([searchString length]==0){
        isSearching=NO;
        [_tableView reloadData];
    }
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    isSearching=NO;
    [_tableView reloadData];
    return YES;
}

#pragma mark Alertview deligate methods

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==1)
    {
        if(buttonIndex==0)
        {
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidUnBlockedUser:) name:Notification_Block_Unblock_User object:nil];
            
            //Unblock user which is blocked from app
            if([_btnBlockUser isSelected])
            {
                [[WebServicesController WebServiceMethod] blockUnblockUserWithUserId:[AppHelper userDefaultsForKey:KUserId] blockUserId:[selectedUserDict valueForKey:KUserId] groupId:@"0" requestType:@"unblock" andReason:@"Unblock this user"];
            }
            else//Unblock user which is blocked from group
            {
                [[WebServicesController WebServiceMethod] blockUnblockUserWithUserId:[AppHelper userDefaultsForKey:KUserId] blockUserId:[selectedUserDict valueForKey:KUserId] groupId:[selectedUserDict valueForKey:@"group_id"] requestType:@"unblock" andReason:@"Unblock this user"];
            }
        }
    }
}

#pragma mark Detect view touch
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"touch detect");
    [super touchesBegan:touches withEvent:event];
    if([_txtSearch isFirstResponder])
        [_txtSearch resignFirstResponder];
}


#pragma mark Services response methods

-(void)userDidGetBlockedUsers:(NSNotification *)note
{
    NSLog(@"Request Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    
    UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[_viewSearch viewWithTag:1001];
    if(activityIndicator)
        [activityIndicator stopAnimating];
    UIImageView *imgView=(UIImageView*)[_viewSearch viewWithTag:906];
    imgView.hidden=NO;
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Block_User object:nil];
    if (note.userInfo)
    {
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0)
        {
            NSLog(@"NO ERROR");
        
            NSArray *dataArray=[note.userInfo valueForKey:@"data"];
            if(isSearching)
            {
                if(afterSearchData && [afterSearchData count]>0)
                    [afterSearchData removeAllObjects];
                
                if(dataArray.count>0){
                    for (int i=0; i<dataArray.count; i++) {
                        [afterSearchData addObject:[dataArray objectAtIndex:i]];
                    }
                }
                [_tableView reloadData];
            }
            else
            {
                //pageNo++;
                if(arrayOfBlockedUsers && [arrayOfBlockedUsers count]>0)
                    [arrayOfBlockedUsers removeAllObjects];
                
                if(dataArray.count>0){
                    for (int i=0; i<dataArray.count; i++) {
                        [arrayOfBlockedUsers addObject:[dataArray objectAtIndex:i]];
                    }
                }
                else
                    isHitWebService=NO;
                [_tableView reloadData];
            }
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1){
            isHitWebService=NO;
        }
    }
}

-(void)userDidUnBlockedUser:(NSNotification *)note
{
    NSLog(@"Request Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Block_User object:nil];
    if (note.userInfo)
    {
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0)
        {
            [afterSearchData removeObject:selectedUserDict];
            [arrayOfBlockedUsers removeObject:selectedUserDict];
            [_tableView reloadData];
            if([_btnGroupBlock isSelected])
                [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_GroupMembers object:nil userInfo:nil];
        }
        else
            [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

#pragma mark Segur method
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:@"userprofile"])
    {
        NSDictionary *dataDict=(NSDictionary*)sender;
        UserProfileVC *userProfileObj=segue.destinationViewController;
        userProfileObj.groupId=@"";
        userProfileObj.groupOwnerId=@"";
        userProfileObj.name=[dataDict valueForKey:@"name"];
        userProfileObj.imgUrl=[dataDict valueForKey:@"image"];
        userProfileObj.blockUserId=[dataDict valueForKey:@"user_id"];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
