//
//  CellSelectionView.m
//  youskoop
//
//  Created by user on 3/19/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "CellSelectionView.h"
#import "UIImageView+AFNetworking.h"
#import "Defines.h"
#import "WebServicesController.h"
#include "AppHelper.h"
#import "RequestViewViewController.h"

#import "UserProfileVC.h"
#import "HomeView.h"
#import "VideoPlayerVC.h"

#import "CallViewController.h"

@interface CellSelectionView ()<updatePaymentStatus,updateSkoopData>{
    
    BOOL isShowSelfProfile;
    NSDictionary *selectedData;
    
    __weak IBOutlet UILabel *_lblHeaderTitle;
    __weak IBOutlet UIImageView *_imgLivePortal;
    __weak IBOutlet UIView *_viewCalling;
    __weak IBOutlet UILabel *_lblLPChargeMessage;
}
@end

@implementation CellSelectionView
@synthesize outletTableView,getInfoRequest,imgviewRequest,lblDate,lblLocation,lblSkoopName,lblName,lblTime,arrayOfReply;
@synthesize isGetBuyVideos;
@synthesize navTitle;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    
    [super viewDidLoad];
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7)
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    //Set navigation title
    if(self.navTitle){
        _lblHeaderTitle.text = self.navTitle;
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshSkoopReplyList:) name:Notification_Refresh_Skoop_Reply_list object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updatePaymentStatus:) name:Notification_Update_Payment_Status object:nil];
    
    UIImageView *imgPurchaseMsgBase = (UIImageView *)[_viewCalling viewWithTag:101];
    imgPurchaseMsgBase.layer.cornerRadius = 5.0;
    
    [AppHelper getRoundedImageWithImageView:self.imgviewRequest];
    
    UITapGestureRecognizer *uiTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnSenderSkoopProfileImage:)];
    uiTap.numberOfTapsRequired = 1;
    self.imgviewRequest.userInteractionEnabled = YES;
    [self.imgviewRequest addGestureRecognizer:uiTap];
    
    if([self.getInfoRequest valueForKey:@"group_name"] && [[self.getInfoRequest valueForKey:@"group_name"] length]>0)
        self.lblLocation.text = [NSString stringWithFormat:@"Group: %@",[self.getInfoRequest valueForKey:@"group_name"]];
    else
        self.lblLocation.text = [self.getInfoRequest valueForKey:@"location"];
    
    if([self.getInfoRequest valueForKey:@"date"])
        self.lblDate.text = [self.getInfoRequest valueForKey:@"date"];
    
    if([AppHelper userDefaultsDictionaryDataForKey:KIsSendToSkoopReply])
        [AppHelper removeFromUserDefaultsWithKey:KIsSendToSkoopReply];
    
    [self showSkoopReplyDetails];
    
    if ([[self.getInfoRequest objectForKey:@"skoop_id"] isEqualToString:@"1"]) {
        self._headerView.hidden = YES;
        self.outletTableView.frame = CGRectMake(0, 64, 320, 450);
    }
    
}

-(void)viewWillAppear:(BOOL)animated{
    
    self.lblSkoopName.text = [self.getInfoRequest valueForKey:@"searchText"];
    [self.lblSkoopName setLabelSettingForObject:@"skoop"];
    self.lblName.text = [self.getInfoRequest valueForKey:@"name"];
    [self.lblName setLabelSettingForObject:@"name"];
    
    NSArray *visibleCellsArray = [self.outletTableView indexPathsForVisibleRows];
    if(visibleCellsArray && visibleCellsArray.count)
        [self.outletTableView reloadRowsAtIndexPaths:visibleCellsArray withRowAnimation:UITableViewRowAnimationNone];
    
    
}

-(void)showSkoopReplyDetails{
    
    if([[self.getInfoRequest valueForKey:@"live_portal"] integerValue]==1){
        
        CGRect frameRect = self.lblSkoopName.frame;
        frameRect.size.width -= 50;
        self.lblSkoopName.frame = frameRect;
        
        frameRect = self.lblLocation.frame;
        frameRect.size.width -= 50;
        self.lblLocation.frame = frameRect;
        
        frameRect = self.lblTime.frame;
        frameRect.size.width -= 50;
        self.lblTime.frame = frameRect;
        
        _imgLivePortal.hidden = NO;
    }
    else{
        _imgLivePortal.hidden = YES;
    }
    
    if([self.getInfoRequest valueForKey:@"price"] && [[self.getInfoRequest valueForKey:@"price"] floatValue] > 0)
        self._lblCost.text = [NSString stringWithFormat:@"$%@",[self.getInfoRequest valueForKey:@"price"]];
    else
        self._lblCost.text = @"Favor";
    
    if([self.getInfoRequest objectForKey:@"image"] && [[self.getInfoRequest objectForKey:@"image"] length]>0)
        [self.imgviewRequest setImageWithURL:[NSURL URLWithString:[self.getInfoRequest objectForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    else
        self.imgviewRequest.image=[UIImage imageNamed:@"defaultuser.png"];
    
    if([[self.getInfoRequest valueForKey:@"replyCount"] integerValue] > 0){
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        if([[self.getInfoRequest valueForKey:@"live_portal"] integerValue]==1){
            
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetLivePortalConfirmation:) name:Notification_Get_LivePortal_Confirmation object:nil];
            [[WebServicesController WebServiceMethod] getLivePortalConfirmationWithUserId:[AppHelper userDefaultsForKey:KUserId] requestId:[self.getInfoRequest valueForKey:@"skoop_id"] andAppToken:KAppToken];
        }
        else{
            
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetSkoopReplyVideos:) name:Notification_for_reply_skoopid object:nil];
            if([self.getInfoRequest valueForKey:@"skoop_id"]){
                [[WebServicesController WebServiceMethod] getSkoopReplyVideoWithSkoopId:[self.getInfoRequest valueForKey:@"skoop_id"] buy:[NSString stringWithFormat:@"%i",isGetBuyVideos] andAppToken:KAppToken andGroupId:[self.getInfoRequest valueForKey:@"group_id"]];
            }
            else if([self.getInfoRequest valueForKey:@"object_id"]){
                
                [[WebServicesController WebServiceMethod] getSkoopReplyVideoWithSkoopId:[self.getInfoRequest valueForKey:@"object_id"] buy:[NSString stringWithFormat:@"%i",isGetBuyVideos] andAppToken:KAppToken andGroupId:[self.getInfoRequest valueForKey:@"group_id"]];
            }
        }
    }
    
    if([[self.getInfoRequest valueForKey:@"read_status"] integerValue]==0){
        
        if([self.getInfoRequest valueForKey:@"live_portal"] && [[self.getInfoRequest valueForKey:@"live_portal"] integerValue] == 1){
            
            [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[self.getInfoRequest valueForKey:@"skoop_id"] notificationType:@"live_portal_accept" andToken:KAppToken];
        }
        else{
            
            [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[self.getInfoRequest valueForKey:@"skoop_id"] notificationType:@"skoop_reply" andToken:KAppToken];
        }
    }
}

#pragma mark Deligate methods

-(void)updateCallPaymentStatus{
    
    int selectedIndex = (int)[arrayOfReply indexOfObject:selectedData];
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:selectedData];
    [dict setValue:@"1" forKey:@"payment_status"];
    [arrayOfReply replaceObjectAtIndex:selectedIndex withObject:dict];
    
    [self.outletTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
}

-(void)updateSkoopDataWithData{
    
    int selectedIndex = (int)[arrayOfReply indexOfObject:selectedData];
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:selectedData];
    [dict setValue:@"1" forKey:@"paymentStatus"];
    [arrayOfReply replaceObjectAtIndex:selectedIndex withObject:dict];
    
    [self.outletTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark Button action methods
- (IBAction)btnBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)call:(id)sender{
    
//    if([[AppHelper userDefaultsForKey:KAvailableCredit] floatValue] >=  [[self.getInfoRequest valueForKey:@"price"] floatValue]){
//        
//        HomeView *homeViewController = [[self.navigationController viewControllers] objectAtIndex:0];
//        //homeViewController.deligate = self;
//        NSDictionary *paramDict=[NSDictionary dictionaryWithObjectsAndKeys:[AppHelper userDefaultsForKey:KUserName],@"name",[AppHelper userDefaultsForKey:KUserImageUrl],@"image",[selectedData valueForKey:KUserId],@"seller_id",[selectedData valueForKey:@"portal_id"],@"portal_id",[selectedData valueForKey:@"userName"],@"userName",[selectedData valueForKey:@"userImage"],@"userImage",[self.getInfoRequest valueForKey:@"price"],@"price",[selectedData valueForKey:@"payment_status"],@"payment_status",nil];
//        //[homeViewController setupVideoCallWithQuickbloxId:[selectedData valueForKey:@"quick_blox_id"] andCustomParaMeteres:paramDict];
//    }
//    else{
//        [AppHelper showAlertViewWithTag:105 title:AppName message:@"You have insufficient balance to make this call,please recharge your account first.Do you want to recharge your account?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
//    }
    
    [_viewCalling removeFromSuperview];
    
    
    
//    [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[self.getInfoRequest valueForKey:@"skoop_id"] notificationType:@"skoop_reply" andToken:KAppToken];
    [[WebServicesController WebServiceMethod] livePortalCallFromUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:[self.getInfoRequest valueForKey:@"skoop_id"] toOpponentId:[selectedData objectForKey:@"user_id"] andAppToken:KAppToken];
    
    CallViewController *callViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"CallViewController"];
    callViewController.conferenceId = [NSString stringWithFormat:@"skoopid%@", [self.getInfoRequest valueForKey:@"skoop_id"]];
    callViewController.opponentUsername = [selectedData objectForKey:@"userName"];
    callViewController.opponentUserImgUrl = [selectedData objectForKey:@"userImage"];
    [self presentViewController:callViewController animated:YES completion:nil];
    
}

-(IBAction)onClickFlipCameraButton:(id)sender{
    
    UIButton *btnFlip=(UIButton*)sender;
    if([btnFlip isSelected]){
        [btnFlip setSelected:NO];
        
    }
    else{
        [btnFlip setSelected:YES];
        
    }
}

-(IBAction)onClickNoButton:(id)sender
{
    [_viewCalling removeFromSuperview];
}

#pragma mark Services response and receive notifications

-(void)refreshSkoopReplyList:(NSNotification *)note{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Refresh_Skoop_Reply_list object:nil];
    
    if(note.userInfo){
        
        NSLog(@"22233334444444:%@",note.userInfo);
        self.getInfoRequest = [NSMutableDictionary dictionaryWithDictionary:note.userInfo];
        [self showSkoopReplyDetails];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshSkoopReplyList:) name:Notification_Refresh_Skoop_Reply_list object:nil];
}

-(void)updatePaymentStatus:(NSNotification *)note{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Update_Payment_Status object:nil];
    NSLog(@"********updatePaymentStatus*************");
    int selectedIndex = (int)[arrayOfReply indexOfObject:selectedData];
    NSMutableDictionary *dict = [NSMutableDictionary dictionaryWithDictionary:selectedData];
    [dict setValue:@"1" forKey:@"payment_status"];
    [arrayOfReply replaceObjectAtIndex:selectedIndex withObject:dict];
    
    [self.outletTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updatePaymentStatus:) name:Notification_Update_Payment_Status object:nil];
}

-(void)userDidGetSkoopReplyVideos:(NSNotification *)note{
    
    NSLog(@"Reply Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_for_reply_skoopid object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            NSLog(@"NO ERROR");
            arrayOfReply = [NSMutableArray arrayWithArray:[note.userInfo valueForKey:@"data"]];
            self.lblSkoopName.text = [note.userInfo valueForKey:@"searchText"];
            
            if([note.userInfo valueForKey:@"group_name"] && [[note.userInfo valueForKey:@"group_name"] length]>0)
                self.lblLocation.text = [NSString stringWithFormat:@"Group: %@",[note.userInfo valueForKey:@"group_name"]];
            else
                self.lblLocation.text = [note.userInfo valueForKey:@"location"];
            
            if([note.userInfo valueForKey:@"skoop_date"])
                self.lblDate.text = [note.userInfo valueForKey:@"skoop_date"];
            
            if([[arrayOfReply objectAtIndex:0] valueForKey:@"price"] && [[[arrayOfReply objectAtIndex:0] valueForKey:@"price"] floatValue]>0)
                self._lblCost.text = [NSString stringWithFormat:@"$%@",[[arrayOfReply objectAtIndex:0] valueForKey:@"price"]];
            else
                self._lblCost.text = @"Favor";
            
            [outletTableView reloadData];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1){
            [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
    }
}

-(void)userDidGetLivePortalConfirmation:(NSNotification *)note{
    
    NSLog(@"Reply Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_LivePortal_Confirmation object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            NSLog(@"NO ERROR");
            
            self.lblSkoopName.text = [note.userInfo valueForKey:@"searchText"];
            
            if([note.userInfo valueForKey:@"group_name"] && [[note.userInfo valueForKey:@"group_name"] length]>0)
                self.lblLocation.text = [NSString stringWithFormat:@"Group: %@",[note.userInfo valueForKey:@"group_name"]];
            else
                self.lblLocation.text = [note.userInfo valueForKey:@"location"];
            
            if([note.userInfo valueForKey:@"skoop_date"])
                self.lblDate.text = [note.userInfo valueForKey:@"skoop_date"];
            
            if([note.userInfo valueForKey:@"price"] && [[note.userInfo valueForKey:@"price"] floatValue]>0){
                
                self._lblCost.text = [NSString stringWithFormat:@"$%@",[note.userInfo valueForKey:@"price"]];
                [self.getInfoRequest setValue:[note.userInfo valueForKey:@"price"] forKey:@"price"];
            }
            else
                self._lblCost.text = @"Favor";
            
            arrayOfReply = [NSMutableArray arrayWithArray:[note.userInfo valueForKey:@"data"]];
            [outletTableView reloadData];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1){
            [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
    }
}

#pragma mark Tap gesture method
-(void)tapOnSenderSkoopProfileImage:(UITapGestureRecognizer*)tapGesture
{
    NSDictionary *dataDict=[NSDictionary dictionaryWithObjectsAndKeys:[self.getInfoRequest valueForKey:@"name"],@"name",[self.getInfoRequest objectForKey:@"image"],@"userImage", nil];
    isShowSelfProfile=YES;
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

-(void)tapOnReplierSkoopProfileImage:(UITapGestureRecognizer*)tapGesture{
    
    UITableViewCell *tableVewCell=nil;
    if(IS_IOS_7)
        tableVewCell=(UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[tapGesture.view superview] superview];
    
    NSIndexPath *indexPath=[self.outletTableView indexPathForCell:tableVewCell];
    NSDictionary *dataDict=[self.arrayOfReply objectAtIndex:indexPath.row];
    isShowSelfProfile=NO;
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag==102){
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if(alertView.tag==105){
        
        if(buttonIndex == 0){
            
            [self performSegueWithIdentifier:@"credit_card" sender:nil];
        }
    }
}

#pragma mark Touch detect

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    if (touch.view.tag==44){
        [_viewCalling removeFromSuperview];
    }
}

#pragma mark Tableview deligates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [arrayOfReply count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 94.0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CellIdentifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil){
        cell =(UITableViewCell *)[cell.contentView viewWithTag:200];
        cell.layer.borderColor=[UIColor grayColor].CGColor;
    }
    
    UIImageView *imgVewThumbnail=(UIImageView*)[cell.contentView viewWithTag:202];
    UIImageView *imgVewReplier=(UIImageView*)[cell.contentView viewWithTag:208];
    UIImageView *imgPlay=(UIImageView*)[cell.contentView viewWithTag:203];
    UIImageView *imgVewLock=(UIImageView*)[cell.contentView viewWithTag:204];
    
    CBAutoScrollLabel *lblSkoopname_=(CBAutoScrollLabel*)[cell.contentView viewWithTag:2205];
    [lblSkoopname_ setLabelSettingForObject:@"skoop"];
    
    UILabel *lblSkoopAddress=(UILabel*)[cell.contentView viewWithTag:206];
    UILabel *lblSkoopDate=(UILabel*)[cell.contentView viewWithTag:207];
    UILabel *lblPercentage=(UILabel*)[cell.contentView viewWithTag:210];
    CBAutoScrollLabel *lblReplierName=(CBAutoScrollLabel*)[cell.contentView viewWithTag:212];
    [lblReplierName setLabelSettingForObject:@"name"];
    
    NSDictionary *getData=[arrayOfReply objectAtIndex:indexPath.row];
    
    [AppHelper getRoundedImageWithImageView:imgVewReplier];
    
    if([self.getInfoRequest valueForKey:@"live_portal"] && [[self.getInfoRequest valueForKey:@"live_portal"] integerValue]==1)
    {
        CGRect frameRect=lblSkoopname_.frame;
        frameRect.origin.x=73;
        frameRect.size.width=167;
        lblSkoopname_.frame=frameRect;
        
        frameRect=lblSkoopAddress.frame;
        frameRect.origin.x=73;
        frameRect.size.width=167;
        lblSkoopAddress.frame=frameRect;
        
        frameRect=lblSkoopDate.frame;
        frameRect.origin.x=73;
        lblSkoopDate.frame=frameRect;
        
        imgPlay.hidden=YES;
        imgVewLock.hidden=YES;
        
        imgVewThumbnail.frame=CGRectMake(13, 23, 50, 50);
        imgVewThumbnail.image=[UIImage imageNamed:@"Call.png"];
        
        lblSkoopname_.text=self.lblSkoopName.text;
    }
    else{
        if([[getData valueForKey:@"price"] floatValue] > 0 && [[getData valueForKey:@"paymentStatus"] integerValue] == 0)
            imgVewLock.hidden=NO;
        else
            imgVewLock.hidden=YES;
        
        [imgVewThumbnail setImageWithURL:[NSURL URLWithString:[getData objectForKey:@"thumbnail"]] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
        lblSkoopname_.text=[NSString stringWithFormat:@"%@(%@ Sec)",self.lblSkoopName.text,[getData valueForKey:@"duration"]];
        
    }
    
    if([[getData objectForKey:@"userImage"] length]>0)
        [imgVewReplier setImageWithURL:[NSURL URLWithString:[getData objectForKey:@"userImage"]] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    else
        imgVewReplier.image=[UIImage imageNamed:@"defaultuser.png"];
    
    UITapGestureRecognizer *uiTap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnReplierSkoopProfileImage:)];
    uiTap1.numberOfTapsRequired=1;
    imgVewReplier.userInteractionEnabled=YES;
    [imgVewReplier addGestureRecognizer:uiTap1];

    lblSkoopAddress.text=self.lblLocation.text;
    lblSkoopDate.text=[getData valueForKey:@"date"];
    
    lblPercentage.text=[NSString stringWithFormat:@"%i",[[getData valueForKey:@"like"] intValue]];
    lblReplierName.text=[getData valueForKey:@"userName"];
    lblReplierName.textColor=KTextColor;
    
    UIImageView *imvLine = (UIImageView *)[cell.contentView viewWithTag:905];
    imvLine.hidden = YES;
    if ([[self.getInfoRequest objectForKey:@"skoop_id"] isEqualToString:@"1"]) {
        imvLine.hidden = NO;
        lblSkoopname_.text = [NSString stringWithFormat:@"%@", [getData valueForKey:@"userName"]];
    }else{

    }
    
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    selectedData=[arrayOfReply objectAtIndex:indexPath.row];
    if([[self.getInfoRequest valueForKey:@"live_portal"] integerValue] ==1 ){
        
//        if([[selectedData valueForKey:@"payment_status"] integerValue] == 0){
        if([[self.getInfoRequest valueForKey:@"price"] floatValue] != 0.00 ){
        
            _lblLPChargeMessage.text = [NSString stringWithFormat:@"After 30 seconds, you will be charged $%@.\n1. You can avoid being charged if you end the call before 30 seconds have passed.\n2. If the Live Portal call should disconnect for any technical reason after you have been charged, you can call the user back with no additional charge for the next 2 hours.\n\nDo you want to continue?",[self.getInfoRequest valueForKey:@"price"]];
            [[AppDelegate getAppDelegate].window addSubview:_viewCalling];
        }
        else {
        
            [[WebServicesController WebServiceMethod] livePortalCallFromUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:[self.getInfoRequest valueForKey:@"skoop_id"] toOpponentId:[selectedData objectForKey:@"user_id"] andAppToken:KAppToken];
        
            CallViewController *callViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"CallViewController"];
            callViewController.conferenceId = [NSString stringWithFormat:@"skoopid%@", [self.getInfoRequest valueForKey:@"skoop_id"]];
            callViewController.opponentUsername = [selectedData objectForKey:@"userName"];
            callViewController.opponentUserImgUrl = [selectedData objectForKey:@"userImage"];
            [self presentViewController:callViewController animated:YES completion:nil];
            
        }
//        }
//        else{
//            
//            HomeView *homeViewController = [[self.navigationController viewControllers] objectAtIndex:0];
//            homeViewController.deligate = self;
//            NSDictionary *paramDict=[NSDictionary dictionaryWithObjectsAndKeys:[AppHelper userDefaultsForKey:KUserName],@"name",[AppHelper userDefaultsForKey:KUserImageUrl],@"image",[selectedData valueForKey:KUserId],@"seller_id",[selectedData valueForKey:@"portal_id"],@"portal_id",[selectedData valueForKey:@"userName"],@"userName",[selectedData valueForKey:@"userImage"],@"userImage",[selectedData valueForKey:@"payment_status"],@"payment_status",nil];
//            [homeViewController setupVideoCallWithQuickbloxId:[selectedData valueForKey:@"quick_blox_id"] andCustomParaMeteres:paramDict];
//        }
    }
    else{
        
        UIStoryboard *story = [UIStoryboard storyboardWithName:@"youSkoopLayouts" bundle:nil];
        VideoPlayerVC *videoPlayerVC = [story instantiateViewControllerWithIdentifier:@"VideoPlayerVC"];
        videoPlayerVC.videoURL = [selectedData valueForKey:@"video"];
        videoPlayerVC.isShowingOwnVideo = NO;
        videoPlayerVC.deligate = self ;
        videoPlayerVC.selecteDataDict = [NSMutableDictionary dictionaryWithDictionary:selectedData];
        [[AppDelegate getAppDelegate] hideTabBar:self.tabBarController];
        [self.navigationController pushViewController:videoPlayerVC animated:NO];
    }
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if([segue.identifier isEqualToString:@"userprofile"]){
        
        NSDictionary *dataDict=(NSDictionary*)sender;
        NSLog(@"%@",dataDict);
        UserProfileVC *userProfileObj=segue.destinationViewController;
        userProfileObj.groupId=@"";
        userProfileObj.groupOwnerId=@"";
        
        if(isShowSelfProfile){
            
            userProfileObj.name=[dataDict valueForKey:@"name"];
            userProfileObj.imgUrl=[dataDict valueForKey:@"image"];
            userProfileObj.blockUserId=[AppHelper userDefaultsForKey:KUserId];
        }
        else{
            
            userProfileObj.name=[dataDict valueForKey:@"userName"];
            userProfileObj.imgUrl=[dataDict valueForKey:@"userImage"];
            userProfileObj.blockUserId=[dataDict valueForKey:@"user_id"];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
