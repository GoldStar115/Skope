//
//  RequestViewViewController.m
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "RequestViewViewController.h"
#import "MapKit/MapKit.h"
#import "SBJson.h"
#import "CLController.h"
#import "AnnotationClass.h"
#import "WebServicesController.h"
#import "HomeView.h"
#import "InboxView.h"
#import "NSDate+convenience.h"

///////
#import "TRTextFieldExtensions.h"
#import "TRGoogleMapsAutocompletionCellFactory.h"
#import "AppHelper.h"
#import "SliderSwitch.h"


@interface RequestViewViewController ()<SliderSwitchDelegate>
{
    NSMutableDictionary *dictForRequest;
    double locationLatitude;
    double locationLongitude;
    id countofusers;
    BOOL isLongPress;
    NSInteger selectedSwitchIndex;
    
    __weak IBOutlet UILabel *_lblCallCharge;
    __weak IBOutlet UILabel *_lblSkoopPrice2;
    __weak IBOutlet UILabel *_lblSkoopPrice1;
    __weak IBOutlet UILabel *_lblPrice;
    __weak IBOutlet UILabel *_lblAvailableUsers;
    __weak IBOutlet UIView *_viewOffer;
    __weak IBOutlet UIView *_viewPrice;
    __weak IBOutlet UILabel *_lblYourOffer;
    __weak IBOutlet UIButton *_btnInfo;
}

@property (weak, nonatomic) IBOutlet UIView *_searchView;
@property (weak, nonatomic) IBOutlet UITextField *_searchText;
@property (weak, nonatomic) IBOutlet UIView *_viewForMap;
@property (weak, nonatomic) IBOutlet MKMapView *_mapView;
@property (weak, nonatomic) IBOutlet UITextField *_showMeTxt;
@property (weak, nonatomic) IBOutlet UITextField *_locationTxt;
@property (weak, nonatomic) IBOutlet UIDatePicker *_futureDate;
@property (weak, nonatomic) IBOutlet UIView *_viewForDatePicker;
@property (weak, nonatomic) IBOutlet UILabel *futureLb;

- (IBAction)_sendRequestBtnClick:(id)sender;
- (IBAction)backBtnClick:(id)sender;
- (IBAction)closeMapBtnClick:(id)sender;
- (IBAction)_howmanyuserBTnClick:(id)sender;
- (IBAction)useThisLocationClick:(id)sender;
- (IBAction)checkBocBtnClick:(id)sender;
- (IBAction)cancelDatePickerclick:(id)sender;
- (IBAction)doneDatePickerClick:(id)sender;

@end

@implementation RequestViewViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    //Set navigation image according to ios version
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    dictForRequest=[NSMutableDictionary dictionary];
    //isAddAnnotation=NO;
    CGRect frameRect=self._viewForDatePicker.frame;
    frameRect.origin.y=568;
    
    UILabel *lblYourOffer=(UILabel*)[self.view viewWithTag:1];
    lblYourOffer.textColor=[UIColor colorWithRed:12.0/255.0 green:34.0/255.0 blue:96.0/255.0 alpha:1.0];
    _lblPrice.textColor=[UIColor colorWithRed:12.0/255.0 green:34.0/255.0 blue:96.0/255.0 alpha:1.0];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(goesToRootView) name:Notification_Send_to_tab_root object:nil];
    
    self._viewForDatePicker.hidden=YES;
    myAnotation = [[MKPointAnnotation alloc] init];
    [myAnotation setTitle:@" "];
    
    self._viewForMap.hidden = YES;
    UIButton *radiobutton1 = (UIButton*)[self.view viewWithTag:101];
    radiobutton1.selected = YES;
    
    //Manage skoop button selected
    _viewPrice.hidden=YES;
    _lblAvailableUsers.text=@"";
    _btnInfo.hidden = YES;
    
    if([AppHelper userDefaultsForKey:KSaveReqData])
    {
        NSMutableDictionary *dataDict=[AppHelper userDefaultsDictionaryDataForKey:KSaveReqData];
        if([dataDict valueForKey:@"searchText"])
            self._showMeTxt.text=[dataDict valueForKey:@"searchText"];
        
        if([dataDict valueForKey:@"location"])
        {
            self._locationTxt.text=[dataDict valueForKey:@"location"];
            if([[dataDict valueForKey:@"location"] length]>5)
                [self performSelector:@selector(methodToGetLocationFromAddress:) withObject:[dataDict valueForKey:@"location"] afterDelay:0.2];
        }
        
        if([dataDict valueForKey:@"skoopDate"])
            self.futureLb.text=[dataDict valueForKey:@"skoopDate"];
        if([dataDict valueForKey:@"lat"])
            locationLatitude=[[dataDict valueForKey:@"lat"] doubleValue];
        if([dataDict valueForKey:@"long"])
            locationLongitude=[[dataDict valueForKey:@"long"] doubleValue];
        
        if([dataDict valueForKey:@"offer"]){
            UIButton *radiobutton1 = (UIButton*)[self.view viewWithTag:101];//0.0
            UIButton *radiobutton2 = (UIButton*)[self.view viewWithTag:102];//0.99
            UIButton *radiobutton3 = (UIButton*)[self.view viewWithTag:103];//9.99
            
            if([[dataDict valueForKey:@"offer"] isEqualToString:@"0"]){
                [radiobutton1 setSelected:YES];
                [radiobutton2 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            else if([[dataDict valueForKey:@"offer"] isEqualToString:@"0.99"]){
                [radiobutton1 setSelected:NO];
                [radiobutton2 setSelected:YES];
                [radiobutton3 setSelected:NO];
            }
            else if([[dataDict valueForKey:@"offer"] isEqualToString:@"9.99"]){
                [radiobutton1 setSelected:NO];
                [radiobutton2 setSelected:NO];
                [radiobutton3 setSelected:YES];
            }
        }
    }
    
    UIPanGestureRecognizer* panRec = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(didDragMap:)];
    [panRec setDelegate:self];
    [self._mapView addGestureRecognizer:panRec];
    
    UILongPressGestureRecognizer *lpgr = [[UILongPressGestureRecognizer alloc]
                                          initWithTarget:self action:@selector(handleLongPressOnMap:)];
    lpgr.minimumPressDuration = 0.8; //user needs to press for 0.8 seconds
    [self._mapView addGestureRecognizer:lpgr];
    
    [self performSelector:@selector(initializeAutocompleteApi) withObject:nil afterDelay:0.2];
    
    //Add custom switch view
    SliderSwitch *slideSwitchH=[[SliderSwitch alloc] init];
    [slideSwitchH setFrameHorizontal:(CGRectMake(57, 4, 200, 30)) numberOfFields:2 withCornerRadius:1.0];
    //200/2=100
    //width of each option is 100 (It should not be a fractional value)
    slideSwitchH.delegate=self;
    [slideSwitchH setFrameBackgroundColor:[UIColor clearColor]];
    [slideSwitchH setSwitchFrameColor:[UIColor clearColor]];
    UIView *sliderView=(UIView*)[self.view viewWithTag:567];
    [sliderView addSubview:slideSwitchH];
    selectedSwitchIndex=0;
}

-(void)viewWillAppear:(BOOL)animated{
    
    //Set skoop and love portal call price
    NSDictionary *priceDict = [AppHelper userDefaultsDictionaryDataForKey:KPriceData];
    _lblCallCharge.text = [NSString stringWithFormat:@"$%@/2 hours",[priceDict valueForKey:@"live_charge"]];
    _lblSkoopPrice1.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"skoop_charge1"]];
    _lblSkoopPrice2.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"skoop_charge2"]];
    
    //Hide tabbar
    [[AppDelegate getAppDelegate] hideTabBar:self.tabBarController];
}

-(void)viewWillDisappear:(BOOL)animated{
    //Show tabbar
    [[AppDelegate getAppDelegate] showTabBar:self.tabBarController];
}

#pragma mark - Slider Switch Delegate Methods

-(void)switchChangedSliderSwitch:(SliderSwitch *)sliderSwitch{
    NSDictionary *priceDict = [AppHelper userDefaultsDictionaryDataForKey:KPriceData];
    if (sliderSwitch.selectedIndex==0){//Select skoop switch
        if(selectedSwitchIndex==1){
            selectedSwitchIndex=0;
            
            _lblSkoopPrice1.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"skoop_charge1"]];
            _lblSkoopPrice2.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"skoop_charge2"]];
            _lblYourOffer.text = @"Your skoop offer";
            _btnInfo.hidden = YES;
            
//            UIButton *btnCalendar=(UIButton*)[self.view viewWithTag:179];
//            btnCalendar.userInteractionEnabled=YES;
        }
    }
    else if (sliderSwitch.selectedIndex==1){//Select live portal switch
        if(selectedSwitchIndex==0){
            
            selectedSwitchIndex=1;
            _lblSkoopPrice1.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"live_charge1"]];
            _lblSkoopPrice2.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"live_charge2"]];
            _lblYourOffer.text = @"Your live portal offer";
            _btnInfo.hidden = NO;
            
//            UIButton *btnCalendar=(UIButton*)[self.view viewWithTag:179];
//            btnCalendar.userInteractionEnabled=NO;
        }
    }
}

//Method for handle long press on map
- (void)handleLongPressOnMap:(UIGestureRecognizer *)gestureRecognizer{
    if (gestureRecognizer.state != UIGestureRecognizerStateBegan)
        return;
    
    CGPoint touchPoint = [gestureRecognizer locationInView:self._mapView];
    CLLocationCoordinate2D touchMapCoordinate =[self._mapView convertPoint:touchPoint toCoordinateFromView:self._mapView];
    
    locationLatitude=touchMapCoordinate.latitude;
    locationLongitude=touchMapCoordinate.longitude;
    isLongPress=YES;
    [self startGeocoderWithLocationWithGoogle:NO];
}

//Initialize autocomplete api for location searching
-(void)initializeAutocompleteApi{
    
    [AppHelper removeFromUserDefaultsWithKey:kIsSearchCity];
    [self._searchView bringSubviewToFront:self._searchText];
    [self setMapZoomLabelWithCllocation:[CLController sharedInstance].userCurrentLocation.coordinate withRegionAnimated:NO];
    
    if(!_itemSource){
        
        NSLog(@"Initialize====TRGoogleMapsAutocompleteItemsSource");
        _itemSource = [[TRGoogleMapsAutocompleteItemsSource alloc] initWithMinimumCharactersToTrigger:1 apiKey:Google_API_Key withLati:[CLController sharedInstance].userCurrentLocation.coordinate.latitude withLongi:[CLController sharedInstance].userCurrentLocation.coordinate.longitude];
    }
}

- (void)didDragMap:(UIGestureRecognizer*)gestureRecognizer {
    
    if (gestureRecognizer.state == UIGestureRecognizerStateEnded){
        NSLog(@"drag ended");
    }
}

-(void)goesToRootView{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Send_to_tab_root object:nil];
    [self.navigationController popToRootViewControllerAnimated:NO];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(goesToRootView) name:Notification_Send_to_tab_root object:nil];
}

#pragma mark Button action methods

//Send Skoop request
- (IBAction)_sendRequestBtnClick:(id)sender{
    
    if([self._showMeTxt isFirstResponder])
        [self._showMeTxt resignFirstResponder];
    else if([self._searchText isFirstResponder])
        [self._searchText resignFirstResponder];
    
    if([self checkMandatoryField]){
        
        if([AppHelper userDefaultsForKey:KUserId])
            [dictForRequest setValue:[AppHelper userDefaultsForKey:KUserId] forKey:KUserId];
        
        UIButton *radiobutton1 = (UIButton*)[self.view viewWithTag:101];//0.0
        UIButton *radiobutton2 = (UIButton*)[self.view viewWithTag:102];//0.99
        UIButton *radiobutton3 = (UIButton*)[self.view viewWithTag:103];//9.99
        
        NSDictionary *priceDict = [AppHelper userDefaultsDictionaryDataForKey:KPriceData];
        
        NSString *offer = nil;
        if(radiobutton1.isSelected)
            offer = @"0";
        else if(radiobutton2.isSelected && selectedSwitchIndex == 0)
            offer = [NSString stringWithFormat:@"%.2f",[[priceDict valueForKey:@"skoop_charge1"] floatValue]];
        else if(radiobutton2.isSelected && selectedSwitchIndex == 1)
            offer = [NSString stringWithFormat:@"%.2f",[[priceDict valueForKey:@"live_charge1"] floatValue]];
        else if(radiobutton3.isSelected && selectedSwitchIndex == 0)
            offer = [NSString stringWithFormat:@"%.2f",[[priceDict valueForKey:@"skoop_charge2"] floatValue]];
        else if(radiobutton3.isSelected && selectedSwitchIndex == 1)
            offer = [NSString stringWithFormat:@"%.2f",[[priceDict valueForKey:@"live_charge2"] floatValue]];
        
        [dictForRequest setValue:offer forKey:@"offer"];
        
        NSString *skoopdate = nil;
        NSTimeInterval timeDiff = 0;
        if([self.futureLb.text isEqualToString:@"Future Skoop?"]){
            skoopdate = [AppHelper getGmtDateWithGivenDate:[NSDate date]];
        }
        else{
            skoopdate = [AppHelper getGmtDateWithGivenDate:[self._futureDate date]];
            timeDiff = [[self._futureDate date] timeIntervalSinceNow];
        }
                
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSendSkoopReqquest:) name:Notification_for_Request object:nil];
        if(timeDiff >= 60){//Future skoop
            
            [[WebServicesController WebServiceMethod] sendSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] groupId:@"0" skoopDate:skoopdate offer:offer searchText:self._showMeTxt.text token:KAppToken livePortal:[NSString stringWithFormat:@"%i",(int)selectedSwitchIndex] location:self._locationTxt.text latitude:[NSString stringWithFormat:@"%f",locationLatitude] longitude:[NSString stringWithFormat:@"%f",locationLongitude] andSkoopType:@"1"];
        }
        else{//current skoop
            
            [[WebServicesController WebServiceMethod] sendSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] groupId:@"0" skoopDate:skoopdate offer:offer searchText:self._showMeTxt.text token:KAppToken livePortal:[NSString stringWithFormat:@"%i",(int)selectedSwitchIndex] location:self._locationTxt.text latitude:[NSString stringWithFormat:@"%f",locationLatitude] longitude:[NSString stringWithFormat:@"%f",locationLongitude] andSkoopType:@"0"];
        }
        
    }
}

//Back button action
- (IBAction)backBtnClick:(id)sender {
    //Save all filled data in user defaults
    [dictForRequest setValue:self._showMeTxt.text forKey:@"searchText"];
    [dictForRequest setValue:self._locationTxt.text forKey:@"location"];
    
    UIButton *radiobutton1 = (UIButton*)[self.view viewWithTag:101];//0.0
    UIButton *radiobutton2 = (UIButton*)[self.view viewWithTag:102];//0.99
    UIButton *radiobutton3 = (UIButton*)[self.view viewWithTag:103];//9.99
    
    if(radiobutton1.isSelected)
        [dictForRequest setValue:@"0" forKey:@"offer"];
    else if(radiobutton2.isSelected)
        [dictForRequest setValue:@"0.99" forKey:@"offer"];
    else if(radiobutton3.isSelected)
        [dictForRequest setValue:@"9.99" forKey:@"offer"];
    
    if(![self.futureLb.text isEqualToString:@"Future Skoop?"])
        [dictForRequest setValue:self.futureLb.text forKey:@"skoopDate"];
    
    if(locationLatitude)
        [dictForRequest setValue:[NSString stringWithFormat:@"%f",locationLatitude] forKey:@"lat"];
    if(locationLongitude)
        [dictForRequest setValue:[NSString stringWithFormat:@"%f",locationLongitude] forKey:@"long"];
    
    [AppHelper saveToUserDefaults:dictForRequest withKey:KSaveReqData];
    
    [self.navigationController popViewControllerAnimated:YES];
}

//Hide map
- (IBAction)closeMapBtnClick:(id)sender {
    self._viewForMap.hidden = YES;
    if([self._locationTxt isFirstResponder])
        [self._locationTxt resignFirstResponder];
    else if([self._searchText isFirstResponder])
        [self._searchText resignFirstResponder];
}

//Show how many users are in this area.
- (IBAction)_howmanyuserBTnClick:(id)sender
{
    NSMutableDictionary *dictoflocation=[[ NSMutableDictionary alloc] init];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sendCountUsers:) name:Notification_for_Count_Users object:nil];
    [dictoflocation setValue:[AppHelper userDefaultsForKey:KUserId] forKey:KUserId];
    [dictoflocation setValue:[NSString stringWithFormat:@"%f", locationLongitude] forKey:@"longitude"];
    [dictoflocation setValue:[NSString stringWithFormat:@"%f", locationLatitude] forKey:@"latitude"];
    [dictoflocation setValue:KAppToken forKey:@"token"];
    [[WebServicesController WebServiceMethod] countUsers:dictoflocation];
}

//Select location for sending skoop request
- (IBAction)useThisLocationClick:(id)sender
{
    if([self._searchText.text length]>0)
    {
        self._viewForMap.hidden = YES;
        self._locationTxt.text = self._searchText.text;
        
        NSMutableDictionary *dictoflocation=[[ NSMutableDictionary alloc] init];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sendCountUsers:) name:Notification_for_Count_Users object:nil];
        [dictoflocation setValue:[AppHelper userDefaultsForKey:KUserId] forKey:KUserId];
        [dictoflocation setValue:[NSString stringWithFormat:@"%f", locationLongitude] forKey:@"longitude"];
        [dictoflocation setValue:[NSString stringWithFormat:@"%f", locationLatitude] forKey:@"latitude"];
        [dictoflocation setValue:KAppToken forKey:@"token"];
        [[WebServicesController WebServiceMethod] countUsers:dictoflocation];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"There is no address selected. Please enter an address." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

//Select skoop type
-(void)checkBocBtnClick:(id)sender{
    
    UIButton *radiobutton1 = (UIButton*)[self.view viewWithTag:101];//0.0
    UIButton *radiobutton2 = (UIButton*)[self.view viewWithTag:102];//0.99
    UIButton *radiobutton3 = (UIButton*)[self.view viewWithTag:103];//9.99
    UIButton *selectedButton = (UIButton *)sender;
    
    NSLog(@":::%i",[radiobutton1 isSelected]);
    
    switch ([selectedButton tag]) {
        case 101:
            if([radiobutton1 isSelected]){
                [radiobutton1 setSelected:NO];
                [radiobutton2 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            else{
                [radiobutton1 setSelected:YES];
                [radiobutton2 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            break;
        case 102:
            if([radiobutton2 isSelected]==YES){
                [radiobutton1 setSelected:NO];
                [radiobutton2 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            else{
                [radiobutton2 setSelected:YES];
                [radiobutton1 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            break;
        case 103:
            if([radiobutton3 isSelected]==YES){
                [radiobutton1 setSelected:NO];
                [radiobutton2 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            else{
                [radiobutton3 setSelected:YES];
                [radiobutton2 setSelected:NO];
                [radiobutton1 setSelected:NO];
            }
            break;
        default:
            break;
    }
    
    if(!([radiobutton1 isSelected] == YES || [radiobutton2 isSelected] == YES || [radiobutton3 isSelected] == YES))
        [radiobutton1 setSelected:YES];
}

//Now button action method
- (IBAction)cancelDatePickerclick:(id)sender
{
    [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect = self._viewForDatePicker.frame;
                         frameRect.origin.y = self.view.bounds.size.height;
                         self._viewForDatePicker.frame = frameRect;
                     }
                     completion:nil];
    
    self.futureLb.text = @"Future Skoop?";
}

//Select skoop date
- (IBAction)doneDatePickerClick:(id)sender {
    
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init] ;
    [dateFormatter setDateFormat:@"MM-dd-yyyy hh:mm a"];
    self.futureLb.text = [dateFormatter stringFromDate:[self._futureDate date]];
    
    [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect = self._viewForDatePicker.frame;
                         frameRect.origin.y = self.view.bounds.size.height;
                         self._viewForDatePicker.frame = frameRect;
                     }
                     completion:nil];
}

//Show date picker for choosing skoop date
- (IBAction)btnCalender:(id)sender
{
    self._futureDate.minimumDate = [NSDate date];
    [self._showMeTxt resignFirstResponder];
    [self._searchText resignFirstResponder];

    self._viewForDatePicker.hidden=NO;
    
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect=self.view.bounds;
                         frameRect.origin.y=0;
                         self._viewForDatePicker.frame=frameRect;
                     }
                     completion:nil];

    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *currentDate = [NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setYear:30];
    NSDate *maxDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
    self._futureDate.maximumDate = maxDate;

    NSDateFormatter  *fomrtr = [[NSDateFormatter alloc] init];
    [fomrtr setDateFormat:@"dd/MM/yyyy hh:mm a"];
    self._futureDate.date=[NSDate date];
}

//Method for adding map on view
- (IBAction)btnMap:(id)sender
{
    self._viewForMap.hidden = NO;
   // isAddAnnotation=NO;
    if(IS_Greater_Or_Equal_to_IOS_7)
        self._mapView.rotateEnabled = NO;
    
    if([self._showMeTxt isFirstResponder])
        [self._showMeTxt resignFirstResponder];
    else if([self._searchText isFirstResponder])
        [self._searchText resignFirstResponder];
    else if([self._locationTxt isFirstResponder])
        [self._locationTxt resignFirstResponder];
    
    if([[self._locationTxt.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]>0){
        self._searchText.text=self._locationTxt.text;
       // isAddAnnotation=YES;
        [self methodToGetLocationFromAddress:self._searchText.text];
    }
    else{
        self._searchText.text=@"";
        [self setMapZoomLabelWithCllocation:[CLController sharedInstance].userCurrentLocation.coordinate withRegionAnimated:NO];
    }
}

-(IBAction)onClickInfoButton:(id)sender{
    [AppHelper showAlertViewWithTag:1 title:AppName message:@"1. You won’t be charged until 30 seconds into the call in case the other user is not providing what you asked for.\n\n2. If the Live Portal call should disconnect for any technical reason after you have been charged, you can call the user back with no additional charge for the next 2 hours.\n\n3. Additional data charges from your service provider may apply." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

//Detect view touch
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"touch detect");
    
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    //Check date picker view and remove it
    if (touch.view.tag == 345) {
        [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionTransitionNone
                         animations:^{
                             CGRect frameRect = self._viewForDatePicker.frame;
                             frameRect.origin.y = self.view.bounds.size.height;
                             self._viewForDatePicker.frame = frameRect;
                         }
                         completion:nil];
    }
    
    if([self._searchText isFirstResponder])
        [self._searchText resignFirstResponder];
    else  if([self._showMeTxt isFirstResponder])
        [self._showMeTxt resignFirstResponder];
    else  if([self._locationTxt isFirstResponder])
        [self._locationTxt resignFirstResponder];

}

#pragma mark Textfield deligate methods
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    BOOL isTrue=NO;
    if(textField==self._searchText)
    {
        isTrue=YES;
        [AppHelper saveToUserDefaults:@"1" withKey:kIsSearchFromMap];
    }
    else if(textField==self._locationTxt)
    {
        [AppHelper removeFromUserDefaultsWithKey:kIsSearchFromMap];
        isTrue=YES;
    }
    
    if(isTrue)
    {
        isLongPress=YES;
        _autocompleteView = [TRAutocompleteView autocompleteViewBindedTo:textField
                                                             usingSource:_itemSource   cellFactory:[[TRGoogleMapsAutocompletionCellFactory alloc]
                                                                                                    initWithCellForegroundColor:[UIColor whiteColor]                                                                                                                                                                fontSize:12]
                                                            presentingIn:self];
        [textField setLeftPadding:0];
        _autocompleteView.topMargin = 0;
        _autocompleteView.backgroundColor = [UIColor clearColor];
        _autocompleteView.didAutocompleteWith = ^(id<TRSuggestionItem> item){
        };
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSLog(@"**********textFieldShouldReturn***************");
    if(textField==self._showMeTxt)
        [self._locationTxt becomeFirstResponder];
    else
        [textField resignFirstResponder];
    
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField
{
    if(textField==self._searchText && [self._searchText.text length]>0)
    {
        //isAddAnnotation=YES;
        [self methodToGetLocationFromAddress:self._searchText.text];
    }
    else if (textField==self._locationTxt && [self._locationTxt.text length]>0)
    {
      //  isAddAnnotation=NO;
        [self methodToGetLocationFromAddress:self._locationTxt.text];
        self._searchText.text=self._locationTxt.text;
    }
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(textField.text.length+string.length-range.length==0)
        [self removeAllAnnotationsExceptCurrentLocation];
    
    if (range.location == 0 && [string isEqualToString:@" "]) {
        return NO;
    }
    return YES;
}

 -(BOOL)textFieldShouldClear:(UITextField *)textField
{
    if(textField==self._locationTxt)
        _lblAvailableUsers.text=@"";
    
    [self removeAllAnnotationsExceptCurrentLocation];
    return YES;
}

#pragma mark Receive notifications
-(void)userDidSendSkoopReqquest:(NSNotification *)note{
    
    [AppDelegate dismissGlobalHUD];
    [self.navigationController popToRootViewControllerAnimated:NO];
    
    [[NSNotificationCenter defaultCenter]removeObserver:self name:Notification_for_Request object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Count object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"requests",@"req_type", nil]];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_Calendar object:@"refresh" userInfo:nil];
            [AppHelper removeFromUserDefaultsWithKey:KSaveReqData];
            self._viewForDatePicker.hidden=YES;
            [UIView animateWithDuration:0.4 delay:0 options:UIViewAnimationOptionTransitionNone animations:^{
                // animate it to the identity transform (100% scale)
                self.view.center=CGPointMake(160, -self.view.frame.size.height);
                
                NSMutableDictionary *dataDict = [NSMutableDictionary dictionary];
                [dataDict setValue:@"" forKey:@"group_name"];
                [dataDict setValue:[AppHelper userDefaultsForKey:KUserImageUrl] forKey:@"image"];
                [dataDict setValue:self._locationTxt.text forKey:@"location"];
                [dataDict setValue:self._showMeTxt.text forKey:@"searchText"];
                [dataDict setValue:[dictForRequest valueForKey:@"offer"] forKey:@"price"];
                [dataDict setValue:[note.userInfo objectForKey:@"skoop_id"] forKey:@"skoop_id"];
                [dataDict setValue:[note.userInfo objectForKey:@"date"] forKey:@"date"];
                [dataDict setValue:[AppHelper userDefaultsForKey:KUserName] forKey:@"name"];
                [dataDict setValue:[AppHelper userDefaultsForKey:KUserId] forKey:@"user_id"];
                [dataDict setValue:@"1" forKey:@"read_status"];
                [dataDict setValue:@"0" forKey:@"replyCount"];
                
                if(selectedSwitchIndex == 0){//Regular skoop request
                    
                    [dataDict setValue:@"0" forKey:@"live_portal"];
                }
                else{//Live portal request
                    
                    [dataDict setValue:@"1" forKey:@"live_portal"];
                }
                [AppHelper saveToUserDefaults:dataDict withKey:KIsSendToSkoopReply];
                
            } completion:^(BOOL finished){
                // if you want to do something once the animation finishes, put it here
                //[self.navigationController popToRootViewControllerAnimated:NO];
            }];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1){
            //[AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
        }
    }
}

-(void)sendCountUsers:(NSNotification *)note
{
    NSLog(@"Count of Users Notification======%@",note.userInfo);
    
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_for_Count_Users object:nil];
    if (note.userInfo)
    {
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0)
        {
            countofusers=[note.userInfo valueForKey:@"data"];
            if([self._viewForMap isHidden])
            {
                if([countofusers integerValue]==0)
                {
                    [AppHelper showAlertViewWithTag:1 title:AppName message:@"There are no users available in this area." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
                    _lblAvailableUsers.text=@"There are no users available in this area.";
                }
                else
                {
                    if([countofusers integerValue]==1)
                        _lblAvailableUsers.text=@"There is 1 user available in this area.";
                    else
                        _lblAvailableUsers.text=[NSString stringWithFormat:@"There are %i users available in this area.",[countofusers intValue]];
                }
            }
            else
            {
                [self removeAllAnnotationsExceptCurrentLocation];
                
                CLLocationCoordinate2D location;
                location.latitude = locationLatitude;
                location.longitude = locationLongitude;
                
                [myAnotation setCoordinate:location];
                [self._mapView addAnnotation:myAnotation];
                
                if(isLongPress)
                    isLongPress=NO;
                else
                    [self setMapZoomLabelWithCllocation:location withRegionAnimated:NO];
            }
        }
    }
}

//Check mandatory fields for sendin skoop request
-(BOOL)checkMandatoryField{
    
    if([self._showMeTxt.text isEqualToString:@""] && [self._locationTxt.text isEqualToString:@""]){
        [AppHelper showAlertViewWithTag:1 title:nil message:@"Oops :) Please tell us what you want to see and in what location." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        return FALSE;
    }
    else if([self._showMeTxt.text isEqualToString:@""]){
        [AppHelper showAlertViewWithTag:1 title:nil message:@"Please Enter show me." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        return FALSE;
    }
    else if([self._locationTxt.text isEqualToString:@""]){
        [AppHelper showAlertViewWithTag:1 title:nil message:@"Please choose location." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        return FALSE;
    }
    return TRUE;
}

//Find address fron latitude and longitude using google api
-(void) startGeocoderWithLocationWithGoogle:(BOOL)isRemoveAnnotation
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        NSString *urlString = [NSString stringWithFormat:@"http://maps.googleapis.com/maps/api/geocode/json?latlng=%f,%f&sensor=true",locationLatitude,locationLongitude];
        NSDictionary *googleResponse = (NSDictionary*)[[NSString stringWithContentsOfURL:[NSURL URLWithString:urlString] encoding:NSUTF8StringEncoding error:NULL] JSONValue];
        
        NSDictionary    *resultsDict = [googleResponse valueForKey:@"results"];
        // Add the transcript to the data source and reload
        dispatch_async(dispatch_get_main_queue(), ^{
            if(resultsDict)
            {
                //this will set the image when loading is finished
                if([[resultsDict valueForKey:@"formatted_address"] count]>0 )
                {
                    
                    if(isLongPress){
                        NSLog(@"map hidden");
                        self._searchText.text = [[resultsDict valueForKey:@"formatted_address"] objectAtIndex:0];
                        
                        NSMutableDictionary *dictoflocation=[[ NSMutableDictionary alloc] init];
                        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sendCountUsers:) name:Notification_for_Count_Users object:nil];
                        [dictoflocation setValue:[AppHelper userDefaultsForKey:KUserId] forKey:KUserId];
                        [dictoflocation setValue:[NSString stringWithFormat:@"%f", locationLongitude] forKey:@"longitude"];
                        [dictoflocation setValue:[NSString stringWithFormat:@"%f", locationLatitude] forKey:@"latitude"];
                        [dictoflocation setValue:KAppToken forKey:@"token"];
                        [[WebServicesController WebServiceMethod] countUsers:dictoflocation];
                    }
                    
                    //If drad the pin
                    if(isRemoveAnnotation)
                    {
                        [self removeAllAnnotationsExceptCurrentLocation];
                        CLLocationCoordinate2D location;
                        location.latitude = locationLatitude;
                        location.longitude = locationLongitude;
                        [myAnotation setCoordinate:location];
                        [self._mapView addAnnotation:myAnotation];
                    }
                    
                }
            }
        });
    });
}

#pragma mark Get location from address

-(void)methodToGetLocationFromAddress:(NSString*)address{
    CLGeocoder *geocoder = [[CLGeocoder alloc] init];
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [geocoder geocodeAddressString:address completionHandler:^(NSArray *placemarks, NSError *error) {
        //NSLog(@"location Array = %@", placemarks);
        if ([placemarks count] > 0) {
            
            CLPlacemark *placemark = [placemarks objectAtIndex:0];
            CLLocation *location = placemark.location;
            CLLocationCoordinate2D coordinate = location.coordinate;
            
            locationLatitude=coordinate.latitude;
            locationLongitude=coordinate.longitude;
            [myAnotation setCoordinate:coordinate];
            
            NSMutableDictionary *dictoflocation=[[ NSMutableDictionary alloc] init];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sendCountUsers:) name:Notification_for_Count_Users object:nil];
            [dictoflocation setValue:[AppHelper userDefaultsForKey:KUserId] forKey:KUserId];
            [dictoflocation setValue:[NSString stringWithFormat:@"%f", locationLongitude] forKey:@"longitude"];
            [dictoflocation setValue:[NSString stringWithFormat:@"%f", locationLatitude] forKey:@"latitude"];
            [dictoflocation setValue:KAppToken forKey:@"token"];
            [[WebServicesController WebServiceMethod] countUsers:dictoflocation];
            [self setMapZoomLabelWithCllocation:coordinate withRegionAnimated:NO];
        }
        else
            [AppHelper showAlertViewWithTag:1 title:AppName message:Address_does_not_exist delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        [AppDelegate dismissGlobalHUD];
    }];
}

-(void)setMapZoomLabelWithCllocation:(CLLocationCoordinate2D)location withRegionAnimated:(BOOL)animated{
    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(location,1609/1.5,1609/1.5);
//    MKCoordinateRegion region = MKCoordinateRegionMakeWithDistance(location,1609 * 5,1609 * 5);
    if ( (region.center.latitude >= -90) && (region.center.latitude <= 90) && (region.center.longitude >= -180) && (region.center.longitude <= 180)){
        [self._mapView setRegion:region animated:animated];
        [self._mapView regionThatFits:region];
    }
}

-(void)removeAllAnnotationsExceptCurrentLocation
{
    NSLog(@"remove all annotation");
    for (AnnotationClass *ann in [self._mapView annotations])
    {
        if(![ann isKindOfClass:[MKUserLocation class]])
            [self._mapView removeAnnotation:ann];
    }
}
#pragma mark Mapview deligate methods

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation
{
    NSString *defaultPinID;
    
    if([annotation  isKindOfClass:[MKUserLocation class]])
	{
        return nil;
    }
    else
    {
        defaultPinID = @"com.invasivecode.pin";
       
        MKAnnotationView *pinView=nil;
        pinView = (MKAnnotationView *)[mapView dequeueReusableAnnotationViewWithIdentifier:defaultPinID];
        if ( pinView == nil ){
            pinView = [[MKAnnotationView alloc] initWithAnnotation:annotation reuseIdentifier:defaultPinID];
        }
        pinView.image=[UIImage imageNamed:@"map_pin.png"];
        pinView.canShowCallout=YES;
        
        UIView *leftCallView=[[UIView alloc] initWithFrame:CGRectMake(0, 0, 155, 43)];
        leftCallView.backgroundColor=[UIColor clearColor];
        UILabel *lblCount=[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 155, 43)];
        lblCount.backgroundColor=[UIColor clearColor];
        lblCount.textColor=[UIColor blackColor];
        
        if([countofusers integerValue]==0)
            lblCount.text=[NSString stringWithFormat:@"      %@ members",countofusers];
        else if([countofusers integerValue]>1)
            lblCount.text=[NSString stringWithFormat:@"      %@ members",countofusers];
        else
            lblCount.text=[NSString stringWithFormat:@"      %@ member",countofusers];
        
        lblCount.textAlignment=NSTextAlignmentCenter;
        [leftCallView addSubview:lblCount];
        pinView.leftCalloutAccessoryView = leftCallView;
        pinView.rightCalloutAccessoryView=nil;
        
        [self performSelector:@selector(selectAnnotation:) withObject:annotation afterDelay:0.5];
        
        return pinView;
    }
}

- (void)selectAnnotation:(id < MKAnnotation >)annotation
{
    [self._mapView selectAnnotation:annotation animated:NO];
}

- (void)openCalloutOnAnnotation
{
    NSLog(@":::::%@",self._mapView.annotations);
    for(id<MKAnnotation> currentAnnotation in self._mapView.annotations)
    {
        if(((id <MKAnnotation>)currentAnnotation !=self._mapView.userLocation))
        {
            NSLog(@"*********************");
            /*Show callout*/
            [self._mapView selectAnnotation:currentAnnotation animated:YES];
        }
    }
}

/*This method hide callout on selected annotation*/
- (void)hideCalloutWithAnnotationTag:(NSInteger)selectedAnnotationTag{
    
    for(id<MKAnnotation> currentAnnotation in self._mapView.annotations){
        if(((id <MKAnnotation>)currentAnnotation !=__mapView.userLocation))
        {
            /*Hide callout*/
            [self._mapView deselectAnnotation:currentAnnotation animated:YES];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
