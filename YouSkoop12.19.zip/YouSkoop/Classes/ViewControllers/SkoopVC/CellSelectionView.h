//
//  CellSelectionView.h
//  youskoop
//
//  Created by user on 3/19/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol updateSkoopData<NSObject>

-(void)updateSkoopDataWithData;
@end

@interface CellSelectionView : UIViewController<UITableViewDelegate,UITableViewDataSource>
{
    NSMutableDictionary *get_reply_skoop;
}

@property BOOL isGetBuyVideos;
@property (strong, nonatomic) NSString *navTitle;
@property( strong,nonatomic) NSMutableDictionary *getInfoRequest;
@property( strong, nonatomic) NSMutableArray *arrayOfReply;

@property (weak, nonatomic) IBOutlet UILabel *_lblCost;
@property (weak, nonatomic) IBOutlet UITableView *outletTableView;
@property (strong, nonatomic) IBOutlet UIView *_headerView;
@property (weak, nonatomic) IBOutlet UILabel *lblDate;
@property (weak, nonatomic) IBOutlet CBAutoScrollLabel *lblSkoopName;
@property (weak, nonatomic) IBOutlet UILabel *lblTime;
@property (weak, nonatomic) IBOutlet UILabel *lblLocation;
@property (weak, nonatomic) IBOutlet UIImageView *imgviewRequest;
@property (weak, nonatomic) IBOutlet CBAutoScrollLabel *lblName;


- (IBAction)btnBack:(id)sender;
@end
