//
//  RequestViewViewController.h
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MapKit/MapKit.h"
#import "AnnotationClass.h"

#import "TRAutocompleteView.h"
#import "TRGoogleMapsAutocompleteItemsSource.h"

@interface RequestViewViewController : UIViewController <UITextFieldDelegate,MKMapViewDelegate,UIGestureRecognizerDelegate>
{
    MKPointAnnotation *myAnotation;
    
    TRGoogleMapsAutocompleteItemsSource *_itemSource;
    TRAutocompleteView *_autocompleteView;
}

- (IBAction)btnCalender:(id)sender;
- (IBAction)btnMap:(id)sender;
@end
