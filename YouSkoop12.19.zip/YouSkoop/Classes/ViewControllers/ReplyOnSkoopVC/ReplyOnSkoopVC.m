//
//  ReplyOnSkoopVC.m
//  youskoop
//
//  Created by Shitesh Patel on 08/04/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "ReplyOnSkoopVC.h"
#import "EGORefreshTableHeaderView.h"
#import "WebServicesController.h"
#import "VideoUploaderVC.h"
#import "RequestViewViewController.h"
#import "SkoopReplyData.h"
#import "UserProfileVC.h"
#import "VideoPlayerVC.h"

#define Current 1
#define Future   0
#define  PageLimit     @"50"

@interface ReplyOnSkoopVC ()<UITableViewDataSource,UITableViewDelegate,saveDataProtocol>

@end

@implementation ReplyOnSkoopVC
{
    //NSMutableArray *mainArrayForScoops;
    NSMutableArray *arrayForCurrentScoops;
    NSMutableArray *arrayForFutureScoops;
    NSArray *pendingSkoopArray;
    NSMutableDictionary *selectedDict;
    
    BOOL isCurrentScoopServiceHit;
    BOOL isFutureScoopServiceHit;
    BOOL isHitWebService;
    BOOL isShowReplierProfile;
    
    int requestType;
    int currentPageNo;
    int futurePageNo;
    int shownCurrentCell;
    int shownFutureCell;
    
    NSInteger selectedIndex;
    NSInteger prevSelectedIndex;
    NSDictionary *userInfoDict;
    NSString *selectedTime;
    NSString *selectedSkoopId;
    NSString *currentSkoopId;
    
    __weak IBOutlet UILabel *_lblSetAReminder;
    __weak IBOutlet UILabel *_lblDevider;
    __weak IBOutlet UILabel *_lblSkoopRequest;
    __weak IBOutlet UIView *_viewSelectTime;
    __weak IBOutlet UILabel *_lblMinutesBefore;
}
@synthesize requestArray;
@synthesize isShowFutureSkoop;
@synthesize skoopId;
@synthesize isUpdateUpcomingSkoop;
@synthesize isComesFromCalendarClass;
@synthesize deligate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        NSMutableArray *array=[[NSMutableArray alloc] init];
        self.requestArray=array;
    }
    return self;
}

- (void)viewDidLoad{
    
    [super viewDidLoad];
    
    //Set navigation image according to ios version
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    NSLog(@":::%@",self.skoopId);
    if(self.skoopId)
        currentSkoopId = self.skoopId;
    else
        currentSkoopId = @"0";
    
    //Add observers
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnSkoop:) name:Notification_reply_on_skoop object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(goesToRootView) name:Notification_Send_to_tab_root object:nil];
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidChangeProfileImage:) name:Notification_Refresh_UserImage object:nil];
     [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidRefreshSkoopList:) name:Notification_Refresh_SkoopList object:nil];
    
    isHitWebService=YES;
    arrayForCurrentScoops=[[NSMutableArray alloc]init];
    arrayForFutureScoops=[[NSMutableArray alloc]init];
    
    [self._btnCurrent setTitleColor:[UIColor colorWithRed:197.0/255.0 green:66.0/255.0 blue:230.0/255.0 alpha:1.0] forState:UIControlStateSelected];
    [self._btnCurrent setTitleColor:[UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:1.0] forState:UIControlStateNormal];
    self._btnCurrent.backgroundColor=[UIColor colorWithRed:100.0/255.0 green:39.0/255.0 blue:142.0/255.0 alpha:1.0];
    self._btnCurrent.tintColor=[UIColor clearColor];
    [self._btnCurrent setSelected:YES];
    
    [self._btnFuture setTitleColor:[UIColor colorWithRed:197.0/255.0 green:66.0/255.0 blue:230.0/255.0 alpha:1.0] forState:UIControlStateSelected];
    [self._btnFuture setTitleColor:[UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:1.0] forState:UIControlStateNormal];
    self._btnFuture.backgroundColor=[UIColor colorWithRed:88.0/255.0 green:23.0/255.0 blue:133.0/255.0 alpha:1.0];
    self._btnFuture.tintColor=[UIColor clearColor];
    [self._btnFuture setSelected:NO];
    
    _lblMinutesBefore.textColor=KTextColor;
    _lblSetAReminder.textColor=KTextColor;
    
    isCurrentScoopServiceHit=YES;
    isFutureScoopServiceHit=YES;
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    self.refreshControl.attributedTitle = [[NSAttributedString alloc] initWithString:@"Refreshing data..."];
    self.refreshControl.tintColor = [UIColor grayColor];
    [self.refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
    [self._uiTableView addSubview:self.refreshControl];
    requestType=Current;
    currentPageNo=1;
    futurePageNo=1;
    shownCurrentCell=0;
    shownFutureCell=0;
    
    pendingSkoopArray=[NSArray arrayWithArray:[[WebServicesController WebServiceMethod] getAllSkoopReplyData]];
}

-(void)goesToRootView
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Send_to_tab_root object:nil];
    [self.navigationController popToRootViewControllerAnimated:NO];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(goesToRootView) name:Notification_Send_to_tab_root object:nil];
}

-(void)viewWillAppear:(BOOL)animated
{
    //[AppHelper removeFromUserDefaultsWithKey:KIsSendToAnswerSkoopPage];
    [self performSelector:@selector(hitWebserviceForGettingSkoopList) withObject:nil afterDelay:0.3];
    NSArray *visibleCellsArray = [self._uiTableView indexPathsForVisibleRows];
    if(visibleCellsArray && visibleCellsArray.count)
        [self._uiTableView reloadRowsAtIndexPaths:visibleCellsArray withRowAnimation:UITableViewRowAnimationNone];
}

-(void)hitWebserviceForGettingSkoopList{
    
    if(isHitWebService){
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetSkoopRequestList:) name:Notification_for_mySkoop object:nil];
        if(self.isShowFutureSkoop){
            
            if(arrayForFutureScoops && arrayForFutureScoops.count>0)
                [arrayForFutureScoops removeAllObjects];
            
            requestType = Future;
            futurePageNo = 1;
            
            [self._btnCurrent setSelected:NO];
            [self._btnFuture setSelected:YES];
            self._btnFuture.backgroundColor = [UIColor colorWithRed:100.0/255.0 green:39.0/255.0 blue:142.0/255.0 alpha:1.0];
            self._btnCurrent.backgroundColor = [UIColor colorWithRed:88.0/255.0 green:23.0/255.0 blue:133.0/255.0 alpha:1.0];
            
            [[WebServicesController WebServiceMethod] getSkoopRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:@"" pageNo:[NSString stringWithFormat:@"%i",futurePageNo] pageLImit:PageLimit appToken:KAppToken andRequestType:@"future"];
        }
        else{
            if(arrayForCurrentScoops && arrayForCurrentScoops.count>0)
                [arrayForCurrentScoops removeAllObjects];
            
            requestType = Current;
            currentPageNo = 1;
            
            [self._btnCurrent setSelected:YES];
            [self._btnFuture setSelected:NO];
            self._btnCurrent.backgroundColor=[UIColor colorWithRed:100.0/255.0 green:39.0/255.0 blue:142.0/255.0 alpha:1.0];
            self._btnFuture.backgroundColor=[UIColor colorWithRed:88.0/255.0 green:23.0/255.0 blue:133.0/255.0 alpha:1.0];
            
            [[WebServicesController WebServiceMethod] getSkoopRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:@"" pageNo:[NSString stringWithFormat:@"%i",currentPageNo] pageLImit:PageLimit appToken:KAppToken andRequestType:@"current"];
        }
    }
}

#pragma mark Tap gesture method
-(void)tapOnSenderSkoopProfileImage:(UITapGestureRecognizer*)tapGesture{
    UITableViewCell *tableVewCell = nil;
    if(IS_IOS_7){
        tableVewCell = (UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    }
    else{
        tableVewCell = (UITableViewCell*)[[tapGesture.view superview] superview];
    }
    
    NSIndexPath *indexPath = [self._uiTableView indexPathForCell:tableVewCell];
    NSDictionary *dataDict = nil;
    if(requestType == Current)
        dataDict = [arrayForCurrentScoops objectAtIndex:indexPath.row];
    else
        dataDict = [arrayForFutureScoops objectAtIndex:indexPath.row];
    
    isShowReplierProfile=NO;
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

-(void)tapOnReplierSkoopProfileImage:(UITapGestureRecognizer*)tapGesture
{
    UITableViewCell *tableVewCell=nil;
    if(IS_IOS_7)
        tableVewCell=(UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[tapGesture.view superview] superview];
    
    NSIndexPath *indexPath=[self._uiTableView indexPathForCell:tableVewCell];
    
    NSDictionary *dataDict=nil;
    if(requestType==Current)
        dataDict=[arrayForCurrentScoops objectAtIndex:indexPath.row];
    else
        dataDict=[arrayForFutureScoops objectAtIndex:indexPath.row];
    
    isShowReplierProfile=YES;
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

#pragma mark Protocol methods
-(void)setRequiredBoolVariable:(BOOL)boolValue
{
    isHitWebService=YES;
}

-(void)updateSkoopReplyDataWithDataDict:(NSDictionary*)dataDict{
    
    prevSelectedIndex=selectedIndex;
    
    NSMutableDictionary *dict=nil;
    if(requestType==Current)
        dict=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:selectedIndex]];
    else
        dict=[NSMutableDictionary dictionaryWithDictionary:[arrayForFutureScoops objectAtIndex:selectedIndex]];
    
    [dict setValue:@"0" forKey:@"upload"];
    [dict setValue:dataDict forKey:@"reply"];
    
    if(requestType==Current)
        [arrayForCurrentScoops replaceObjectAtIndex:selectedIndex withObject:dict];
    else
        [arrayForFutureScoops replaceObjectAtIndex:selectedIndex withObject:dict];
    
    [self._uiTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
    
    [[WebServicesController WebServiceMethod] parseSkoopReplyDataWithDataDictionary:dataDict];
}

#pragma mark Receive notifications

-(void)userDidChangeProfileImage:(NSNotification*)noti{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Refresh_UserImage object:nil];
    [self._uiTableView reloadData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidChangeProfileImage:) name:Notification_Refresh_UserImage object:nil];
}

-(void)userDidGetSkoopRequestList:(NSNotification *)notification{
    
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_for_mySkoop object:nil];
    
    NSLog(@"%@",notification.userInfo);
    NSDictionary *dict=notification.userInfo;
    [self.refreshControl endRefreshing];
    if(dict){
        if([[dict objectForKey:@"errorCode"] integerValue]==0){
            
            if([dict valueForKey:@"total"]){ //Show total future and current skoops
                NSArray *countArray=[[dict valueForKey:@"total"] componentsSeparatedByString:@","];
                if(countArray.count>0)
                    self._lblCurrentCount.text=[countArray objectAtIndex:0];
                if(countArray.count>1)
                    self._lblFutureCount.text=[countArray objectAtIndex:1];
            }
            
            isHitWebService=NO;
            
            int skoopIndex=-1;
            if(requestType==Current){
                currentPageNo++;
                if([[dict objectForKey:@"data"] count]>0){
                    NSArray *skoopArray=[dict valueForKey:@"data"];
                    for (NSMutableDictionary *scoopDict in skoopArray) {
                        BOOL isAdded=NO;
                        if([[scoopDict valueForKey:@"skoop_id"] isEqualToString:self.skoopId])
                            skoopIndex= (int)[skoopArray indexOfObject:scoopDict];
                        
                        for (int i=0; i<pendingSkoopArray.count; i++) {//Check for current replied video
                            SkoopReplyData *skoop=[pendingSkoopArray objectAtIndex:i];
                            
                            if([[scoopDict valueForKey:@"skoop_id"] isEqualToString:skoop.skoopId]){
                                
                                NSDictionary *dataDict=[[NSDictionary alloc] initWithObjectsAndKeys:skoop.replyDate,@"date",skoop.videoLength,@"duration",skoop.userImageUrl,@"image",skoop.message,@"message",[AppHelper userDefaultsForKey:KUserName],@"name",skoop.paymentStatus,@"paymentStatus",skoop.thumbImage,@"thumbimage",[AppHelper userDefaultsForKey:KUserId],@"user_id",skoop.videoUrl,@"video_path",skoop.isUpload,@"upload", nil];
                                
                                NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:scoopDict];
                                [dict setValue:dataDict forKey:@"reply"];
                                [arrayForCurrentScoops addObject:dict];
                                isAdded=YES;
                            }
                        }
                        
                        //Check if already added
                        if(!isAdded)
                            [arrayForCurrentScoops addObject:scoopDict];
                    }
                    
                    [self._uiTableView reloadData];
                    isCurrentScoopServiceHit=YES;
                }
            }
            else if(requestType==Future){
                
                futurePageNo++;
                if([dict objectForKey:@"data"] && [[dict objectForKey:@"data"] count]>0){
                    
                    NSArray *skoopArray=[dict valueForKey:@"data"];
                    for (int i=0; i<[skoopArray count]; i++){
                        
                        NSDictionary *scoopDict=[skoopArray objectAtIndex:i];
                        if([[scoopDict valueForKey:@"skoop_id"] isEqualToString:self.skoopId])
                            skoopIndex=i;//Store index for auto scroll on current skoop
                        
                        [arrayForFutureScoops addObject:scoopDict];
                    }
                    [self._uiTableView reloadData];
                    isFutureScoopServiceHit=YES;
                }
                else{
                    if(futurePageNo<=2){
                        if(arrayForFutureScoops && arrayForFutureScoops.count>0)
                            [arrayForFutureScoops removeAllObjects];
                        [self._uiTableView reloadData];
                    }
                }
            }
            
            if(skoopIndex >= 0){
                self.skoopId=@"0";
                //Autoscroll on current skoop
                [self performSelector:@selector(scrollTableViewWithIndexPath:) withObject:[NSIndexPath indexPathForRow:skoopIndex inSection:0] afterDelay:0.2];
            }
        }
        else if([[dict objectForKey:@"errorCode"] integerValue]==1){
            if(requestType==Future)
                isFutureScoopServiceHit=NO;
            if(requestType==Current)
                isCurrentScoopServiceHit=NO;
            [AppHelper showAlertViewWithTag:1 title:AppName message:[dict valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
    }
}

-(void)scrollTableViewWithIndexPath:(NSIndexPath*)indexPath
{
    [self._uiTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}


-(void)userDidLReadNotification:(NSNotification*)note{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Read_Notofication object:nil];
}

-(void)userDidReplyOnSkoop:(NSNotification *)notification{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_reply_on_skoop object:nil];
    NSLog(@":::%@",notification.userInfo);
    if(notification.userInfo && [[notification.userInfo valueForKey:@"errorCode"] integerValue] ==0){
        
        if([notification.userInfo valueForKey:@"skoop_id"]){
            [[WebServicesController WebServiceMethod] deleteFileFromDocumentDirectoryWithFileName:[NSString stringWithFormat:@"movie%@.mov",[notification.userInfo valueForKey:@"skoop_id"]]];
            [[WebServicesController WebServiceMethod] deleteSkoopWithSkoopId:[notification.userInfo valueForKey:@"skoop_id"]];
            pendingSkoopArray=[NSArray arrayWithArray:[[WebServicesController WebServiceMethod] getAllSkoopReplyData]];
        }
        
        if(prevSelectedIndex<arrayForCurrentScoops.count){
            
            NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:prevSelectedIndex]];
            [dict setValue:@"1" forKey:@"upload"];
            NSMutableDictionary *replyDict=[NSMutableDictionary dictionaryWithDictionary:[dict valueForKey:@"reply"]];
            
            if([notification.userInfo valueForKey:@"video_path"]){
                [replyDict setValue:[notification.userInfo valueForKey:@"video_path"] forKey:@"video_path"];
                if([replyDict valueForKey:@"video_data"])
                    [replyDict removeObjectForKey:@"video_data"];
                [dict setValue:replyDict forKey:@"reply"];
                [arrayForCurrentScoops replaceObjectAtIndex:prevSelectedIndex withObject:dict];
                NSLog(@"::::%@",[NSIndexPath indexPathForRow:prevSelectedIndex inSection:0]);
                [self._uiTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:prevSelectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
            }
        }
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnSkoop:) name:Notification_reply_on_skoop object:nil];
}

-(void)userDidRefreshSkoopList:(NSNotification *)notification{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Refresh_SkoopList object:nil];
    currentSkoopId = [notification.userInfo valueForKey:@"skoop_id"];
    self.skoopId = currentSkoopId;
    isHitWebService = YES;
    self.isShowFutureSkoop = [[notification.userInfo valueForKey:@"skoop_type"] integerValue];
    [self hitWebserviceForGettingSkoopList];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidRefreshSkoopList:) name:Notification_Refresh_SkoopList object:nil];
}

-(void)userDidReplyOnLivePortalRequest:(NSNotification *)notification{
    
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Reply_LivePortal_Req object:nil];
    
    NSLog(@":::%@",notification.userInfo);
    NSDictionary *dict=notification.userInfo;
    
    if([[dict objectForKey:@"errorCode"] integerValue]==0){
         [AppHelper showAlertViewWithTag:1 title:AppName message:[dict valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        
        if(isComesFromCalendarClass){
            [[self deligate] updateLPReplyStatusOnCalendatTab];
        }
        
        NSMutableDictionary *dataDict=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:selectedIndex]];
        [dataDict setValue:@"1" forKey:@"reply_status"];
        [arrayForCurrentScoops replaceObjectAtIndex:selectedIndex withObject:dataDict];
        [self._uiTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[dict valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(void)userDidAddSkoopInToCalendar:(NSNotification *)notification{
    
    NSLog(@":::%@",notification.userInfo);
    [AppDelegate dismissGlobalHUD];
    if(notification.userInfo && [[notification.userInfo valueForKey:@"errorCode"] integerValue] == 0){
        
        NSInteger objectIndex=[arrayForFutureScoops indexOfObject:selectedDict];
        NSMutableDictionary *dataDict=[NSMutableDictionary dictionaryWithDictionary:selectedDict];
        [dataDict setValue:@"1" forKey:@"added_status"];
        [dataDict setValue:selectedTime forKey:@"reminder_time"];
        [arrayForFutureScoops replaceObjectAtIndex:objectIndex withObject:dataDict];
        
        [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Add_Skoop_Into_Calendar object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_Calendar object:@"refresh" userInfo:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_UpcomingSkoopList object:nil userInfo:(NSDictionary*)dataDict];
    }
    [AppHelper showAlertViewWithTag:1 title:AppName message:[notification.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(void)userDidDeleteSkoop:(NSNotification *)note{
    
    NSLog(@"Deleter skoop Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Delete_Skoop object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            
            if(isUpdateUpcomingSkoop){
                [[self deligate] updateMyProfileDataWithUpdateType:0];
            }
            
            NSDictionary *dataDict;
            if(requestType == Current){
                
                dataDict = [arrayForCurrentScoops objectAtIndex:selectedIndex];
                [arrayForCurrentScoops removeObjectAtIndex:selectedIndex];
                self._lblCurrentCount.text = [NSString stringWithFormat:@"%i",[self._lblCurrentCount.text intValue]-1];
            }
            else{
                
                dataDict = [arrayForFutureScoops objectAtIndex:selectedIndex];
                [arrayForFutureScoops removeObjectAtIndex:selectedIndex];
                self._lblFutureCount.text = [NSString stringWithFormat:@"%i",[self._lblFutureCount.text intValue]-1];
            }
            [self._uiTableView reloadData];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_Calendar object:[dataDict valueForKey:@"skoop_id"] userInfo:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_UpcomingSkoopList object:[dataDict valueForKey:@"skoop_id"] userInfo:nil];
            [[AppDelegate getAppDelegate] deleteSkoopEventFromCalendarWithDict:dataDict];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1)
            [AppHelper showAlertViewWithTag:101 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    }
}

- (void)refresh:(id)sender{
    
    // do your refresh here and reload the tablview
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"MMM d, h:mm a"];
    NSString *lastUpdated = [NSString stringWithFormat:@"Last updated on %@",[formatter stringFromDate:[NSDate date]]];
    self.refreshControl.attributedTitle = [[NSAttributedString alloc] initWithString:lastUpdated];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetSkoopRequestList:) name:Notification_for_mySkoop object:nil];
    if(requestType==Current)
        [[WebServicesController WebServiceMethod] getSkoopRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:@"" pageNo:[NSString stringWithFormat:@"%i",currentPageNo] pageLImit:PageLimit appToken:KAppToken andRequestType:@"current"];
    else
        [[WebServicesController WebServiceMethod] getSkoopRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:@"" pageNo:[NSString stringWithFormat:@"%i",futurePageNo] pageLImit:PageLimit appToken:KAppToken andRequestType:@"future"];
}
#pragma mark- Button action methods
- (IBAction)lenseButtonPressed:(id)sender{
    
    UITableViewCell *tblCell=nil;
    if(IS_IOS_7)
        tblCell=(UITableViewCell*)[[[sender superview] superview] superview];
    else
        tblCell=(UITableViewCell*)[[sender superview] superview];
    
    NSIndexPath *indexPath=[self._uiTableView indexPathForCell:tblCell];
     selectedDict=[NSMutableDictionary dictionaryWithDictionary:[arrayForFutureScoops objectAtIndex:indexPath.row]];
    [self addSkoopIntoCalendarAndReloadRowWithIndexPath:indexPath];
}

-(void)addSkoopIntoCalendarAndReloadRowWithIndexPath:(NSIndexPath *)indexPath{
    
    selectedSkoopId = [selectedDict valueForKey:@"skoop_id"];
    if(requestType==Future){
        
        if([_viewSelectTime superview]==nil){
            
            UIButton *btn15Min=(UIButton*)[_viewSelectTime viewWithTag:100];
            UIButton *btn30Min=(UIButton*)[_viewSelectTime viewWithTag:101];
            UIButton *btn45Min=(UIButton*)[_viewSelectTime viewWithTag:102];
            UIButton *btn60Min=(UIButton*)[_viewSelectTime viewWithTag:103];
            
            selectedTime=@"15";
            [btn15Min setSelected:YES];
            [btn30Min setSelected:NO];
            [btn45Min setSelected:NO];
            [btn60Min setSelected:NO];
            switch ([[selectedDict valueForKey:@"reminder_time"] integerValue]) {
                    
                case 15:
                    selectedTime=@"15";
                    [btn15Min setSelected:YES];
                    [btn30Min setSelected:NO];
                    [btn45Min setSelected:NO];
                    [btn60Min setSelected:NO];
                    break;
                    
                case 30:
                    selectedTime=@"30";
                    [btn15Min setSelected:NO];
                    [btn30Min setSelected:YES];
                    [btn45Min setSelected:NO];
                    [btn60Min setSelected:NO];
                    break;
                    
                case 45:
                    selectedTime=@"45";
                    [btn15Min setSelected:NO];
                    [btn30Min setSelected:NO];
                    [btn45Min setSelected:YES];
                    [btn60Min setSelected:NO];
                    break;
                    
                case 60:
                    selectedTime=@"60";
                    [btn15Min setSelected:NO];
                    [btn30Min setSelected:NO];
                    [btn45Min setSelected:NO];
                    [btn60Min setSelected:YES];
                    break;
                    
                default:
                    break;
            }
            
            if([[selectedDict valueForKey:@"added_status"] integerValue] == 1)
                _lblSkoopRequest.text=@"Change time of reminder?";
            else
                _lblSkoopRequest.text=@"Save Skoop request in calendar?";
            
            [self.view addSubview:_viewSelectTime];
            if([[selectedDict valueForKey:@"read_status"] integerValue]==0){
                
                NSInteger objectIndex=[arrayForFutureScoops indexOfObject:selectedDict];
                [selectedDict setValue:@"1" forKey:@"read_status"];
                
                if(objectIndex<arrayForFutureScoops.count)
                    [arrayForFutureScoops replaceObjectAtIndex:objectIndex withObject:selectedDict];
                
                [self performSelector:@selector(reloadTableviewAfterDelayWithIndexPath:) withObject:indexPath afterDelay:0.2];
                
                [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[selectedDict valueForKey:@"skoop_id"] notificationType:@"skoop_request" andToken:KAppToken];
            }
        }
    }
}

//Select time for getting alert before skoop time
-(IBAction)onClickSelectTimeButton:(id)sender{
    
    UIButton *btnTime=(UIButton*)sender;
    UIButton *btn15Min=(UIButton*)[_viewSelectTime viewWithTag:100];
    UIButton *btn30Min=(UIButton*)[_viewSelectTime viewWithTag:101];
    UIButton *btn45Min=(UIButton*)[_viewSelectTime viewWithTag:102];
    UIButton *btn60Min=(UIButton*)[_viewSelectTime viewWithTag:103];
    
    if(![btnTime isSelected])
        [btnTime setSelected:YES];
    
    if(btnTime.tag==100){//15 minutes button
    
        selectedTime=@"15";
        [btn30Min setSelected:NO];
        [btn45Min setSelected:NO];
        [btn60Min setSelected:NO];
    }
    else if(btnTime.tag==101){//30 minutes button
    
        selectedTime=@"30";
        [btn15Min setSelected:NO];
        [btn45Min setSelected:NO];
        [btn60Min setSelected:NO];
    }
    else if(btnTime.tag==102){//45 minutes button
    
        selectedTime=@"45";
        [btn30Min setSelected:NO];
        [btn15Min setSelected:NO];
        [btn60Min setSelected:NO];
    }
    else if(btnTime.tag==103){//60 minutes button
    
        selectedTime=@"60";
        [btn30Min setSelected:NO];
        [btn45Min setSelected:NO];
        [btn15Min setSelected:NO];
    }
}

//Add future skoop into calender for reminder
-(IBAction)onClickSaveButton:(id)sender{
    
    if([_viewSelectTime superview]!=nil)
        [_viewSelectTime removeFromSuperview];
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidAddSkoopInToCalendar:) name:Notification_Add_Skoop_Into_Calendar object:nil];
    [[WebServicesController WebServiceMethod] addSkoopIntoCalendarWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:selectedSkoopId skoopTime:selectedTime andAppToken:KAppToken];
}

//Add future skoop into calender for reminder
-(IBAction)onClickSaveWithoutReminderButton:(id)sender{
    
    if([_viewSelectTime superview]!=nil)
        [_viewSelectTime removeFromSuperview];
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidAddSkoopInToCalendar:) name:Notification_Add_Skoop_Into_Calendar object:nil];
    [[WebServicesController WebServiceMethod] addSkoopIntoCalendarWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:selectedSkoopId skoopTime:@"0" andAppToken:KAppToken];
}

-(IBAction)onClickCancelButton:(id)sender{
    if([_viewSelectTime superview]!=nil)
        [_viewSelectTime removeFromSuperview];
}

//Select future/current skoop
- (IBAction)BtnRequestType:(id)sender{
    
    UIButton *tappedButton=sender;
    if(tappedButton==self._btnCurrent && requestType!=Current){
        
        requestType=Current;
        [self._btnCurrent setSelected:YES];
        [self._btnFuture setSelected:NO];
        self._btnCurrent.backgroundColor=[UIColor colorWithRed:100.0/255.0 green:39.0/255.0 blue:142.0/255.0 alpha:1.0];
        self._btnFuture.backgroundColor=[UIColor colorWithRed:88.0/255.0 green:23.0/255.0 blue:133.0/255.0 alpha:1.0];
        
        if(currentPageNo==1 && isCurrentScoopServiceHit){
            if(arrayForCurrentScoops.count>0)
                [arrayForCurrentScoops removeAllObjects];
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetSkoopRequestList:) name:Notification_for_mySkoop object:nil];
            [[WebServicesController WebServiceMethod] getSkoopRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:@"" pageNo:[NSString stringWithFormat:@"%i",futurePageNo] pageLImit:PageLimit appToken:KAppToken andRequestType:@"current"];
        }
        else{
            [self._uiTableView reloadData];
            if(shownCurrentCell<arrayForCurrentScoops.count)
                [self._uiTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:shownCurrentCell inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:NO];
        }
    }
    else if(tappedButton==self._btnFuture && requestType!=Future){
        
        requestType=Future;
        [self._btnCurrent setSelected:NO];
        [self._btnFuture setSelected:YES];
        self._btnFuture.backgroundColor=[UIColor colorWithRed:100.0/255.0 green:39.0/255.0 blue:142.0/255.0 alpha:1.0];
        self._btnCurrent.backgroundColor=[UIColor colorWithRed:88.0/255.0 green:23.0/255.0 blue:133.0/255.0 alpha:1.0];
        
        if(futurePageNo==1 && isFutureScoopServiceHit){
            
            if(arrayForFutureScoops.count>0)
                [arrayForFutureScoops removeAllObjects];
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetSkoopRequestList:) name:Notification_for_mySkoop object:nil];
            [[WebServicesController WebServiceMethod] getSkoopRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:@"" pageNo:[NSString stringWithFormat:@"%i",futurePageNo] pageLImit:PageLimit appToken:KAppToken andRequestType:@"future"];
        }
        else{
            
            [self._uiTableView reloadData];
            if(shownFutureCell<arrayForFutureScoops.count)
                [self._uiTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:shownFutureCell inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:NO];
        }
    }
}

- (IBAction)BtnForBack:(id)sender{
//    if([AppHelper userDefaultsForKey:KIsBackScreen])
//        [self.navigationController popViewControllerAnimated:NO];
//    else
        [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark tableView Delegates
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    NSDictionary *dictOfScoop=nil;
    CGFloat cellHeight ;
    int numberOfRows ;
    if(requestType==Current){
        dictOfScoop=[[NSDictionary alloc]initWithDictionary:[arrayForCurrentScoops objectAtIndex:indexPath.row]];
        numberOfRows = (int)arrayForCurrentScoops.count;
    }
    else{
        dictOfScoop=[[NSDictionary alloc]initWithDictionary:[arrayForFutureScoops objectAtIndex:indexPath.row]];
        numberOfRows = (int)arrayForFutureScoops.count;
    }
    
    if([dictOfScoop objectForKey:@"reply"])
        cellHeight = 185;
    else
        cellHeight = 97;
    if(indexPath.row == numberOfRows-1)
        return cellHeight + 20;
    else
        return cellHeight;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    UILabel *lblNoData=(UILabel*)[self.view viewWithTag:123];
    if((requestType==Current && arrayForCurrentScoops.count==0) || (requestType==Future && arrayForFutureScoops.count==0)){
        if(!lblNoData){
            lblNoData=[[UILabel alloc] initWithFrame:CGRectMake(0, self._uiTableView.frame.size.height/2.0-15.0, 320, 30.0)];
            lblNoData.backgroundColor=[UIColor clearColor];
            lblNoData.textColor=KTextColor;
            lblNoData.tag=123;
            lblNoData.textAlignment=NSTextAlignmentCenter;
            lblNoData.text=@"No data available";
            [self._uiTableView addSubview:lblNoData];
        }
    }
    else
        [lblNoData removeFromSuperview];
    
    if(requestType==Current)
        return arrayForCurrentScoops.count;
    else
        return arrayForFutureScoops.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary *dictOfScoop=nil;
     if(requestType==Current){
         dictOfScoop=[arrayForCurrentScoops objectAtIndex:indexPath.row];
         shownCurrentCell= (int)indexPath.row;
     }
    else{
        dictOfScoop=[arrayForFutureScoops objectAtIndex:indexPath.row];
        shownFutureCell= (int)indexPath.row;
    }
    
    UITableViewCell *cell;
    
    if([dictOfScoop objectForKey:@"reply"])
        cell = [tableView dequeueReusableCellWithIdentifier:@"SkoopReqRep"];
    else
        cell = [tableView dequeueReusableCellWithIdentifier:@"SkoopRequest"];
        
    if (cell == nil){
        
        NSArray *topLevelObjects = nil;
        if([dictOfScoop objectForKey:@"reply"])
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SkoopReqRep" owner:self options:nil];
        else
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SkoopRequest" owner:self options:nil];
        
        // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
        cell = [topLevelObjects objectAtIndex:0];
        cell.backgroundColor=[UIColor clearColor];
        
        if(!IS_Greater_Or_Equal_to_IOS_7){
            UIImageView *imgView=[[UIImageView alloc] initWithFrame:cell.frame];
            imgView.image=[UIImage imageNamed:@"unread_notify_bg.png"];
            imgView.tag=777;
            [cell.contentView addSubview:imgView];
        }
        
        UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:208];
        [AppHelper getRoundedImageWithImageView:profileImage];
        UITapGestureRecognizer *uiTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnSenderSkoopProfileImage:)];
        uiTap.numberOfTapsRequired=1;
        profileImage.userInteractionEnabled=YES;
        [profileImage addGestureRecognizer:uiTap];
        
        if([dictOfScoop objectForKey:@"reply"]){
            cell.backgroundColor=[UIColor clearColor];
            UIImageView *replyProfileImage=(UIImageView *)[cell.contentView viewWithTag:219];
            UITapGestureRecognizer *uiTap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnReplierSkoopProfileImage:)];
            uiTap1.numberOfTapsRequired=1;
            replyProfileImage.userInteractionEnabled=YES;
            [replyProfileImage addGestureRecognizer:uiTap1];
        }
    }
    if(currentSkoopId && [currentSkoopId isEqualToString:[dictOfScoop valueForKey:@"skoop_id"]])
         [cell.contentView.layer setBorderColor:[UIColor colorWithRed:86.0/255.0 green:40.0/255.0 blue:144.0/255.0 alpha:1.0].CGColor];
    else
        [cell.contentView.layer setBorderColor:[UIColor clearColor].CGColor];
    
    [cell.contentView.layer setBorderWidth:2.0f];
    
    if(isCurrentScoopServiceHit && requestType==Current && indexPath.row==arrayForCurrentScoops.count-1){
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetSkoopRequestList:) name:Notification_for_mySkoop object:nil];
        [[WebServicesController WebServiceMethod] getSkoopRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:@"" pageNo:[NSString stringWithFormat:@"%i",currentPageNo] pageLImit:PageLimit appToken:KAppToken andRequestType:@"current"];
    }
    else if(isFutureScoopServiceHit && requestType==Future && indexPath.row==arrayForFutureScoops.count-1){
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetSkoopRequestList:) name:Notification_for_mySkoop object:nil];
        [[WebServicesController WebServiceMethod] getSkoopRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:@"" pageNo:[NSString stringWithFormat:@"%i",futurePageNo] pageLImit:PageLimit appToken:KAppToken andRequestType:@"future"];
    }
    UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:208];
    
    UILabel *lblLikeCount=(UILabel *)[cell.contentView viewWithTag:210];
    lblLikeCount.backgroundColor=[UIColor clearColor];
    lblLikeCount.text=[NSString stringWithFormat:@"%i",[[dictOfScoop valueForKey:@"like"] intValue]];
    
    CBAutoScrollLabel *lblName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:212];
    [lblName setLabelSettingForObject:@"name"];
    
    CBAutoScrollLabel *lblsearchText=(CBAutoScrollLabel *)[cell.contentView viewWithTag:205];
    [lblsearchText setLabelSettingForObject:@"skoop"];
    
    UILabel *lblLocation=(UILabel *)[cell.contentView viewWithTag:206];
    UILabel *lblDate=(UILabel *)[cell.contentView viewWithTag:207];
    UILabel *lblCost=(UILabel *)[cell.contentView viewWithTag:209];
    lblCost.textColor=KTextColor;
    
    NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfScoop objectForKey:@"image"]]];
    NSString *imgUrl=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:imgUrl];
    
    if([urlString length]>0)
        [profileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    else
        profileImage.image=[UIImage imageNamed:@"defaultuser.png"];
    
    lblName.text=[dictOfScoop valueForKey:@"name"];
    lblsearchText.text=[dictOfScoop valueForKey:@"searchText"];
    
    if([dictOfScoop valueForKey:@"group_name"] && [[dictOfScoop valueForKey:@"group_name"] length]>0)
        lblLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfScoop valueForKey:@"group_name"]];
    else
        lblLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfScoop valueForKey:@"location"]];
    
    lblDate.text=[NSString stringWithFormat:@"%@",[dictOfScoop valueForKey:@"date"]];
    
    if([[dictOfScoop valueForKey:@"price"] floatValue]>0)
        lblCost.text=[NSString stringWithFormat:@"$%@",[dictOfScoop valueForKey:@"price"]];
    else
        lblCost.text=@"Favor";
    
    UIButton *btnLense=(UIButton*)[cell.contentView viewWithTag:425];
    [btnLense addTarget:self action:@selector(lenseButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
    
    if([[dictOfScoop valueForKey:@"live_portal"] integerValue]==1){
        
        if([[dictOfScoop valueForKey:@"reply_status"] integerValue]==0){
            
            [btnLense setImage:[UIImage imageNamed:@"live_poratl_small.png"] forState:UIControlStateNormal];
            [btnLense setImage:[UIImage imageNamed:@"live_poratl_small.png"] forState:UIControlStateHighlighted];
        }
        else{
            
             [btnLense setImage:[UIImage imageNamed:@"live_green.png"] forState:UIControlStateNormal];
             [btnLense setImage:[UIImage imageNamed:@"live_green.png"] forState:UIControlStateHighlighted];
        }
        btnLense.frame=CGRectMake(275, 25, 40, 40);
    }
    else{
        
        [btnLense setImage:[UIImage imageNamed:@"lens_icon.png"] forState:UIControlStateNormal];
        [btnLense setImage:[UIImage imageNamed:@"lens_icon.png"] forState:UIControlStateHighlighted];
        btnLense.frame=CGRectMake(278, 27, 35, 35);
    }
    
    if(requestType==Current)//Can not add current skoop in to the calendar
        btnLense.userInteractionEnabled=NO;
    else
        btnLense.userInteractionEnabled=YES;
    
    if(IS_Greater_Or_Equal_to_IOS_7){
        
        if(![[dictOfScoop valueForKey:@"read_status"] isKindOfClass:[NSNull class]] && [[dictOfScoop valueForKey:@"read_status"] integerValue]==1)
            cell.backgroundColor=[UIColor clearColor];
        else
            cell.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"unread_notify_bg.png"]];
    }
    else{
        
        UIImageView *imgView=(UIImageView *)[cell.contentView viewWithTag:777];
        if(![[dictOfScoop valueForKey:@"read_status"] isKindOfClass:[NSNull class]] && [[dictOfScoop valueForKey:@"read_status"] integerValue]==1)
            imgView.hidden=YES;
        else
            imgView.hidden=NO;
    }
    
    if([dictOfScoop objectForKey:@"reply"]){
        
        UIView *bottomView=(UIView*)[cell.contentView viewWithTag:900];
        
        cell.backgroundColor=[UIColor clearColor];
        NSDictionary *dictOfReply=[dictOfScoop objectForKey:@"reply"];
        UIImageView *replyVideoImageView=(UIImageView *)[cell.contentView viewWithTag:202];
        
        UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[cell.contentView viewWithTag:indexPath.row+1];
        
        if([dictOfScoop valueForKey:@"upload"] && [[dictOfScoop valueForKey:@"upload"] integerValue]==0){
            
            if(activityIndicator){
                [activityIndicator startAnimating];
            }
            else{
                
                activityIndicator= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
                activityIndicator.backgroundColor=[UIColor clearColor];
                activityIndicator.alpha = 1.0;
                activityIndicator.tag=indexPath.row+1;
                activityIndicator.center = replyVideoImageView.center;
                activityIndicator.hidesWhenStopped = YES;
                [bottomView addSubview:activityIndicator];
                [activityIndicator startAnimating];
            }
        }
        else if(activityIndicator){
            [activityIndicator stopAnimating];
            [activityIndicator removeFromSuperview];
        }
        
        if([[dictOfReply valueForKey:@"paymentStatus"] isEqualToString:@"1"])
            lblCost.textColor=KTextColor_Green;
        
        UIImageView *replyProfileImage=(UIImageView *)[cell.contentView viewWithTag:219];
        replyProfileImage.backgroundColor=[UIColor lightGrayColor];
        [AppHelper getRoundedImageWithImageView:replyProfileImage];
        
        UITapGestureRecognizer *uiTap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnReplierSkoopProfileImage:)];
        uiTap1.numberOfTapsRequired=1;
        replyProfileImage.userInteractionEnabled=YES;
        [replyProfileImage addGestureRecognizer:uiTap1];
        
        NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[AppHelper userDefaultsForKey:KUserImageUrl]]];
        NSString *imgUrl=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url=[NSURL URLWithString:imgUrl];
        
        if([urlString length]>0)
            [replyProfileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
        else
            replyProfileImage.image=[UIImage imageNamed:@"defaultuser.png"];
        
        if([dictOfReply objectForKey:@"thumbnail"]){
            
            NSString *urlString1 = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfReply objectForKey:@"thumbnail"]]];
            NSString *imgUrl1=[urlString1  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            NSURL *url1=[NSURL URLWithString:imgUrl1];
            [replyVideoImageView setImageWithURL:url1 placeholderImage:[UIImage imageNamed:@"thumbimage"]];
        }
        else
            replyVideoImageView.image=[dictOfReply valueForKey:@"thumbimage"];
        
        CBAutoScrollLabel *lblReplyName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:214];
        [lblReplyName setLabelSettingForObject:@"name"];
        lblReplyName.text=[dictOfReply valueForKey:@"name"];
        
        CBAutoScrollLabel *lblReplysearchText=(CBAutoScrollLabel *)[cell.contentView viewWithTag:1210];
        [lblReplysearchText setLabelSettingForObject:@"skoop"];
        lblReplysearchText.text = [NSString stringWithFormat:@"%@(%@ Sec)",[dictOfScoop valueForKey:@"searchText"],[[dictOfScoop valueForKey:@"reply"] valueForKey:@"duration"]];
        
        UILabel *lblReplyLocation=(UILabel *)[cell.contentView viewWithTag:1211];
        
        if([dictOfScoop valueForKey:@"group_name"] && [[dictOfScoop valueForKey:@"group_name"] length]>0)
            lblReplyLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfScoop valueForKey:@"group_name"]];
        else
            lblReplyLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfScoop valueForKey:@"location"]];
        
        UILabel *lblReplyDate=(UILabel *)[cell.contentView viewWithTag:215];
        lblReplyDate.text=[NSString stringWithFormat:@"%@",[dictOfReply valueForKey:@"date"]];
    }
    return  cell;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *tblCell=[self._uiTableView cellForRowAtIndexPath:indexPath];
    NSMutableDictionary *dataDict = nil;
    if(requestType==Current){
        
        dataDict=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:indexPath.row]];
        if([[dataDict valueForKey:@"live_portal"] integerValue]==1){
            if([[dataDict valueForKey:@"reply_status"] integerValue] == 1){
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have already replied to this request." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
            }
            else{
                selectedIndex=indexPath.row;
                [AppHelper showAlertViewWithTag:102 title:AppName message:@"Would you like to tell this user that you are available for a Live Portal call?" delegate:self cancelButtonTitle:Alert_No otherButtonTitles:Alert_Yes];
            }
            
            if([[dataDict valueForKey:@"read_status"] integerValue] == 0){
                
                [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[dataDict valueForKey:@"skoop_id"] notificationType:@"skoop_request" andToken:KAppToken];
                
                [dataDict setValue:@"1" forKey:@"read_status"];
                [arrayForCurrentScoops replaceObjectAtIndex:indexPath.row withObject:dataDict];
                [self performSelector:@selector(reloadTableviewAfterDelayWithIndexPath:) withObject:indexPath afterDelay:0.2];
            }
        }
        else{
            if(tblCell.tag == 200){
                
                if([dataDict valueForKey:@"upload"] && [[dataDict valueForKey:@"upload"] integerValue]==0)
                    [AppHelper showAlertViewWithTag:1 title:AppName message:@"Video is not uploaded yet." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
                else{
                    
                    VideoPlayerVC *videoPlayerVC = [self.storyboard instantiateViewControllerWithIdentifier:@"VideoPlayerVC"];
                    videoPlayerVC.videoURL =[[dataDict valueForKey:@"reply"] valueForKey:@"video_path"];
                    videoPlayerVC.isShowingOwnVideo = YES;
                    videoPlayerVC.selecteDataDict = dataDict;
                    [self.navigationController pushViewController:videoPlayerVC animated:NO];
                }
            }
            else{
                selectedIndex=indexPath.row;
                
                [self performSegueWithIdentifier:@"goforreply" sender:dataDict];
                
                if([[dataDict valueForKey:@"read_status"] integerValue] == 0){
                    
                    [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[dataDict valueForKey:@"skoop_id"] notificationType:@"skoop_request" andToken:KAppToken];
                    
                    [dataDict setValue:@"1" forKey:@"read_status"];
                    [self performSelector:@selector(reloadTableviewAfterDelayWithIndexPath:) withObject:indexPath afterDelay:0.2];
                    [arrayForCurrentScoops replaceObjectAtIndex:indexPath.row withObject:dataDict];
                }
            }
        }
        currentSkoopId=@"0";
    }
    else{
        
        dataDict=[NSMutableDictionary dictionaryWithDictionary:[arrayForFutureScoops objectAtIndex:indexPath.row]];
        
        if([[dataDict valueForKey:@"read_status"] integerValue] == 0){
            [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[dataDict valueForKey:@"skoop_id"] notificationType:@"skoop_request" andToken:KAppToken];
        }
        [dataDict setValue:@"1" forKey:@"read_status"];
        [self performSelector:@selector(reloadTableviewAfterDelayWithIndexPath:) withObject:indexPath afterDelay:0.2];
        
        selectedDict=[NSMutableDictionary dictionaryWithDictionary:[arrayForFutureScoops objectAtIndex:indexPath.row]];
        [self addSkoopIntoCalendarAndReloadRowWithIndexPath:indexPath];
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete){
        
        //add code here for when you hit delete
        selectedIndex=indexPath.row;
        [AppHelper showAlertViewWithTag:101 title:AppName message:@"Are you sure you want to delete this skoop request?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
    }
}


-(void)reloadTableviewAfterDelayWithIndexPath:(NSIndexPath*)indexPath
{
    [self._uiTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag==101){
        
        if(buttonIndex==0){
            
            NSDictionary *dataDict;
            if(requestType==Current)
                dataDict=[arrayForCurrentScoops objectAtIndex:selectedIndex];
            else
                dataDict=[arrayForFutureScoops objectAtIndex:selectedIndex];
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidDeleteSkoop:) name:Notification_Delete_Skoop object:nil];
            [[WebServicesController WebServiceMethod] deleteSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:[dataDict valueForKey:@"skoop_id"] andAppToken:KAppToken];
        }
    }
    else if(alertView.tag==102){
        
        if(buttonIndex==1){
            
            NSMutableDictionary *dataDict=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:selectedIndex]];
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnLivePortalRequest:) name:Notification_Reply_LivePortal_Req object:nil];
            [[WebServicesController WebServiceMethod] replyOnLivePortalRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] requestId:[dataDict valueForKey:@"skoop_id"] andAppToken:KAppToken];
        }
    }
}

#pragma mark Video player deligate
-(void)movieLoadStateDidChange:(id)sender{
    NSLog(@"STATE CHANGED");
    if(MPMovieLoadStatePlaythroughOK ) {
        
        [AppDelegate dismissGlobalHUD];
        NSLog(@"State is Playable OK");
        NSLog(@"Enough data has been buffered for playback to continue uninterrupted..");
    }
}

#pragma mark Detect view touch
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    if (touch.view.tag==4445)
        [_viewSelectTime removeFromSuperview];
}

#pragma mark Segur method
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    if([segue.identifier isEqual:@"goforreply"]){
        NSDictionary *dataDict=(NSDictionary*)sender;
        NSLog(@"::::%@",dataDict);
        VideoUploaderVC *videoObj=segue.destinationViewController;
        videoObj.videoLoaderDelegate=self;
        videoObj.isUploadVideoForGroup = NO;
        videoObj.skoopId=[dataDict valueForKey:@"skoop_id"];
        //videoObj.groupId = self.groupId;
        
    }
    else if([segue.identifier isEqualToString:@"userprofile"]){
        NSDictionary *dataDict=(NSDictionary*)sender;
        UserProfileVC *userProfileObj=segue.destinationViewController;
        userProfileObj.groupId=@"";
        userProfileObj.groupOwnerId=@"";
        
        if(isShowReplierProfile){
            userProfileObj.name=[[dataDict valueForKey:@"reply"] valueForKey:@"name"];
            userProfileObj.imgUrl=[[dataDict valueForKey:@"reply"] valueForKey:@"image"];
            userProfileObj.blockUserId=[AppHelper userDefaultsForKey:KUserId];
        }
        else{
            userProfileObj.name=[dataDict valueForKey:@"name"];
            userProfileObj.imgUrl=[dataDict valueForKey:@"image"];
            userProfileObj.blockUserId=[dataDict valueForKey:@"user_id"];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
