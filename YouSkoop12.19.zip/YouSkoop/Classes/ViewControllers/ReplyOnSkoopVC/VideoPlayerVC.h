//
//  VideoPlayerVC.h
//  youskoop
//
//  Created by Pramod Kumar Pranav on 3/17/15.
//  Copyright (c) 2015 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import<MediaPlayer/MediaPlayer.h>
#import "CellSelectionView.h"

@interface VideoPlayerVC : UIViewController{
    
    MPMoviePlayerController *mplayer;
}
@property id<updateSkoopData>deligate;
@property (strong, nonatomic) NSMutableDictionary *selecteDataDict;
@property (strong, nonatomic) NSString *videoURL;
@property  BOOL isShowingOwnVideo;
@end
