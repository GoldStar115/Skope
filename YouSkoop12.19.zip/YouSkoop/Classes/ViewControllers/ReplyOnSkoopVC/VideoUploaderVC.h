//
//  VideoUploaderVC.h
//  youskoop
//
//  Created by Gurdeep_Singh on 4/11/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol saveDataProtocol <NSObject>

@optional
-(void)setRequiredBoolVariable:(BOOL)boolValue;
-(void)updateSkoopReplyDataWithDataDict:(NSDictionary*)dataDict;
-(void)updateSkoopListFromVideoUploader;

@end

@interface VideoUploaderVC : UIViewController <UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate>{
    
    id<saveDataProtocol> videoLoaderDelegate;
}
@property id<saveDataProtocol> videoLoaderDelegate;
@property (strong, nonatomic) NSString *skoopId;
@property (strong, nonatomic) NSString *groupId;
@property BOOL isUploadVideoForGroup;

-(IBAction)onClickBackButtom:(id)sender;
-(IBAction)onClickSendButtom:(id)sender;
- (IBAction)PlayVideo:(id)sender;
- (IBAction)RecordAndPlay:(id)sender;

//For Opening UIImagePickerController
- (BOOL) startMediaBrowserFromViewController: (UIViewController*) controller
                               usingDelegate: (id <UIImagePickerControllerDelegate,
                                               UINavigationControllerDelegate>) delegate;
- (BOOL) startCameraControllerFromViewController: (UIViewController*) controller
                                   usingDelegate: (id <UIImagePickerControllerDelegate,
                                                   UINavigationControllerDelegate>) delegate andAnimation:(BOOL)isYes;
- (void)video: (NSString *) videoPath didFinishSavingWithError: (NSError *) error contextInfo:(void*)contextInfo;

@end
