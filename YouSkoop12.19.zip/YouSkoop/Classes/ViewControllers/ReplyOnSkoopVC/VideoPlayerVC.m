//
//  VideoPlayerVC.m
//  youskoop
//
//  Created by Pramod Kumar Pranav on 3/17/15.
//  Copyright (c) 2015 user. All rights reserved.
//

#import "VideoPlayerVC.h"
#import "CreditCardCV.h"
#import "ReplyOnSkoopVC.h"

#define degreesToRadian(x) (M_PI * (x) / 180.0)

@interface VideoPlayerVC ()

@end

@implementation VideoPlayerVC{
    
    __weak IBOutlet UIView *_viewPurchase;
    NSTimer *callTimer;
}
@synthesize videoURL=_videoURL;
@synthesize isShowingOwnVideo;
@synthesize selecteDataDict;
@synthesize deligate;

- (void)viewDidLoad {
    [super viewDidLoad];
    //Set navigation image according to ios version
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    MPMoviePlayerController *moviePlayerController = [[MPMoviePlayerController alloc] initWithContentURL:[NSURL URLWithString:_videoURL]];
    [moviePlayerController setShouldAutoplay:YES];
    [moviePlayerController.view setFrame:CGRectMake(0, navImage.frame.origin.y+navImage.frame.size.height + 45, self.view.bounds.size.width, self.view.bounds.size.height-(navImage.frame.origin.y+navImage.frame.size.height + 90))];
    moviePlayerController.fullscreen = YES;
  
    [moviePlayerController setScalingMode:MPMovieScalingModeAspectFit];
    moviePlayerController.view.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(movieLoadStateDidChange:)
                                                 name: MPMoviePlayerLoadStateDidChangeNotification
                                               object: moviePlayerController];
    
    [moviePlayerController play];
    mplayer = moviePlayerController;
    [self.view addSubview:mplayer.view];
    
    if(!isShowingOwnVideo && [[self.selecteDataDict valueForKey:@"price"] floatValue]>0 && [[self.selecteDataDict valueForKey:@"paymentStatus"] integerValue] == 0){
        
        if(callTimer != nil){
            
            [callTimer invalidate];
            callTimer = nil;
        }
        callTimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkVideoPlayTime) userInfo:nil repeats:YES];
        
        mplayer.controlStyle = MPMovieControlStyleNone;
        
        UILabel *lbl3SecondsPrev=[[UILabel alloc] initWithFrame:CGRectMake((self.view.bounds.size.width - 220)/2 , mplayer.view.frame.origin.y+mplayer.view.frame.size.height/2-10, 220, 20)];
        lbl3SecondsPrev.backgroundColor=[UIColor clearColor];
        lbl3SecondsPrev.textColor=[UIColor lightGrayColor];
        lbl3SecondsPrev.textAlignment=NSTextAlignmentCenter;
        lbl3SecondsPrev.text=@"3 seconds preview";
        lbl3SecondsPrev.tag=555;
        lbl3SecondsPrev.hidden=NO;
        [self.view addSubview:lbl3SecondsPrev];
    }
    else if(!isShowingOwnVideo){
        
        UIButton *btnReportVideo=[UIButton buttonWithType:UIButtonTypeCustom];
        btnReportVideo.frame=CGRectMake(self.view.frame.size.width - 130, moviePlayerController.view.frame.origin.y-32, 120, 35);
        [btnReportVideo setBackgroundImage:[UIImage imageNamed:@"blockUser.png"] forState:UIControlStateNormal];
        [btnReportVideo setBackgroundImage:[UIImage imageNamed:@"blockUser.png"] forState:UIControlStateSelected];
        [btnReportVideo setTitle:@"Report Video" forState:UIControlStateNormal];
        [btnReportVideo setTitle:@"Report Video" forState:UIControlStateSelected];
        [btnReportVideo addTarget:self action:@selector(onClickReportVideoButton:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:btnReportVideo];
    }
    
    CGRect frameRect=_viewPurchase.frame;
    frameRect.origin.y=self.view.bounds.size.height+10;
    _viewPurchase.frame=frameRect;
    [self.view addSubview:_viewPurchase];
}

-(void)viewWillAppear:(BOOL)animated{
    //Hide tabbar
    [[AppDelegate getAppDelegate] hideTabBar:self.tabBarController];
}
-(void)viewWillDisappear:(BOOL)animated{
    //Shoew tababr
    [[AppDelegate getAppDelegate] showTabBar:self.tabBarController];
    if(mplayer)
        [mplayer pause];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Button action methods
- (IBAction)btnBack:(id)sender
{
    if(mplayer)
        [mplayer stop];
    [self.navigationController popViewControllerAnimated:NO];
}

-(IBAction)onClickReportVideoButton:(id)sender{
    
    [AppHelper showAlertViewWithTag:103 title:AppName message:@"Are you sure you want to report this video?" delegate:self cancelButtonTitle:Alert_No otherButtonTitles:Alert_Yes];
}

-(IBAction)onClickBuyButton:(id)sender{
    
    if([[self.selecteDataDict valueForKey:@"price"] floatValue] <= [[AppHelper userDefaultsForKey:KAvailableCredit] floatValue]){
        [AppHelper showAlertViewWithTag:104 title:AppName message:[NSString stringWithFormat:@"You will be charged $%@. Proceed?",[self.selecteDataDict valueForKey:@"price"]] delegate:self cancelButtonTitle:Alert_No otherButtonTitles:Alert_Yes];
    }
    else{
        [AppHelper showAlertViewWithTag:105 title:AppName message:@"You have insufficient balance to buy this skoop,please recharge your account first.Do you want to recharge your account?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
    }
}

-(IBAction)onClickCancelButton:(id)sender{
    
    [self.navigationController popViewControllerAnimated:NO];
}

-(IBAction)onClickPlayAgainButton:(id)sender{
    
    [UIView animateWithDuration:0.5 animations:^(void){
        
        [mplayer stop];
        [mplayer play];
         if(callTimer != nil){
             
             [callTimer invalidate];
             callTimer = nil;
         }
         callTimer = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkVideoPlayTime) userInfo:nil repeats:YES];
         
         CGRect frameRect=_viewPurchase.frame;
         frameRect.origin.y=self.view.bounds.size.height+10;
         _viewPurchase.frame=frameRect;
     }completion:nil];
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag==103){
        
        if(buttonIndex == 1){
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReportVideo:) name:Notification_Report_Video object:nil];
            [[WebServicesController WebServiceMethod] reportVideoWithUserId:[AppHelper userDefaultsForKey:KUserId] replyId:[self.selecteDataDict valueForKey:@"reply_id"] andAppToken:KAppToken];
        }
    }
    else if(alertView.tag==104){
        
        if(buttonIndex == 1){
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidBuySkoop:) name:Notification_Purchase_Skoop object:nil];
            [[WebServicesController WebServiceMethod] buySkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] amount:[NSString stringWithFormat:@"%f",[[self.selecteDataDict valueForKey:@"price"] floatValue]] replyId:[self.selecteDataDict valueForKey:@"reply_id"] sellerId:[self.selecteDataDict valueForKey:@"user_id"] skoopId:[self.selecteDataDict valueForKey:@"skoop_id"] andAppToken:KAppToken];
        }
    }
    else if(alertView.tag==105){
        
        if(buttonIndex == 0){
            
            CreditCardCV *creditCard = [self.storyboard instantiateViewControllerWithIdentifier:@"CreditCardDetail"];
            [self.navigationController pushViewController:creditCard animated:YES];
        }
    }
}

#pragma mark - Video player deligate

-(void)movieLoadStateDidChange:(id)sender{
    NSLog(@"STATE CHANGED");
    if(MPMovieLoadStatePlaythroughOK ) {
        
        [AppDelegate dismissGlobalHUD];
        NSLog(@"State is Playable OK");
        NSLog(@"Enough data has been buffered for playback to continue uninterrupted..");
    }
}

#pragma mark Services response
-(void)userDidReportVideo:(NSNotification*)note
{
    NSLog(@"Dictionary: %@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Report_Video object:nil];
    
    if(note.userInfo)
    {
        [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    }
}

-(void)userDidBuySkoop:(NSNotification*)note{
    
    NSLog(@"Dictionary: %@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Purchase_Skoop object:nil];
    
    if(note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Count object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"buys",@"req_type", nil]];
            
            [AppHelper saveToUserDefaults:[note.userInfo valueForKey:@"total_amount"] withKey:KAvailableCredit];
            [self.selecteDataDict setValue:@"1" forKey:@"paymentStatus"];
            [[self deligate] updateSkoopDataWithData];
            
            [UIView animateWithDuration:0.5 animations:^(void)
             {
                 [_viewPurchase bringSubviewToFront:mplayer.view];
                 CGRect frameRect=_viewPurchase.frame;
                 frameRect.origin.y = self.view.bounds.size.height+10;
                 _viewPurchase.frame=frameRect;
             }completion:nil];
            
            UILabel *lbl3SecPreview = (UILabel *)[self.view viewWithTag:555];
            if(lbl3SecPreview)
                lbl3SecPreview.hidden = YES;
            mplayer.controlStyle = MPMovieControlStyleDefault;
            //natural play
            //mplayer.endPlaybackTime = NAN;
            [mplayer play];
            
            //Add Report Video button
            UIButton *btnReportVideo=[UIButton buttonWithType:UIButtonTypeCustom];
            btnReportVideo.frame=CGRectMake(self.view.frame.size.width - 130, mplayer.view.frame.origin.y-32, 120, 35);
            [btnReportVideo setBackgroundImage:[UIImage imageNamed:@"blockUser.png"] forState:UIControlStateNormal];
            [btnReportVideo setBackgroundImage:[UIImage imageNamed:@"blockUser.png"] forState:UIControlStateSelected];
            [btnReportVideo setTitle:@"Report Video" forState:UIControlStateNormal];
            [btnReportVideo setTitle:@"Report Video" forState:UIControlStateSelected];
            [btnReportVideo addTarget:self action:@selector(onClickReportVideoButton:) forControlEvents:UIControlEventTouchUpInside];
            [self.view addSubview:btnReportVideo];
        }
        
        [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    }
}

#pragma mark Method timer method
-(void)checkVideoPlayTime{
    
    //Stop video after 3 seconds preview
    if([[self.selecteDataDict valueForKey:@"price"] floatValue]>0 && [[self.selecteDataDict valueForKey:@"paymentStatus"] integerValue] == 0 && mplayer.currentPlaybackTime>=3.0){
        
        if(callTimer != nil){
            [callTimer invalidate];
            callTimer = nil;
        }
        [mplayer pause];
        
        [UIView animateWithDuration:0.5 animations:^(void)
         {
             [_viewPurchase bringSubviewToFront:mplayer.view];
             CGRect frameRect = _viewPurchase.frame;
             frameRect.origin.y = (self.view.bounds.size.height-frameRect.size.height)/2.0+10;
             _viewPurchase.frame = frameRect;
         }completion:nil];
    }
}

@end
