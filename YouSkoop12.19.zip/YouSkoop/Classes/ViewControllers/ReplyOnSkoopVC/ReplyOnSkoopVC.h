//
//  ReplyOnSkoopVC.h
//  youskoop
//
//  Created by Shitesh Patel on 08/04/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoUploaderVC.h"

@protocol updateMyProfileData<NSObject>

@optional
-(void)updateMyProfileDataWithUpdateType:(NSInteger)updateType;
-(void)updateLPReplyStatusOnCalendatTab;
@end

@interface ReplyOnSkoopVC : UIViewController

@property id<updateMyProfileData> deligate;
@property (weak, nonatomic) IBOutlet UIButton *_btnFuture;
@property (weak, nonatomic) IBOutlet UIButton *_btnCurrent;
@property (weak, nonatomic) IBOutlet UILabel *_lblFutureCount;
@property (weak, nonatomic) IBOutlet UILabel *_lblCurrentCount;
@property (strong, nonatomic) UIRefreshControl *refreshControl;
@property (strong, nonatomic) NSMutableArray *requestArray;
@property (weak, nonatomic) IBOutlet UITableView *_uiTableView;
@property (strong, nonatomic) NSString *skoopId;
@property BOOL isShowFutureSkoop;
@property BOOL isUpdateUpcomingSkoop;
@property BOOL isComesFromCalendarClass;

- (IBAction)BtnRequestType:(id)sender;
- (IBAction)BtnForBack:(id)sender;

@end
