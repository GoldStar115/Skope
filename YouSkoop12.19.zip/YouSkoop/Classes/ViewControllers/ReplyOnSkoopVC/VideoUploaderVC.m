//
//  VideoUploaderVC.m
//  youskoop
//
//  Created by Gurdeep_Singh on 4/11/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "VideoUploaderVC.h"

#import <MobileCoreServices/UTCoreTypes.h>
#import <MediaPlayer/MediaPlayer.h>
#import <MediaPlayer/MPMoviePlayerController.h>
#import <AVFoundation/AVFoundation.h>
#import <CoreMedia/CoreMedia.h>
#import "NMRangeSlider.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import "RequestViewViewController.h"
#import "AppHelper.h"

enum {
    camera = 0,
    gallery = 1
} sourceForVideo;

@interface VideoUploaderVC ()
{

    UIImage *thumbnail;
    NSString *videoPathString;
    
    int durationTime,startTime,endTime;
    NSTimeInterval time;
    NSString *finaltime;
    UIActivityIndicatorView *spinner;
    NSData *videoData;
    UILabel *leftLabel;
	UILabel *rightLabel;
    BOOL isVideoSelected;
    
    UIImagePickerController *cameraUI;
    
    __weak IBOutlet UIButton *_btnPlayPause;
    __weak IBOutlet UILabel *_lblWarning;
    __weak IBOutlet UIButton *_btnRecordVideo;
    __weak IBOutlet UIButton *_btnStartRecording;
    __weak IBOutlet UIView *_cameraOverLayView;
    __weak IBOutlet UIButton *_btnFlip;
    __weak IBOutlet UILabel *_lblTime;
    __weak IBOutlet UIButton *_btnCancelRecording;
    NSTimer *timerForCheckPlayTime;
    NSTimer *timerForVideoRecording;
    int recordTime;
    
    IBOutlet UIButton *btnSendSkoop;
    
    IBOutlet UIView *viewBottom;
    
    
}
@property (weak, nonatomic) IBOutlet NMRangeSlider *labelSlider;
@property (weak, nonatomic) IBOutlet UILabel *lowerLabel;
@property (weak, nonatomic) IBOutlet UILabel *upperLabel;
@property (weak, nonatomic) IBOutlet UIView *viewFormovieController;

@property (strong, nonatomic) MPMoviePlayerController *movieController;
@property(strong,nonatomic) NSURL *urlString;
- (IBAction)labelSliderChanged:(NMRangeSlider*)sender;

@end

@implementation VideoUploaderVC
@synthesize skoopId;
@synthesize videoLoaderDelegate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#pragma mark - View lifecycle

-(void)viewDidLoad
{
    [super viewDidLoad];
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    UIImageView *sliderBaseImage=(UIImageView*)[self.view viewWithTag:12];
    sliderBaseImage.backgroundColor=[UIColor colorWithRed:9.0/255.0 green:21.0/255.0 blue:57.0/255.0 alpha:1.0];
    thumbnail=[[UIImage alloc] init];
    _lblWarning.hidden=YES;
    
    CGRect frameRect=self.labelSlider.frame;
    frameRect.origin.y=viewBottom.bounds.size.height-43;
    self.labelSlider.frame=frameRect;
    self.labelSlider.isSlide=NO;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didChangeVideoPlayBackState:) name:MPMoviePlayerPlaybackStateDidChangeNotification object:nil];
    
    _cameraOverLayView.backgroundColor=[UIColor clearColor];
    _movieController.controlStyle=MPMovieControlStyleNone;
    
//    if (_isUploadVideoForGroup) {
//        [btnSendSkoop setTitle:@"Upload Video" forState:UIControlStateNormal];
//    }
    
    CGRect frameRect1=viewBottom.frame;
    frameRect1.origin.y=self.view.bounds.size.height-52;
    viewBottom.frame=frameRect1;
}

-(void)viewWillDisappear:(BOOL)animated{
    //Shoew tababr
    [[AppDelegate getAppDelegate] showTabBar:self.tabBarController];
}

-(void)viewWillAppear:(BOOL)animated
{
    if(!timerForCheckPlayTime)
        timerForCheckPlayTime=[NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(checkCurrentVideoPlayBackTime) userInfo:nil repeats:YES];
    //Hide tabbar
    [[AppDelegate getAppDelegate] hideTabBar:self.tabBarController];
}

-(void)viewDidDisappear:(BOOL)animated
{
    if(timerForCheckPlayTime)
    {
        [timerForCheckPlayTime invalidate];
        timerForCheckPlayTime=nil;
    }
    
    if(timerForVideoRecording)
    {
        [timerForVideoRecording invalidate];
        timerForVideoRecording=nil;
    }
}

#pragma mark Timer method
//Checking video playback time and pause if reach on end bound
-(void)checkCurrentVideoPlayBackTime
{
    //NSLog(@"::::::%f >= %i",self.movieController.currentPlaybackTime,endTime);
    if(endTime>0 && (int)self.movieController.currentPlaybackTime>=endTime)
    {
        self.movieController.currentPlaybackTime=endTime;
        [self.movieController pause];
    }
}

#pragma mark Button action methods

- (IBAction)flipCamera:(id)sender
{
    if([_btnFlip isSelected])
    {
        [_btnFlip setSelected:NO];
        cameraUI.cameraDevice = UIImagePickerControllerCameraDeviceRear;
    }
    else
    {
        [_btnFlip setSelected:YES];
        cameraUI.cameraDevice = UIImagePickerControllerCameraDeviceFront;
    }
}

- (IBAction)cancelCameraView:(id)sender
{
    [cameraUI.view removeFromSuperview];
}

- (IBAction)startVideoRecording:(id)sender
{
    NSLog(@"::::%i",[_btnStartRecording isSelected]);
    if([_btnStartRecording isSelected])
    {
        [_btnStartRecording setSelected:NO];
        [cameraUI stopVideoCapture];
        if(timerForVideoRecording)
        {
            [timerForVideoRecording invalidate];
            timerForVideoRecording=nil;
        }
    }
    else
    {
        [_btnStartRecording setSelected:YES];
        [cameraUI startVideoCapture];
        recordTime=0;
        if(!timerForVideoRecording)
            timerForVideoRecording=[NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(updateRecordingTime) userInfo:nil repeats:YES];
        _btnCancelRecording.hidden=YES;
        _btnFlip.hidden=YES;
        _lblTime.hidden=NO;
    }
}

-(IBAction)onClickBackButtom:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)PlayVideo:(id)sender
{
    if(isVideoSelected)
    {
        UIButton *btnPlayPause=(UIButton*)sender;
        if([btnPlayPause isSelected]){
            [btnPlayPause setSelected:NO];
            [self.movieController pause];
        }
        else{
            [btnPlayPause setSelected:YES];
            [self.movieController play];
        }
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have to record a Skoop first!" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

- (IBAction)RecordAndPlay:(id)sender {
    
//    if([_btnRecordVideo isSelected])
//    {
//        [self.cam captureVideoStop];
//        [_btnRecordVideo setSelected:NO];
//    }
//    else
//    {
        UIActionSheet *imageAction=[[UIActionSheet alloc]initWithTitle:@"Pick video" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Gallery",nil];
        imageAction.delegate=self;
        [imageAction showInView:self.view];
  //  }
}

- (IBAction)onClickForwardButton:(id)sender{
    NSLog(@"onClickForwardButton");
    if(isVideoSelected)
        self.movieController.currentPlaybackTime=endTime;
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have to record a Skoop first!" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

- (IBAction)onClickRevindButton:(id)sender{
    NSLog(@"onClickRevindButton");
    if(isVideoSelected)
        self.movieController.currentPlaybackTime=startTime;
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have to record a Skoop first!" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(IBAction)onClickSendButtom:(id)sender
{
    [self.movieController pause];
    durationTime = endTime - startTime;
    
    if(endTime==0 && startTime==0)
        durationTime = self.movieController.duration;
    else if(startTime>0 && endTime==0)
        durationTime = self.movieController.duration-startTime;
    else if(startTime==0)
        durationTime = endTime;
    
    if(isVideoSelected){
        if (durationTime < 3)
            [AppHelper showAlertViewWithTag:111 title: AppName message:@"Your Skoop needs to be longer than 3 seconds." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        else  if (durationTime > 60)
            [AppHelper showAlertViewWithTag:111 title: AppName message:@"Video length can't exceed 60 seconds." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        else
        {
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [self cropVideo:self.urlString];
        }
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have to record a Skoop first!" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

#pragma mark Method for update call duration
-(void)updateRecordingTime
{
    NSLog(@"callDuration::::::%i",recordTime);
    recordTime++;
    if(recordTime/60)
    {
        if(recordTime/60>9 && recordTime%60>9)
            _lblTime.text=[NSString stringWithFormat:@"%i:%i",recordTime/60,recordTime%60];
        else if(recordTime/60<9 && recordTime%60>9)
            _lblTime.text=[NSString stringWithFormat:@"0%i:%i",recordTime/60,recordTime%60];
        else if(recordTime/60>9 && recordTime%60<9)
            _lblTime.text=[NSString stringWithFormat:@"%i:0%i",recordTime/60,recordTime%60];
        else if(recordTime/60<9 && recordTime%60<9)
            _lblTime.text=[NSString stringWithFormat:@"0%i:0%i",recordTime/60,recordTime%60];
    }
    else if(recordTime>9)
        _lblTime.text=[NSString stringWithFormat:@"00:%i",recordTime];
    else
        _lblTime.text=[NSString stringWithFormat:@"00:0%i",recordTime];
}


// Handle control value changed events just like a normal slider
- (IBAction)labelSliderChanged:(NMRangeSlider*)sender
{
    if(isVideoSelected)
    {
        self.movieController.currentPlaybackTime =(NSTimeInterval) (sender.lowerValue * self.movieController.duration);
        
        int lowerValue=(int)(sender.lowerValue * self.movieController.duration);
        int upperValue=(int)(sender.upperValue * self.movieController.duration);
        startTime= lowerValue ;
        endTime= upperValue ;
        if(![self isValidVideoLength:endTime-startTime])
            return;
        
        if(lowerValue/60>0){
            if((lowerValue%60)>9)
                self.lowerLabel.text = [NSString stringWithFormat:@"Start at 0%i:%i",(int)(lowerValue/60),(lowerValue%60)];
            else
                self.lowerLabel.text = [NSString stringWithFormat:@"Start at 0%i:0%i",(int)(lowerValue/60),(lowerValue%60)];
        }
        else{
            if((lowerValue%60)>9)
                self.lowerLabel.text = [NSString stringWithFormat:@"Start at 00:%i",(lowerValue%60)];
            else
                self.lowerLabel.text = [NSString stringWithFormat:@"Start at 00:0%i",(lowerValue%60)];
        }
        
        if(upperValue/60>0){
            if((upperValue%60)>9)
                self.upperLabel.text = [NSString stringWithFormat:@"End at 0%i:%i",(int)(upperValue/60),(upperValue%60)];
            else
                self.upperLabel.text = [NSString stringWithFormat:@"End at 0%i:0%i",(int)(upperValue/60),(upperValue%60)];
        }
        else{
            if((upperValue%60)>9)
                self.upperLabel.text = [NSString stringWithFormat:@"End at 00:%i",(upperValue%60)];
            else
                self.upperLabel.text = [NSString stringWithFormat:@"End at 00:0%i",(upperValue%60)];
        }
    }
//    else
//        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have to record a Skoop first!" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(BOOL)isValidVideoLength:(NSInteger)videoLength
{
    if(videoLength<3)
    {
        _lblWarning.hidden=NO;
        self.upperLabel.hidden=YES;
        self.lowerLabel.hidden=YES;
        
        //Set slider frame
        CGRect frameRect=self.labelSlider.frame;
        frameRect.origin.y=viewBottom.bounds.size.height-33;
        self.labelSlider.frame=frameRect;
        
        return NO;
    }
    else
    {
        _lblWarning.hidden=YES;
        self.upperLabel.hidden=NO;
        self.lowerLabel.hidden=NO;
        
        //Set slider frame
        CGRect frameRect=self.labelSlider.frame;
        frameRect.origin.y=viewBottom.bounds.size.height-43;
        self.labelSlider.frame=frameRect;
        
        return YES;
    }
}

-(void)callWebserviceFOrReply
{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm a / dd MMM, yyyy "];
    
    NSDictionary *dataDict=[[NSDictionary alloc] initWithObjectsAndKeys:[dateFormatter stringFromDate:[NSDate date]],@"date",[AppHelper userDefaultsForKey:KUserImageUrl],@"image",@"",@"message",[AppHelper userDefaultsForKey:KUserName],@"name",@"0",@"paymentStatus",thumbnail,@"thumbimage",[AppHelper userDefaultsForKey:KUserId],@"user_id",videoPathString,@"video_path",videoData,@"video_data",self.skoopId,@"skoop_id",[NSString stringWithFormat:@"%i",durationTime],@"duration", nil];
        
    [[self videoLoaderDelegate] updateSkoopReplyDataWithDataDict:dataDict];
    [AppDelegate dismissGlobalHUD];
    
//    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnSkoop:) name:Notification_reply_on_skoop object:nil];
    if (!_isUploadVideoForGroup) {
        [[WebServicesController WebServiceMethod] replyOnSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:self.skoopId groupId:_groupId replyVideo:videoData andToken:KAppToken];
    } else {
        [[WebServicesController WebServiceMethod] replyOnSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:@"1" groupId:_groupId replyVideo:videoData andToken:KAppToken];
    }
    
    [self.navigationController popViewControllerAnimated:NO];
}

#pragma mark get notifications
-(void)userDidReplyOnSkoop:(NSNotification *)notification{
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_reply_on_skoop object:nil];
    NSDictionary *dict=notification.userInfo;
    
    NSLog(@"getMyScoopDataResponse response %@",dict);
    
    if(dict!=nil){
        if([[dict valueForKey:@"errorCode"] integerValue]==0){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Count object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"skoops",@"req_type", nil]];
            [[self videoLoaderDelegate] setRequiredBoolVariable:YES];
            [self.navigationController popViewControllerAnimated:YES];
            
        }
        else
            [AppHelper showAlertViewWithTag:1 title:AppName message:[dict valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
    }
}

//Receive notification for video player current state and according this set play button image
-(void)didChangeVideoPlayBackState:(NSNotification*)noti{
    if(self.movieController.playbackState==MPMoviePlaybackStateStopped || self.movieController.playbackState==MPMoviePlaybackStatePaused)
       [_btnPlayPause setSelected:NO];
    else if (self.movieController.playbackState==MPMoviePlaybackStatePlaying)
        [_btnPlayPause setSelected:YES];
}

#pragma mark-ActionSheetDelegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex {
    
    switch (buttonIndex){
        case 0:{
            NSLog(@"camera");
            sourceForVideo = camera;
            if (self.movieController) {
                [self.movieController pause];
            }
            [self startCameraControllerFromViewController: self
                                            usingDelegate: self andAnimation:YES];
            
            CGRect frameRect1=viewBottom.frame;
            frameRect1.origin.y=self.view.bounds.size.height;
            viewBottom.frame=frameRect1;
            
            break;
        }
        case 1:{
            NSLog(@"gallery");
            [_btnRecordVideo setSelected:YES];
            sourceForVideo = gallery;
            if (self.movieController) {
                [self.movieController pause];
            }
            [self startMediaBrowserFromViewController:self usingDelegate:self];
            break;
        }
        default:
            break;
    }
}

#pragma mark Videoplayer deligates
- (void)moviePlaybackComplete:(NSNotification *)notification{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:MPMoviePlayerPlaybackDidFinishNotification object:nil];
    
    if (self.movieController) {
        [self.movieController stop];
        [self.movieController.view removeFromSuperview];
        self.movieController = nil;
    }
    
    _movieController  = [[MPMoviePlayerController alloc] initWithContentURL:_urlString];
    _movieController.controlStyle=MPMovieControlStyleNone;
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(moviePlaybackComplete:)
                                                 name:MPMoviePlayerPlaybackDidFinishNotification
                                               object:nil];
    [[self.movieController view] setFrame: [_viewFormovieController bounds]];
    [_viewFormovieController addSubview: [self.movieController view]];
    self.movieController.initialPlaybackTime=startTime;
    [self.movieController play];
    [self performSelector:@selector(pauseVideoWithDelay) withObject:nil afterDelay:0.3];
}

-(void)pauseVideoWithDelay{
    [_btnPlayPause setSelected:NO];
    [self.movieController pause];
}

#pragma mark imagePicker Delegates

- (BOOL) startMediaBrowserFromViewController: (UIViewController*) controller
                               usingDelegate: (id <UIImagePickerControllerDelegate,
                                               UINavigationControllerDelegate>) delegate{
    
    if (([UIImagePickerController isSourceTypeAvailable:
          UIImagePickerControllerSourceTypeSavedPhotosAlbum] == NO)
        || (delegate == nil)
        || (controller == nil))
        return NO;
    
    UIImagePickerController *mediaUI = [[UIImagePickerController alloc] init];
    mediaUI.sourceType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    mediaUI.mediaTypes = [[NSArray alloc] initWithObjects: (NSString *) kUTTypeMovie, nil];
    
    // Hides the controls for moving & scaling pictures, or for
    // trimming movies. To instead show the controls, use YES.
    mediaUI.allowsEditing = NO;
    mediaUI.delegate = delegate;
    [controller presentViewController:mediaUI animated:YES completion:nil];
    
    return YES;
    
}


- (BOOL) startCameraControllerFromViewController: (UIViewController*) controller
                                   usingDelegate: (id <UIImagePickerControllerDelegate,
                                                   UINavigationControllerDelegate>) delegate andAnimation:(BOOL)isYes{
    
    if (([UIImagePickerController isSourceTypeAvailable:
          UIImagePickerControllerSourceTypeCamera] == NO)
        || (delegate == nil)
        || (controller == nil))
        return NO;
    
    if(cameraUI)
        cameraUI=nil;
    cameraUI = [[UIImagePickerController alloc] init];
    cameraUI.sourceType = UIImagePickerControllerSourceTypeCamera;
    
    // Displays a control that allows the user to choose movie capture
    cameraUI.mediaTypes = [[NSArray alloc] initWithObjects: (NSString *) kUTTypeMovie, nil];
    
    // Hides the controls for moving & scaling pictures, or for
    cameraUI.showsCameraControls=NO;
    
    //Add overlay
    cameraUI.cameraOverlayView=_cameraOverLayView;
    
    // trimming movies. To instead show the controls, use YES.
    cameraUI.allowsEditing = NO;
    cameraUI.delegate = delegate;
    if(IS_Greater_Or_Equal_to_IOS_7)
        cameraUI.view.frame=CGRectMake(0, 64, 320, self.view.frame.size.height-64);
    else
        cameraUI.view.frame=CGRectMake(0, 44, 320, self.view.frame.size.height-44);
    
    if([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear])
    {
        cameraUI.cameraDevice=UIImagePickerControllerCameraDeviceRear;
        _btnFlip.hidden=NO;
    }
    else
    {
        cameraUI.cameraDevice=UIImagePickerControllerCameraDeviceFront;
        _btnFlip.hidden=YES;
    }
    
    CGRect frameRect=_cameraOverLayView.frame;
    frameRect.size.height=cameraUI.view.frame.size.height;
    _cameraOverLayView.frame=frameRect;
   // [controller presentViewController:cameraUI animated:NO completion:nil];
    
    _btnCancelRecording.hidden=NO;
    _lblTime.hidden=YES;
    
    [self.view addSubview:cameraUI.view];
    
    return YES;
}


// For responding to the user accepting a newly-captured picture or movie
- (void) imagePickerController: (UIImagePickerController *) picker
 didFinishPickingMediaWithInfo: (NSDictionary *) info {
    
    CGRect frameRect1=viewBottom.frame;
    frameRect1.origin.y=self.view.bounds.size.height-120;
    viewBottom.frame=frameRect1;
    
    NSString *mediaType = [info objectForKey: UIImagePickerControllerMediaType];///
    
    //[self dismissViewControllerAnimated:NO completion:nil];
    _viewFormovieController.backgroundColor=[UIColor clearColor];
     [AppHelper stausBarColorChange];
 
    if (self.movieController) {
        [self.movieController stop];
        [self.movieController.view removeFromSuperview];
        self.movieController = nil;
    }
    NSString *moviePath =(__bridge NSString*) [[info objectForKey:UIImagePickerControllerMediaURL] path];

    // Handle a movie capture
    if (CFStringCompare ((__bridge CFStringRef)mediaType, kUTTypeMovie, 0)
        == kCFCompareEqualTo) {
        
        // If source type is camera, wait till video is saved to library and then instantiate movieController
        // If source type is galley , instantiate moviecontroller right away.
        
        if ( sourceForVideo == camera ){
            if (UIVideoAtPathIsCompatibleWithSavedPhotosAlbum (moviePath)){
                if(!spinner)
                    spinner = [[UIActivityIndicatorView alloc]
                                                    initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                spinner.center = _viewFormovieController.center;
                spinner.hidesWhenStopped = YES;
                [self.view addSubview:spinner];
                [spinner startAnimating];
                isVideoSelected=YES;
                self.labelSlider.isSlide=YES;
                UISaveVideoAtPathToSavedPhotosAlbum (moviePath,self, @selector(video:didFinishSavingWithError:contextInfo:), nil);
                [_btnRecordVideo setImage:[UIImage imageNamed:@"re-record.png"] forState:UIControlStateNormal];
            }
        }
        else if (sourceForVideo == gallery){
            _urlString = [info objectForKey:UIImagePickerControllerMediaURL];
            if(_movieController)
                self.movieController.contentURL = _urlString;
            else
                _movieController  = [[MPMoviePlayerController alloc] initWithContentURL:_urlString];
            _movieController.controlStyle=MPMovieControlStyleNone;
            
            [[NSNotificationCenter defaultCenter] addObserver:self
                                                     selector:@selector(moviePlaybackComplete:)
                                                         name:MPMoviePlayerPlaybackDidFinishNotification
                                                       object:nil];
            [[self.movieController view] setFrame:[_viewFormovieController bounds]];
            [_viewFormovieController addSubview: [self.movieController view]];
            [self.movieController play];
            isVideoSelected=YES;
            self.labelSlider.isSlide=YES;
            thumbnail = [self.movieController thumbnailImageAtTime:1.0 timeOption:MPMovieTimeOptionNearestKeyFrame];
            
            [self performSelector:@selector(pauseVideoWithDelay) withObject:nil afterDelay:0.3];
            [self performSelector:@selector(setInitialStartAndEndVideoTime) withObject:nil afterDelay:0.5];
            
            [_btnRecordVideo setImage:[UIImage imageNamed:@"re-record.png"] forState:UIControlStateNormal];
        }
        [picker dismissViewControllerAnimated:YES completion:nil];
        [self.movieController view].backgroundColor = [UIColor clearColor];
        
    }
}

-(void)setInitialStartAndEndVideoTime{
    int upperValue=(int)self.movieController.duration;
    if(![self isValidVideoLength:upperValue])
        return;
    
    self.lowerLabel.text = @"Start at 00:00";
    
    if(upperValue/60>0){
        if((upperValue%60)>9)
            self.upperLabel.text = [NSString stringWithFormat:@"End at 0%i:%i",(int)(upperValue/60),(upperValue%60)];
        else
            self.upperLabel.text = [NSString stringWithFormat:@"End at 0%i:0%i",(int)(upperValue/60),(upperValue%60)];
    }
    else{
        if((upperValue%60)>9)
            self.upperLabel.text = [NSString stringWithFormat:@"End at 00:%i",(upperValue%60)];
        else
            self.upperLabel.text = [NSString stringWithFormat:@"End at 00:0%i",(upperValue%60)];
    }
}

// For responding to the user tapping Cancel.
- (void) imagePickerControllerDidCancel: (UIImagePickerController *) picker {
    
    if (self.movieController) {
        [self.movieController play];
    }
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)video:(NSString*)videoPath didFinishSavingWithError:(NSError*)error contextInfo:(void*)contextInfo
{
    if (error) {
        [AppHelper showAlertViewWithTag:1 title:@"Error" message:@"Video saving failed,please try again" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        [spinner stopAnimating];
    }
    else{
        [spinner stopAnimating];

        _urlString = [NSURL fileURLWithPath:videoPath];
        
        if(_movieController)
            self.movieController.contentURL=_urlString;
        else
            _movieController  = [[MPMoviePlayerController alloc] initWithContentURL:_urlString];
        _movieController.controlStyle=MPMovieControlStyleNone;
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(moviePlaybackComplete:)
                                                     name:MPMoviePlayerPlaybackDidFinishNotification
                                                   object:nil];
        [[self.movieController view] setFrame: [_viewFormovieController bounds]];
        [_viewFormovieController addSubview: [self.movieController view]];
        [self.movieController play];
        thumbnail = [self.movieController thumbnailImageAtTime:1.0 timeOption:MPMovieTimeOptionNearestKeyFrame];
        
        [self performSelector:@selector(pauseVideoWithDelay) withObject:nil afterDelay:0.3];
        [self performSelector:@selector(setInitialStartAndEndVideoTime) withObject:nil afterDelay:0.5];
        
        [cameraUI.view removeFromSuperview];
    }
}

#pragma mark video cropping method and hit webservice for skoop reply

-(void)cropVideo:(NSURL*)videoToTrimURL
{
    NSLog(@"videoToTrimURL::::::%@",videoToTrimURL);
    AVURLAsset *asset = [AVURLAsset URLAssetWithURL:videoToTrimURL options:nil];
    
    AVAssetExportSession *exportSession = [[AVAssetExportSession alloc] initWithAsset:asset presetName:AVAssetExportPresetHighestQuality];
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *outputURL = paths[0];
    
    NSFileManager *manager = [NSFileManager defaultManager];
    [manager createDirectoryAtPath:outputURL withIntermediateDirectories:YES attributes:nil error:nil];
    outputURL = [outputURL stringByAppendingPathComponent:@"Video2.mp4"];
    
    // Remove Existing File
    [manager removeItemAtPath:outputURL error:nil];
     
    exportSession.outputURL = [NSURL fileURLWithPath:outputURL];
    exportSession.shouldOptimizeForNetworkUse = YES;
    exportSession.outputFileType = AVFileTypeMPEG4;
    
    CMTime start = CMTimeMakeWithSeconds(startTime, 600); // you will modify time range here
    CMTime duration = CMTimeMakeWithSeconds(durationTime, 600);
    CMTimeRange range = CMTimeRangeMake(start, duration);
    exportSession.timeRange = range;
    
    [exportSession exportAsynchronouslyWithCompletionHandler:^(void)
     {
         switch (exportSession.status)
         {
             case AVAssetExportSessionStatusCompleted:
                 
                 NSLog(@"::::====%@",_urlString);
                 unsigned long long fileSize = [[[NSFileManager defaultManager] attributesOfItemAtPath:outputURL error:nil] fileSize];
                 float sizeInMB = fileSize/(1024*1024);
                 if (sizeInMB > 50)
                     [AppHelper showAlertViewWithTag:99 title:@"FileSize Limit Reached" message:@"Video Can't Exceed to 50 MB." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                 else{
                     self.urlString=[NSURL fileURLWithPath:outputURL];
                     if(!videoData)
                         videoData=[[NSData alloc] initWithContentsOfURL:self.urlString];
                     else
                         videoData=[NSData dataWithContentsOfURL:self.urlString];
                     
                     dispatch_async(dispatch_get_main_queue(), ^{
                        NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
                        NSString *documentsDirectory = [paths objectAtIndex:0];
                        videoPathString= [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"/movie%@.mov",self.skoopId]];
                         [self callWebserviceFOrReply];
                    });
                 }
                 break;
             
             case AVAssetExportSessionStatusFailed:
                 NSLog(@"Failed:%@",exportSession.error);
                 [AppDelegate dismissGlobalHUD];
                 [AppHelper showAlertViewWithTag:102 title:@"Error" message:@"Error in saving video" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                 break;
             
             case AVAssetExportSessionStatusCancelled:
                 NSLog(@"Canceled:%@",exportSession.error);
                 [AppDelegate dismissGlobalHUD];
                 [AppHelper showAlertViewWithTag:103 title:@"Cancelled" message:@"Process has been cancelled" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
                 break;
             
             default:
                 break;
         }
         
     }];
}

#pragma mark - CustomSlider

- (void) configureLabelSlider{
    
    self.labelSlider.minimumValue = 0;
    self.labelSlider.maximumValue = 100;
    
    self.labelSlider.lowerValue = 0;
    self.labelSlider.upperValue = 100;
    
    self.labelSlider.minimumRange = 1;
}

- (void)didReceiveMemoryWarning
{
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
}

- (void)viewDidUnload{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
    
    if (self.movieController) {
        [self.movieController stop];
        [self.movieController.view removeFromSuperview];
        self.movieController = nil;
    }
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_reply_on_skoop object:nil];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


@end
