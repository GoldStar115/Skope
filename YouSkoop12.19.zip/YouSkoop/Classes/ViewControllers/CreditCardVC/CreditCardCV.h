//
//  CreditCardCV.h
//  youskoop
//
//  Created by Shitesh Patel on 10/09/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface CreditCardCV : UIViewController{
    
}
@end
