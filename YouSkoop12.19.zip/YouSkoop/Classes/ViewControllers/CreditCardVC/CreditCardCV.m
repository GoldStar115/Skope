//
//  CreditCardCV.m
//  youskoop
//
//  Created by Shitesh Patel on 10/09/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "CreditCardCV.h"

@interface CreditCardCV (){
    NSMutableDictionary *creditInfoDict;
    NSString *rechargeAmount;
    UITextField *txtCurrentFocus;
    __weak IBOutlet UIView *_viewWebView;
    __weak IBOutlet UIView *_viewWithdraw;
    __weak IBOutlet UILabel *_lblWithdrawableAmount;
    __weak IBOutlet UILabel *_lblPendingBalance;
    __weak IBOutlet UITextField *_txtWithdrawAmount;
}

@property (nonatomic, strong) IBOutlet UIWebView *_webView;
@end

@implementation CreditCardCV

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    UIImageView *imgPurchaseMsgBase = (UIImageView *)[_viewWithdraw viewWithTag:101];
    imgPurchaseMsgBase.layer.cornerRadius = 5.0;
    
    creditInfoDict = [[NSMutableDictionary alloc] init];
    [creditInfoDict setValue:@"" forKey:@"email"];
    txtCurrentFocus = [[UITextField alloc] init];
    _viewWebView.hidden =  YES;
    
    self._webView.contentMode = UIViewContentModeScaleAspectFill;
    self._webView.scalesPageToFit = YES;
    self._webView.autoresizingMask = (UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight);
    
    UILabel *lblAmount = (UILabel*)[self.view viewWithTag:600];
    if([AppHelper userDefaultsForKey:KAvailableCredit])
        lblAmount.text = [NSString stringWithFormat:@"youSKOOP Balance:$ %.2f",[[AppHelper userDefaultsForKey:KAvailableCredit] floatValue]];
    else
        lblAmount.text = @"youSKOOP Balance:$ 0.0";
    
    if(![AppHelper userDefaultsDictionaryDataForKey:KSavedCCInfo]){
    
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetCreditCardInfo:) name:Notification_Get_CCInfo object:nil];
        [[WebServicesController WebServiceMethod] getCreditCardInfoWithUserId:[AppHelper userDefaultsForKey:KUserId] paymentInfo:@"both" andAppToken:KAppToken];
    }
    else{
        
        creditInfoDict = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[AppHelper userDefaultsDictionaryDataForKey:KSavedCCInfo]];
        [self displayCreditCartInfo];
    }
}

-(void)viewWillAppear:(BOOL)animated{
    //Hide tabbar
    [[AppDelegate getAppDelegate] hideTabBar:self.tabBarController];
}
-(void)viewWillDisappear:(BOOL)animated{
    //Show tabbar
    [[AppDelegate getAppDelegate] showTabBar:self.tabBarController];
}

#pragma mark Button action methods
-(IBAction)onClickBackButton:(id)sender{
    
    if([_viewWebView isHidden]){
        [self.navigationController popViewControllerAnimated:YES];
    }
    else{
        _viewWebView.hidden = YES;
        [self._webView stopLoading];
    }
}

- (IBAction)submitBtnPressed:(UIButton *)sender{
    
    if([txtCurrentFocus isFirstResponder])
        [txtCurrentFocus resignFirstResponder];
    
    NSString *warningStr=NULL;
    
    if([AppHelper userDefaultsDictionaryDataForKey:KSavedCCInfo]){
        
        if([[creditInfoDict valueForKey:@"ccno"] hasPrefix:@"xxxxxxx"]){
            
            warningStr = [self checkCreditCardFields];
            
            if(warningStr!=NULL){
                
                [AppHelper showAlertViewWithTag:0 title:AppName message:warningStr delegate:Nil cancelButtonTitle:nil otherButtonTitles:@"ok"];
            }
            else{
                
                [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSaveCreditCardInfo:) name:Notification_Save_CCInfo object:nil];
                [[WebServicesController WebServiceMethod] saveCreditCardInfoWithUserId:[AppHelper userDefaultsForKey:KUserId] firstName:[creditInfoDict valueForKey:@"fname"] lastName:[creditInfoDict valueForKey:@"lname"] cardNumber:[creditInfoDict valueForKey:@"ccno"] cardType:[creditInfoDict valueForKey:@"cardtype"] expiryMonth:[creditInfoDict valueForKey:@"expmonth"] expiryYear:[creditInfoDict valueForKey:@"expyear"] cvvCode:[creditInfoDict valueForKey:@"cvc"] paypalEmal:[creditInfoDict valueForKey:@"email"] isSaveCard:@"0" andAppToken:KAppToken];
            }
        }
        else{
            warningStr = [self checkCreditCardFields];
            
            if(warningStr!=NULL){
                
                [AppHelper showAlertViewWithTag:0 title:AppName message:warningStr delegate:Nil cancelButtonTitle:nil otherButtonTitles:@"ok"];
            }
            else{
            
                [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSaveCreditCardInfo:) name:Notification_Save_CCInfo object:nil];
                [[WebServicesController WebServiceMethod] saveCreditCardInfoWithUserId:[AppHelper userDefaultsForKey:KUserId] firstName:[creditInfoDict valueForKey:@"fname"] lastName:[creditInfoDict valueForKey:@"lname"] cardNumber:[creditInfoDict valueForKey:@"ccno"] cardType:[creditInfoDict valueForKey:@"cardtype"] expiryMonth:[creditInfoDict valueForKey:@"expmonth"] expiryYear:[creditInfoDict valueForKey:@"expyear"] cvvCode:[creditInfoDict valueForKey:@"cvc"] paypalEmal:[creditInfoDict valueForKey:@"email"] isSaveCard:@"1" andAppToken:KAppToken];
            }
            
            
        }
    }
    else{
        warningStr = [self checkCreditCardFields];
        
        if(warningStr!=NULL){
            [AppHelper showAlertViewWithTag:0 title:AppName message:warningStr delegate:Nil cancelButtonTitle:nil otherButtonTitles:@"ok"];
        }
        else{
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSaveCreditCardInfo:) name:Notification_Save_CCInfo object:nil];
            [[WebServicesController WebServiceMethod] saveCreditCardInfoWithUserId:[AppHelper userDefaultsForKey:KUserId] firstName:[creditInfoDict valueForKey:@"fname"] lastName:[creditInfoDict valueForKey:@"lname"] cardNumber:[creditInfoDict valueForKey:@"ccno"] cardType:[creditInfoDict valueForKey:@"cardtype"] expiryMonth:[creditInfoDict valueForKey:@"expmonth"] expiryYear:[creditInfoDict valueForKey:@"expyear"] cvvCode:[creditInfoDict valueForKey:@"cvc"] paypalEmal:[creditInfoDict valueForKey:@"email"] isSaveCard:@"1" andAppToken:KAppToken];
        }
    }
}

-(IBAction)onClickRechargeButton:(id)sender{
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:AppName message:@"Please select your payment option to recharge your youSKOOP account." delegate:self cancelButtonTitle:Alert_Cancel otherButtonTitles:@"PayPal",@"Credit Card", nil];
    alertView.tag = 2;
    [alertView show];
}

-(IBAction)onClickRedeemButton:(id)sender{
    
    if([_viewWithdraw superview] == nil){
        
        [self.view addSubview:_viewWithdraw];
        _lblWithdrawableAmount.text = [NSString stringWithFormat:@"Maximum withdrawable amount: $%@",[AppHelper userDefaultsForKey:KRedeemAmount]];
        _lblPendingBalance.text = [NSString stringWithFormat:@"Pending balance: $%.2f",[[AppHelper userDefaultsForKey:KAvailableCredit] floatValue] - [[AppHelper userDefaultsForKey:KRedeemAmount] floatValue]];
    }
}

-(IBAction)onClickWithdrawButton:(id)sender{
    
    if([txtCurrentFocus isFirstResponder]){
        
        [txtCurrentFocus resignFirstResponder];
    }
    
    if(_txtWithdrawAmount.text && [_txtWithdrawAmount.text floatValue] > 0){
        
        if([_txtWithdrawAmount.text floatValue] <= [[AppHelper userDefaultsForKey:KRedeemAmount] floatValue]){
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidRedeemedOurBalance:) name:Notification_Redeem_Point object:nil];
            [[WebServicesController WebServiceMethod] redeemYourPointWithUserId:[AppHelper userDefaultsForKey:KUserId] redeemAmount:[NSString stringWithFormat:@"%.2f",[_txtWithdrawAmount.text floatValue]] andAppToken:KAppToken];
        }
        else{
            
            [AppHelper showAlertViewWithTag:5 title:AppName message:@"Withdraw amount must be less than withdrawable amount." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
    }
    else{
        
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please enter your withdraw amount" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

-(IBAction)onClickCancelButton:(id)sender{
    
    if([txtCurrentFocus isFirstResponder]){
        
        [txtCurrentFocus resignFirstResponder];
    }
    [_viewWithdraw removeFromSuperview];
}

-(NSString*)checkCreditCardFields{
    
    NSString *warningStr=NULL;
    if(![creditInfoDict valueForKey:@"fname" ] || [[creditInfoDict valueForKey:@"fname"] length] == 0)
        warningStr=@"Please enter first name.";
    
    else if(![creditInfoDict valueForKey:@"lname" ] || [[creditInfoDict valueForKey:@"lname"] length] == 0)
        warningStr=@"Please enter last name.";
    
    else if(![creditInfoDict valueForKey:@"ccno"] || [[creditInfoDict valueForKey:@"ccno"] length] == 0)
        warningStr=@"Please enter credit card number.";
    
    else if(![creditInfoDict valueForKey:@"expmonth" ] || [[creditInfoDict valueForKey:@"expmonth"] length] == 0)
        warningStr=@"Please enter expiry month.";
    
    else if([[creditInfoDict valueForKey:@"expmonth"] integerValue] <=0 || [[creditInfoDict valueForKey:@"expmonth"] integerValue] >12)
        warningStr=@"Please enter valid expiry month.";
    
    else if(![creditInfoDict valueForKey:@"expyear" ] || [[creditInfoDict valueForKey:@"expyear" ] length] == 0)
        warningStr=@"Please enter expiry year.";
    
    else if(![creditInfoDict valueForKey:@"cvc" ] || [[creditInfoDict valueForKey:@"cvc" ] length] == 0)
        warningStr=@"Please enter cvc number.";
    
    else if([creditInfoDict valueForKey:@"email" ] && [[creditInfoDict valueForKey:@"email"] length] > 0){
        
        if(![AppHelper emailValidate:[creditInfoDict valueForKey:@"email" ]]){
            warningStr = @"Please enter valid paypal e-mail.";
        }
        else if(![creditInfoDict valueForKey:@"cemail"] || [[creditInfoDict valueForKey:@"cemail"] length] == 0)
            warningStr=@"Please enter your PayPal e-mail to redeem your earnings.";
        else if (![[creditInfoDict valueForKey:@"email" ] isEqualToString:[creditInfoDict valueForKey:@"cemail" ]])
            warningStr=@"PayPal e-mail and confirm e-mail does not match.";
    }
    else if(![creditInfoDict valueForKey:@"email"] || [[creditInfoDict valueForKey:@"email"] length] == 0)
        warningStr=@"Please enter your PayPal e-mail to redeem your earnings.";
    else if(![AppHelper checkCreditCardNumber:[creditInfoDict valueForKey:@"ccno"]])
        warningStr = @"Please enter valid credit card number";{
    }
    return warningStr;
}

#pragma mark -  TextField Delegate
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    
    txtCurrentFocus = textField;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField{
    
    UIImageView *imgCardType = (UIImageView*)[self.view viewWithTag:508];
    imgCardType.image = [UIImage imageNamed:@""];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    
    if(textField == _txtWithdrawAmount){
        [textField resignFirstResponder];
    }
    else if([textField tag] != 507){
        
        UITextField *nextTxtField = (UITextField*)[self.view viewWithTag:[textField tag] + 1];
        [nextTxtField becomeFirstResponder];
    }
    
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    
    NSLog(@"textFieldDidEndEditing");
    if([textField tag] == 500)
        [creditInfoDict setValue:textField.text forKey:@"fname"];
    else if([textField tag] == 501)
        [creditInfoDict setValue:textField.text forKey:@"lname"];
    else if([textField tag] == 502){
        [creditInfoDict setValue:textField.text forKey:@"ccno"];
    }
    else if([textField tag] == 503){
        [creditInfoDict setValue:textField.text forKey:@"expmonth"];
    }
    else if([textField tag] == 504){
        NSDateFormatter *dateFormatter  =  [[NSDateFormatter alloc] init];
        [dateFormatter setDateFormat:@"yyyy"];
        NSString *year = [dateFormatter stringFromDate:[NSDate date]];
        year = [year substringWithRange:NSMakeRange(0, 2)];
        [creditInfoDict setValue:[NSString stringWithFormat:@"%@%@",year,textField.text] forKey:@"expyear"];
    }
    else if([textField tag] == 505)
        [creditInfoDict setValue:textField.text forKey:@"cvc"];
    else if([textField tag] == 506)
        [creditInfoDict setValue:textField.text forKey:@"email"];
    else if([textField tag] == 507)
        [creditInfoDict setValue:textField.text forKey:@"cemail"];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if(textField.tag == 502){
        NSString *resultStr = [textField.text stringByReplacingCharactersInRange:range withString:string];
        
        if([resultStr length] <= 4){
            UIImageView *imgCardType = (UIImageView*)[self.view viewWithTag:508];
            if([AppHelper checkCardBrandWithNumber:resultStr] == CreditCardBrandMasterCard){
                imgCardType.image = [UIImage imageNamed:@"mastercard.png"];
                [creditInfoDict setValue:@"mastercard" forKey:@"cardtype"];
            }
            else if([AppHelper checkCardBrandWithNumber:resultStr] == CreditCardBrandVisa){
                imgCardType.image = [UIImage imageNamed:@"visacard.png"];
                [creditInfoDict setValue:@"visa" forKey:@"cardtype"];
            }
            else if([AppHelper checkCardBrandWithNumber:resultStr] == CreditCardBrandDiscover){
                imgCardType.image = [UIImage imageNamed:@"discovercard.png"];
                [creditInfoDict setValue:@"discover" forKey:@"cardtype"];
            }
            else if([AppHelper checkCardBrandWithNumber:resultStr] == CreditCardBrandDinersClub){
                imgCardType.image = [UIImage imageNamed:@""];
                [creditInfoDict setValue:@"dinersclub" forKey:@"cardtype"];
            }
            else if([AppHelper checkCardBrandWithNumber:resultStr] == CreditCardBrandAmex){
                imgCardType.image = [UIImage imageNamed:@""];
                [creditInfoDict setValue:@"amex" forKey:@"cardtype"];
            }
            else{
                imgCardType.image = [UIImage imageNamed:@""];
            }
        }
        if([resultStr length] <= 16)
            return YES;
        else
            return NO;
    }
    
    return YES;
}

#pragma mark Get weservices response
-(void)userDidGetCreditCardInfo:(NSNotification *)note
{
    NSLog(@"Reply Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_CCInfo object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            NSDictionary *dataInfo = [[note.userInfo objectForKey:@"data"] objectAtIndex:0];
            //Save credit card info
            if([dataInfo valueForKey:@"card_number"] && [[dataInfo valueForKey:@"card_number"] length] > 0)
                [creditInfoDict setValue:[dataInfo valueForKey:@"card_number"] forKey:@"ccno"];
            if([dataInfo valueForKey:@"first_name"] && [[dataInfo valueForKey:@"first_name"] length] > 0)
                [creditInfoDict setValue:[dataInfo valueForKey:@"first_name"] forKey:@"fname"];
            if([dataInfo valueForKey:@"last_name"] && [[dataInfo valueForKey:@"last_name"] length] > 0)
                [creditInfoDict setValue:[dataInfo valueForKey:@"last_name"] forKey:@"lname"];
            if([dataInfo valueForKey:@"card_type"] && [[dataInfo valueForKey:@"card_type"] length] > 0)
                [creditInfoDict setValue:[dataInfo valueForKey:@"card_type"] forKey:@"cardtype"];
            if([dataInfo valueForKey:@"expire_month"] && [[dataInfo valueForKey:@"expire_month"] length] > 0)
                [creditInfoDict setValue:[dataInfo valueForKey:@"expire_month"] forKey:@"expmonth"];
            if([dataInfo valueForKey:@"expire_year"] && [[dataInfo valueForKey:@"expire_year"] length] > 0)
                [creditInfoDict setValue:[dataInfo valueForKey:@"expire_year"] forKey:@"expyear"];
            if([dataInfo valueForKey:@"cvc"] && [[dataInfo valueForKey:@"cvc"] length] > 0)
                [creditInfoDict setValue:[dataInfo valueForKey:@"cvc"] forKey:@"cvc"];
            if([dataInfo valueForKey:@"paypal_email"] && [[dataInfo valueForKey:@"paypal_email"] length] > 0)
                [creditInfoDict setValue:[dataInfo valueForKey:@"paypal_email"] forKey:@"email"];
            
            [AppHelper saveToUserDefaults:[creditInfoDict mutableCopy] withKey:KSavedCCInfo];
            
            [self displayCreditCartInfo];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1){
            [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
    }
}

-(void)displayCreditCartInfo{
    //Display credit card info
    NSLog(@"%@",creditInfoDict);
    for (int i=500; i<508; i++) {
        UITextField *txtField = (UITextField*)[self.view viewWithTag:i];
        if(i == 500){
            txtField.text = [creditInfoDict valueForKey:@"fname"];
        }
        else if(i == 501){
            txtField.text = [creditInfoDict valueForKey:@"lname"];
        }
        else if(i == 502){
            txtField.text = [creditInfoDict valueForKey:@"ccno"];
            UIImageView *imgCardType = (UIImageView*)[self.view viewWithTag:508];
            if([[creditInfoDict valueForKey:@"cardtype"] isEqualToString:@"mastercard"]){
                imgCardType.image = [UIImage imageNamed:@"mastercard.png"];
            }
            else if([[creditInfoDict valueForKey:@"cardtype"] isEqualToString:@"visa"]){
                imgCardType.image = [UIImage imageNamed:@"visacard.png"];
            }
            else if([[creditInfoDict valueForKey:@"cardtype"] isEqualToString:@"discover"]){
                imgCardType.image = [UIImage imageNamed:@"discovercard.png"];
            }
            else if([[creditInfoDict valueForKey:@"cardtype"] isEqualToString:@"dinersclub"]){
                imgCardType.image = [UIImage imageNamed:@"dinersclub.png"];
            }
            else if([[creditInfoDict valueForKey:@"cardtype"] isEqualToString:@"amex"]){
                imgCardType.image = [UIImage imageNamed:@"amex.png"];
            }
        }
        else if(i == 503){
            txtField.text = [creditInfoDict valueForKey:@"expmonth"];
        }
        else if(i == 504){
            txtField.text = [creditInfoDict valueForKey:@"expyear"];
        }
        else if(i == 505){
            
            txtField.text = [creditInfoDict valueForKey:@"cvc"];
        }
        else if((i == 506 || i == 507) && [creditInfoDict valueForKey:@"email"] && [[creditInfoDict valueForKey:@"email"] length] > 0){
            txtField.text = [creditInfoDict valueForKey:@"email"];
        }
    }
}

-(void)userDidSaveCreditCardInfo:(NSNotification *)note{
    
    NSLog(@"Reply Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Save_CCInfo object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    
            NSMutableDictionary *dataInfo = [note.userInfo objectForKey:@"data"];
            
            NSMutableDictionary *ccData = [NSMutableDictionary dictionaryWithDictionary:(NSDictionary *)[AppHelper userDefaultsDictionaryDataForKey:KSavedCCInfo]];
            if(!ccData)
                ccData = [[NSMutableDictionary alloc] init];
            
            if([dataInfo valueForKey:@"card_number"] && [[dataInfo valueForKey:@"card_number"] length] > 0)
                [ccData setValue:[dataInfo valueForKey:@"card_number"] forKey:@"ccno"];
            if([dataInfo valueForKey:@"first_name"] && [[dataInfo valueForKey:@"first_name"] length] > 0)
                [ccData setValue:[dataInfo valueForKey:@"first_name"] forKey:@"fname"];
            if([dataInfo valueForKey:@"last_name"] && [[dataInfo valueForKey:@"last_name"] length] > 0)
                [ccData setValue:[dataInfo valueForKey:@"last_name"] forKey:@"lname"];
            if([dataInfo valueForKey:@"card_type"] && [[dataInfo valueForKey:@"card_type"] length] > 0)
                [ccData setValue:[dataInfo valueForKey:@"card_type"] forKey:@"cardtype"];
            if([dataInfo valueForKey:@"expire_month"] && [[dataInfo valueForKey:@"expire_month"] length] > 0)
                [ccData setValue:[dataInfo valueForKey:@"expire_month"] forKey:@"expmonth"];
            if([dataInfo valueForKey:@"expire_year"] && [[dataInfo valueForKey:@"expire_year"] length] > 0)
                [ccData setValue:[dataInfo valueForKey:@"expire_year"] forKey:@"expyear"];
            if([dataInfo valueForKey:@"ccv2"] && [[dataInfo valueForKey:@"ccv2"] length] > 0)
                [ccData setValue:[dataInfo valueForKey:@"ccv2"] forKey:@"cvc"];
            
//            [ccData setValue:[creditInfoDict valueForKey:@"ccno"] forKey:@"ccno"];
//            [ccData setValue:[creditInfoDict valueForKey:@"fname"] forKey:@"fname"];
//            [ccData setValue:[creditInfoDict valueForKey:@"lname"] forKey:@"lname"];
//            [ccData setValue:[creditInfoDict valueForKey:@"cardtype"] forKey:@"cardtype"];
//            [ccData setValue:[creditInfoDict valueForKey:@"expmonth"] forKey:@"expmonth"];
//            [ccData setValue:[creditInfoDict valueForKey:@"expyear"] forKey:@"expyear"];
//            [ccData setValue:[creditInfoDict valueForKey:@"cvc"] forKey:@"cvc"];
            
            [ccData setValue:[creditInfoDict valueForKey:@"email"] forKey:@"email"];
            [ccData setValue:[creditInfoDict valueForKey:@"email"] forKey:@"cemail"];
            
            
            [AppHelper saveToUserDefaults:ccData withKey:KSavedCCInfo];
            [self.navigationController popViewControllerAnimated:YES];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1){
            [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
    }
}

-(void)userDidRechargeAccount:(NSNotification *)note
{
    NSLog(@"Reply Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Recharge_Account object:nil];
    if (note.userInfo){
        if([[note.userInfo valueForKey:@"errorCode"] integerValue] == 0){
            if(![[note.userInfo valueForKey:@"total_amount"] isKindOfClass:[NSNull class]]){
                [AppHelper saveToUserDefaults:[note.userInfo valueForKey:@"total_amount"] withKey:KAvailableCredit];
                UILabel *lblAmount = (UILabel*)[self.view viewWithTag:600];
                lblAmount.text = [NSString stringWithFormat:@"youSKOOP Balance:$ %.2f",[[note.userInfo valueForKey:@"total_amount"] floatValue]];
            }
        }
        [AppHelper showAlertViewWithTag:102 title:AppName message:@"Your youSKOOP account has been recharged successfully." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    }
}

-(void)userDidRechargeAccountUsingPaypal:(NSNotification *)note
{
    NSLog(@"Reply Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Recharge_Account_Paypal object:nil];
    if (note.userInfo){
        
        if([[note.userInfo valueForKey:@"errorCode"] integerValue] == 0){
            _viewWebView.hidden = NO;
            [self._webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:[note.userInfo valueForKey:@"payment_url"]]]];
        }
        else{
            [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
    }
}

-(void)userDidRedeemedOurBalance:(NSNotification *)note
{
    NSLog(@"Reply Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Redeem_Point object:nil];
    if (note.userInfo){
        if([[note.userInfo valueForKey:@"errorCode"] integerValue] == 0){
            [AppHelper saveToUserDefaults:[note.userInfo valueForKey:@"total_amount"] withKey:KAvailableCredit];
            UILabel *lblAmount = (UILabel*)[self.view viewWithTag:600];
            lblAmount.text = [NSString stringWithFormat:@"youSKOOP Balance:$ %@",[note.userInfo valueForKey:@"total_amount"] ];
        }
        [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    }
}

#pragma mark Detect view touch
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    
    if([txtCurrentFocus isFirstResponder])
        [txtCurrentFocus resignFirstResponder];
}

#pragma mark - Optional UIWebViewDelegate delegate methods
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    return YES;
}

- (void)webViewDidStartLoad:(UIWebView *)webView
{
    NSLog(@"webViewDidStartLoad");
    [AppDelegate showGlobalProgressHUDWithTitle:@"loading..."];
}

- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@":::::%@",webView.request.URL);
    NSString *responseUrlString = [NSString stringWithFormat:@"%@",webView.request.URL];
    if(responseUrlString && [responseUrlString hasPrefix:@"http://youskoop.com/payment/success"]){//success
        
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Your youSKOOP account has been recharged successfully." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
       
        float amount = 0.0;
        UILabel *lblAmount = (UILabel*)[self.view viewWithTag:600];
        if([AppHelper userDefaultsForKey:KAvailableCredit]){
            amount = [[AppHelper userDefaultsForKey:KAvailableCredit] floatValue] + [rechargeAmount floatValue];
        }
        else{
            amount = [rechargeAmount floatValue];
        }
        lblAmount.text = [NSString stringWithFormat:@"youSKOOP Balance:$ %.2f",amount];
        [AppHelper saveToUserDefaults:[NSString stringWithFormat:@"%.2f",amount] withKey:KAvailableCredit];
         _viewWebView.hidden = YES;
    }
    else if(responseUrlString && [responseUrlString hasPrefix:@"http://youskoop.com/payment/cancel"]){//success
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Your payment process has been cancelled." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        _viewWebView.hidden = YES;
    }
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    NSLog(@"didFailLoadWithError");
    [AppDelegate dismissGlobalHUD];
    [AppHelper showAlertViewWithTag:1 title:AppName message:@"Some error occurs during process,please try again later." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag == 2){//Recharge account
        if(buttonIndex == 1){//Payment through paypal
            NSMutableDictionary *ccData = [AppHelper userDefaultsDictionaryDataForKey:KSavedCCInfo];
            if([ccData valueForKey:@"email"] && [[ccData valueForKey:@"email"] length] > 0){
                UIAlertView * alert = [[UIAlertView alloc] initWithTitle:AppName message:@"Please enter your recharge amount" delegate:self cancelButtonTitle:Alert_Cancel otherButtonTitles:@"Recharge", nil];
                alert.tag = 3;
                alert.alertViewStyle = UIAlertViewStylePlainTextInput;
                UITextField *textField = [alert textFieldAtIndex:0];
                textField.keyboardType = UIKeyboardTypeDecimalPad;
                textField.placeholder = @"Ener amount in dollar($)";
                [alert show];
            }
            else
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please first save your paypal email id." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
        else if(buttonIndex == 2){//Payment through credit card
            if([AppHelper userDefaultsDictionaryDataForKey:KSavedCCInfo]){
                UIAlertView * alert = [[UIAlertView alloc] initWithTitle:AppName message:@"Please enter your recharge amount" delegate:self cancelButtonTitle:Alert_Cancel otherButtonTitles:@"Recharge", nil];
                alert.tag = 4;
                alert.alertViewStyle = UIAlertViewStylePlainTextInput;
                UITextField *textField = [alert textFieldAtIndex:0];
                textField.keyboardType = UIKeyboardTypeDecimalPad;
                textField.placeholder = @"Ener amount in dollar($)";
                [alert show];
            }
            else
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please save your credit card info." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
    }
    else if (alertView.tag == 3){
        if(buttonIndex == 1){
            UITextField *txtRecharge = [alertView textFieldAtIndex:0];
            rechargeAmount = @"0";
            rechargeAmount = txtRecharge.text;
            if(rechargeAmount && [rechargeAmount floatValue] > 0){
                NSMutableDictionary *ccData = [AppHelper userDefaultsDictionaryDataForKey:KSavedCCInfo];
                [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidRechargeAccountUsingPaypal:) name:Notification_Recharge_Account_Paypal object:nil];
                [[WebServicesController WebServiceMethod] rechargeAccountWithPaypalEmail:[ccData valueForKey:@"email"] userId:[AppHelper userDefaultsForKey:KUserId] amount:[NSString stringWithFormat:@"%f",[rechargeAmount floatValue]] andAppToken:KAppToken];
            }
            else
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please enter valid recharge amount" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
    }
    else if (alertView.tag == 4){
        if(buttonIndex == 1){
            UITextField *txtRecharge = [alertView textFieldAtIndex:0];
            rechargeAmount = @"0";
            rechargeAmount = txtRecharge.text;
            if(rechargeAmount && [rechargeAmount floatValue] > 0){
                [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
                [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidRechargeAccount:) name:Notification_Recharge_Account object:nil];
                [[WebServicesController WebServiceMethod] rechargeAccountWithUserId:[AppHelper userDefaultsForKey:KUserId] amount:[NSString stringWithFormat:@"%f",[rechargeAmount floatValue]] andAppToken:KAppToken];
            }
            else
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please enter valid recharge amount" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
    }
    else if (alertView.tag == 5){
        if(buttonIndex == 1){
            UITextField *txtRedeem = [alertView textFieldAtIndex:0];
            if(txtRedeem.text && [txtRedeem.text floatValue] > 0){
                if([txtRedeem.text floatValue] <= [[AppHelper userDefaultsForKey:KRedeemAmount] floatValue]){
                    
                    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
                    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidRedeemedOurBalance:) name:Notification_Redeem_Point object:nil];
                    [[WebServicesController WebServiceMethod] redeemYourPointWithUserId:[AppHelper userDefaultsForKey:KUserId] redeemAmount:[NSString stringWithFormat:@"%.2f",[txtRedeem.text floatValue]] andAppToken:KAppToken];
                }
                else{
                    [AppHelper showAlertViewWithTag:5 title:AppName message:@"Withdraw amount must be less than withdrawable amount." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
                }
            }
            else{
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please enter your withdraw amount" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
            }
        }
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
