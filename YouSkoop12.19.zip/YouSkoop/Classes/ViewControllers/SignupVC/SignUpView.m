//
//  SignUpView.m
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "SignUpView.h"
#import "WebServicesController.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import "FacebookLoginInfo.h"
#import "Twitter/Twitter.h"
#import "TWAccessTokenGenerator.h"
#import "Social/Social.h"
#import "Accounts/Accounts.h"
#import "CLController.h"
#import "FacebookControllar.h"

@interface SignUpView ()

@end

@implementation SignUpView
@synthesize dictSignUpCredentials,txtName,txtUserName,txtUserEmail,txtUserPassword,scrollview;
int registeration1_val=0;
NSString *fbid,*twid,*twtoken, *twname;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    
    [super viewDidLoad];
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    UILabel *lblEnterEmail=(UILabel*)[self.view viewWithTag:5];
    lblEnterEmail.textColor=KTextColor;
    [AppHelper stausBarColorChange];
    dictSignUpCredentials =[[NSMutableDictionary alloc]init];
    
    //add keyboard notification
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(keyboardwillShowNotification:)
     name:UIKeyboardDidShowNotification
     object:nil];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(keyboardwillHideNotification:)
     name:UIKeyboardDidHideNotification
     object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark Button action methods

//Signup button action
- (IBAction)btnSubmitSignUpDetails:(id)sender{
    
    [self.scrollview setContentOffset:CGPointMake(0,0) animated:NO];
    [self.txtName resignFirstResponder];
    [self.txtUserEmail resignFirstResponder];
    [self.txtUserName resignFirstResponder];
    [self.txtUserPassword resignFirstResponder];
    NSString*erroeMessage=nil;
    
    //Validations
    
    if([self.txtName.text length]==0)
        erroeMessage=@"Please enter name.";
    else if([self.txtUserName.text length]==0)
        erroeMessage=@"Please enter username.";
    else if([self.txtUserEmail.text length]==0)
        erroeMessage=@"Please enter email address.";
    else if([self validateEmail:self.txtUserEmail.text]==NO)
        erroeMessage=@"Please enter the valid email.";
    else if ([self.txtUserPassword.text length]==0)
        erroeMessage=@"Please enter the password.";
    else if([self.txtUserPassword.text length]<=6)
        erroeMessage=@"Password length must be greater than six characters.";
    
    if(erroeMessage){
        [AppHelper showAlertViewWithTag:670 title:AppName message:erroeMessage delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    }
    else{
        
        [dictSignUpCredentials setValue:txtName.text forKey:@"name"];
        [dictSignUpCredentials setValue:txtUserName.text forKey:@"userName"];
        [dictSignUpCredentials setValue:txtUserEmail.text forKey:@"email"];
        [dictSignUpCredentials setValue:txtUserPassword.text forKey:@"password"];
        [dictSignUpCredentials setValue:KAppToken forKey:@"token"];
        
        switch (registeration1_val){
            case 0: //Regular signup
                
                [dictSignUpCredentials setValue:@"0" forKey:@"registrationType"];
                break;
                
            case 1: //Sign up with facebook
                
                [dictSignUpCredentials setValue:@"1" forKey:@"registrationType"];
                [dictSignUpCredentials setValue:fbid forKey:@"facebook_uid"];
                [dictSignUpCredentials setValue:[AppHelper userDefaultsForKey:KFbAccessToken] forKey:@"fb_token"];
                break;
                
            case 2: //Sign up with twitter
                
                [dictSignUpCredentials setValue:@"2" forKey:@"registrationType"];
                [dictSignUpCredentials setValue:twtoken forKey:@"twitter_token"];
                [dictSignUpCredentials setValue:twid forKey:@"twitter_uid"];
                break;
            default:
                break;
        }
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self
                                                 selector:@selector(postUserRegistration:)
                                                     name:Notification_for_userRegistration
                                                   object:nil];
        [[WebServicesController WebServiceMethod] signUpServices:dictSignUpCredentials];
    }
}

//Signup through facebook
- (IBAction)btnfacebooksignup:(id)sender
{
    [self.txtName resignFirstResponder];
    [self.txtUserEmail resignFirstResponder];
    [self.txtUserName resignFirstResponder];
    [self.txtUserPassword resignFirstResponder];
    [self.scrollview setContentOffset:CGPointMake(0,0) animated:NO];
    registeration1_val=1;
    
    //[FacebookControllar sharedFacebookControllar].requestType = RequestForPostingAccessToken;
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetFacebookDetail:) name:GetFacebookAccessToken object:nil];
    //NSArray *permissions = [[NSArray alloc]initWithObjects:@"publish_stream",@"publish_actions",@"user_hometown",@"user_location",@"friends_location",@"friends_hometown", nil];
    //[[FacebookControllar sharedFacebookControllar] LoginWithFacebookWithFacebookPermission:permissions];
    [self loginWithFacebook];
}
- (IBAction)btnTwitterLoginClick:(id)sender
{
    registeration1_val=2;
    [self loginViaTwitter];
}

- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)loginWithFacebook {
    
    if (![FBSDKAccessToken currentAccessToken]) {
        
        FBSDKLoginManager *login = [[FBSDKLoginManager alloc] init];
        [login logInWithReadPermissions:@[@"email"] fromViewController:self handler:^(FBSDKLoginManagerLoginResult *result, NSError *error) {
            
            if (error) {
                
            } else if (result.isCancelled) {
                
                
            } else {
                // If you ask for multiple permissions at once, you
                // should check if specific permissions missing
                if ([result.grantedPermissions containsObject:@"email"]) {
                    
                    [self loginWithFacebook];
                }
            }
        }];
        return;
    }
    
    access_token= [NSString stringWithFormat:@"%@",[FBSDKAccessToken currentAccessToken].tokenString];
    NSLog(@"FBAccessToken = %@",access_token);
    
    NSMutableDictionary *params = [NSMutableDictionary dictionary];
    [params setValue:@"id, first_name, last_name, email, name" forKey:@"fields"];
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    
    [[[FBSDKGraphRequest alloc] initWithGraphPath:@"me" parameters:params] startWithCompletionHandler:^(FBSDKGraphRequestConnection *connection, id user, NSError *error){
        
        [AppDelegate dismissGlobalHUD];
        if (!error) {
            [AppHelper saveToUserDefaults:[user valueForKey:@"id"] withKey:KFacebook_id];
            [AppHelper saveToUserDefaults:access_token withKey:KFbAccessToken];
            fbid = [user objectForKey:@"id"];
            NSLog(@"%@",user);
//            [dictUserCredentials setValue:KAppToken forKey:@"token"];
//            [dictUserCredentials setValue:[user objectForKey:@"id"] forKey:@"facebook_uid"];
//            [dictUserCredentials setValue:access_token forKey:@"fb_token"];
//            [dictUserCredentials setValue:@"0" forKey:@"login_attempt"];
            
            //[AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSignedIn:) name:Notification_login object:nil];
            //[[WebServicesController WebServiceMethod] signIn:dictUserCredentials];
            
            txtName.text = [user objectForKey:@"name"];
            txtUserEmail.text = [user objectForKey:@"email"];
            txtUserName.text = [NSString stringWithFormat:@"%@%@",[user objectForKey:@"first_name"], [user objectForKey:@"last_name"]];
            
        }
        else{
            NSLog(@"Error:%@", error);
        }
    }];
}


#pragma mark-Textfield deligate methods

-(void)keyboardwillShowNotification:(NSNotification*)note
{
    if(IS_IPHONE5)
        [self.scrollview setContentSize:CGSizeMake(320,505)];
    else
        [self.scrollview setContentSize:CGSizeMake(320,600)];
    
    self.scrollview.scrollEnabled=YES;
}

-(void)keyboardwillHideNotification:(NSNotification*)note
{
    self.scrollview.contentOffset=CGPointMake(0, 0);
    self.scrollview.scrollEnabled=NO;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    //[textField resignFirstResponder];
    
    if (textField == txtName) {
        [txtUserName becomeFirstResponder];
    } else if(textField == txtUserName){
        [txtUserEmail becomeFirstResponder];
    } else if (textField == txtUserEmail){
        [txtUserPassword becomeFirstResponder];
    }else{
        [UIView animateWithDuration:0.25 animations:^{
            [self.scrollview setContentOffset:CGPointMake(0,0) animated:NO];
        }];
        [textField resignFirstResponder];
    }
    
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    
    if (textField == txtUserPassword) {
        [UIView animateWithDuration:0.25 animations:^{
            [scrollview setContentOffset:CGPointMake(0, 102)];
        }];
    }
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    NSString *textFieldString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if (textField.text.length==0 && [string isEqualToString:@" "])
        return NO;
    else if (textField==self.txtUserName && [textFieldString length]>25)
        return NO;
    
    return YES;
}

#pragma mark Alertview deligate methods
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag==67890)
    {
        if ([AppHelper userDefaultsForKey:KUserId])
        {
            [self performSegueWithIdentifier:@"Signup" sender:nil];
        }
    }
}

//Check email is valid or not
-(BOOL)validateEmail: (NSString *)str
{
    NSString *emailRegEx = predicateFormatForEmailID;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegEx];
    return [emailTest evaluateWithObject:str];
}

#pragma mark Receive notofications

//User did register
-(void)postUserRegistration:(NSNotification *)note{
    
    NSLog(@"postUserRegistration======%@",note.userInfo);
    registeration1_val=0;
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:Notification_for_userRegistration object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            
            //[[AppDelegate getAppDelegate] configureVideoChatCredentials];
            [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:KUserId] withKey:KUserId];
            [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"name"] withKey:KUserName];
            [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"email"] withKey:KUserEmail];
            [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"image"] withKey:KUserImageUrl];
            [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"quick_blox_login"] withKey:KQuickBloxCredential];
            if([[note.userInfo objectForKey:@"data"] objectForKey:@"quick_blox_id"])
                [AppHelper saveToUserDefaults:[[note.userInfo objectForKey:@"data"] objectForKey:@"quick_blox_id"] withKey:KQuickBloxId];
            
            NSMutableDictionary *profData=[[NSMutableDictionary alloc] init];
            [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"name"] forKey:@"name"];
            [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"image"] forKey:@"image"];
            [profData setValue:[[note.userInfo objectForKey:@"data"] objectForKey:@"email"] forKey:@"email"];
            [profData setValue:@"1" forKey:@"notification"];
            [profData setValue:@"1" forKey:@"sound"];
            [AppHelper saveToUserDefaults:profData withKey:KUserProfData];
            
            [self performSegueWithIdentifier:@"Pushfromsignup" sender:nil];
            [AppHelper showAlertViewWithTag:67890 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1){
            self.txtUserEmail.text=nil;
            [AppHelper showAlertViewWithTag:690 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
        else{
            [AppHelper showAlertViewWithTag:690 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
    }
}

-(void)userDidGetFacebookDetail:(NSNotification*)noti{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:GetFacebookAccessToken object:nil];
    NSLog(@"%@",noti);
    [AppDelegate dismissGlobalHUD];
    if(noti.userInfo && [[noti.userInfo valueForKey:@"isSuccess"] isEqualToString:@"Yes"]){
        
        [AppHelper saveToUserDefaults:[[noti.userInfo valueForKey:@"data"] valueForKey:@"id"] withKey:KFacebook_id];
        NSDictionary *userDataDict = noti.userInfo;
        
        if([userDataDict valueForKey:@"email"])
            txtUserEmail.text=[userDataDict objectForKey:@"email"];
        self.txtName.text=[userDataDict objectForKey:@"name"];
        fbid = [userDataDict objectForKey:@"id"];
    }
    
}

-(void) getFBInfo:(NSNotification*)notification{
    
   // [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:@"FBInfoNotification" object:nil];
    if(notification.userInfo!=nil){
        NSDictionary *dictUserInfo=[[NSMutableDictionary alloc]initWithDictionary:[[FacebookLoginInfo getFacebookLoginInfo] getUserInfo] ];
        
        NSLog(@"%@",dictUserInfo);
        txtUserEmail.text=[dictUserInfo objectForKey:@"email"];
        self.txtName.text=[dictUserInfo objectForKey:@"first_name"];
        fbid=[dictUserInfo objectForKey:@"id"];
    }
}

- (void)userDidGetTwitterUserInfo:(NSNotification*)noti{
    
    [AppHelper saveToUserDefaults:@"" withKey:@"POST"];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:@"Twitter_Tokens_Rvcd" object:nil];
    twid=[AppHelper userDefaultsForKey:KTwitter_id];
    twtoken=[AppHelper userDefaultsForKey:KTwitter_token];
    
    NSDictionary *userDataDict = noti.object;
    if([userDataDict valueForKey:@"name"])
        self.txtName.text = [userDataDict valueForKey:@"name"];
    self.txtUserName.text = [AppHelper userDefaultsForKey:@"screen_Name"];
}

#pragma mark Other methods

-(void) loginViaTwitter   //MARK:- Login via Twitter
{
    registeration1_val = 2;
    [self.txtName resignFirstResponder];
    [self.txtUserEmail resignFirstResponder];
    [self.txtUserName resignFirstResponder];
    [self.txtUserPassword resignFirstResponder];
    [self.scrollview setContentOffset:CGPointMake(0,0) animated:NO];
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[TWAccessTokenGenerator sharedAccessTokenGenerator] initialize];
    ACAccountStore *accountStore = [[ACAccountStore alloc] init];
    ACAccountType *accountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    [accountStore requestAccessToAccountsWithType:accountType options:nil completion:^(BOOL granted, NSError *error)
     {
         if (granted)
         {
             NSArray *accounts = [accountStore accountsWithAccountType:accountType];
             // Check if the users has setup at least one Twitter account
             if (accounts.count > 0)
             {
                 ACAccount *twitterAccount = [accounts objectAtIndex:0];//Getting first account
                 
                 NSString *temp =[[twitterAccount.description componentsSeparatedByString:@"\"user_id\" = "] lastObject];
                 NSArray *temparr=[temp componentsSeparatedByString:@";"];
                 if ([temparr count]>0)
                 {
                     NSString *userName=[temparr objectAtIndex:0];
                     
                     // Creating a request to get the info about a user on Twitter
                     SLRequest *twitterInfoRequest = [SLRequest requestForServiceType:SLServiceTypeTwitter requestMethod:SLRequestMethodGET URL:[NSURL URLWithString:@"https://api.twitter.com/1.1/users/show.json"] parameters:[NSDictionary dictionaryWithObject:userName forKey:@"screen_name"]];
                     [twitterInfoRequest setAccount:twitterAccount];
                     // Making the request
                     [twitterInfoRequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
                      {
                          dispatch_async(dispatch_get_main_queue(), ^
                                         {
                                             // Check if there was an error
                                             if (error)
                                             {
                                                 
                                                 return;
                                             }
                                             // Check if there is some response data
                                             if (responseData)
                                             {
                                                 [self getTwitterTokens];
                                             }
                                             [AppDelegate dismissGlobalHUD];
                                         });
                      }];
                 }
             }
             else
             {
                 dispatch_async(dispatch_get_main_queue(), ^
                                {
                                    [AppDelegate dismissGlobalHUD];
                                    [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please ensure that you have at least one twitter account setup and have internet connectivity. You can setup a twitter account in the iOS Settings > Twitter > login." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                                });
                 
             }
         }
         else
         {
             NSLog(@"12344324");
             dispatch_async(dispatch_get_main_queue(), ^
                            {
                                [AppDelegate dismissGlobalHUD];
                                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please ensure that you have permission to access twitter account. You can turn on permission in the iOS Settings > Twitter." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                            });
         }
         if (error)
         {             //[MessageView showMessageView:@"ERROR_INTERNET_CONNECTION" onView:self.view];
         }
     }];
}

-(void)getTwitterTokens
{
    [TWAccessTokenGenerator sharedAccessTokenGenerator].view=self.view;
    [[TWAccessTokenGenerator sharedAccessTokenGenerator] refreshTwitterAccounts];
    [AppHelper saveToUserDefaults:@"YES" withKey:@"POST"];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetTwitterUserInfo:) name:@"Twitter_Tokens_Rvcd" object:nil];
}

@end
