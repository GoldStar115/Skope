//
//  SignUpView.h
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface SignUpView : UIViewController<UIScrollViewDelegate,UITextFieldDelegate,UIAlertViewDelegate>
{
    NSMutableDictionary *dictSignUpCredentials;
    NSMutableDictionary *dictUserCredentials;
    NSString *access_token;
}
@property (weak, nonatomic) IBOutlet UITextField *txtUserName;
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtUserPassword;
@property (weak, nonatomic) IBOutlet UITextField *txtUserEmail;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollview;
@property(strong,nonatomic) NSMutableDictionary *dictSignUpCredentials;

- (IBAction)btnBack:(id)sender;
- (IBAction)btnfacebooksignup:(id)sender;
- (IBAction)btnTwitterLoginClick:(id)sender;
- (IBAction)btnSubmitSignUpDetails:(id)sender;

@end
