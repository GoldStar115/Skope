//
//  HomeView.h
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RequestViewViewController.h"



@protocol updatePaymentStatus <NSObject>

@optional
-(void)updateCallPaymentStatus;

@end

@interface HomeView : UIViewController{
    
}


@property id<updatePaymentStatus> deligate;

@end
