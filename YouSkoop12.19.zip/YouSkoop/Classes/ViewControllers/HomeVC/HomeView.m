//
//  HomeView.m
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//
#import "WelcomeView.h"
#import "HomeView.h"
#import "CLController.h"
#import "SendRequestVC.h"
#import "NotificationVC.h"
#import "InboxView.h"
#import "ReplyOnSkoopVC.h"
#import "SkoopReplyData.h"
#import "SendGroupSkoop.h"
#import "UserProfileVC.h"
#import "EditProfileVC.h"
#import "CellSelectionView.h"
#import <EventKit/EventKit.h>
#import "CreditCardCV.h"
#import "AppcustomTabbar.h"
#import "VideoPlayerVC.h"

#import <ooVooSDK/ooVooSDK.h>
#import <ooVooSDK/ooVooPushService.h>






#define MinimumFreeCallTime     30

@interface HomeView (){
    __weak IBOutlet UIScrollView *_scrollView;
    __weak IBOutlet UILabel *_lblInboxCount;
    __weak IBOutlet UILabel *_lblAnswerReqCount;
    __weak IBOutlet UILabel *_lblGroupRequestCount;
    __weak IBOutlet UIImageView *_imgNotCount;
    __weak IBOutlet UIImageView *_imgInboxCount;
    __weak IBOutlet UIImageView *_imgSkoopRepCount;
    __weak IBOutlet UIImageView *_imgUserProfileImage;
    
    IBOutlet UIImageView *_opponentVideoView;
    IBOutlet UIImageView *_myVideoView;
    __weak IBOutlet UIView *_viewVideoCall;
    __weak IBOutlet UIButton *_btnHangup;
    __weak IBOutlet UIButton *_btnAnswer;
    __weak IBOutlet UIImageView *_imgCallingWave;
    __weak IBOutlet UIImageView *_imgCall;
    __weak IBOutlet UILabel *_lblTime;
    __weak IBOutlet UILabel *_lblCallerName;
    __weak IBOutlet UIImageView *_imgCallerImage;
    
    int callDuration;
    NSTimer *callTimer;
    
    
    
    NSUInteger videoChatOpponentID;
    
    NSString *sessionID;
    
    int skoopIndex;
    NSArray *skoopReplyArray;
    NSDictionary *callerDetail;
    BOOL isReceivePortalCall;
    CGRect userVideoFrame;
    
    ooVooClient *sdk;
}


@property (strong) NSNumber *opponentID;
@property (strong, nonatomic) NSDictionary *callerDetail;




@end

@implementation HomeView


@synthesize opponentID;
@synthesize callerDetail;

@synthesize deligate;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Start location manager
    [[CLController sharedInstance] initializelocationManager];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateNotificationCountFromPushNotification:) name:Notification_Update_Notofication_Count object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNotificationListWithPush:) name:Notification_Update_Notification_List object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateOnlyNotificationCountFromPushNotification:) name:Notification_Update_Only_Notofication_Count object:nil];
    
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    userVideoFrame = _viewVideoCall.frame;
    [AppHelper getRoundedRectImageWithImageView:_imgUserProfileImage withColor:[UIColor whiteColor] andRadius:_imgUserProfileImage.frame.size.width/2 andWidth:2.0];
    
    if(IS_IPHONE_5){
        [_scrollView setScrollEnabled:NO];
    }
    else{
        _scrollView.contentSize = CGSizeMake(320, 480);
        [_scrollView setScrollEnabled:YES];
    }
    
    UITapGestureRecognizer *uiTap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnUserProfileImage:)];
    uiTap.numberOfTapsRequired=1;
    _imgUserProfileImage.userInteractionEnabled = YES;
    [_imgUserProfileImage addGestureRecognizer:uiTap];
    
    UILabel *lblBalance = (UILabel*)[self.view viewWithTag:15555];
    UITapGestureRecognizer *uiTapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnAvailableBalance:)];
    uiTapGesture.numberOfTapsRequired = 1;
    lblBalance.userInteractionEnabled = YES;
    [lblBalance addGestureRecognizer:uiTapGesture];
    
    [AppHelper getRoundedImageWithImageView:_imgCallerImage];
    
    //Configure video calling
    
    sdk = [ooVooClient sharedInstance];
    [self ooVooAuthorization];
    
    //Set call animation image
    NSArray *animationImages = [NSArray arrayWithObjects:[UIImage imageNamed:@"curve1.png"],[UIImage imageNamed:@"curve2.png"],[UIImage imageNamed:@"curve3.png"],[UIImage imageNamed:@"curve4.png"],nil];
    _imgCallingWave.animationImages = animationImages ;
    _imgCallingWave.animationRepeatCount = 0;
    _imgCallingWave.animationDuration = 1.0;
}

-(void)viewWillAppear:(BOOL)animated{
    
    //Show available balance
    float amount = 0.0;
    UILabel *lblAmount = (UILabel*)[self.view viewWithTag:15555];
    if([AppHelper userDefaultsForKey:KAvailableCredit]){
        amount = [[AppHelper userDefaultsForKey:KAvailableCredit] floatValue];
    }
    lblAmount.text = [NSString stringWithFormat:@"$ %.2f",amount];
    
    //Check control comes here from send skoop screen
    if([AppHelper userDefaultsForKey:KIsSendToInbox]){
        [self performSegueWithIdentifier:@"inbox" sender:nil];
    }
    else if([AppHelper userDefaultsForKey:KIsSendToSkoopReply]){
        [self performSegueWithIdentifier:@"skoop_reply" sender:[AppHelper userDefaultsForKey:KIsSendToSkoopReply]];
    }
    
    if([AppHelper userDefaultsForKey:KSkoopReplyCount]){
        _lblInboxCount.text=[AppHelper userDefaultsForKey:KSkoopReplyCount];
    }
    if([AppHelper userDefaultsForKey:KSkoopRequest]){
        _lblAnswerReqCount.text=[AppHelper userDefaultsForKey:KSkoopRequest];
    }
    if([AppHelper userDefaultsForKey:KNotificationCount]){
        _lblGroupRequestCount.text=[AppHelper userDefaultsForKey:KNotificationCount];
    }
    
    [self hideShowNotificationCount];
    
    NSMutableDictionary *profDict=[AppHelper userDefaultsDictionaryDataForKey:KUserProfData];
    if([profDict valueForKey:@"image"] && [[profDict valueForKey:@"image"] length]>0){
        [_imgUserProfileImage setImageWithURL:[NSURL URLWithString:[profDict valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"default_user_iconm.png"]];
    }
    
     //Hit webservice for getting unread notification
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidLGetNotificationCount:) name:Notification_Get_Notofication_Count object:nil];
    if(![AppHelper userDefaultsForKey:isSyncData]){
        [[WebServicesController WebServiceMethod] getNotificationCountWithUserId:[AppHelper userDefaultsForKey:KUserId] isGetSyncData:@"1" andToken:KAppToken];
    }
    else{
        [[WebServicesController WebServiceMethod] getNotificationCountWithUserId:[AppHelper userDefaultsForKey:KUserId] isGetSyncData:@"0" andToken:KAppToken];
    }
    [self performSelector:@selector(getAllSkoopFromCoreData) withObject:nil afterDelay:1.0];
}

#pragma mark Configure video chat


-(void)ooVooAuthorization{
    
    [[ooVooClient sharedInstance] authorizeClient:ooVooToken
                                       completion:^(SdkResult *result) {
                                           if (result.Result == sdk_error_OK)
                                           {
                                               NSLog(@"Good Authorization");
                                               [self ooVooLogin];
                                           }
                                           else
                                           {
                                               NSLog(@"Failed Authorization - Check your ooVoo token !");
                                               
                                           }
                                       }];
}

-(void)ooVooLogin{
    NSString *strVideoUserId = [NSString stringWithFormat:@"skoop_user%@", [AppHelper userDefaultsForKey:KUserId]];
    NSLog(@"userId = %@", strVideoUserId);
    
    [sdk.Account login:strVideoUserId
                 completion:^(SdkResult *result) {
                     
                     if (result.Result == sdk_error_OK)
                     {
                         NSLog(@"ooVoo Login Success");
                         
                         [sdk.Messaging connect];
                         [self setBackCamera];
                         [self setResolution];
                         
                     }
                     else
                     {
                         UIAlertView *alert =[[UIAlertView alloc] initWithTitle:@"Login Error" message:result.description delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                         [alert show];
                     }
                 }];
}

- (void)setBackCamera{
    
    NSArray *arr_dev = [sdk.AVChat.VideoController getDevicesList];
    NSString *deviceId = ((id<ooVooDevice>)[arr_dev objectAtIndex:0]).deviceID;
    [sdk.AVChat.VideoController setConfig:deviceId forKey:ooVooVideoControllerConfigKeyCaptureDeviceId];
}

- (void)setResolution{
    
    //    NSMutableArray *allowedResolutions = [NSMutableArray new];
    //    NSArray* resolutions = [sdk.AVChat.VideoController.activeDevice getAvailableResolutions];
    //
    //    if(resolutions)
    //    {
    //        for(NSNumber* resolution in resolutions)
    //        {
    //            if ([sdk.AVChat isResolutionSuported:[resolution integerValue]]) {
    //                [allowedResolutions addObject:resolution];
    //            }
    //        }
    //    }
    //
    //    NSLog(@"allowedResolutions = %@", allowedResolutions);
    //
    //    NSString *currentRes = [sdk.AVChat.VideoController getConfig:ooVooVideoControllerConfigKeyResolution];
    //    NSLog(@"currentRes = %@", currentRes);
    [sdk.AVChat.VideoController setConfig:@"4" forKey:ooVooVideoControllerConfigKeyResolution];
}


#pragma mark Tap gesture method
-(void)tapOnUserProfileImage:(UITapGestureRecognizer*)tapGesture{
    [self performSegueWithIdentifier:@"userprofile" sender:nil];
}

-(void)tapOnAvailableBalance:(UITapGestureRecognizer*)tapGesture{
    [self performSegueWithIdentifier:@"creditcard_info" sender:nil];
}

#pragma mark Other methods

-(void)hideShowNotificationCount
{
    if([AppHelper userDefaultsForKey:KSkoopReplyCount] && [[AppHelper userDefaultsForKey:KSkoopReplyCount] integerValue]>0){
        _lblInboxCount.hidden=NO;
        _imgInboxCount.hidden=NO;
    }
    else{
        _lblInboxCount.hidden=YES;
        _imgInboxCount.hidden=YES;
    }
    
    if([AppHelper userDefaultsForKey:KSkoopRequest] && [[AppHelper userDefaultsForKey:KSkoopRequest] integerValue]>0){
        _lblAnswerReqCount.hidden=NO;
        _imgSkoopRepCount.hidden=NO;
    }
    else{
        _lblAnswerReqCount.hidden=YES;
        _imgSkoopRepCount.hidden=YES;
    }
    
    if([AppHelper userDefaultsForKey:KNotificationCount] && [[AppHelper userDefaultsForKey:KNotificationCount] integerValue]>0){
        _lblGroupRequestCount.hidden=NO;
        _imgNotCount.hidden=NO;
    }
    else {
        _lblGroupRequestCount.hidden=YES;
        _imgNotCount.hidden=YES;
    }
}

// Method for getting all pending skoop reply and send
-(void)getAllSkoopFromCoreData
{
    skoopIndex=0;
    skoopReplyArray=[NSArray arrayWithArray:[[WebServicesController WebServiceMethod] getAllSkoopReplyData]];
    if(skoopIndex<skoopReplyArray.count)
        [self resumeOfPendingSkoopRequest];
}

//Method for getting all sync skoop data
-(void)getAllSyncedSkoop
{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetSyncSkoop:) name:Notification_Get_Sync_Skoop object:nil];
    [[WebServicesController WebServiceMethod] getSyncSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] andAppToken:KAppToken];
}

-(void)resumeOfPendingSkoopRequest{
    
    SkoopReplyData *skoopData=[skoopReplyArray objectAtIndex:skoopIndex++];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnSkoop:) name:Notification_reply_on_skoop object:nil];
    [[WebServicesController WebServiceMethod] replyOnSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:skoopData.skoopId replyVideo:skoopData.videoNsdata andToken:KAppToken];
}

#pragma mark Button action methods
- (IBAction)onClickNotificationButton:(id)sender
{
    [self performSegueWithIdentifier:@"notification" sender:nil];
}

- (IBAction)onClickSettingsButton:(id)sender
{
    [self performSegueWithIdentifier:@"editprofile" sender:nil];
}

- (IBAction)onClickInboxButton:(id)sender
{
    [self performSegueWithIdentifier:@"inbox" sender:nil];
}
- (IBAction)onClickReplyButton:(id)sender
{
    [self performSegueWithIdentifier:@"reply" sender:nil];
}
- (IBAction)onClickSendRequestButton:(id)sender
{
    [self performSegueWithIdentifier:@"sendrequest" sender:nil];
}

//Reject and cancel live portal call by receiver
-(IBAction)onClickHangupCallButton:(id)sender{
    NSLog(@"******************Hang Up*******************");
    if(isReceivePortalCall){
        if([_btnHangup tag] == 701){ //Decline live portal call
            
            if([_viewVideoCall superview] != nil){
                [UIView animateWithDuration:0.5 animations:^(void){
                    CGRect frameRect=_viewVideoCall.frame;
                    frameRect.origin.y=568;
                    _viewVideoCall.frame=frameRect;
                }completion:^(BOOL finish)
                 {
                     [_viewVideoCall removeFromSuperview];
                 }];
            }
            
            [_imgCallingWave stopAnimating];
            
           
        }
        else{//Cancel live portal call
            _btnHangup.tag = 701;
            
            if(callTimer!=nil){
                [callTimer invalidate];
                callTimer=nil;
            }
            
            
            [UIView animateWithDuration:0.5 animations:^(void){
                CGRect frameRect=_viewVideoCall.frame;
                frameRect.origin.y=568;
                _viewVideoCall.frame=frameRect;
            }completion:^(BOOL finish)
             {
                 [_viewVideoCall removeFromSuperview];
             }];
            
            // release video chat
            //
            
            
            //Hit webservice for getting available balance
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidLGetNotificationCount:) name:Notification_Get_Notofication_Count object:nil];
            [[WebServicesController WebServiceMethod] getNotificationCountWithUserId:[AppHelper userDefaultsForKey:KUserId] isGetSyncData:@"0" andToken:KAppToken];
        }
    }
    else{
        if(callTimer!=nil){
            [callTimer invalidate];
            callTimer=nil;
        }
        
        
        [UIView animateWithDuration:0.5 animations:^(void){
            CGRect frameRect=_viewVideoCall.frame;
            frameRect.origin.y=568;
            _viewVideoCall.frame=frameRect;
        }completion:^(BOOL finish)
         {
             [_viewVideoCall removeFromSuperview];
         }];
        
        // release video chat
        //
        
    }
    [[AppDelegate getAppDelegate] setIdleTimerDisabledWithBool:NO];
}

-(IBAction)onClickAcceptCallButton:(id)sender{
    
    NSLog(@"accept");
    [_btnHangup setImage:[UIImage imageNamed:@"endCall.png"] forState:UIControlStateNormal];
    [_btnHangup setImage:[UIImage imageNamed:@"endCall.png"] forState:UIControlStateSelected];
    [_btnHangup setImage:[UIImage imageNamed:@"endCall.png"] forState:UIControlStateHighlighted];
    
    _btnAnswer.hidden = YES;
    _btnHangup.tag = 702;
    
    
    
    //Check rear camera is available or not
    if([UIImagePickerController isCameraDeviceAvailable:UIImagePickerControllerCameraDeviceRear])
        [self performSelector:@selector(changeCamera) withObject:nil afterDelay:0.5];
    
    // Accept call
    //
    NSDictionary *dataDict=[NSDictionary dictionaryWithObjectsAndKeys:[AppHelper userDefaultsForKey:KUserName],@"name",[AppHelper userDefaultsForKey:KUserImageUrl],@"image",nil];
    
    
    
    _lblTime.text=@"Connecting...";
    
    _lblCallerName.text=[self.callerDetail valueForKey:@"name"];
    NSString *urlString=[self.callerDetail valueForKey:@"image"];
    if([urlString length]>0)
        [_imgCallerImage setImageWithURL:[NSURL URLWithString:urlString] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
}

-(IBAction)onClickCancelCallButton:(id)sender//Cancel live portal call by caller
{
    if(callTimer!=nil){
        [callTimer invalidate];
        callTimer=nil;
    }
    
    
    [UIView animateWithDuration:0.5 animations:^(void){
        CGRect frameRect=_viewVideoCall.frame;
        frameRect.origin.y=568;
        _viewVideoCall.frame=frameRect;
    }completion:^(BOOL finish)
     {
         [_viewVideoCall removeFromSuperview];
     }];
    
    
}

#pragma mark Receive notifications

-(void)updateNotificationCountFromPushNotification:(NSNotification*)noti{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Update_Notofication_Count object:nil];
    NSDictionary *dataDict = noti.userInfo;
    
    if([[dataDict valueForKey:@"push_type"] isEqualToString:KPush_For_Get_Skoop_Request] || [[dataDict valueForKey:@"push_type"] isEqualToString:KPush_Buy_Skoop]){
        
        NSArray *navArray=self.navigationController.viewControllers;
        
        if(![[navArray lastObject] isKindOfClass:[ReplyOnSkoopVC class]]){
            
            NSDictionary *skoopDict=nil;
            
            if([[dataDict valueForKey:@"push_type"] isEqualToString:KPush_Buy_Skoop])
                skoopDict = [NSDictionary dictionaryWithObjectsAndKeys:@"0",@"skoop_type",[dataDict valueForKey:@"skoop_id"],@"skoop_id", nil];
            else
                skoopDict = [NSDictionary dictionaryWithObjectsAndKeys:[dataDict valueForKey:@"skoop_type"],@"skoop_type",[dataDict valueForKey:@"skoop_id"],@"skoop_id", nil];
                
            if(self.navigationController){
                
                [self performSegueWithIdentifier:@"reply" sender:skoopDict];
            }
            else{
                
                UITabBarController *tabBarCont = [AppcustomTabbar singletonMethod];
                UINavigationController *curNav = [tabBarCont.viewControllers objectAtIndex:1];
                
                UIStoryboard *story = [UIStoryboard storyboardWithName:@"youSkoopLayouts" bundle:nil];
                ReplyOnSkoopVC *replySkoopVC = [story instantiateViewControllerWithIdentifier:@"SkoopReplyId"];
                replySkoopVC.isShowFutureSkoop=[[dataDict valueForKey:@"skoop_type"] integerValue];
                replySkoopVC.skoopId=[dataDict valueForKey:@"skoop_id"];
                [curNav pushViewController:replySkoopVC animated:YES];
            }
        }
        else{
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_SkoopList object:nil userInfo:dataDict];
        }
        
        //Select skoop tab
        [self.tabBarController.delegate tabBarController:self.tabBarController shouldSelectViewController:[[self.tabBarController viewControllers] objectAtIndex:1]];
        [self.tabBarController setSelectedIndex:1];
    }
    else if([[dataDict valueForKey:@"push_type"] isEqualToString:KPush_For_Get_Skoop_Reply] || [[dataDict valueForKey:@"push_type"] isEqualToString:KPush_Confirm_Live_Portal]){
        
        NSMutableDictionary *dataDictInfo=[NSMutableDictionary dictionary];
        [dataDictInfo setValue:[dataDict valueForKey:@"skoop_id"] forKey:@"skoop_id"];
        if([[dataDict valueForKey:@"push_type"] isEqualToString:KPush_Confirm_Live_Portal])
            [dataDictInfo setValue:@"1" forKey:@"live_portal"];
        else
            [dataDictInfo setValue:@"0" forKey:@"live_portal"];
        
        [dataDictInfo setValue:[AppHelper userDefaultsForKey:KUserImageUrl] forKey:@"image"];
        [dataDictInfo setValue:[AppHelper userDefaultsForKey:KUserName] forKey:@"name"];
        [dataDictInfo setValue:@"" forKey:@"searchText"];
        [dataDictInfo setValue:@"" forKey:@"location"];
        [dataDictInfo setValue:@"1" forKey:@"replyCount"];
        [dataDictInfo setValue:@"0" forKey:@"read_status"];
        [dataDictInfo setValue:[dataDict objectForKey:@"group_id"] forKey:@"group_id"];
        
        NSArray *navArray=self.navigationController.viewControllers;
        if(![[navArray lastObject] isKindOfClass:[CellSelectionView class]]){
            
            //Select skoop tab
            [self.tabBarController.delegate tabBarController:self.tabBarController shouldSelectViewController:[[self.tabBarController viewControllers] objectAtIndex:1]];
            [self.tabBarController setSelectedIndex:1];
            [self performSegueWithIdentifier:@"skoop_reply" sender:dataDictInfo];
        }
        else{
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_Skoop_Reply_list object:nil userInfo:dataDictInfo];
        }
    }
    
    [self hideShowNotificationCount];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateNotificationCountFromPushNotification:) name:Notification_Update_Notofication_Count object:nil];
}

-(void)updateOnlyNotificationCountFromPushNotification:(NSNotification*)noti{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Update_Only_Notofication_Count object:nil];
    NSDictionary *dataDict=noti.userInfo;
    
    if([[dataDict valueForKey:@"push_type"] isEqualToString:KPush_For_Get_Skoop_Request]){
        
        if([dataDict valueForKey:@"count"])
            [AppHelper saveToUserDefaults:[dataDict valueForKey:@"count"] withKey:KSkoopRequest];
        else
            [AppHelper saveToUserDefaults:@"0" withKey:KSkoopRequest];
        _lblAnswerReqCount.text=[AppHelper userDefaultsForKey:KSkoopRequest];
    }
    else if([[dataDict valueForKey:@"push_type"] isEqualToString:KPush_For_Get_Skoop_Reply] || [[dataDict valueForKey:@"push_type"] isEqualToString:KPush_Confirm_Live_Portal]){
        
        if([dataDict valueForKey:@"count"])
            [AppHelper saveToUserDefaults:[dataDict valueForKey:@"count"] withKey:KSkoopReplyCount];
        else
            [AppHelper saveToUserDefaults:@"0" withKey:KSkoopReplyCount];
        _lblInboxCount.text=[AppHelper userDefaultsForKey:KSkoopReplyCount];
    }
    else if([[dataDict objectForKey:@"push_type"] isEqualToString:KPush_For_Group_Req] || [[dataDict objectForKey:@"push_type"] isEqualToString:KPush_Unblock_from_group] || [[dataDict objectForKey:@"push_type"] isEqualToString:KPush_Block_from_group] || [[dataDict objectForKey:@"push_type"] isEqualToString:KPush_Block_from_app] || [[dataDict objectForKey:@"push_type"] isEqualToString:KPush_Unblock_from_app] || [[dataDict objectForKey:@"push_type"] isEqualToString:KPush_For_Get_Group_Skoop_Request]){
        
        if([dataDict valueForKey:@"count"])
            [AppHelper saveToUserDefaults:[dataDict valueForKey:@"count"] withKey:KNotificationCount];
        else
            [AppHelper saveToUserDefaults:@"0" withKey:KNotificationCount];
        
        NSLog(@"Set notification count:%@==%@",[AppHelper userDefaultsForKey:KNotificationCount],[dataDict valueForKey:@"count"]);
        _lblGroupRequestCount.text = [AppHelper userDefaultsForKey:KNotificationCount];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateOnlyNotificationCountFromPushNotification:) name:Notification_Update_Only_Notofication_Count object:nil];
}


-(void)userDidReplyOnSkoop:(NSNotification *)notification{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_reply_on_skoop object:nil];
    NSLog(@"%@",notification.userInfo);
    if(notification.userInfo){
        if([notification.userInfo valueForKey:@"skoop_id"])
            [[WebServicesController WebServiceMethod] deleteSkoopWithSkoopId:[notification.userInfo valueForKey:@"skoop_id"]];
        if([notification.userInfo valueForKey:@"errorCode"]==0){
            
            dispatch_async(dispatch_get_main_queue(), ^(void){
                
                [[WebServicesController WebServiceMethod] deleteSkoopWithSkoopId:[notification.userInfo valueForKey:@"skoop_id"]];
                if(skoopIndex<skoopReplyArray.count)
                    [self resumeOfPendingSkoopRequest];
            });
        }
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnSkoop:) name:Notification_reply_on_skoop object:nil];
}

-(void)userDidGetSyncSkoop:(NSNotification *)notification{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Sync_Skoop object:nil];
    NSLog(@"%@",notification.userInfo);
    
    if(notification.userInfo){
        if([notification.userInfo valueForKey:@"errorCode"]==0)
        {
            
        }
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnSkoop:) name:Notification_reply_on_skoop object:nil];
}

-(void)userDidLGetNotificationCount:(NSNotification*)note{
    
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Notofication_Count object:nil];
    
    if(note.userInfo){
        
        if([[note.userInfo valueForKey:@"errorCode"] integerValue] == 0){
            
            if([[note.userInfo valueForKey:@"isLogin"] integerValue] == 1){
                
                [AppHelper saveToUserDefaults:[[note.userInfo valueForKey:@"data"] valueForKey:@"amount"] withKey:KPriceData];
                
                //Save counts in user defaults
                [AppHelper saveToUserDefaults:[[note.userInfo valueForKey:@"data"] valueForKey:@"notification_count"] withKey:KNotificationCount];
                [AppHelper saveToUserDefaults:[[note.userInfo valueForKey:@"data"] valueForKey:@"skoop_request"] withKey:KSkoopRequest];
                [AppHelper saveToUserDefaults:[[note.userInfo valueForKey:@"data"] valueForKey:@"skoop_reply"] withKey:KSkoopReplyCount];
                
                _lblInboxCount.text = [[note.userInfo valueForKey:@"data"] valueForKey:@"skoop_reply"];
                _lblAnswerReqCount.text = [[note.userInfo valueForKey:@"data"] valueForKey:@"skoop_request"];
                _lblGroupRequestCount.text = [[note.userInfo valueForKey:@"data"] valueForKey:@"notification_count"];
                
                [self hideShowNotificationCount];
                
                [AppHelper saveToUserDefaults:[NSString stringWithFormat:@"%.2f",[[[note.userInfo valueForKey:@"data"] valueForKey:@"total_amount"] floatValue]] withKey:KAvailableCredit];
                [AppHelper saveToUserDefaults:[NSString stringWithFormat:@"%.2f",[[[note.userInfo valueForKey:@"data"] valueForKey:@"redeem_amount"] floatValue]] withKey:KRedeemAmount];
                
                //Update available balance
                UILabel *lblAmount = (UILabel*)[self.view viewWithTag:15555];
                lblAmount.text = [NSString stringWithFormat:@"$ %.2f",[[AppHelper userDefaultsForKey:KAvailableCredit] floatValue]];
                
                if(![AppHelper userDefaultsForKey:isSyncData]){
                    NSArray *syncDataArray=[note.userInfo valueForKey:@"synData"];
                    for (int i=0; i<syncDataArray.count; i++){
                        [self createReminderWithData:[syncDataArray objectAtIndex:i]];
                    }
                    [AppHelper saveToUserDefaults:@"1" withKey:isSyncData];
                }
            }
            else{
                
                [[AppDelegate getAppDelegate] loggedOutFromApp];
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have loged out due to login on another device with same credential." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:Nil];
            }
        }
    }
}

-(void)refreshNotificationListWithPush:(NSNotification*)noti{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Update_Notification_List object:nil];
    NSArray *navArray = self.navigationController.viewControllers;
    if(![[navArray lastObject] isKindOfClass:[NotificationVC class]]){
        
        if(self.navigationController){
            [self performSegueWithIdentifier:@"notification" sender:[noti.userInfo valueForKey:@"notification_id"]];
        }
        else{
            
            UITabBarController *tabBarCont = [AppcustomTabbar singletonMethod];
            UINavigationController *curNav = [tabBarCont.viewControllers objectAtIndex:1];
            
            UIStoryboard *story = [UIStoryboard storyboardWithName:@"youSkoopLayouts" bundle:nil];
            NotificationVC *notiVC = [story instantiateViewControllerWithIdentifier:@"Notificationview"];
            notiVC.notificationId = [noti.userInfo valueForKey:@"notification_id"];
            [curNav pushViewController:notiVC animated:YES];
        }
    }
    
    //Select skoop tab
    [self.tabBarController.delegate tabBarController:self.tabBarController shouldSelectViewController:[[self.tabBarController viewControllers] objectAtIndex:1]];
    [self.tabBarController setSelectedIndex:1];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(refreshNotificationListWithPush:) name:Notification_Update_Notification_List object:nil];
}

-(void)userDidPaidLivePortalCallPayment:(NSNotification*)noti{
    
    NSLog(@"%@",noti.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Live_Portal_Payment object:nil];
    if(noti.userInfo){
        
        if([[noti.userInfo valueForKey:@"errorCode"] integerValue] == 0){
            
            [AppHelper saveToUserDefaults:[NSString stringWithFormat:@"%.2f",[[noti.userInfo valueForKey:@"total_amount"] floatValue]] withKey:KAvailableCredit];
            //Update available balance
            UILabel *lblAmount = (UILabel*)[self.view viewWithTag:15555];
            lblAmount.text = [NSString stringWithFormat:@"$ %.2f",[[AppHelper userDefaultsForKey:KAvailableCredit] floatValue]];
            [[self deligate] updateCallPaymentStatus];
        }
        else if([[noti.userInfo valueForKey:@"errorCode"] integerValue] == 1){
            
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidPaidLivePortalCallPayment:) name:Notification_Live_Portal_Payment object:nil];
            [[WebServicesController WebServiceMethod] livePortalPaymentWithUserId:[AppHelper userDefaultsForKey:KUserId] sellerId:[self.callerDetail valueForKey:@"seller_id"] portalId:[self.callerDetail valueForKey:@"portal_id"] amount:[self.callerDetail valueForKey:@"price"] andAppToken:KAppToken];
        }
    }
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(alertView.tag==1){
        
        [[AppDelegate getAppDelegate] loggedOutFromApp];
    }
}

#pragma mark Sync calendar data
-(void)createReminderWithData:(NSDictionary*)dataDict{
    EKEventStore *eventStore = [[EKEventStore alloc] init];
    
    [eventStore requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error)
     {
         if (!granted) { return; }
         
         EKEvent *event  = [EKEvent eventWithEventStore:eventStore];
         
         NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
         [dateFormatter setDateFormat:@"EEE,hh:mm a,MM/dd,yyyy"];
         
         NSDate *evenStartDate=[dateFormatter dateFromString:[dataDict valueForKey:@"date"]];
         
//         if(![[dataDict valueForKey:@"reminder_time"] isKindOfClass:[NSNull class]])
//             event.startDate=[dateFormatter dateFromString:[dataDict valueForKey:@"reminder_date_time"]];
//         else
//             return;
         
         event.startDate=evenStartDate;
         evenStartDate=[evenStartDate dateByAddingTimeInterval:3600];
         event.endDate=evenStartDate;
         
         if([dataDict valueForKey:@"searchText"])
             event.title = [NSString stringWithFormat:@"youSKOOP:%@",[dataDict valueForKey:@"searchText"]];
         else
             event.title = @"youSKOOP:Reminder";
         
         event.location=[dataDict valueForKey:@"location"];
         event.notes=[dataDict valueForKey:@"location"];
         
         // Get an array of all the calendars.
         NSArray *calendars = [eventStore calendarsForEntityType:EKEntityTypeEvent];
         
         // Get the default calendar, set by the user in preferences.
         EKCalendar *defaultCal = eventStore.defaultCalendarForNewEvents;
         // Find out if this calendar is modifiable.
         BOOL isDefaultCalModifiable = defaultCal.allowsContentModifications ;
         
         NSPredicate *predicate = [eventStore predicateForEventsWithStartDate:event.startDate
                                                                      endDate:event.endDate calendars:calendars];
         
         NSArray *matchingEvents = [eventStore eventsMatchingPredicate:predicate];
         
         if( ! isDefaultCalModifiable) {
             // The default calendar is not modifiable
             NSLog(@"The default calendar is not modifiable");
             return ;
         }
         
         if([matchingEvents count ] > 0){
             NSLog(@"Event already added");
             return ;
         }
         
         [event setCalendar:[eventStore defaultCalendarForNewEvents]];
         
         NSError *err;
         BOOL isSuccess= [eventStore saveEvent:event span:EKSpanThisEvent error:&err];
         NSLog(@"Event Success:::::::%i       %@",isSuccess,err);
     }];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark prepare segue

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    if([segue.identifier isEqualToString:@"reply"]){
        
        NSDictionary *dataDict=nil;
        if(sender)
            dataDict=(NSDictionary*)sender;
        
        ReplyOnSkoopVC *destViewController = segue.destinationViewController;
        if(dataDict){
            destViewController.isShowFutureSkoop=[[dataDict valueForKey:@"skoop_type"] integerValue];
            destViewController.skoopId=[dataDict valueForKey:@"skoop_id"];
        }
    }
    else if([segue.identifier isEqualToString:@"notification"]){
        
        NotificationVC *destViewController = segue.destinationViewController;
        if(sender){
            NSString *requestId=(NSString*)sender;
            destViewController.notificationId=requestId;
        }
    }
    else if([segue.identifier isEqualToString:@"userprofile"]){
        
        UserProfileVC *userProfile = segue.destinationViewController;
        userProfile.groupId=@"";
        userProfile.name = [AppHelper userDefaultsForKey:KUserName];
        userProfile.blockUserId = [AppHelper userDefaultsForKey:KUserId];
    }
    else if([segue.identifier isEqual:@"skoop_reply"]){
        
        NSDictionary *dataDict=(NSDictionary*)sender;
        CellSelectionView *cellselectionobj=segue.destinationViewController;
        cellselectionobj.getInfoRequest=[NSMutableDictionary dictionaryWithDictionary:dataDict];
    }
}


     @end
