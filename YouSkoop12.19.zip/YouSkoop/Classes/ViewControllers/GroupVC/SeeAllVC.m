//
//  SeeAllVC.m
//  youskoop
//
//  Created by Richika_Golchha on 4/28/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "SeeAllVC.h"
#import "AppHelper.h"
#import "AFNetworking.h"
#import "Defines.h"
#import "GroupProfileVC.h"
#import "SendGroupSkoop.h"

@interface SeeAllVC ()
{
    __weak IBOutlet UITextField *_txtSearch;
    NSArray *searchDataArray;
    BOOL isSearching;
}
@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
@property (strong, nonatomic) NSArray *searchDataArray;

@end

@implementation SeeAllVC

@synthesize searchDataArray;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    
    if(!IS_IPHONE_5){
        CGRect frameRect=self._tableView.frame;
        frameRect.size.height=353;
        self._tableView.frame=frameRect;
    }
    self.titleLabel.text=self.pageTitle;
}

#pragma mark table view delegates
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(isSearching)
        return [self.searchDataArray count];
    else
        return [self.groupDataArray count];
}

-(UITableViewCell *)tableView:(UITableView *)table_View cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"CellId";
    UITableViewCell *cell = [table_View dequeueReusableCellWithIdentifier:CellIdentifier];
    cell.backgroundColor=[UIColor clearColor];
    
     UIImageView *image_view = (UIImageView *)[cell.contentView viewWithTag:201];
     [AppHelper getRoundedRectImageWithImageView:image_view withColor:[UIColor clearColor] andRadius:10.0 andWidth:2.0];
    
    NSDictionary *dict=nil;
    if(isSearching)
        dict=[self.searchDataArray objectAtIndex:indexPath.row];
    else
        dict=[self.groupDataArray objectAtIndex:indexPath.row];
    
    UILabel *lblGroupName = (UILabel *)[cell.contentView viewWithTag:202];
    lblGroupName.textColor=KTextColor;
    lblGroupName.text=[dict valueForKey:@"group_name"];
    
    UILabel *lblDescription = (UILabel *)[cell.contentView viewWithTag:203];
    if([[dict valueForKey:@"owner_id"] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
        lblDescription.text=[NSString stringWithFormat:@"(%@/Admin) %@",[dict valueForKey:@"group_type"],[dict valueForKey:@"group_description"]];
    else
        lblDescription.text=[NSString stringWithFormat:@"(%@) %@",[dict valueForKey:@"group_type"],[dict valueForKey:@"group_description"]];

    UILabel *lblCount = (UILabel *)[cell.contentView viewWithTag:204];
    lblCount.textColor=KTextColor;
    lblCount.text=[NSString stringWithFormat:@"%@ Skoops - %@ Members",[dict valueForKey:@"skoop_count"],[dict valueForKey:@"member_count"]];

    if([dict valueForKey:@"image"])
        [image_view setImageWithURL:[NSURL URLWithString:[dict valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"user_default.png"]];
    
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if([_txtSearch isFirstResponder])
        [_txtSearch resignFirstResponder];
    else
    {
        NSDictionary *groupDict=nil;
        if(isSearching)
            groupDict=[self.searchDataArray objectAtIndex:indexPath.row];
        else
            groupDict=[self.groupDataArray objectAtIndex:indexPath.row];
        [self performSegueWithIdentifier:@"seeall" sender:groupDict];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    int numberOfRows ;
    if(isSearching)
        numberOfRows = (int)self.searchDataArray.count;
    else
        numberOfRows = (int)self.groupDataArray.count;
    if(indexPath.row == numberOfRows-1)
        return 109.0;
    else
        return 89.0;
}

#pragma mark Textfield deligates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    isSearching=YES;
    NSString *searchText = [textField.text stringByReplacingCharactersInRange:range withString:string];
    [self searchGroupWithText:searchText];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSString *searchString=[textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if([searchString length]==0){
        isSearching=NO;
        [self._tableView reloadData];
    }
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    isSearching=NO;
    [self._tableView reloadData];
    return YES;
}

-(void)searchGroupWithText:(NSString*)searchText
{
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"(group_name MATCHES[c] %@)",
                              [NSString stringWithFormat: @".*\\b%@.*",searchText]];
    
    self.searchDataArray=[self.groupDataArray filteredArrayUsingPredicate:predicate];
    [self._tableView reloadData];
}


#pragma mark-BackButton

- (IBAction)backButton:(id)sender{
    
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)onClickSendRequestButton:(id)sender{
    
    SendGroupSkoop *contentView = [self.storyboard instantiateViewControllerWithIdentifier:@"sendgroupskoops"];
    contentView.isSaveSendSkoop = YES;
    [self.navigationController pushViewController:contentView animated:YES];
}

#pragma mark Prepare for segue
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    
    NSDictionary *groupDataDict=(NSDictionary*)sender;
    NSLog(@"%@",groupDataDict);
    if ([segue.identifier isEqualToString:@"seeall"]){
        
        GroupProfileVC *grpProfile=segue.destinationViewController;
        grpProfile.name=[groupDataDict valueForKey:@"group_name"];
        grpProfile.imgUrl=[groupDataDict valueForKey:@"cover_image"];
        grpProfile.groupImageUrl=[groupDataDict valueForKey:@"image"];
        grpProfile.groupDescription=[groupDataDict valueForKey:@"group_description"];
        grpProfile.groupId=[groupDataDict valueForKey:@"group_id"];
        grpProfile.categoryName=[groupDataDict valueForKey:@"category_name"];
        grpProfile.categoryId=[groupDataDict valueForKey:@"category_id"];
        grpProfile.groupType=[groupDataDict valueForKey:@"group_type"];
        grpProfile.ownerId=[groupDataDict valueForKey:@"owner_id"];
        grpProfile.prEmail=[groupDataDict valueForKey:@"pr_email"];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
