//
//  GroupVC.h
//

//
//  Created by Shitesh Patel on 08/04/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupProfileVC.h"
#import "XLCycleScrollView.h"

@interface GroupVC : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate,updateMyGroupListProtocol,saveDataProtocol,upDateSkoopListDeligate,XLCycleScrollViewDatasource,XLCycleScrollViewDelegate>
{
    
}
@property (strong, nonatomic) IBOutlet UIView *pickerView;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerCategory;
@property (strong, nonatomic) IBOutlet UITableView *_tableView;

- (IBAction)onClickSendRequestButton:(id)sender;
- (IBAction)pickerDoneAction:(id)sender;
- (IBAction)pickerCancelAction:(id)sender;
- (IBAction)seeAllAction:(id)sender;
- (IBAction)onClickLeftArrowButton:(id)sender;
- (IBAction)onClickRightArrowtButton:(id)sender;

@end
