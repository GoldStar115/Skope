//
//  MyGroupVC.h
//  youskoop
//
//  Created by Shitesh Patel on 17/04/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GroupProfileVC.h"

@interface MyGroupVC : UIViewController<updateMyGroupListProtocol>{
    
}
- (IBAction)backButton:(id)sender;
@end
