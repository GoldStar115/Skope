//
//  CallViewController.h
//  youskoop
//
//  Created by My Star on 11/18/15.
//  Copyright © 2015 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <ooVooSDK/ooVooSDK.h>
#import <ooVooSDK/ooVooPushService.h>

@interface CallViewController : UIViewController

@property (nonatomic, retain) ooVooClient *sdk;

@property NSString *conferenceId;
@property NSString *opponentUsername;
@property NSString *opponentUserImgUrl;

@end
