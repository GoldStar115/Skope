//
//  IndividualGroupVC.m
//  youskoop
//
//  Created by Richika_Golchha on 5/12/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "IndividualGroupVC.h" 
#import "UserProfileVC.h"

#define is_selected @"is_selected"

@interface IndividualGroupVC ()
{
    NSMutableArray *individualGroupArray;
    NSMutableArray *afterSearchArray;
    NSInteger rowIndex;
    NSMutableArray *selectedMembers;
    NSString *searchText;
    BOOL isSearching;
}

@property (strong, nonatomic) IBOutlet UIButton *selectAll;
@property (strong, nonatomic) IBOutlet UITableView *_tableView;
@property (strong, nonatomic) IBOutlet UIView *_searchView;
@property (strong, nonatomic) IBOutlet UITextField *_textField;
@property (strong, nonatomic) IBOutlet UIButton *inviteButton;

@end

@implementation IndividualGroupVC
@synthesize groupId,groupName,isShowSearch,requestGroupId;

#pragma mark-ViewLifeCycle
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    if(!isShowSearch){
        self._searchView.hidden=YES;
        self.inviteButton.hidden=YES;
    }
    
    UILabel *lblNavTitle=(UILabel*)[self.view viewWithTag:500];
    lblNavTitle.text=self.groupName;
    
    if(!IS_IPHONE_5){
        CGRect frameRect=self._tableView.frame;
        if(!isShowSearch){
            frameRect.size.height=373;
            if(IS_Greater_Or_Equal_to_IOS_7)
                frameRect.origin.y=64;
            else
                frameRect.origin.y=44;
        }
        else
            frameRect.size.height=263;
        self._tableView.frame=frameRect;
        
        UIButton *btnSendReq=(UIButton*)[self.view viewWithTag:11111];
        CGRect btnFrameRect=btnSendReq.frame;
        btnFrameRect.origin.y=399.0;
        btnSendReq.frame=btnFrameRect;
    }
    else if(IS_IPHONE_5 && !isShowSearch){
        CGRect frameRect=self._tableView.frame;
        frameRect.size.height=444;
        if(IS_Greater_Or_Equal_to_IOS_7)
            frameRect.origin.y=64;
        else
            frameRect.origin.y=44;
        self._tableView.frame=frameRect;
    }
    
    individualGroupArray=[[NSMutableArray alloc] init];
    afterSearchArray=[[NSMutableArray alloc]init];
    selectedMembers=[[NSMutableArray alloc]init];

    isSearching=NO;
    searchText=@"";
    
    self._tableView.backgroundColor=[UIColor clearColor];
     
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getIndividualGroupMembers:) name: Notification_Get_IndividualGroupMembers object:nil];
    [[WebServicesController WebServiceMethod] getIndividualGroupMembersDataUserId:[AppHelper userDefaultsForKey:KUserId] searchText:@"" pageNumber:@"1" pageLimit:@"100" andGroupId:self.groupId];
}

#pragma mark-GeneralMethods

-(void)getMembersWithText:(NSString*)string andIsShowIndicator:(BOOL)showIndicator
{
    if(showIndicator)
    {
        [AppDelegate dismissGlobalHUD];
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    }
    else
    {
        UIImageView *imgView=(UIImageView*)[self._searchView viewWithTag:806];
        imgView.hidden=YES;
        NSLog(@"image: %@",imgView);
        
        UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[self._searchView viewWithTag:1001];
        
        if(activityIndicator)
            [activityIndicator startAnimating];
        else
        {
            activityIndicator= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            activityIndicator.backgroundColor=[UIColor clearColor];
            activityIndicator.alpha = 1.0;
            activityIndicator.tag=1001;
            activityIndicator.center = imgView.center;
            activityIndicator.hidesWhenStopped = YES;
            [self._searchView addSubview:activityIndicator];
            [activityIndicator startAnimating];
        }
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getIndividualGroupMembers:) name: Notification_Get_IndividualGroupMembers object:nil];
     [[WebServicesController WebServiceMethod] getIndividualGroupMembersDataUserId:[AppHelper userDefaultsForKey:KUserId] searchText:string pageNumber:@"1" pageLimit:@"100" andGroupId:self.groupId];
}

-(void) sendInviteToMember:(NSNotification *)note
{
    [AppDelegate dismissGlobalHUD];
    
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Send_InviteToMember object:nil];
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
        [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:self cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
}

#pragma mark Tap gesture methods
-(void)tapOnUserProfileImage:(UITapGestureRecognizer*)tapGesture
{
    UITableViewCell *tableVewCell=nil;
    if(IS_IOS_7)
        tableVewCell=(UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[tapGesture.view superview] superview];
    
    NSIndexPath *indexPath=[self._tableView indexPathForCell:tableVewCell];
    NSDictionary *dataDict=nil;
    
    
    if(isSearching)
        dataDict=[afterSearchArray objectAtIndex:indexPath.row];
    else
        dataDict=[individualGroupArray objectAtIndex:indexPath.row];
    
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}


#pragma mark Receive notification methods
-(void)getIndividualGroupMembers:(NSNotification*) note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    //  [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_IndividualGroupMembers object:nil];
    if(note.userInfo)
    {
        if(isSearching)
        {
            UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[self._searchView viewWithTag:1001];
            
            if(activityIndicator)
                [activityIndicator stopAnimating];
            
            UIImageView *imgView=(UIImageView*)[self._searchView viewWithTag:806];
            imgView.hidden=NO;
            
            //afterSearchArray=[note.userInfo valueForKey:@"data"];
            if(afterSearchArray.count>0)
                [afterSearchArray removeAllObjects];
            
            NSArray *array=[note.userInfo valueForKey:@"data"];
            for (int i=0; i<array.count; i++)
            {
                NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[array objectAtIndex:i]];
                [afterSearchArray addObject:dict];
            }
            
            NSLog(@"%@",afterSearchArray);
            
            if( afterSearchArray.count == 0 )
            {
                self.selectAll.enabled=NO;
            }
            else
                self.selectAll.enabled=YES;
        }
        else
        {
            if(individualGroupArray.count>0)
                [individualGroupArray removeAllObjects];
            
            NSArray *array=[note.userInfo valueForKey:@"data"];
            for (int i=0; i<array.count; i++)
            {
                NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[array objectAtIndex:i]];
                [individualGroupArray addObject:dict];
            }
            NSLog(@"aarrraaayy::: %@",individualGroupArray);
            NSLog(@"%@",individualGroupArray);
            
            if( individualGroupArray.count == 0 )
            {
                self.selectAll.enabled=NO;
            }
            else
                self.selectAll.enabled=YES;
        }
        [self._tableView reloadData];
    }
    
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag==102){
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark table view delegates

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    UILabel *lblNoData=(UILabel*)[self.view viewWithTag:123];
    BOOL isShowLabel=NO;
    if(isSearching && afterSearchArray.count==0)
        isShowLabel=YES;
    else if(individualGroupArray.count==0)
        isShowLabel=YES;
    
    if(isShowLabel){
        if(!lblNoData){
            lblNoData=[[UILabel alloc] initWithFrame:CGRectMake(0, self._tableView.frame.size.height/2.0-15.0, 320, 30.0)];
            lblNoData.backgroundColor=[UIColor clearColor];
            lblNoData.textColor=KTextColor;
            lblNoData.tag=123;
            lblNoData.textAlignment=NSTextAlignmentCenter;
            lblNoData.text=@"No data available";
            [self._tableView addSubview:lblNoData];
        }
    }
    else
        [lblNoData removeFromSuperview];
    
    if(isSearching)
        return [afterSearchArray count];
    else
        return [individualGroupArray count];
}

-(UITableViewCell *)tableView:(UITableView *)table_View cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [table_View dequeueReusableCellWithIdentifier:@"Cell"];
    
    if (cell == nil)
    {
        NSLog(@"****************nil*********************");
        NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"MemberCell" owner:self options:nil];
        // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
        cell = [topLevelObjects objectAtIndex:0];
        cell.backgroundColor=[UIColor clearColor];
        
        UIImageView *imgUser = (UIImageView *)[cell.contentView viewWithTag:801];
        [AppHelper getRoundedImageWithImageView:imgUser];
        UITapGestureRecognizer *uiTap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnUserProfileImage:)];
        uiTap1.numberOfTapsRequired=1;
        imgUser.userInteractionEnabled=YES;
        [imgUser addGestureRecognizer:uiTap1];
    }

    UIImageView *imgUser = (UIImageView *)[cell.contentView viewWithTag:801];
    UIButton *check_img=(UIButton*)[cell.contentView viewWithTag:804];
    [check_img addTarget:self action:@selector(selectMember:) forControlEvents:UIControlEventTouchUpInside];
    
    if(!isShowSearch)
        check_img.hidden=YES;
    
    if([self.selectAll isSelected])
        check_img.selected=YES;
    
    NSMutableDictionary *dict=nil;
    
    if(isSearching)
        dict=[afterSearchArray objectAtIndex:indexPath.row];
    else
        dict=[individualGroupArray objectAtIndex:indexPath.row];
    
    UILabel *lblLikeCount=(UILabel *)[cell.contentView viewWithTag:800];
    lblLikeCount.backgroundColor=[UIColor clearColor];
    lblLikeCount.text=[NSString stringWithFormat:@"%i",[[dict valueForKey:@"like"] integerValue]];
    
    if([dict valueForKey:is_selected] && [[dict valueForKey:is_selected] isEqualToString:@"1"])
        check_img.selected=YES;
    else  if(![dict valueForKey:is_selected] || [[dict valueForKey:is_selected] isEqualToString:@"0"])
        check_img.selected=NO;

    UILabel *lblName = (UILabel *)[cell.contentView viewWithTag:802];
    lblName.text=[dict valueForKey:@"name"];
    
    UILabel *lblDate = (UILabel *)[cell.contentView viewWithTag:805];
    lblDate.text=[dict valueForKey:@"join_date"];
    
    if([[dict valueForKey:@"image"] length]>0)
        [imgUser setImageWithURL:[NSURL URLWithString:[dict valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    else
        imgUser.image=[UIImage imageNamed:@"defaultuser.png"];
    
    return cell;
}

#pragma mark-textFieldDelegates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    isSearching=YES;
    searchText = [self._textField.text stringByReplacingCharactersInRange:range withString:string];
    [self getMembersWithText:searchText andIsShowIndicator:NO];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSString *searchString=[textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if([searchString length]==0)
    {
       isSearching=NO;
        [self._tableView reloadData];
    }
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    isSearching=NO;
    [self._tableView reloadData];
    return YES;
}

#pragma mark-ButtonMethods
- (IBAction)selectMember:(id)sender
{
    if([self._textField isFirstResponder])
        [self._textField resignFirstResponder];
    else
    {
        UIButton *btn=(UIButton*)sender;
        UITableViewCell *cell=nil;
        
        if(IS_IOS_7)
            cell=(UITableViewCell*)[[[btn superview]superview]superview];
        else
            cell=(UITableViewCell*)[[btn superview]superview];
        
        rowIndex=[self._tableView indexPathForCell:cell].row;
        NSMutableDictionary *dictionary=nil;
        if(isSearching)
            dictionary=(NSMutableDictionary*)[afterSearchArray objectAtIndex:rowIndex];
        else
            dictionary=(NSMutableDictionary*)[individualGroupArray objectAtIndex:rowIndex];
        
        if([btn isSelected])
        {
            btn.selected=NO;
            [dictionary setValue:@"0" forKey:is_selected];
            [selectedMembers removeObject:[dictionary valueForKey:@"user_id"]];
        }
        else
        {
            btn.selected=YES;
            [dictionary setValue:@"1" forKey:is_selected];
            [selectedMembers addObject:[dictionary valueForKey:@"user_id"]];
        }
        
        if(isSearching)
        {
            [afterSearchArray replaceObjectAtIndex:rowIndex withObject:dictionary];
            
            if(selectedMembers.count == afterSearchArray.count)
                self.selectAll.selected=YES;
            else
                [self.selectAll setSelected:NO];
        }
        else
        {
            [individualGroupArray replaceObjectAtIndex:rowIndex withObject:dictionary];
            if(selectedMembers.count == individualGroupArray.count)
                self.selectAll.selected=YES;
            else
                [self.selectAll setSelected:NO];
        }
    }
}

- (IBAction)selectAllMember:(id)sender
{
    if([self._textField isFirstResponder])
        [self._textField resignFirstResponder];
    else
    {
        if([self.selectAll isSelected])
        {
            self.selectAll.selected=NO;
            if(isSearching)
            {
                for(int i=0;i<[afterSearchArray count];i++)
                {
                    NSMutableDictionary *dict=(NSMutableDictionary*)[afterSearchArray objectAtIndex:i];
                    [dict setValue:@"0" forKey:is_selected];
                    [afterSearchArray replaceObjectAtIndex:i withObject:dict];
                }
                [selectedMembers removeAllObjects];
            }
            else
            {
                for(int i=0;i<[individualGroupArray count];i++)
                {
                    NSMutableDictionary *dict=(NSMutableDictionary*)[individualGroupArray objectAtIndex:i];
                    [dict setValue:@"0" forKey:is_selected];
                    [individualGroupArray replaceObjectAtIndex:i withObject:dict];
                }
                [selectedMembers removeAllObjects];
            }
            [self._tableView reloadData];
        }
        else
        {
            if(isSearching)
            {
                self.selectAll.enabled=YES;
                self.selectAll.selected=YES;
                
                for(int i=0;i<[afterSearchArray count];i++)
                {
                    NSMutableDictionary *dict=(NSMutableDictionary*)[afterSearchArray objectAtIndex:i];
                    [dict setValue:@"1" forKey:is_selected];
                    [afterSearchArray replaceObjectAtIndex:i withObject:dict];
                }
                
                if(selectedMembers.count>0)
                    [selectedMembers removeAllObjects];
                
                for(int i=0;i<[afterSearchArray count];i++)
                    [selectedMembers addObject:[[afterSearchArray objectAtIndex:i] valueForKey:@"user_id"]];
            }
            else
            {
                self.selectAll.enabled=YES;
                self.selectAll.selected=YES;
                for(int i=0;i<[individualGroupArray count];i++)
                {
                    NSMutableDictionary *dict=(NSMutableDictionary*)[individualGroupArray objectAtIndex:i];
                    [dict setValue:@"1" forKey:is_selected];
                    [individualGroupArray replaceObjectAtIndex:i withObject:dict];
                }
                
                if(selectedMembers.count>0)
                    [selectedMembers removeAllObjects];
                for(int i=0;i<[individualGroupArray count];i++)
                    [selectedMembers addObject:[[individualGroupArray objectAtIndex:i] valueForKey:@"user_id"]];
            }
            [self._tableView reloadData];
        }
    }
}

- (IBAction)inviteMembers:(id)sender
{
    if(selectedMembers.count>0){
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(sendInviteToMember:) name:  Notification_Send_InviteToMember object:nil];
        [[WebServicesController WebServiceMethod] sendInviteToMembersWithMemberIds:selectedMembers andGroupId:self.requestGroupId];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please select at least one member to send the request." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
}

- (IBAction)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark Segue method
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:@"userprofile"])
    {
        NSDictionary *dataDict=(NSDictionary*)sender;
        UserProfileVC *userProfileObj=segue.destinationViewController;
        userProfileObj.groupId=self.groupId;
        //userProfileObj.groupOwnerId=self.ownerId;
        
        userProfileObj.name=[dataDict valueForKey:@"name"];
        userProfileObj.imgUrl=[dataDict valueForKey:@"image"];
        userProfileObj.blockUserId=[dataDict valueForKey:KUserId];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
