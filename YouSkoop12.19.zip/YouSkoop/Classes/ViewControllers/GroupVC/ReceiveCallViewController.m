//
//  ReceiveCallViewController.m
//  youskoop
//
//  Created by My Star on 11/19/15.
//  Copyright © 2015 user. All rights reserved.
//

#import "ReceiveCallViewController.h"
#import "Defines.h"


@interface ReceiveCallViewController ()<ooVooAVChatDelegate, ooVooVideoControllerDelegate>{
    
    
    IBOutlet UIImageView *imgViewOpponent;
    IBOutlet UILabel *lblOpponent;
    
    IBOutlet UIButton *btnAnswer;
    IBOutlet UIButton *btnDecline;
    IBOutlet UILabel *lblCallTime;
    IBOutlet UIImageView *imgViewWhiteBg;
    
    IBOutlet ooVooVideoPanel *viewMyVideo;
    IBOutlet ooVooVideoPanel *viewOpponentVideo;
    
    ooVooClient *sdk;
   
    IBOutlet UIActivityIndicatorView *spinner;
    UIView *backView;
    
    int collapsedSeconds;
}

@end

@implementation ReceiveCallViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    viewMyVideo.hidden = YES;
    viewOpponentVideo.hidden = YES;
    
    spinner.hidden = NO;
    
    
    sdk = [ooVooClient sharedInstance];
    
    sdk.AVChat.delegate = self;
    sdk.AVChat.VideoController.delegate = self;
    
    //[self ooVooAuthorization];
    
    spinner.hidden = YES;
//    [spinner startAnimating];
//    backView = [[UIView alloc] initWithFrame:CGRectMake(0, 450, 320, 120)];
//    backView.backgroundColor = [UIColor colorWithWhite:1.0 alpha:0.0];
//    [self.view addSubview:backView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClickAnswerButton:(id)sender {
    
    [self createPanel];
    
    //viewMyVideo.hidden = NO;
    btnAnswer.hidden = YES;
    lblCallTime.text = @"Connecting...";
    
    imgViewOpponent.layer.cornerRadius = imgViewOpponent.frame.size.width / 2.0;
    
    dispatch_async(dispatch_get_global_queue(0,0), ^{
        NSData * data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:_opponentUserImgUrl]];
        if ( data == nil )
            return;
        dispatch_async(dispatch_get_main_queue(), ^{
            [imgViewOpponent setImage:[UIImage imageWithData: data]];
        });
    });
    
    lblOpponent.text = _opponentUsername;
}

- (IBAction)onClickDeclineButton:(id)sender {
    
    [self leaveSession];
//    [self removeDelegates];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}



-(void)ooVooAuthorization{
    
    [[ooVooClient sharedInstance] authorizeClient:ooVooToken
                                       completion:^(SdkResult *result) {
                                           if (result.Result == sdk_error_OK)
                                           {
                                               NSLog(@"Good Authorization");
                                               [self ooVooLogin];
                                           }
                                           else
                                           {
                                               NSLog(@"Failed Authorization - Check your ooVoo token !");
                                               
                                           }
                                       }];
}

-(void)ooVooLogin{
    NSString *strVideoUserId = [NSString stringWithFormat:@"skoop_user%@", [AppHelper userDefaultsForKey:KUserId]];
    NSLog(@"userId = %@", strVideoUserId);
    
    [sdk.Account login:strVideoUserId
                 completion:^(SdkResult *result) {
                     
//                     [spinner stopAnimating];
//                     spinner.hidden = YES;
//                     [backView removeFromSuperview];
                     
                     if (result.Result == sdk_error_OK)
                     {
                         NSLog(@"ooVoo Login Success");
                         
                         [sdk.Messaging connect];
                         
                     }
                     else
                     {
                         UIAlertView *alert =[[UIAlertView alloc] initWithTitle:@"Login Error" message:result.description delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                         [alert show];
                     }
                 }];
    
}

- (void)setBackCamera{
    
    NSArray *arr_dev = [sdk.AVChat.VideoController getDevicesList];
    NSString *deviceId = ((id<ooVooDevice>)[arr_dev objectAtIndex:0]).deviceID;
    [sdk.AVChat.VideoController setConfig:deviceId forKey:ooVooVideoControllerConfigKeyCaptureDeviceId];
}

- (void)setResolution{
    
    //    NSMutableArray *allowedResolutions = [NSMutableArray new];
    //    NSArray* resolutions = [sdk.AVChat.VideoController.activeDevice getAvailableResolutions];
    //
    //    if(resolutions)
    //    {
    //        for(NSNumber* resolution in resolutions)
    //        {
    //            if ([sdk.AVChat isResolutionSuported:[resolution integerValue]]) {
    //                [allowedResolutions addObject:resolution];
    //            }
    //        }
    //    }
    //
    //    NSLog(@"allowedResolutions = %@", allowedResolutions);
    //
    //    NSString *currentRes = [sdk.AVChat.VideoController getConfig:ooVooVideoControllerConfigKeyResolution];
    //    NSLog(@"currentRes = %@", currentRes);
    [sdk.AVChat.VideoController setConfig:@"4" forKey:ooVooVideoControllerConfigKeyResolution];
}

-(void)createPanel{
    
//    [self setBackCamera];
//    [self setResolution];
    
    [sdk.AVChat.VideoController bindVideoRender:nil/*[ActiveUserManager activeUser].userId*/ render:viewMyVideo];
    [sdk.AVChat.VideoController openCamera];
    
    [sdk.AVChat.AudioController initAudio:^(SdkResult *result) {
        //[self.sdk.AVChat.VideoController setConfig:currentRes forKey:ooVooVideoControllerConfigKeyResolution];
        
        //if([self currentEffect])
        //  [self.sdk.AVChat.VideoController setConfig:[self currentEffect] forKey:ooVooVideoControllerConfigKeyEffectId];
        
        NSLog(@"result %d description %@", result.Result, result.description);
        
        [sdk updateConfig:^(SdkResult *result){
            //NSString *displayName = [[ActiveUserManager activeUser].displayName length] > 0 ? [ActiveUserManager activeUser].displayName : [ActiveUserManager activeUser].userId;
            [sdk.AVChat.VideoController startTransmitVideo];
            [sdk.AVChat join:_conferenceId user_data:@"Great!"];
            
            viewMyVideo.hidden = NO;
        }];
    }];
    
}

- (void)didParticipantJoin:(id<ooVooParticipant>)participant user_data:(NSString *)user_data{

    //[backView removeFromSuperview];
    
//    viewOpponentVideo.hidden = NO;
//    [sdk.AVChat.VideoController registerRemoteVideo:participant.participantID];
//    [sdk.AVChat.VideoController bindVideoRender:participant.participantID render:viewOpponentVideo];
    
    collapsedSeconds = 0;
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(onTimer) userInfo:nil repeats:YES];
    
}

- (void)onTimer{
    
    collapsedSeconds++;
    int displaySeconds = collapsedSeconds - ooVooBlankTime;
    if (displaySeconds > 0) {
        double seconds = fmod(displaySeconds, 60.0);
        double minutes = fmod(trunc(displaySeconds / 60.0), 60.0);
        //double hours = trunc(displaySeconds / 3600.0);
        lblCallTime.text = [NSString stringWithFormat:@"%02.0f : %02.0f", minutes, seconds];
    }
    
}

- (void)didConferenceStateChange:(ooVooAVChatState)state error:(sdk_error)code{
    if (state == ooVooAVChatStateJoined && code == sdk_error_OK)
    {
        [UIApplication sharedApplication].idleTimerDisabled = (code == sdk_error_OK);
        [sdk.AVChat.AudioController setRecordMuted:NO];
        [sdk.AVChat.AudioController setPlaybackMute:NO];
        
        
    }
    else if (state == ooVooAVChatStateJoined || state == ooVooAVChatStateDisconnected)
    {
        if (state == ooVooAVChatStateJoined && code != sdk_error_OK)
        {
            //UIAlertView *alert =  [[UIAlertView alloc] initWithTitle:@"Join Error" message:[VideoConferenceVC getErrorDescription:code] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            //[alert show];
        }
        
        if (state == ooVooAVChatStateDisconnected)
        {
            // currentRes = defaultRes;
            // [self animateViewsForState:true]; // return to first view ....
            
            
            // _isViewInTransmitMode = false;
            //[self resetAll];
            //[self refreshScrollViewContentSize];
            
            
            [sdk.AVChat.VideoController bindVideoRender:nil/*[ActiveUserManager activeUser].userId*/ render:viewMyVideo];
            //  [self.sdk.AVChat.VideoController setConfig:self.defaultCameraId forKey:ooVooVideoControllerConfigKeyCaptureDeviceId];
                        [sdk.AVChat.VideoController openCamera];
        }
        
        [UIApplication sharedApplication].idleTimerDisabled = NO;
        // [self resetAndShowNavigationBarbuttons:NO];
    }
}

- (void)didNetworkReliabilityChange:(NSNumber*)score{
    NSLog(@"Reliability = %@",score);
    //[InternetActivityView setInternetActivityLevel:score];
}

- (void)didReceiveData:(NSString *)uid data:(NSData *)data {
}

- (void)didParticipantLeave:(id<ooVooParticipant>)participant{
    
    viewOpponentVideo.hidden = YES;
    viewMyVideo.hidden = YES;
    //btnAnswer.hidden = NO;
    
//    [sdk.AVChat.VideoController unbindVideoRender: participant.participantID render:viewOpponentVideo];
//    [sdk.AVChat.VideoController unRegisterRemoteVideo:participant.participantID];
    
    [self leaveSession];
    //[sdk.Messaging disconnect];
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)didConferenceError:(sdk_error)code{
    
}




- (void)didRemoteVideoStateChange:(NSString *)uid state:(ooVooAVChatRemoteVideoState)state width:(const int)width height:(const int)height error:(sdk_error)code{
    
}


- (void)didCameraStateChange:(ooVooDeviceState)state devId:(NSString *)devId width:(const int)width height:(const int)height fps:(const int)fps error:(sdk_error)code{
    
}


- (void)didVideoTransmitStateChange:(BOOL)state devId:(NSString *)devId error:(sdk_error)code{
    
}


- (void)didVideoPreviewStateChange:(BOOL)state devId:(NSString *)devId error:(sdk_error)code{
    
}

-(void)leaveSession{
    //    [participants removeAllObjects];
    
    [sdk.AVChat.VideoController closeCamera];
//    [sdk.AVChat.VideoController unbindVideoRender:nil render:viewOpponentVideo];
    [sdk.AVChat leave];
    
    //[sdk.Messaging disconnect];
    //[sdk.Account logout];
    
    [sdk.AVChat.AudioController unInitAudio:^(SdkResult *result) {
        NSLog(@"unInit Resoult %d",result.Result);
        //[self dismissViewControllerAnimated:YES completion:nil];
    }];
}


-(void) didSecurityState:(bool) is_secure{
    //    for (UIBarButtonItem *btn in self.navigationItem.rightBarButtonItems) {
    //        if (btn.tag==200) // it's the lock image on navigation bar
    //        {
    //            [btn setImage:is_secure?[UIImage imageNamed:@"Lock"]:[UIImage imageNamed:@"Unlock"] ];
    //
    //        }
    //    }
}

@end
