//
//  youSKOOPVC.m
//  youskoop
//
//  Created by Richika_Golchha on 5/8/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "youSKOOPVC.h"
#import "IndividualGroupVC.h"

#define is_selected  @"is_selected"

@interface youSKOOPVC ()
{
    __weak IBOutlet UILabel *_lblMyGroup;
    __weak IBOutlet UILabel *_lblPressGroup;
    __weak IBOutlet UIImageView *_imgBaseMyGroup;
    NSMutableArray *youSkoopArray;
    NSMutableArray *selectedGroup;
    NSMutableArray *afterSearchArray;
    NSString *searchText;
    BOOL isSearching; 
}
@property (strong, nonatomic) IBOutlet UITextField *_textField;
@property (strong, nonatomic) IBOutlet UIView *_searchView;
@property (strong, nonatomic) IBOutlet UITableView *_tableView;
@end

@implementation youSKOOPVC
@synthesize groupId;
@synthesize userId;
@synthesize isInviteUser;
@synthesize navController;
@synthesize isHideNavigationBar;

#pragma mark-ViewLifeCycle
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    
    if(isHideNavigationBar){
        
        //Hidden status bar
        if ([self respondsToSelector:@selector(setNeedsStatusBarAppearanceUpdate)]) {
            // iOS 7
            [self performSelector:@selector(setNeedsStatusBarAppearanceUpdate)];
        } else {
            // iOS 6
            [[UIApplication sharedApplication] setStatusBarHidden:YES withAnimation:UIStatusBarAnimationNone];
        }
        
        UILabel *lblNavTitle = (UILabel*)[self.view viewWithTag:500];
        lblNavTitle.hidden = YES;
        UIButton *btnBack = (UIButton*)[self.view viewWithTag:501];
        btnBack.hidden = YES;
    
        self._searchView.frame = CGRectMake(0, 0, 320, 49);
        _imgBaseMyGroup.frame = CGRectMake(0, 49, 320, 27);
        _lblMyGroup.frame = CGRectMake(0, 49, 84, 28);
        _lblPressGroup.frame = CGRectMake(82, 49, 238, 28);
        self._tableView.frame = CGRectMake(0, 77, 320, 200);
        
        if(IS_IPHONE_5){
            
            CGRect frameRect = self._tableView.frame;
            frameRect.size.height = 290;
            self._tableView.frame = frameRect;
            
            UIButton *btnSendReq = (UIButton*)[self.view viewWithTag:11111];
            CGRect btnFrameRect = btnSendReq.frame;
            btnFrameRect.origin.y = 509;
            btnSendReq.frame = btnFrameRect;
        }
        else{
            
            CGRect frameRect = self._tableView.frame;
            frameRect.size.height = 201;
            self._tableView.frame = frameRect;
            
            UIButton *btnSendReq = (UIButton*)[self.view viewWithTag:11111];
            CGRect btnFrameRect = btnSendReq.frame;
            btnFrameRect.origin.y = 331.0;
            btnSendReq.frame = btnFrameRect;
        }
    }
    else{
        
        if(IS_Greater_Or_Equal_to_IOS_7){
            navImage.image = [UIImage imageNamed:@"statusbar_7.png"];
        }
        else{
            navImage.frame = CGRectMake(0, 0, 320, 44);
            navImage.image = [UIImage imageNamed:@"statusbar_6.png"];
        }
        
        if(IS_IPHONE_5){
            
            CGRect frameRect = self._tableView.frame;
            frameRect.size.height = 321;
            self._tableView.frame = frameRect;
            
            UIButton *btnSendReq = (UIButton*)[self.view viewWithTag:11111];
            CGRect btnFrameRect = btnSendReq.frame;
            btnFrameRect.origin.y = 458;
            btnSendReq.frame = btnFrameRect;
        }
        else{
            
            CGRect frameRect = self._tableView.frame;
            frameRect.size.height = 233;
            self._tableView.frame = frameRect;
            
            UIButton *btnSendReq = (UIButton*)[self.view viewWithTag:11111];
            CGRect btnFrameRect = btnSendReq.frame;
            btnFrameRect.origin.y = 370;
            btnSendReq.frame = btnFrameRect;
        }
    }
    
    youSkoopArray = [[NSMutableArray alloc] init];
    selectedGroup = [[NSMutableArray alloc] init];
    afterSearchArray = [[NSMutableArray alloc] init];
    searchText = @"";
    isSearching = NO;
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getYouSkoopData:) name: Notification_For_GetGroupList object:nil];
    if(self.isInviteUser){
         [[WebServicesController WebServiceMethod] getMyGroupDataWithUserId:[AppHelper userDefaultsForKey:KUserId] SearchString:@"" pageNumber:@"1" limit:@"100" exGroupId:self.groupId inviteUserId:self.userId andIsGetNameList:NO];
    }
    else{
         [[WebServicesController WebServiceMethod] getMyGroupDataWithUserId:[AppHelper userDefaultsForKey:KUserId] SearchString:@"" pageNumber:@"1" limit:@"100" exGroupId:self.groupId inviteUserId:@"0" andIsGetNameList:NO];
    }
}

- (BOOL)prefersStatusBarHidden {
    return YES;
}

#pragma mark-GeneralMethods
-(void) getYouSkoopData : (NSNotification *)note
{
    [AppDelegate dismissGlobalHUD];
    
    NSLog(@"Dictionary: %@",note.userInfo);
//    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_For_GetGroupList object:nil];
    
    if(note.userInfo)
    {
        if(isSearching)
        {
            UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[self._searchView viewWithTag:1002];
            
            if(activityIndicator)
                [activityIndicator stopAnimating];
            
            UIImageView *imgView=(UIImageView*)[self._searchView viewWithTag:906];
            imgView.hidden=NO;
            
            if(afterSearchArray.count>0)
                [afterSearchArray removeAllObjects];
            
            NSArray *array=[note.userInfo valueForKey:@"data"];
            for (int i=0; i<array.count; i++)
            {
                NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[array objectAtIndex:i]];
                [afterSearchArray addObject:dict];
            }
        }
        else
        {           
            if(youSkoopArray.count>0)
                [youSkoopArray removeAllObjects];
            
            NSArray *array=[note.userInfo valueForKey:@"data"];
            for (int i=0; i<array.count; i++)
            {
                NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[array objectAtIndex:i]];
                [youSkoopArray addObject:dict];
            }
        }
        [self._tableView reloadData];
    }
}

-(void) userDidSendInvite:(NSNotification *)note
{
    [AppDelegate dismissGlobalHUD];
    
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Send_InviteToGroup object:nil];
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
    {
        [selectedGroup removeAllObjects];
        [self._tableView reloadData];
        [AppHelper showAlertViewWithTag:102 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:self cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag==102){
        [self.navigationController popViewControllerAnimated:YES];
    }
}

#pragma mark-GeneralMethods
-(void)getYouSkoopDataWithText:(NSString*)string andIsShowIndicator:(BOOL)showIndicator
{
    if(showIndicator)
    {
        [AppDelegate dismissGlobalHUD];
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    }
    else
    {
        UIImageView *imgView=(UIImageView*)[self._searchView viewWithTag:906];
        imgView.hidden=YES;
        
        UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[self._searchView viewWithTag:1002];
        
        if(activityIndicator)
            [activityIndicator startAnimating];
        else{
            activityIndicator= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            activityIndicator.backgroundColor=[UIColor clearColor];
            activityIndicator.alpha = 1.0;
            activityIndicator.tag=1002;
            activityIndicator.center = imgView.center;
            activityIndicator.hidesWhenStopped = YES;
            [self._searchView addSubview:activityIndicator];
            [activityIndicator startAnimating];
        }
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getYouSkoopData:) name: Notification_For_GetGroupList object:nil];
    if(self.isInviteUser){
        [[WebServicesController WebServiceMethod] getMyGroupDataWithUserId:[AppHelper userDefaultsForKey:KUserId] SearchString:string pageNumber:@"1" limit:@"100" exGroupId:self.groupId inviteUserId:self.userId andIsGetNameList:NO];
    }
    else{
        [[WebServicesController WebServiceMethod] getMyGroupDataWithUserId:[AppHelper userDefaultsForKey:KUserId] SearchString:string pageNumber:@"1" limit:@"100" exGroupId:self.groupId inviteUserId:@"0" andIsGetNameList:NO];
    }
}

#pragma mark-textFieldDelegates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    isSearching=YES;
    searchText = [self._textField.text stringByReplacingCharactersInRange:range withString:string];
    [self getYouSkoopDataWithText:searchText andIsShowIndicator:NO];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSString *searchString=[textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if([searchString length]==0)
    {
        isSearching=NO;
        [self._tableView reloadData];
    }
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    isSearching=NO;
    [self._tableView reloadData];
    return YES;
}

#pragma mark-tapGesture_method

-(void) imageTapGesture:(UITapGestureRecognizer *)utap
{
    UIImageView *tappedImage=(UIImageView*)utap.view;
    UITableViewCell * cell = nil;
    if(IS_IOS_7)
        cell = (UITableViewCell *)[[[tappedImage superview]superview]superview];
    else
        cell = (UITableViewCell *)[[tappedImage superview]superview];
    NSIndexPath *tableViewIndexPath=[self._tableView indexPathForCell:cell];
    
    NSDictionary *groupDict=nil;
    if(isSearching)
        groupDict=[afterSearchArray objectAtIndex:tableViewIndexPath.row];
    else
        groupDict=[youSkoopArray objectAtIndex:tableViewIndexPath.row];
    
    if([[groupDict valueForKey:@"member_count"] integerValue]>0)
    {
        UIStoryboard *story=[UIStoryboard storyboardWithName:@"youSkoopLayouts" bundle:nil];
        IndividualGroupVC *groupObj=[story instantiateViewControllerWithIdentifier:@"groupmembers"];
        groupObj.isShowSearch=YES;
        groupObj.groupName = [groupDict valueForKey:@"group_name"];
        groupObj.groupId = [groupDict valueForKey:@"group_id"];
        groupObj.requestGroupId = self.groupId;
        [self.navController pushViewController:groupObj animated:YES];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"There are no members in this group." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}


#pragma mark table view delegates

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    UILabel *lblNoData=(UILabel*)[self.view viewWithTag:123];
    BOOL isShowLabel=NO;
    if(isSearching && afterSearchArray.count==0)
        isShowLabel=YES;
    else if(youSkoopArray.count==0)
        isShowLabel=YES;
    
    if(isShowLabel){
        if(!lblNoData){
            lblNoData=[[UILabel alloc] initWithFrame:CGRectMake(0, self._tableView.frame.size.height/2.0-15.0, 320, 30.0)];
            lblNoData.backgroundColor=[UIColor clearColor];
            lblNoData.textColor=KTextColor;
            lblNoData.tag=123;
            lblNoData.textAlignment=NSTextAlignmentCenter;
            lblNoData.text=@"No data available";
            [self._tableView addSubview:lblNoData];
        }
    }
    else
        [lblNoData removeFromSuperview];
    
    if(isSearching)
        return [afterSearchArray count];
    else
        return [youSkoopArray count];
}

-(UITableViewCell *)tableView:(UITableView *)table_View cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [table_View dequeueReusableCellWithIdentifier:@"Cell"];
    cell.backgroundColor=[UIColor clearColor];
    
    UIImageView *image_view = (UIImageView *)[cell.contentView viewWithTag:601];

    UITapGestureRecognizer *uiTap=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(imageTapGesture:)];
    uiTap.numberOfTapsRequired=1;
    [image_view addGestureRecognizer:uiTap];
    
    [AppHelper getRoundedRectImageWithImageView:image_view withColor:[UIColor clearColor] andRadius:10.0 andWidth:2.0];
    
    NSMutableDictionary *dict=nil;
    if(isSearching)
        dict=[afterSearchArray objectAtIndex:indexPath.row];
    else
      dict=[youSkoopArray objectAtIndex:indexPath.row];
    
    UIButton *btnCheck=(UIButton*)[cell.contentView viewWithTag:606];
    if([selectedGroup containsObject:[dict valueForKey:@"group_id"]])
        btnCheck.selected = YES;
    else
        btnCheck.selected=NO;
    
    UILabel *lblGroupName = (UILabel *)[cell.contentView viewWithTag:602];
    lblGroupName.textColor = KTextColor;
    if([[dict valueForKey:@"group_name"] isKindOfClass:[NSNull class]])
        lblGroupName.text=@"Group Name";
    else
        lblGroupName.text = [dict valueForKey:@"group_name"];
    
    UILabel *description = (UILabel *)[cell.contentView viewWithTag:603];
    description.text = [dict valueForKey:@"group_description"];
    
    UILabel *lblCount = (UILabel *)[cell.contentView viewWithTag:604];
    lblCount.textColor=KTextColor;
    lblCount.text=[NSString stringWithFormat:@"%@ Skoops - %@ Members",[dict valueForKey:@"skoop_count"],[dict valueForKey:@"member_count"]];

    
    if([dict valueForKey:@"image"] && [[dict valueForKey:@"image"] length]>0)
        [image_view setImageWithURL:[NSURL URLWithString:[dict valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"user_default.png"]];
    else
        image_view.image = [UIImage imageNamed:@"user_default.png"];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if([self._textField isFirstResponder])
        [self._textField resignFirstResponder];
    else{
        UITableViewCell *tblCell=[self._tableView cellForRowAtIndexPath:indexPath];
        UIButton *btnCheck=(UIButton*)[tblCell.contentView viewWithTag:606];
        
        NSMutableDictionary *dictionary=(NSMutableDictionary*)[youSkoopArray objectAtIndex:indexPath.row];
        
        if([selectedGroup containsObject:[dictionary valueForKey:@"group_id"]]){
            btnCheck.selected=NO;
            [selectedGroup removeObject:[dictionary valueForKey:@"group_id"]];
        }
        else{
            btnCheck.selected=YES;
            [selectedGroup addObject:[dictionary valueForKey:@"group_id"]];
        }
    }
}

#pragma mark-buttonMethods

- (IBAction)inviteGroup:(id)sender{
    if(youSkoopArray.count == 0){
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"There are no groups to send the request." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
    }
    else if(selectedGroup.count>0){
        NSLog(@"::::::%@",self.groupId);
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSendInvite:) name:  Notification_Send_InviteToGroup object:nil];
        NSLog(@":::%i",self.isInviteUser);
        if(self.isInviteUser){//User is sending group join request to specific user
            [[WebServicesController WebServiceMethod] sendInviteToGroupWithGroupIds:selectedGroup inviteUserId:self.userId andGroupId:self.groupId];
        }
        else{//User is sending group join request to group members 
            [[WebServicesController WebServiceMethod] sendInviteToGroupWithGroupIds:selectedGroup inviteUserId:@"0" andGroupId:self.groupId];
        }
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please select at least one group to send the request." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
}

- (IBAction)backButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark-memoryMethods

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
