//
//  IndividualGroupVC.h
//  youskoop
//
//  Created by Richika_Golchha on 5/12/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndividualGroupVC : UIViewController{
    
}
@property (nonatomic, strong)NSString *groupId;
@property (nonatomic, strong)NSString *requestGroupId;
@property (nonatomic, strong)NSString *groupName;
@property BOOL isShowSearch;
@end
