//
//  CreateGroupVC.h
//  youskoop
//
//  Created by Shitesh Patel on 17/04/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol updateGroupProfileProtocol <NSObject>

-(void)updateGroupProfileWithDataDict:(NSDictionary*)dataDict;

@end

@interface CreateGroupVC : UIViewController<UIGestureRecognizerDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate,UIActionSheetDelegate,UITextViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate>

@property id<updateGroupProfileProtocol> deligate;
@property BOOL isEditGroup;
@property (strong, nonatomic) NSMutableDictionary *groupDescription;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet UITextView *descriptionView;

@property (strong, nonatomic) IBOutlet UIImageView *_imgCoverImage;
@property (strong, nonatomic) IBOutlet UIImageView *_imgGroupIcon;

@property (strong, nonatomic) IBOutlet UIView *pickerView;
@property (strong, nonatomic) IBOutlet UIPickerView *pickerCategory;
@property (strong, nonatomic) IBOutlet UILabel *labelSelectCategory;
@property (strong, nonatomic) IBOutlet UIButton *pickerDone;

-(IBAction)onClickYesButton:(id)sender;
-(IBAction)onClickNoButton:(id)sender;
-(IBAction)onClickOkButton:(id)sender;

@end
