//
//  GroupVC.m
//  youskoop
//
//  Created by Shitesh Patel on 08/04/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "GroupVC.h"
#import "WebServicesController.h"
#import "SeeAllVC.h"
#import "Defines.h"
#import "AppHelper.h"
#import "RequestViewViewController.h"
#import "MyGroupVC.h"
#import "CreateGroupVC.h"

@interface GroupVC (){
    
    NSMutableArray *categoryGroupsDataArray;
    NSMutableArray *popularGroupsDataArray;
    NSMutableArray *celebrityGroupsDataArray;
    NSMutableArray *featuredGroupDataArray;
    NSArray *categoryArray;
    NSInteger selectedTblSection;
    NSInteger selectedCollectionRow;
    NSString *selectedGroup;
    int selectedIndex;
    
    NSTimer *timerForAutoScroll;
    int timerTime;
    
    int categoryGroupPageNumber;
    int popularGroupPageNumber;
    int celebrityGroupPageNumber;
    
    BOOL isFeaturedGroup;
    BOOL isHitCategoryGroupWebService;
    BOOL isHitPopularGroupWebService;
    BOOL isHitCelebGroupWebService;
    __weak IBOutlet UIView *_viewButtonsBase;
    XLCycleScrollView *csView ;
}
@property (strong, nonatomic) UILabel *lblcategoryName;

@end

#define pageLimit              @"1000"

@implementation GroupVC
@synthesize _tableView;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.backgroundColor=[UIColor blackColor];
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    UIButton *btnCreateGroup=(UIButton*)[self.view viewWithTag:500];
    UIButton *btnMyGroup=(UIButton*)[self.view viewWithTag:501];
    UIButton *btnSendRequest=(UIButton*)[self.view viewWithTag:502];
    [btnCreateGroup setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [btnMyGroup setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [btnSendRequest setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    
    //iPhone4 with ios6
    if(!IS_IPHONE_5 && !IS_Greater_Or_Equal_to_IOS_7){
        CGRect frameRect = self._tableView.frame;
        frameRect.size.height = 238;
        self._tableView.frame = frameRect;
    }
    
    CGRect rectFrame=self.pickerView.frame;
    rectFrame.origin.y=568;
    self.pickerView.frame=rectFrame;
    
    [AppHelper saveToUserDefaults:@"1" withKey:isUpdateGroupProfile];
    
    //Hobbies & Leisure is default selected category
    selectedIndex = -1;
    selectedGroup=@"Hobbies & Leisure";
    self.lblcategoryName.text = selectedGroup;
    
    if(IS_Greater_Or_Equal_to_IOS_7){
        csView = [[XLCycleScrollView alloc] initWithFrame:CGRectMake(0, 62, self.view.frame.size.width, self.view.frame.size.width/2.5)];
    }
    else{
        csView = [[XLCycleScrollView alloc] initWithFrame:CGRectMake(0, 42, self.view.frame.size.width, self.view.frame.size.width/2.5)];
    }
    csView.delegate = self;
    csView.datasource = self;
    [self.view addSubview:csView];
    timerTime = 0;
}

-(void)viewWillAppear:(BOOL)animated{
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        //Call your function or whatever work that needs to be done
        //Code in this part is run on a background thread
        [self hitWebservice];
        [self hitWebServiceForGettingCategoryList];
    });
    
    if([AppHelper userDefaultsForKey:isSendGroupSkoop]){
        
        isFeaturedGroup=NO;
        [self performSegueWithIdentifier:@"grpProfile_link" sender:[AppHelper userDefaultsDictionaryDataForKey:isSendGroupSkoop]];
        [AppHelper removeFromUserDefaultsWithKey:isSendGroupSkoop];
    }
}

/*Method for select category*/
- (void)handleCategoryLabelTap:(UITapGestureRecognizer *)recognizer
{
    [UIView animateWithDuration:0.5 animations:^{
        CGRect rectFrame=self.pickerView.frame;
        rectFrame.origin.y=0;
        self.pickerView.frame=rectFrame;
    }completion:nil];
}

/*Hit webservice for getting caregory list*/
-(void)hitWebServiceForGettingCategoryList{
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(didGetCategoryDataList:) name: Notification_Get_CategoryNames object:nil];
    [[WebServicesController WebServiceMethod] getCategoryNamesForCreateGroup];
}

/*Hit webservice for getting initial page data*/
-(void)hitWebservice{
    
    categoryGroupPageNumber = 2;
    popularGroupPageNumber = 2;
    celebrityGroupPageNumber = 2;
    
    isHitCategoryGroupWebService = YES;
    isHitCelebGroupWebService = YES;
    isHitPopularGroupWebService = YES;
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetFeaturedGroupsdata:) name: Notification_Get_CarouselImages object:nil];
    [[WebServicesController WebServiceMethod] getFeaturedGroupsWithUserId:[AppHelper userDefaultsForKey:KUserId] appToken:KAppToken pageNumber:@"1" andPageLimit:@"1000"];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getAllGategoryData:) name: Notification_Get_AllGroupsData object:nil];
    if(selectedIndex < categoryArray.count ){
        
        [[WebServicesController WebServiceMethod] getAllGroupsDetailWithUserId:[AppHelper userDefaultsForKey:KUserId] appToken:KAppToken categoryId:[[categoryArray objectAtIndex:selectedIndex] valueForKey:@"category_id"] andPageLimit:pageLimit];
    }
    else{
        
        [[WebServicesController WebServiceMethod] getAllGroupsDetailWithUserId:[AppHelper userDefaultsForKey:KUserId] appToken:KAppToken categoryId:@"11" andPageLimit:pageLimit];
    }
}

#pragma mark Circular scrollview deligates

-(void)autoScrollTheFeaturedImage{
    
    timerTime++;
    if(timerTime == 5){
        
        timerTime = 0;
        [csView autoScroll];
    }
}

- (NSInteger)numberOfPages{
    
    return featuredGroupDataArray.count;
}

- (UIView *)pageAtIndex:(NSInteger)index{
    
    timerTime = 0;
    NSDictionary *dataDict=(NSDictionary*)[featuredGroupDataArray objectAtIndex:index];
    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, csView.frame.size.width, csView.frame.size.height)];
    imgView.tag = 500+index;
    imgView.contentMode = UIViewContentModeScaleToFill;
    
    if([dataDict valueForKey:@"featured_image"] && [[dataDict valueForKey:@"featured_image"] length]>0){
        [imgView setImageWithURL:[NSURL URLWithString:[dataDict valueForKey:@"featured_image"]] placeholderImage:[UIImage imageNamed:@"cover.png"]];
    }
    else{
        imgView.image = [UIImage imageNamed:@"cover.png"];
    }
    return imgView;
}

- (void)didClickPage:(XLCycleScrollView *)csView atIndex:(NSInteger)index{
    
    NSDictionary *dataDict=(NSDictionary*)[featuredGroupDataArray objectAtIndex:index];
    isFeaturedGroup=YES;
    selectedCollectionRow=index;
    [self performSegueWithIdentifier:@"featuredgroup" sender:dataDict];
}


#pragma mark Detect touch
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    if (touch.view.tag==345)//Touched view is category picker view
    {
        //hide category picker
        [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                         animations:^{
                             CGRect frameRect=self.pickerView.frame;
                             frameRect.origin.y=568;
                             self.pickerView.frame=frameRect;
                         }
                         completion:nil];
        
        if([selectedGroup length]==0)
            self.lblcategoryName.text=@"Search By Category";
        else
            self.lblcategoryName.text=selectedGroup;
    }
}

#pragma mark Protocol methods
-(void)updateMyGroupList{
    NSMutableDictionary *dataDict=nil;
    
    if(isFeaturedGroup){
        dataDict=[NSMutableDictionary dictionaryWithDictionary:[featuredGroupDataArray objectAtIndex:selectedCollectionRow]];
    }
    else{
        
        if(selectedTblSection==0){
            dataDict=[NSMutableDictionary dictionaryWithDictionary:[categoryGroupsDataArray objectAtIndex:selectedCollectionRow]];
        }
        else  if(selectedTblSection==1){
            dataDict=[NSMutableDictionary dictionaryWithDictionary:[popularGroupsDataArray objectAtIndex:selectedCollectionRow]];
        }
        else if(selectedTblSection==2){
            dataDict=[NSMutableDictionary dictionaryWithDictionary:[celebrityGroupsDataArray objectAtIndex:selectedCollectionRow]];
        }
    }
    
    if([[dataDict valueForKey:@"join_status"] integerValue]==1)
        [dataDict setObject:@"0" forKey:@"join_status"];
    else
        [dataDict setObject:@"1" forKey:@"join_status"];
    
    if(isFeaturedGroup){
        
        [featuredGroupDataArray replaceObjectAtIndex:selectedCollectionRow withObject:dataDict];
    }
    else{
        
        if(selectedTblSection==0){
            [categoryGroupsDataArray replaceObjectAtIndex:selectedCollectionRow withObject:dataDict];
        }
        else  if(selectedTblSection==1){
            [popularGroupsDataArray replaceObjectAtIndex:selectedCollectionRow withObject:dataDict];
        }
        else if(selectedTblSection==2){
            [celebrityGroupsDataArray replaceObjectAtIndex:selectedCollectionRow withObject:dataDict];
        }
    }
}

#pragma mark-Webservices response
-(void)didGetCategoryDataList:(NSNotification*)note
{
    //[AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_CategoryNames object:nil];
    //NSLog(@"%@",note.userInfo);
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue] == 0){
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
            
            NSArray *categoryDataArray = [note.userInfo valueForKey:@"data"];
            
            if(!categoryArray || (categoryArray && categoryArray.count < categoryDataArray.count)){
               
                categoryArray = [NSArray arrayWithArray:[note.userInfo valueForKey:@"data"]];
                [self.pickerCategory reloadAllComponents];
                
                NSDictionary *dataDict = [NSDictionary dictionaryWithObjectsAndKeys:@"11",@"category_id",@"Hobbies & Leisure",@"category_name", nil];
                selectedIndex = (int)[categoryArray indexOfObject:dataDict];
                selectedGroup = @"Hobbies & Leisure";
                self.lblcategoryName.text = selectedGroup;
                
                //Select default category
                [self.pickerCategory selectRow:selectedIndex inComponent:0 animated:NO];
            }
        });
    }
}

-(void)selectDefaultCategory{
    
    [self.pickerCategory selectRow:selectedIndex inComponent:0 animated:NO];
}

-(void)getAllGategoryData:(NSNotification*)note{
    
    [AppDelegate dismissGlobalHUD];
    NSLog(@"All groups==========: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_AllGroupsData object:nil];
    
    if(note.userInfo){
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
           
            NSArray *categoryImgData=[[note.userInfo valueForKey:@"data"] valueForKey:@"category"];
            if(categoryImgData.count>0){
                
                categoryGroupsDataArray = nil;
                categoryGroupsDataArray = [NSMutableArray arrayWithArray:categoryImgData];
            }
            
            NSArray *popularImgData=[[note.userInfo valueForKey:@"data"]valueForKey:@"popular"];
            if(popularImgData.count>0){
                
                popularGroupsDataArray = nil;
                popularGroupsDataArray = [NSMutableArray arrayWithArray:popularImgData];
            }
            
            NSArray *celebrityImgData = [[note.userInfo valueForKey:@"data"]valueForKey:@"celebrity"];
            if(celebrityImgData.count > 0){
                
                celebrityGroupsDataArray = nil;
                celebrityGroupsDataArray = [NSMutableArray arrayWithArray:celebrityImgData];
            }
            [self._tableView reloadData];
        });
    }
}

//Did get featured group data from server
-(void) userDidGetFeaturedGroupsdata: (NSNotification*) note{
    [AppDelegate dismissGlobalHUD];
    
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_CarouselImages object:nil];
    
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0){
        NSArray *carouselImgData=[note.userInfo valueForKey:@"data"];
        if(carouselImgData.count>0){
            
            featuredGroupDataArray=nil;
            featuredGroupDataArray=[NSMutableArray arrayWithArray:carouselImgData];
        }
        
        if(timerForAutoScroll){
            [timerForAutoScroll invalidate];
            timerForAutoScroll = Nil;
        }
        timerForAutoScroll = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(autoScrollTheFeaturedImage) userInfo:Nil repeats:YES];
        [csView reloadData];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(void) userDidGetCelebrityGroups : (NSNotification*) note{
    [AppDelegate dismissGlobalHUD];
    
    //NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Celebrity_Groups object:nil];
    
    if(note.userInfo){
        
        if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue] == 0){
            
            dispatch_async(dispatch_get_main_queue(), ^(void) {
                
                //Stop your activity indicator or anything else with the GUI
                //Code here is run on the main thread
                NSArray *groupsData=[note.userInfo valueForKey:@"data"];
                
                if(groupsData.count > 0){
                    
                    if(celebrityGroupPageNumber == 1){
                        
                        celebrityGroupsDataArray = [NSMutableArray arrayWithArray:groupsData];
                    }
                    else{
                        
                        for (int i = 0 ; i < groupsData.count ; i++) {
                            [celebrityGroupsDataArray addObject:[groupsData objectAtIndex:i]];
                        }
                    }
                    celebrityGroupPageNumber++;
                    [self._tableView reloadSections:[NSIndexSet indexSetWithIndex:2] withRowAnimation:UITableViewRowAnimationNone];
                }
                else{
                    isHitCelebGroupWebService = NO;
                }
            });
        }
        else
            [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

-(void) userDidGetPopularGroups : (NSNotification*) note{
    [AppDelegate dismissGlobalHUD];
    
    //NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Popular_Groups object:nil];
    
    if(note.userInfo){
        
        if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue] == 0){
            
            dispatch_async(dispatch_get_main_queue(), ^(void) {
                
                //Stop your activity indicator or anything else with the GUI
                //Code here is run on the main thread
                NSArray *groupsData=[note.userInfo valueForKey:@"data"];
                
                if(groupsData.count > 0){
                    
                    if(popularGroupPageNumber == 1){
                        
                        popularGroupsDataArray = [NSMutableArray arrayWithArray:groupsData];
                    }
                    else{
                        
                        for (int i = 0 ; i < groupsData.count ; i++) {
                            [popularGroupsDataArray addObject:[groupsData objectAtIndex:i]];
                        }
                    }
                    popularGroupPageNumber++;
                    [self._tableView reloadSections:[NSIndexSet indexSetWithIndex:1] withRowAnimation:UITableViewRowAnimationNone];
                }
                else{
                    isHitPopularGroupWebService = NO;
                }
            });
        }
        else
            [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

-(void) userDidGetCategoryGroupsData: (NSNotification*) note{
    [AppDelegate dismissGlobalHUD];
    
    NSLog(@"Category groups data: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Group_By_Category object:nil];
    
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0){
        
        dispatch_async(dispatch_get_main_queue(), ^(void) {
            
            //Stop your activity indicator or anything else with the GUI
            //Code here is run on the main thread
            NSArray *groupsData=[note.userInfo valueForKey:@"data"];
            
            if(groupsData.count > 0){
                
                if(categoryGroupPageNumber == 1){
                    
                    categoryGroupsDataArray = [NSMutableArray arrayWithArray:groupsData];
                }
                else{
                    
                    for (int i = 0 ; i < groupsData.count ; i++) {
                        [categoryGroupsDataArray addObject:[groupsData objectAtIndex:i]];
                    }
                }
                categoryGroupPageNumber++;
            }
            else{
                if(categoryGroupPageNumber == 1){
                    
                    categoryGroupsDataArray = nil;
                }
                isHitCategoryGroupWebService = NO;
            }
            
            [self._tableView reloadSections:[NSIndexSet indexSetWithIndex:0] withRowAnimation:UITableViewRowAnimationNone];
        });
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

#pragma mark table view delegates

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(indexPath.section == 2)
        return 140;
    else
        return 120;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"TableCellID";
    
    UITableViewCell *cell = (UITableViewCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    cell.backgroundColor=[UIColor clearColor];
    
    UILabel *myLabel = (UILabel*) [cell.contentView viewWithTag:103];
    UIButton *btnSeeAll = (UIButton*) [cell.contentView viewWithTag:104];
    UIImageView *imgDropDownImage=(UIImageView*)[cell.contentView viewWithTag:4444];
    [btnSeeAll setTitleColor:[UIColor colorWithRed:88.0/255.0 green:25.0/255.0 blue:132.0/255.0 alpha:1.0] forState:UIControlStateNormal];
    [btnSeeAll setTitleColor:[UIColor colorWithRed:88.0/255.0 green:25.0/255.0 blue:132.0/255.0 alpha:1.0] forState:UIControlStateSelected];
    
    myLabel.textColor=KTextColor;
    
    if(indexPath.section==0){
        
        self.lblcategoryName=myLabel;
        myLabel.userInteractionEnabled=YES;
        UITapGestureRecognizer *gesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleCategoryLabelTap:)];
        gesture.numberOfTapsRequired=1;
        [myLabel addGestureRecognizer:gesture];
    }
    
    if(indexPath.section==0)
    {
        imgDropDownImage.hidden=NO;
        if([selectedGroup length]>0)
            myLabel.text =selectedGroup;
        else
            myLabel.text =@"Search By Category";
        
        UILabel *lblNoGroups = (UILabel*)[cell.contentView viewWithTag:70000];
        if(!categoryGroupsDataArray.count){
            
            if(!lblNoGroups){
                
                lblNoGroups = [[UILabel alloc] initWithFrame:CGRectMake(-7, 53, self.view.bounds.size.width, 30)];
                lblNoGroups.backgroundColor = [UIColor clearColor];
                lblNoGroups.textAlignment = NSTextAlignmentCenter;
                lblNoGroups.text = @"There are no groups in this category";
                lblNoGroups.textColor = KTextColor;
                lblNoGroups.textColor = [UIColor whiteColor];
                lblNoGroups.font = [UIFont systemFontOfSize:14.0];
                lblNoGroups.tag = 70000;
                [cell.contentView addSubview:lblNoGroups];
            }
        }
        else if(lblNoGroups)
            [lblNoGroups removeFromSuperview];
    }
    else if(indexPath.section==1)
    {
        imgDropDownImage.hidden=YES;
        myLabel.text =@"Popular Groups";
        
        UILabel *lblNoPopularGroups = (UILabel*)[cell.contentView viewWithTag:70001];
        if(!popularGroupsDataArray.count){
            
            if(!lblNoPopularGroups){
                
                lblNoPopularGroups = [[UILabel alloc] initWithFrame:CGRectMake(-7, 53, self.view.bounds.size.width, 30)];
                lblNoPopularGroups.backgroundColor = [UIColor clearColor];
                lblNoPopularGroups.textAlignment = NSTextAlignmentCenter;
                lblNoPopularGroups.text = @"There are no popular groups";
                lblNoPopularGroups.textColor = KTextColor;
                lblNoPopularGroups.textColor = [UIColor whiteColor];
                lblNoPopularGroups.font = [UIFont systemFontOfSize:14.0];
                lblNoPopularGroups.tag = 70001;
                [cell.contentView addSubview:lblNoPopularGroups];
            }
        }
        else if(lblNoPopularGroups)
            [lblNoPopularGroups removeFromSuperview];
            
    }
    else if(indexPath.section==2)
    {
        imgDropDownImage.hidden=YES;
        myLabel.text =@"Celebrity Groups";
        
        UILabel *lblNoCelebGroups = (UILabel*)[cell.contentView viewWithTag:70002];
        if(!celebrityGroupsDataArray.count){
            
            if(!lblNoCelebGroups){
                
                lblNoCelebGroups = [[UILabel alloc] initWithFrame:CGRectMake(-7, 53, self.view.bounds.size.width, 30)];
                lblNoCelebGroups.backgroundColor = [UIColor clearColor];
                lblNoCelebGroups.textAlignment = NSTextAlignmentCenter;
                lblNoCelebGroups.text = @"There are no celebrity groups";
                lblNoCelebGroups.textColor = KTextColor;
                lblNoCelebGroups.textColor = [UIColor whiteColor];
                lblNoCelebGroups.font = [UIFont systemFontOfSize:14.0];
                lblNoCelebGroups.tag = 70002;
                [cell.contentView addSubview:lblNoCelebGroups];
            }
        }
        else if(lblNoCelebGroups)
            [lblNoCelebGroups removeFromSuperview];
    }
    
    UICollectionView *cellCollection = (UICollectionView *)[cell.contentView viewWithTag:101];
    cellCollection.pagingEnabled=NO;
    [cellCollection reloadData];
    return cell;
}

#pragma mark-pickerViewDelegates

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [categoryArray count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    
    return [[categoryArray objectAtIndex:row] valueForKey:@"category_name"];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    //selectedIndex=row;
}


#pragma mark-CollectionViewDelegates

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    UITableViewCell * cell = nil;
    
    if(IS_IOS_7)
        cell = (UITableViewCell *)[[[collectionView superview]superview]superview];
    else
        cell = (UITableViewCell *)[[collectionView superview]superview];
    
    if([self._tableView indexPathForCell:cell].section==0){
        return [categoryGroupsDataArray count];
    }
    else if([self._tableView indexPathForCell:cell].section==1){
        return [popularGroupsDataArray count];
    }
    else if([self._tableView indexPathForCell:cell].section==2){
        return [celebrityGroupsDataArray count];
    }
    
    return 0;
}

#pragma mark Collection view layout things
 //Layout: Set cell size
- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    //SETTING SIZE FOR ITEM AT INDEX PATH
    CGSize mElementSize = CGSizeMake(82.0, 85.0);
    return mElementSize;
}
- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumInteritemSpacingForSectionAtIndex:(NSInteger)section {
    return 3.0;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    return 3.0;
}

// Layout: Set Edges
- (UIEdgeInsets)collectionView:
(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section {
    // return UIEdgeInsetsMake(0,8,0,8);  // top, left, bottom, right
    return UIEdgeInsetsMake(0,0,0,0);  // top, left, bottom, right
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewCell *cell =[collectionView dequeueReusableCellWithReuseIdentifier:@"cellId" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor clearColor];
    
    UIImageView *image_view = (UIImageView *)[cell.contentView viewWithTag:102];
    CBAutoScrollLabel *lblGroupName=(CBAutoScrollLabel*)[cell.contentView viewWithTag:105];
    [lblGroupName setLabelSettingForObject:@"name"];
   
    [AppHelper getRoundedRectImageWithImageView:image_view withColor:[UIColor clearColor] andRadius:10.0 andWidth:2.0];
    
    UITableViewCell * tableViewCell = nil;
    
    if(IS_IOS_7)
        tableViewCell = (UITableViewCell *)[[[collectionView superview] superview] superview];
    else
        tableViewCell = (UITableViewCell *)[[collectionView superview] superview];
    
    NSIndexPath *tableViewIndexPath=[self._tableView indexPathForCell:tableViewCell];
    
    NSDictionary *selectedData = nil;
    if(tableViewIndexPath.section == 0){
        
        selectedData = [categoryGroupsDataArray objectAtIndex:indexPath.row];
    }
    else if(tableViewIndexPath.section == 1){
        
        selectedData = [popularGroupsDataArray objectAtIndex:indexPath.row];
    }
    else if (tableViewIndexPath.section == 2){
        
        selectedData = [celebrityGroupsDataArray objectAtIndex:indexPath.row];
    }
    
    if([[selectedData valueForKey:@"image"] length]>0)
        [image_view setImageWithURL:[NSURL URLWithString:[selectedData valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"user_default.png"]];
    else
        image_view.image=[UIImage imageNamed:@"user_default.png"];
    
    lblGroupName.text=[NSString stringWithFormat:@" %@",[selectedData valueForKey:@"group_name"]];
    
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell * cell = nil;
    if(IS_IOS_7)
        cell = (UITableViewCell *)[[[collectionView superview]superview]superview];
    else
        cell = (UITableViewCell *)[[collectionView superview]superview];
    
    NSDictionary *dataDict=nil;
    if([self._tableView indexPathForCell:cell].section==0){
        dataDict=[categoryGroupsDataArray objectAtIndex:indexPath.row];
    }
    else  if([self._tableView indexPathForCell:cell].section==1){
        dataDict=[popularGroupsDataArray objectAtIndex:indexPath.row];
    }
    else if([self._tableView indexPathForCell:cell].section==2){
        dataDict=[celebrityGroupsDataArray objectAtIndex:indexPath.row];
    }
    
    if([dataDict valueForKey:@"block_status"] && [[dataDict valueForKey:@"block_status"] integerValue]==1){
        
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You cannot access this group because the admin has blocked you." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
    else{
        selectedCollectionRow=indexPath.row;
        selectedTblSection=[self._tableView indexPathForCell:cell].section;
        
        isFeaturedGroup=NO;
        [self performSegueWithIdentifier:@"grpProfile_link" sender:dataDict];
    }
}

#pragma mark-buttonAction
- (IBAction)onClickSendRequestButton:(id)sender
{
    [self performSegueWithIdentifier:@"sendgroupskoop" sender:nil];
}

- (IBAction)onClickSendGroupSkoopButton:(id)sender
{
    [self performSegueWithIdentifier:@"sendgroupskoop" sender:nil];
}

- (IBAction)seeAllAction:(id)sender{
    
    UIButton *btn=(UIButton*)sender;
    UITableViewCell * cell = nil;
    if(IS_IOS_7)
        cell = (UITableViewCell *)[[[btn superview] superview] superview];
    else
        cell = (UITableViewCell *)[[btn superview] superview];
    
    NSIndexPath *indexPath = [self._tableView indexPathForCell:cell];
    BOOL isDataExist= NO;
    switch (indexPath.section) {
        case 0:
            if(categoryGroupsDataArray.count)
                isDataExist = YES;
            break;
            
        case 1:
            if(popularGroupsDataArray.count)
                isDataExist = YES;
            break;
            
        case 2:
            if(celebrityGroupsDataArray.count)
                isDataExist = YES;
            break;
            
        default:
            break;
    }
    if(isDataExist)
        [self performSegueWithIdentifier:@"seeAll_link" sender:[NSString stringWithFormat:@"%i",(int)indexPath.section]];
}

//Autoscroll collectionview on left
- (IBAction)onClickLeftArrowButton:(id)sender{
    
    UIButton *btnLeftArrow=(UIButton*)sender;
    UITableViewCell * tblViewcell = nil;
    if(IS_IOS_7)
        tblViewcell = (UITableViewCell *)[[[btnLeftArrow superview] superview] superview];
    else
        tblViewcell = (UITableViewCell *)[[btnLeftArrow superview] superview];
    
    UICollectionView *cellCollectionView = (UICollectionView *)[tblViewcell.contentView viewWithTag:101];
    
    NSArray *visibleItems = [cellCollectionView indexPathsForVisibleItems];
    if(visibleItems.count){
        
        NSIndexPath *currentItem = [visibleItems objectAtIndex:0];
        
        //Manage auto scrolls(For overcome the Issue for showing visible cells ordering)
        for (int i=0; i<visibleItems.count-1; i++) {
            
            NSIndexPath *indexPath1=[visibleItems objectAtIndex:i];
            NSIndexPath *indexPath2=[visibleItems objectAtIndex:i+1];
            if(indexPath1.row>indexPath2.row){
                currentItem = [visibleItems objectAtIndex:i+1];
                break;
            }
        }
        
        NSIndexPath *prevItem = [NSIndexPath indexPathForItem:currentItem.item - 1 inSection:0];
        if(prevItem && prevItem.row>=0)
            [cellCollectionView scrollToItemAtIndexPath:prevItem atScrollPosition:UICollectionViewScrollPositionRight animated:YES];
    }
}

//Autoscroll collectionview on right
- (IBAction)onClickRightArrowtButton:(id)sender{
    
    UIButton *btnRightArrow=(UIButton*)sender;
    UITableViewCell * tblViewcell = nil;
    if(IS_IOS_7)
        tblViewcell = (UITableViewCell *)[[[btnRightArrow superview] superview] superview];
    else
        tblViewcell = (UITableViewCell *)[[btnRightArrow superview] superview];
    
    
    NSIndexPath *indexPath=[self._tableView indexPathForCell:tblViewcell];
    UICollectionView *cellCollectionView = (UICollectionView *)[tblViewcell.contentView viewWithTag:101];
    
    NSArray *visibleItems = [cellCollectionView indexPathsForVisibleItems];
    if(visibleItems.count){
        
        NSIndexPath *currentItem = [visibleItems objectAtIndex:visibleItems.count-1];
        
        //Manage auto scrolls(For overcome the Issue for showing visible cells ordering)
        for (int i=0; i<visibleItems.count-1; i++) {
            
            NSIndexPath *indexPath1=[visibleItems objectAtIndex:i];
            NSIndexPath *indexPath2=[visibleItems objectAtIndex:i+1];
            if(indexPath1.row>indexPath2.row){
                currentItem = [visibleItems objectAtIndex:i];
                break;
            }
        }
        
        NSIndexPath *nextItem = [NSIndexPath indexPathForItem:currentItem.item + 1 inSection:0];
        
        //Check array of bounds
        if(nextItem && indexPath.section==0 && nextItem.row<categoryGroupsDataArray.count){
            [cellCollectionView scrollToItemAtIndexPath:nextItem atScrollPosition:UICollectionViewScrollPositionLeft animated:YES];
        }
        else if(nextItem && indexPath.section==1 && nextItem.row<popularGroupsDataArray.count){
            [cellCollectionView scrollToItemAtIndexPath:nextItem atScrollPosition:UICollectionViewScrollPositionLeft animated:YES];
        }
        else if(nextItem && indexPath.section==2 && nextItem.row<celebrityGroupsDataArray.count){
            [cellCollectionView scrollToItemAtIndexPath:nextItem atScrollPosition:UICollectionViewScrollPositionLeft animated:YES];
        }
    }
}

- (IBAction)pickerDoneAction:(id)sender{
    
    if([self.pickerCategory selectedRowInComponent:0]){
        
        [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                         animations:^{
                             CGRect frameRect=self.pickerView.frame;
                             frameRect.origin.y=568;
                             self.pickerView.frame=frameRect;
                         }
                         completion:nil];
        
        categoryGroupPageNumber = 1;
        selectedIndex = (int)[self.pickerCategory selectedRowInComponent:0];
        selectedGroup = [[categoryArray objectAtIndex:selectedIndex] valueForKey:@"category_name"];
        self.lblcategoryName.text = selectedGroup;
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetCategoryGroupsData:) name:Notification_Group_By_Category object:nil];
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            
            //Call your function or whatever work that needs to be done
            //Code in this part is run on a background thread
            [[WebServicesController WebServiceMethod] getCategoryGroupsWithUserId:[AppHelper userDefaultsForKey:KUserId] categoryId:[[categoryArray objectAtIndex:selectedIndex] valueForKey:@"category_id"] appToken:KAppToken pageNumber:[NSString stringWithFormat:@"%i",categoryGroupPageNumber] andPageLimit:pageLimit];
        });
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please select a category." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    
}

- (IBAction)pickerCancelAction:(id)sender {
    
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect=self.pickerView.frame;
                         frameRect.origin.y=568;
                         self.pickerView.frame=frameRect;
                     }
                     completion:nil];
    
    if([selectedGroup length] == 0)
        self.lblcategoryName.text = @"Search By Category";
    else
        self.lblcategoryName.text = selectedGroup;
    
    //Select default category
    [self.pickerCategory selectRow:selectedIndex inComponent:0 animated:NO];
}

#pragma mark Prepare for segue
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:@"featuredgroup"]){
        NSDictionary *dataDict=(NSDictionary*)sender;
        GroupProfileVC *grpProfile=segue.destinationViewController;
        grpProfile.updateListProtocol=self;
        grpProfile.name=[dataDict valueForKey:@"group_name"];
        grpProfile.imgUrl=[dataDict valueForKey:@"cover_image"];
        grpProfile.groupImageUrl=[dataDict valueForKey:@"image"];
        grpProfile.groupDescription=[dataDict valueForKey:@"group_description"];
        grpProfile.groupId=[dataDict valueForKey:@"group_id"];
        grpProfile.groupType=[dataDict valueForKey:@"group_type"];
        grpProfile.ownerId=[dataDict valueForKey:@"owner_id"];
        grpProfile.prEmail=[dataDict valueForKey:@"pr_email"];
        grpProfile.categoryName = [dataDict valueForKey:@"category_name"];
    }
    else if([segue.identifier isEqualToString:@"seeAll_link"]){
        SeeAllVC *seeObj=(SeeAllVC*)segue.destinationViewController;
        NSString *selectedTableIndex=(NSString*)sender;
        if([selectedTableIndex integerValue]==0){
            seeObj.groupDataArray=(NSArray*)categoryGroupsDataArray;
            if(selectedIndex >= 0){
                seeObj.pageTitle = [[categoryArray objectAtIndex:selectedIndex] valueForKey:@"category_name"];
            }
            else{
                seeObj.pageTitle=@"Search By Category";
            }
        }
        else  if([selectedTableIndex integerValue]==1){
            
            seeObj.groupDataArray=(NSArray*)popularGroupsDataArray ;
            seeObj.pageTitle=@"Popular Groups";
        }
        else if([selectedTableIndex integerValue]==2){
            
            seeObj.groupDataArray=(NSArray*)celebrityGroupsDataArray;
            seeObj.pageTitle=@"Celebrity Groups";
        }
    }
    else if ([segue.identifier isEqualToString:@"grpProfile_link"]){
        
        GroupProfileVC *grpProfile=segue.destinationViewController;
        grpProfile.updateListProtocol=self;
        NSDictionary *dataDict=(NSDictionary*)sender;
        grpProfile.name=[dataDict valueForKey:@"group_name"];
        grpProfile.imgUrl=[dataDict valueForKey:@"cover_image"];
        grpProfile.groupImageUrl=[dataDict valueForKey:@"image"];
        grpProfile.groupDescription=[dataDict valueForKey:@"group_description"];
        grpProfile.groupId=[dataDict valueForKey:@"group_id"];
        grpProfile.categoryName=[dataDict valueForKey:@"category_name"];
        grpProfile.groupType=[dataDict valueForKey:@"group_type"];
        grpProfile.ownerId=[dataDict valueForKey:@"owner_id"];
        grpProfile.prEmail=[dataDict valueForKey:@"pr_email"];
        grpProfile.groupStatus=[dataDict valueForKey:@"status"];
        grpProfile.categoryId=[dataDict valueForKey:@"category_id"];
        
        if([dataDict valueForKey:@"skoop_type"])
            grpProfile.reqType=[dataDict valueForKey:@"skoop_type"];
        else
            grpProfile.reqType=@"";
        
        if([dataDict valueForKey:@"skoop_id"])
            grpProfile.skoopId=[dataDict valueForKey:@"skoop_id"];
        else
            grpProfile.skoopId=@"0";
    }
    else if([segue.identifier isEqualToString:@"sendgroupskoop"]){
        
        SendGroupSkoop *sendSkoop=segue.destinationViewController;
        sendSkoop.deligate=self;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
