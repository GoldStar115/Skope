//
//  youSKOOPVC.h
//  youskoop
//
//  Created by Richika_Golchha on 5/8/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface youSKOOPVC : UIViewController

@property BOOL isHideNavigationBar;
@property (strong, nonatomic) NSString *groupId;
@property (strong, nonatomic) NSString *userId;
@property BOOL isInviteUser;
@property (strong, nonatomic) UINavigationController *navController;
-(void)getYouSkoopDataWithText:(NSString*)string andIsShowIndicator:(BOOL)showIndicator;
@end
