//
//  RequestViewViewController.h
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MapKit/MapKit.h"
#import "AnnotationClass.h"

#import "TRAutocompleteView.h"
#import "TRGoogleMapsAutocompleteItemsSource.h"

@protocol upDateSkoopListDeligate <NSObject>

@optional
-(void)updateSkoopList;
-(void)updateSkoopListWithReqType:(NSString*)requType andSkoopId:(NSString*)skoopid;
-(void)updateBoolVariableToSendInboxScreenWithBool:(BOOL)isTrue;

@end

@interface SendGroupSkoop : UIViewController <UITextFieldDelegate,MKMapViewDelegate,UIGestureRecognizerDelegate>{
    id <upDateSkoopListDeligate>deligate;
}
@property id <upDateSkoopListDeligate>deligate;
@property (strong,nonatomic) NSString *groupId;
@property (strong, nonatomic) NSDictionary *selectedGroup;
@property BOOL isSaveSendSkoop;

- (IBAction)btnCalender:(id)sender;
@end
