//
//  GroupProfileVC.m
//  youskoop
//
//  Created by Richika_Golchha on 5/8/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "GroupProfileVC.h"
#import "SendRequestVC.h"
#import "IndividualGroupVC.h"
#import "UserProfileVC.h"
#import "CellSelectionView.h"
#import "VideoPlayerVC.h"
#import "CallViewController.h"

#define CurrentSkoop    1
#define FutureSkoop     0
#define PageLimit          1000

@interface GroupProfileVC (){
    
    NSMutableArray *arrayForCurrentScoops;
    NSMutableArray *arrayForFutureScoops;
    NSDictionary *selectedGroupMemberDataDict;
    NSInteger selectedIndex;
    NSInteger prevSelectedIndex;
    NSArray *pendingSkoopArray;
    UIImageView *cloneImage;
    CGPoint startPoint;
    
    NSString *selectedTime;
    NSString *selectedSkoopId;
    
    BOOL isCurrentScoopServiceHit;
    BOOL isFutureScoopServiceHit;
    BOOL isHitWebService;
    BOOL isShowReplierProfile;
    BOOL isReloadCell;
    
    int requestType;
    int groupMemberCount;
    int currentPageNo;
    int futurePageNo;
    int shownCurrentCell;
    int shownFutureCell;
    NSInteger groupJoinStatus;
    
    NSDictionary *userInfoDict;
    __weak IBOutlet UIButton *_btnSendRequest;
    __weak IBOutlet UIButton *_btnInviteFriend;
    __weak IBOutlet UIButton *_btnEditGroup;
    __weak IBOutlet UIButton *_btnCurrentSkoop;
    __weak IBOutlet UIButton *_btnFutureSkoop;
    __weak IBOutlet UILabel *_lblCurrentSkoopCount;
    __weak IBOutlet UILabel *_lblFutureSkoopCount;
    __weak IBOutlet UILabel *_lblEditGroup;
    __weak IBOutlet UIButton *_btnBlockUser;
    __weak IBOutlet UILabel *_lblSkoopRequest;
    
    IBOutlet UIButton *_btnSeeAll;
    
    IBOutlet UIView *_viewTableHeader1;
    __weak IBOutlet UIView *_viewTableHeader2;
    __weak IBOutlet UIView *_viewTableSectionHeader;
    
    __weak IBOutlet UICollectionView *_collectionView;
    __weak IBOutlet UILabel *_lblGroupMember;
    __weak IBOutlet UIView *_viewBlockUser;
    __weak IBOutlet UILabel *_lblOfficialGroup;
    
    __weak IBOutlet UIView *_viewSelectTime;
    
    BOOL isUploadVideoForGroup;
   
}
@property (strong, nonatomic) NSMutableArray *groupMembersArray;
@property (strong, nonatomic) IBOutlet UIImageView *headingImg;

@end

@implementation GroupProfileVC
@synthesize groupId,imgUrl,name,coverImageUrl,groupDescription;
@synthesize updateListProtocol;
@synthesize groupImageUrl;
@synthesize categoryName;
@synthesize categoryId;
@synthesize groupType;
@synthesize ownerId;
@synthesize prEmail;
@synthesize isFromNotification;
@synthesize reqType;
@synthesize skoopId;
@synthesize groupStatus;
@synthesize _imgGroupImage;
@synthesize grpDescriptionDict;
@synthesize isFromMyGroupClass;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
//        NSMutableArray *array=[[NSMutableArray alloc] init];
//        self.mainArrayForScoops=array;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnSkoop:) name:Notification_reply_on_skoop object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidChangeProfileImage:) name:Notification_Refresh_UserImage object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidRefreshGroupMembers:) name:Notification_Refresh_GroupMembers object:nil];
    
    
    if(![self.ownerId isEqualToString:[AppHelper userDefaultsForKey:KUserId]]){
        _btnEditGroup.hidden=YES;
        _lblEditGroup.hidden=YES;
    }
    isReloadCell = YES;
    self._uiTableView.tableHeaderView=_viewTableHeader2;
    
    arrayForCurrentScoops=[[NSMutableArray alloc]init];
    arrayForFutureScoops=[[NSMutableArray alloc]init];
    
    [_btnSeeAll setTitleColor:[UIColor colorWithRed:88.0/255.0 green:25.0/255.0 blue:132.0/255.0 alpha:1.0] forState:UIControlStateNormal];
    [_btnSeeAll setTitleColor:[UIColor colorWithRed:88.0/255.0 green:25.0/255.0 blue:132.0/255.0 alpha:1.0] forState:UIControlStateSelected];
    _lblGroupMember.textColor=KTextColor;
    
    UIButton *btnJoinGroup=(UIButton*)[self.view viewWithTag:500];
    UIButton *btnInviteFriend=(UIButton*)[self.view viewWithTag:501];
    UIButton *btnSendRequest=(UIButton*)[self.view viewWithTag:502];
    UIButton *btnUploadVideo=(UIButton*)[self.view viewWithTag:503];
    [btnJoinGroup setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [btnInviteFriend setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [btnSendRequest setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [btnUploadVideo setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    
    [_btnCurrentSkoop setTitleColor:[UIColor colorWithRed:197.0/255.0 green:66.0/255.0 blue:230.0/255.0 alpha:1.0] forState:UIControlStateSelected];
    [_btnCurrentSkoop setTitleColor:[UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:1.0] forState:UIControlStateNormal];
    _btnCurrentSkoop.backgroundColor=[UIColor colorWithRed:100.0/255.0 green:39.0/255.0 blue:142.0/255.0 alpha:1.0];
    _btnCurrentSkoop.tintColor=[UIColor clearColor];
    [_btnCurrentSkoop setSelected:YES];
    
    [_btnFutureSkoop setTitleColor:[UIColor colorWithRed:197.0/255.0 green:66.0/255.0 blue:230.0/255.0 alpha:1.0] forState:UIControlStateSelected];
    [_btnFutureSkoop setTitleColor:[UIColor colorWithRed:255.0/255.0 green:255.0/255.0 blue:255.0/255.0 alpha:1.0] forState:UIControlStateNormal];
    _btnFutureSkoop.backgroundColor=[UIColor colorWithRed:88.0/255.0 green:23.0/255.0 blue:133.0/255.0 alpha:1.0];
    _btnFutureSkoop.tintColor=[UIColor clearColor];
    [_btnFutureSkoop setSelected:NO];
    
    isCurrentScoopServiceHit=YES;
    isFutureScoopServiceHit=YES;
    isHitWebService=YES;
    requestType=CurrentSkoop;
    
    self._lblGroupDescription.text=self.groupDescription;
    self.grpName.text=self.name;
    
    if([self.imgUrl length]>0){
        [self.grpImage setImageWithURL:[NSURL URLWithString:self.imgUrl] placeholderImage:[UIImage imageNamed:@"coverphoto_default.png"]];
    }
    else{
        self.grpImage.image=[UIImage imageNamed:@"cover.png"];
    }
    
    if([self.groupImageUrl length]>0){
        [self._imgGroupImage setImageWithURL:[NSURL URLWithString:self.groupImageUrl] placeholderImage:[UIImage imageNamed:@"user_profile_grey.png"]];
    }
    else{
        self._imgGroupImage.image=[UIImage imageNamed:@"user_default.png"];
    }
    
    self.headingImg.backgroundColor=[UIColor colorWithRed:19.0/255.0 green:23.0/255.0 blue:30.0/255.0 alpha:1];
    [AppHelper getRoundedRectImageWithImageView:self._imgGroupImage withColor:[UIColor clearColor] andRadius:9.0 andWidth:2.0];
    
    //Manage view for celebrity group
    if([self.groupType isEqualToString:@"Celebrity"]){
        if([self.prEmail length]>0){
            if([self.groupStatus integerValue]==0)
                _lblOfficialGroup.text=@"(Official Group - Unapproved)";
            else
                _lblOfficialGroup.text=@"(Official Group - Approved)";
        }
        else
            _lblOfficialGroup.text=@"(Fan Group)";
    }
    else{
        _lblOfficialGroup.text = [NSString stringWithFormat:@"(%@)",self.categoryName];
    }
    
    pendingSkoopArray=[NSArray arrayWithArray:[[WebServicesController WebServiceMethod] getAllSkoopReplyData]];
    if(self.isFromNotification)
        [self.updateListProtocol markAsReadNotification];
    
    currentPageNo=1;
    futurePageNo=1;
    shownCurrentCell=0;
    shownFutureCell=0;
    
    isUploadVideoForGroup = NO;
}

-(void)viewWillAppear:(BOOL)animated{
    if(isHitWebService){
        [self performSelector:@selector(hitWebserviceForGettingSkoopListWithPageNumber:) withObject:@"1" afterDelay:0.2];
        [self performSelector:@selector(hitWebServiceForGettingGroupMembers) withObject:nil afterDelay:0.1];
    }
    
    //Reload tableview and collectionview visible cells for re-initialize marque label
    NSArray *visibleCells = [_collectionView indexPathsForVisibleItems];
    if(visibleCells && visibleCells.count)
        [_collectionView reloadItemsAtIndexPaths:visibleCells];
    NSArray *visibleCellsArray = [self._uiTableView indexPathsForVisibleRows];
    if(isReloadCell){
       
        if(visibleCellsArray && visibleCellsArray.count)
            [self._uiTableView reloadRowsAtIndexPaths:visibleCellsArray withRowAnimation:UITableViewRowAnimationNone];
    }
    else
        isReloadCell = YES;
    
}




#pragma mark Tap gesture method
-(void)tapOnSenderSkoopProfileImage:(UITapGestureRecognizer*)tapGesture
{
    UITableViewCell *tableVewCell=nil;
    if(IS_IOS_7)
        tableVewCell=(UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[tapGesture.view superview] superview];
    
    NSIndexPath *indexPath=[self._uiTableView indexPathForCell:tableVewCell];
    NSDictionary *dataDict=nil;
    if(requestType==CurrentSkoop)
        dataDict=[arrayForCurrentScoops objectAtIndex:indexPath.row];
    else
        dataDict=[arrayForFutureScoops objectAtIndex:indexPath.row];
        
    isShowReplierProfile=NO;
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

-(void)tapOnReplierSkoopProfileImage:(UITapGestureRecognizer*)tapGesture
{
    UITableViewCell *tableVewCell=nil;
    if(IS_IOS_7)
        tableVewCell=(UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[tapGesture.view superview] superview];
    
    NSIndexPath *indexPath=[self._uiTableView indexPathForCell:tableVewCell];
    NSDictionary *dataDict=nil;
    if(requestType==CurrentSkoop)
        dataDict=[arrayForCurrentScoops objectAtIndex:indexPath.row];
    else
        dataDict=[arrayForFutureScoops objectAtIndex:indexPath.row];
    
    isShowReplierProfile=YES;
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

- (void) imgLongPressed:(UILongPressGestureRecognizer*)sender
{
    UIImageView *imgView =(UIImageView*) sender.view;
    CGPoint point = [sender locationInView:self.view];
    
    if (sender.state == UIGestureRecognizerStateBegan)
    {
        NSLog(@"UIGestureRecognizerStateBegan");
        
        UICollectionViewCell *collectionVewCell=nil;
        collectionVewCell=(UICollectionViewCell*)[[sender.view superview] superview];
        
        NSIndexPath *indexPath=[_collectionView indexPathForCell:collectionVewCell];
        selectedGroupMemberDataDict=[self.groupMembersArray objectAtIndex:indexPath.row];
        
        startPoint = [sender locationInView:self.view];
        imgView.hidden=YES;
        if(!cloneImage)
            cloneImage=[[UIImageView alloc] init];
        cloneImage.frame = imgView.frame;
        cloneImage.center=point;
        cloneImage.backgroundColor=[UIColor clearColor];
        cloneImage.image=imgView.image;
        [AppHelper getRoundedRectImageWithImageView:cloneImage withColor:[UIColor clearColor] andRadius:cloneImage.frame.size.width/2.0 andWidth:0.0];
        [self.view addSubview:cloneImage];
        
        [UIView animateWithDuration:0.5 animations:^(void){
            CGRect frameRect=_viewBlockUser.frame;
            frameRect.origin.y=self.view.bounds.size.height-100;
            _viewBlockUser.frame=frameRect;
            [_viewBlockUser bringSubviewToFront:self._uiTableView];
        }completion:nil];
    }
    else if (sender.state == UIGestureRecognizerStateChanged)
    {
        cloneImage.center=point;
        
        if(point.y>=self.view.bounds.size.height-85 && point.y<=self.view.bounds.size.height-45)
            [_btnBlockUser setSelected:YES];
        else
            [_btnBlockUser setSelected:NO];
    }
    else if (sender.state == UIGestureRecognizerStateEnded)
    {
        NSLog(@"UIGestureRecognizerStateEnded");
        if(point.y>=self.view.bounds.size.height-85 && point.y<=self.view.bounds.size.height-45)
        {
            [cloneImage removeFromSuperview];
            [UIView animateWithDuration:0.5 animations:^(void){
                CGRect frameRect=_viewBlockUser.frame;
                frameRect.origin.y=self.view.bounds.size.height;
                _viewBlockUser.frame=frameRect;
            }completion:nil];
            
            [AppHelper showAlertViewWithTag:103 title:AppName message:@"Are you sure you want to block this user from the group?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
        }
        else
        {
            [UIView animateWithDuration:0.5 animations:^(void){
                cloneImage.center=startPoint;
            }completion:^(BOOL finish){
                imgView.hidden=NO;
                [cloneImage removeFromSuperview];
                
                [UIView animateWithDuration:0.5 animations:^(void){
                    CGRect frameRect=_viewBlockUser.frame;
                    frameRect.origin.y=self.view.bounds.size.height;
                    _viewBlockUser.frame=frameRect;
                }completion:nil];
                
            }];
        }
        [_btnBlockUser setSelected:NO];
    }
}

#pragma mark Protocal method implimentation
-(void)updateSkoopListWithReqType:(NSString*)requType andSkoopId:(NSString*)skoopid
{
    NSLog(@"*******");
    isReloadCell = NO;
    self.skoopId=skoopid;
    isHitWebService=YES;
    self.reqType=requType;
    
    if([self.reqType isEqualToString:@"future"])
    {
        if(arrayForFutureScoops && [arrayForFutureScoops count]>0)
            [arrayForFutureScoops removeAllObjects];
        futurePageNo=1;
    }
    else
    {
        if(arrayForCurrentScoops && [arrayForCurrentScoops count]>0)
            [arrayForCurrentScoops removeAllObjects];
        currentPageNo=1;
    }
    
    [self hitWebserviceForGettingSkoopListWithPageNumber:[NSString stringWithFormat:@"%i",currentPageNo]];
}

-(void)updateGroupProfileWithDataDict:(NSDictionary*)dataDict{

    NSLog(@"=======%@",dataDict);
    self.grpImage.image = [dataDict valueForKey:@"cover_image"];
    self._imgGroupImage.image = [dataDict valueForKey:@"profile_image"];
    
    self.grpName.text = [dataDict valueForKey:@"group_name"];
    self.name = [dataDict valueForKey:@"group_name"];
    self._lblGroupDescription.text = [dataDict valueForKey:@"group_description"];
    self.groupDescription = [dataDict valueForKey:@"group_description"];
    self.prEmail = [dataDict valueForKey:@"pr_email"];
    self.categoryName = [dataDict valueForKey:@"category_name"];
    self.categoryId = [dataDict valueForKey:@"category_id"];
    
    //Update group dictionary for MyGroups class
//    [self.grpDescriptionDict setValue:[dataDict valueForKey:@"group_name"] forKey:@"group_name"];
//    [self.grpDescriptionDict setValue:[dataDict valueForKey:@"group_description"] forKey:@"group_description"];
//    [self.grpDescriptionDict setValue:[dataDict valueForKey:@"pr_email"] forKey:@"pr_email"];
//    [self.grpDescriptionDict setValue:[dataDict valueForKey:@"category_name"] forKey:@"category_name"];
//    [self.grpDescriptionDict setValue:[dataDict valueForKey:@"category_id"] forKey:@"category_id"];
}

-(void)setRequiredBoolVariable:(BOOL)boolValue
{
    isHitWebService=YES;
    if(requestType==FutureSkoop)
    {
        if(arrayForFutureScoops.count>0)
            [arrayForFutureScoops removeAllObjects];
    }
    else if(requestType==CurrentSkoop)
    {
        if(arrayForCurrentScoops.count>0)
            [arrayForCurrentScoops removeAllObjects];
    }
    
    [self hitWebserviceForGettingSkoopListWithPageNumber:@"1"];
}

-(void)updateSkoopReplyDataWithDataDict:(NSDictionary*)dataDict
{
    isHitWebService=NO;
    NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:selectedIndex]];
    [dict setValue:@"0" forKey:@"upload"];
    [dict setValue:dataDict forKey:@"reply"];
    [arrayForCurrentScoops replaceObjectAtIndex:prevSelectedIndex withObject:dict];
    [self._uiTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:prevSelectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
    
    [[WebServicesController WebServiceMethod] parseSkoopReplyDataWithDataDictionary:dataDict];
}

#pragma mark General methods
-(void)hitWebServiceForGettingGroupMembers{
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetGroupMembers:) name: Notification_Get_IndividualGroupMembers object:nil];
    [[WebServicesController WebServiceMethod] getIndividualGroupMembersDataUserId:[AppHelper userDefaultsForKey:KUserId] searchText:@"" pageNumber:@"1" pageLimit:[NSString stringWithFormat:@"%i",PageLimit] andGroupId:self.groupId];
}

-(void)hitWebserviceForGettingSkoopListWithPageNumber:(NSString*)pageNumber
{
   // NSLog(@"pageNumber::%@      isHitWebService:%i",pageNumber,isHitWebService);
    if(isHitWebService)
    {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetGroupSkoops:) name: Notification_For_GetGroupSkoop object:nil];
        
        NSLog(@":::%@",self.reqType);
        
        if([self.reqType isEqualToString:@"future"])
        {
            futurePageNo=1;
            self.reqType=@"";
            
            requestType=FutureSkoop;
            
            [_btnCurrentSkoop setSelected:NO];
            [_btnFutureSkoop setSelected:YES];
            _btnFutureSkoop.backgroundColor=[UIColor colorWithRed:100.0/255.0 green:39.0/255.0 blue:142.0/255.0 alpha:1.0];
            _btnCurrentSkoop.backgroundColor=[UIColor colorWithRed:88.0/255.0 green:23.0/255.0 blue:133.0/255.0 alpha:1.0];
            
            [AppDelegate showGlobalProgressHUDWithTitle:nil];
            [[WebServicesController WebServiceMethod] getGroupSkoopDataWithGroupId:self.groupId requestType:@"future" pageNumber:@"1" andLimit:[NSString stringWithFormat:@"%i",PageLimit]];
        }
        else if([self.reqType isEqualToString:@"current"])
        {
            currentPageNo=1;
            self.reqType=@"";
            
            requestType=CurrentSkoop;
            
            [_btnCurrentSkoop setSelected:YES];
            [_btnFutureSkoop setSelected:NO];
            _btnCurrentSkoop.backgroundColor=[UIColor colorWithRed:100.0/255.0 green:39.0/255.0 blue:142.0/255.0 alpha:1.0];
            _btnFutureSkoop.backgroundColor=[UIColor colorWithRed:88.0/255.0 green:23.0/255.0 blue:133.0/255.0 alpha:1.0];
            
            [AppDelegate showGlobalProgressHUDWithTitle:nil];
            [[WebServicesController WebServiceMethod] getGroupSkoopDataWithGroupId:self.groupId requestType:@"current" pageNumber:@"1" andLimit:[NSString stringWithFormat:@"%i",PageLimit]];
        }
        else{
            
            if(requestType==CurrentSkoop){
                
                 [AppDelegate showGlobalProgressHUDWithTitle:nil];
                 [[WebServicesController WebServiceMethod] getGroupSkoopDataWithGroupId:self.groupId requestType:@"current" pageNumber:pageNumber andLimit:[NSString stringWithFormat:@"%i",PageLimit]];
            }
            else{
                
                 [AppDelegate showGlobalProgressHUDWithTitle:nil];
                 [[WebServicesController WebServiceMethod] getGroupSkoopDataWithGroupId:self.groupId requestType:@"future" pageNumber:pageNumber andLimit:[NSString stringWithFormat:@"%i",PageLimit]];
            }
        }
    }
}

-(void)changeBoolVariableCurrent{
    isCurrentScoopServiceHit=YES;
}

-(void)changeBoolVariableFuture{
    isFutureScoopServiceHit=YES;
}

-(void)movieLoadStateDidChange:(id)sender{
    NSLog(@"STATE CHANGED");
    if(MPMovieLoadStatePlaythroughOK ) {
        [AppDelegate dismissGlobalHUD];
        NSLog(@"State is Playable OK");
        NSLog(@"Enough data has been buffered for playback to continue uninterrupted..");
    }
}

#pragma mark Detect view touch
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    if (touch.view.tag==4445)
        [_viewSelectTime removeFromSuperview];
}

#pragma mark Button action methods
-(IBAction)onClickEditGroupButton:(id)sender
{
    [self performSegueWithIdentifier:@"editgroup" sender:nil];
}
- (IBAction)unjoinGrpAction:(id)sender
{
    if(groupJoinStatus==1)
    {
        if([self.ownerId isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
            [AppHelper showAlertViewWithTag:101 title:AppName message:@"Since you are the creator of this group you can’t unjoin." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        else
            [AppHelper showAlertViewWithTag:101 title:AppName message:@"Are you sure you want to unjoin this group?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
    }
    else
    {
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidJoinTheGroup:) name:Notification_For_JoinGroup object:nil];
        [[WebServicesController WebServiceMethod] joinGroupWithUserId:[AppHelper userDefaultsForKey:KUserId] andGroupId:self.groupId];
    }
}

- (IBAction)inviteFriendsAction:(id)sender
{
    if(groupJoinStatus == 1){
        [self performSegueWithIdentifier:@"invite_link" sender:nil];
    }
    else{
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You must join this group first to invite friends." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}

- (IBAction)sendRequestAction:(id)sender
{
    if(groupJoinStatus==1)
    {
         [self performSegueWithIdentifier:@"sendskoop" sender:nil];
    }
     else
         [AppHelper showAlertViewWithTag:1 title:AppName message:@"You must join this group first to send request." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

- (IBAction)uploadVideoAction:(id)sender {
    
    if(groupJoinStatus == 1){
        isUploadVideoForGroup = YES;
        [self performSegueWithIdentifier:@"goforreply" sender:nil];
        isHitWebService = NO;
        isReloadCell = NO;
    }
    else{
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You must join this group first to invite friends." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    }
}


-(IBAction)onClickLeftArrowButton:(id)sender
{
    NSArray *visibleItems = [_collectionView indexPathsForVisibleItems];
    if(visibleItems.count){
       
        NSIndexPath *currentItem = [visibleItems objectAtIndex:0];
        //Manage auto scrolls(For overcome the Issue for showing visible cells ordering)
        for (int i=0; i<visibleItems.count-1; i++)
        {
            NSIndexPath *indexPath1=[visibleItems objectAtIndex:i];
            NSIndexPath *indexPath2=[visibleItems objectAtIndex:i+1];
            if(indexPath1.row>indexPath2.row)
            {
                currentItem = [visibleItems objectAtIndex:i+1];
                break;
            }
        }
        
        NSIndexPath *prevItem = [NSIndexPath indexPathForItem:currentItem.item - 1 inSection:0];
        if(prevItem && prevItem.row>=0)
            [_collectionView scrollToItemAtIndexPath:prevItem atScrollPosition:UICollectionViewScrollPositionRight animated:YES];
    }
}

-(IBAction)onClickRightArrowButton:(id)sender
{
    NSArray *visibleItems = [_collectionView indexPathsForVisibleItems];
    if(visibleItems.count){
        
        NSIndexPath *currentItem = [visibleItems objectAtIndex:visibleItems.count-1];
        //Manage auto scrolls(For overcome the Issue for showing visible cells ordering)
        for (int i=0; i<visibleItems.count-1; i++) {
            NSIndexPath *indexPath1=[visibleItems objectAtIndex:i];
            NSIndexPath *indexPath2=[visibleItems objectAtIndex:i+1];
            if(indexPath1.row>indexPath2.row)
            {
                currentItem = [visibleItems objectAtIndex:i];
                break;
            }
        }
        
        NSIndexPath *nextItem = [NSIndexPath indexPathForItem:currentItem.item + 1 inSection:0];
        //Check array of bounds
        if(nextItem && nextItem.row<self.groupMembersArray.count)
            [_collectionView scrollToItemAtIndexPath:nextItem atScrollPosition:UICollectionViewScrollPositionLeft animated:YES];
    }
}

- (IBAction)onClickSkoopRequestType:(id)sender{
    
    UIButton *tappedButton=sender;
    
    if(tappedButton==_btnCurrentSkoop && requestType!=CurrentSkoop){
        
        requestType=CurrentSkoop;
        [_btnCurrentSkoop setSelected:YES];
        [_btnFutureSkoop setSelected:NO];
        _btnCurrentSkoop.backgroundColor=[UIColor colorWithRed:100.0/255.0 green:39.0/255.0 blue:142.0/255.0 alpha:1.0];
        _btnFutureSkoop.backgroundColor=[UIColor colorWithRed:88.0/255.0 green:23.0/255.0 blue:133.0/255.0 alpha:1.0];
        
        if(currentPageNo==1 && isCurrentScoopServiceHit){
            
            [AppDelegate showGlobalProgressHUDWithTitle:nil];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetGroupSkoops:) name: Notification_For_GetGroupSkoop object:nil];
            [[WebServicesController WebServiceMethod] getGroupSkoopDataWithGroupId:self.groupId requestType:@"current" pageNumber:@"1" andLimit:[NSString stringWithFormat:@"%i",PageLimit]];
        }
        else{
            
            [self._uiTableView reloadData];
            if(shownCurrentCell<arrayForCurrentScoops.count)
                [self._uiTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:shownCurrentCell inSection:0] atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
        }
    }
    else if(tappedButton==_btnFutureSkoop && requestType!=FutureSkoop)
    {
        NSLog(@"future");
        requestType=FutureSkoop;
        
        [_btnCurrentSkoop setSelected:NO];
        [_btnFutureSkoop setSelected:YES];
        _btnFutureSkoop.backgroundColor=[UIColor colorWithRed:100.0/255.0 green:39.0/255.0 blue:142.0/255.0 alpha:1.0];
        _btnCurrentSkoop.backgroundColor=[UIColor colorWithRed:88.0/255.0 green:23.0/255.0 blue:133.0/255.0 alpha:1.0];
        
        if(futurePageNo==1 && isFutureScoopServiceHit)
        {
            [AppDelegate showGlobalProgressHUDWithTitle:nil];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetGroupSkoops:) name: Notification_For_GetGroupSkoop object:nil];
            [[WebServicesController WebServiceMethod] getGroupSkoopDataWithGroupId:self.groupId requestType:@"future" pageNumber:@"1" andLimit:[NSString stringWithFormat:@"%i",PageLimit]];
        }
        else
        {
            [self._uiTableView reloadData];
            if(shownFutureCell<arrayForFutureScoops.count)
                [self._uiTableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:shownFutureCell inSection:0] atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
        }
    }
}

- (IBAction)onClickSeeAllButton:(id)sender
{
    [self performSegueWithIdentifier:@"seeAll_link" sender:nil];
}

- (IBAction)backAction:(id)sender
{
    NSArray *navArray=self.navigationController.viewControllers;
    if([[navArray objectAtIndex:navArray.count-2] isKindOfClass:[CreateGroupVC class]])
        [self.navigationController popToRootViewControllerAnimated:YES];
    else
        [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)lenseButtonPressed:(id)sender{
    
    if(requestType == FutureSkoop){
        
        UITableViewCell *tblCell=nil;
        if(IS_IOS_7)
            tblCell=(UITableViewCell*)[[[sender superview] superview] superview];
        else
            tblCell=(UITableViewCell*)[[sender superview] superview];
        
        NSIndexPath *indexPath=[self._uiTableView indexPathForCell:tblCell];
        selectedIndex = indexPath.row;
        NSDictionary *selectedDict = [arrayForFutureScoops objectAtIndex:indexPath.row];
        if(groupJoinStatus == 1){
            
            selectedSkoopId=[selectedDict valueForKey:@"skoop_id"];
            [self addSkoopIntoCalendarAndReloadRowWithIndexPath:indexPath];
        }
        else{
            if([[selectedDict objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Join the group to be able to see Skoop reply." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
            else
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Join the group to be able to reply to Skoop requests." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
    }
}

-(void)addSkoopIntoCalendarAndReloadRowWithIndexPath:(NSIndexPath *)indexPath{
    
    NSMutableDictionary *selectedDict = [NSMutableDictionary dictionaryWithDictionary:[arrayForFutureScoops objectAtIndex:indexPath.row]];
    
    selectedSkoopId = [selectedDict valueForKey:@"skoop_id"];
    if(requestType == FutureSkoop){
        
        if([_viewSelectTime superview]==nil){
            
            UIButton *btn15Min=(UIButton*)[_viewSelectTime viewWithTag:100];
            UIButton *btn30Min=(UIButton*)[_viewSelectTime viewWithTag:101];
            UIButton *btn45Min=(UIButton*)[_viewSelectTime viewWithTag:102];
            UIButton *btn60Min=(UIButton*)[_viewSelectTime viewWithTag:103];
            
            selectedTime=@"15";
            [btn15Min setSelected:YES];
            [btn30Min setSelected:NO];
            [btn45Min setSelected:NO];
            [btn60Min setSelected:NO];
            
            switch ([[selectedDict valueForKey:@"reminder_time"] integerValue]) {
                    
                case 15:
                    selectedTime=@"15";
                    [btn15Min setSelected:YES];
                    [btn30Min setSelected:NO];
                    [btn45Min setSelected:NO];
                    [btn60Min setSelected:NO];
                    break;
                    
                case 30:
                    selectedTime=@"30";
                    [btn15Min setSelected:NO];
                    [btn30Min setSelected:YES];
                    [btn45Min setSelected:NO];
                    [btn60Min setSelected:NO];
                    break;
                    
                case 45:
                    selectedTime=@"45";
                    [btn15Min setSelected:NO];
                    [btn30Min setSelected:NO];
                    [btn45Min setSelected:YES];
                    [btn60Min setSelected:NO];
                    break;
                    
                case 60:
                    selectedTime=@"60";
                    [btn15Min setSelected:NO];
                    [btn30Min setSelected:NO];
                    [btn45Min setSelected:NO];
                    [btn60Min setSelected:YES];
                    break;
                    
                default:
                    break;
            }
            
            if([[selectedDict valueForKey:@"added_status"] integerValue]==1)
                _lblSkoopRequest.text=@"Change time of reminder?";
            else
                _lblSkoopRequest.text=@"Save Skoop request in calendar?";
            
            [self.view addSubview:_viewSelectTime];
            
            if([[selectedDict valueForKey:@"read_status"] integerValue]==0){
                NSInteger objectIndex=[arrayForFutureScoops indexOfObject:selectedDict];
                [selectedDict setValue:@"1" forKey:@"read_status"];
                
                if(objectIndex<arrayForFutureScoops.count)
                    [arrayForFutureScoops replaceObjectAtIndex:objectIndex withObject:selectedDict];
                
                [self performSelector:@selector(reloadTableviewAfterDelayWithIndexPath:) withObject:indexPath afterDelay:0.2];
                
                [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[selectedDict valueForKey:@"skoop_id"] notificationType:@"skoop_request" andToken:KAppToken];
            }
        }
    }
}


//Select time for getting alert before skoop time
-(IBAction)onClickSelectTimeButton:(id)sender
{
    UIButton *btnTime=(UIButton*)sender;
    
    UIButton *btn15Min=(UIButton*)[_viewSelectTime viewWithTag:100];
    UIButton *btn30Min=(UIButton*)[_viewSelectTime viewWithTag:101];
    UIButton *btn45Min=(UIButton*)[_viewSelectTime viewWithTag:102];
    UIButton *btn60Min=(UIButton*)[_viewSelectTime viewWithTag:103];
    
    if(![btnTime isSelected])
        [btnTime setSelected:YES];
    
    if(btnTime.tag==100)//15 minutes button
    {
        selectedTime=@"15";
        [btn30Min setSelected:NO];
        [btn45Min setSelected:NO];
        [btn60Min setSelected:NO];
    }
    else if(btnTime.tag==101)//30 minutes button
    {
        selectedTime=@"30";
        [btn15Min setSelected:NO];
        [btn45Min setSelected:NO];
        [btn60Min setSelected:NO];
    }
    else if(btnTime.tag==102)//45 minutes button
    {
        selectedTime=@"45";
        [btn30Min setSelected:NO];
        [btn15Min setSelected:NO];
        [btn60Min setSelected:NO];
    }
    else if(btnTime.tag==103)//60 minutes button
    {
        selectedTime=@"60";
        [btn30Min setSelected:NO];
        [btn45Min setSelected:NO];
        [btn15Min setSelected:NO];
    }
}

//Add future skoop into calender for reminder
-(IBAction)onClickAddButton:(id)sender{
    
    if([_viewSelectTime superview] != nil)
        [_viewSelectTime removeFromSuperview];
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidAddSkoopInToCalendar:) name:Notification_Add_Skoop_Into_Calendar object:nil];
    [[WebServicesController WebServiceMethod] addSkoopIntoCalendarWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:selectedSkoopId skoopTime:selectedTime andAppToken:KAppToken];
}

//Add future skoop into calender for reminder
-(IBAction)onClickSaveButton:(id)sender{
    
    if([_viewSelectTime superview] != nil)
        [_viewSelectTime removeFromSuperview];
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidAddSkoopInToCalendar:) name:Notification_Add_Skoop_Into_Calendar object:nil];
    [[WebServicesController WebServiceMethod] addSkoopIntoCalendarWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:selectedSkoopId skoopTime:@"0" andAppToken:KAppToken];
}

-(IBAction)onClickCancelButton:(id)sender
{
    if([_viewSelectTime superview]!=nil)
        [_viewSelectTime removeFromSuperview];
}

#pragma mark Services response and Receive notification methods
-(void)userDidChangeProfileImage:(NSNotification*)noti
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Refresh_UserImage object:nil];
    [self._uiTableView reloadData];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidChangeProfileImage:) name:Notification_Refresh_UserImage object:nil];
}

-(void)userDidRefreshGroupMembers:(NSNotification*)noti
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Refresh_GroupMembers object:nil];
    [self hitWebServiceForGettingGroupMembers];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidRefreshGroupMembers:) name:Notification_Refresh_GroupMembers object:nil];
}


-(void)userDidReplyOnSkoop:(NSNotification *)notification
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_reply_on_skoop object:nil];
    NSLog(@":::%@",notification.userInfo);
    
    if([notification.userInfo valueForKey:@"skoop_id"])
    {
        [[WebServicesController WebServiceMethod] deleteFileFromDocumentDirectoryWithFileName:[NSString stringWithFormat:@"movie%@.mov",[notification.userInfo valueForKey:@"skoop_id"]]];
        [[WebServicesController WebServiceMethod] deleteSkoopWithSkoopId:[notification.userInfo valueForKey:@"skoop_id"]];
        pendingSkoopArray=[NSArray arrayWithArray:[[WebServicesController WebServiceMethod] getAllSkoopReplyData]];
    }
    
    if(prevSelectedIndex<arrayForCurrentScoops.count)
    {
        NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:prevSelectedIndex]];
        [dict setValue:@"1" forKey:@"upload"];
        NSMutableDictionary *replyDict=[NSMutableDictionary dictionaryWithDictionary:[dict valueForKey:@"reply"]];
        
        if([notification.userInfo valueForKey:@"video_path"])
        {
            [replyDict setValue:[notification.userInfo valueForKey:@"video_path"] forKey:@"video_path"];
            if([replyDict valueForKey:@"video_data"])
                [replyDict removeObjectForKey:@"video_data"];
            [dict setValue:replyDict forKey:@"reply"];
            [arrayForCurrentScoops replaceObjectAtIndex:prevSelectedIndex withObject:dict];
            [self._uiTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:prevSelectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
        }
    }
    
    [self setRequiredBoolVariable:YES];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnSkoop:) name:Notification_reply_on_skoop object:nil];
}

-(void)userDidGetGroupMembers:(NSNotification*) note
{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"=====%@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_IndividualGroupMembers object:nil];
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
    {
        self.groupMembersArray = nil;
        self.groupMembersArray = [NSMutableArray arrayWithArray:[note.userInfo valueForKey:@"data"]];
        
        [self._uiTableView reloadData];
        [_collectionView reloadData];
        _lblGroupMember.text=[NSString stringWithFormat:@"Members (%i)",(int)self.groupMembersArray.count];
        
        UIButton *btnJoinGroup=(UIButton*)[self.view viewWithTag:500];
        
        groupJoinStatus=[[note.userInfo valueForKey:@"join_status"] integerValue];
        if(groupJoinStatus==1){
            [btnJoinGroup setTitle:@"Unjoin Group" forState:UIControlStateNormal];
            [btnJoinGroup setTitle:@"Unjoin Group" forState:UIControlStateSelected];
        }
        else{
            [btnJoinGroup setTitle:@"Join Group" forState:UIControlStateNormal];
            [btnJoinGroup setTitle:@"Join Group" forState:UIControlStateSelected];
        }
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(void)userDidGetGroupSkoops:(NSNotification*) note
{
    [AppDelegate dismissGlobalHUD];
   // NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_For_GetGroupSkoop object:nil];
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
    {        
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0)
        {
            isHitWebService=NO;
            NSArray *countArray=[[note.userInfo valueForKey:@"total"] componentsSeparatedByString:@","];
            if(countArray.count>0){
                _lblCurrentSkoopCount.text=[countArray objectAtIndex:0];
            }
            if(countArray.count>1){
                _lblFutureSkoopCount.text=[countArray objectAtIndex:1];
            }
            
            int skoopIndex=-1;
            if(requestType==CurrentSkoop)
            {
                currentPageNo++;
                if([[note.userInfo valueForKey:@"data"] count]>0)
                {
                    NSArray *skoopArray = [note.userInfo valueForKey:@"data"];
                    
                    for (int i=0; i<skoopArray.count; i++)
                    {
                        NSDictionary *scoopDict = [skoopArray objectAtIndex:i];
                        if([[scoopDict valueForKey:@"skoop_id"] isEqualToString:self.skoopId])
                            skoopIndex=i;
                        
                        BOOL isAdd=YES;
                        for (int i=0; i<pendingSkoopArray.count; i++)
                        {
                            SkoopReplyData *skoop=[pendingSkoopArray objectAtIndex:i];
                            
                            if([[scoopDict valueForKey:@"skoop_id"] isEqualToString:skoop.skoopId])
                            {
                                NSDictionary *dataDict=[[NSDictionary alloc] initWithObjectsAndKeys:skoop.replyDate,@"date",skoop.videoLength,@"duration",skoop.userImageUrl,@"image",skoop.message,@"message",[AppHelper userDefaultsForKey:KUserName],@"name",skoop.paymentStatus,@"paymentStatus",skoop.thumbImage,@"thumbimage",[AppHelper userDefaultsForKey:KUserId],@"user_id",skoop.videoUrl,@"video_path",skoop.isUpload,@"upload", nil];
                                
                                NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:scoopDict];
                                [dict setValue:dataDict forKey:@"reply"];
                                [arrayForCurrentScoops addObject:dict];
                                isAdd=NO;
                            }
                        }
                        if(isAdd)
                            [arrayForCurrentScoops addObject:scoopDict];
                    }
                    isCurrentScoopServiceHit=YES;
                }
                else
                    isCurrentScoopServiceHit=NO;
                
                [self._uiTableView reloadData];
                if(skoopIndex>=0)
                {
                    self.skoopId=@"0";
                    [self performSelector:@selector(scrollTableViewWithIndexPath:) withObject:[NSIndexPath indexPathForRow:skoopIndex inSection:0] afterDelay:0.2];
                }
            }
            else if(requestType==FutureSkoop)
            {
                futurePageNo++;
                
                if([[note.userInfo valueForKey:@"data"] count]>0)
                {
                    NSArray *skoopArray=[note.userInfo valueForKey:@"data"];
                    for (int i=0; i<skoopArray.count; i++)
                    {
                        NSDictionary *scoopDict=[skoopArray objectAtIndex:i];
                        if([[scoopDict valueForKey:@"skoop_id"] isEqualToString:self.skoopId])
                            skoopIndex=i;
                        [arrayForFutureScoops addObject:scoopDict];
                    }
                    isFutureScoopServiceHit=YES;
                }
                else
                    isFutureScoopServiceHit=NO;
                
                [self._uiTableView reloadData];
                
                if(skoopIndex>=0)
                {
                    self.skoopId=@"0";
                    [self performSelector:@selector(scrollTableViewWithIndexPath:) withObject:[NSIndexPath indexPathForRow:skoopIndex inSection:0] afterDelay:0.2];
                }
            }
        }
        else if([[note.userInfo valueForKey:@"errorCode"] integerValue]==1){
            if(requestType==FutureSkoop)
                isFutureScoopServiceHit=NO;
            if(requestType==CurrentSkoop)
                isCurrentScoopServiceHit=NO;
        }
    }
//    else
//        [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    
}

-(void)scrollTableViewWithIndexPath:(NSIndexPath*)indexPath
{
    [self._uiTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

-(void)userDidUnJoinTheGroup:(NSNotification *)note{
    [AppDelegate dismissGlobalHUD];
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_For_UnJoinGroup object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            UIButton *btnJoinGroup=(UIButton*)[self.view viewWithTag:500];
            groupJoinStatus=0;
            [btnJoinGroup setTitle:@"Join Group" forState:UIControlStateNormal];
            [btnJoinGroup setTitle:@"Join Group" forState:UIControlStateSelected];
            [[self updateListProtocol] updateMyGroupList];
            [self hitWebServiceForGettingGroupMembers];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1){
            [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
        }
    }
}

-(void)userDidJoinTheGroup:(NSNotification *)note{
    NSLog(@"======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_For_JoinGroup object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            UIButton *btnJoinGroup=(UIButton*)[self.view viewWithTag:500];
            [btnJoinGroup setTitle:@"Unjoin Group" forState:UIControlStateNormal];
            [btnJoinGroup setTitle:@"Unjoin Group" forState:UIControlStateSelected];
            
            groupJoinStatus=1;
            requestType=CurrentSkoop;
            isHitWebService=YES;
            [self hitWebserviceForGettingSkoopListWithPageNumber:@"1"];
            [self hitWebServiceForGettingGroupMembers];
            if(self.isFromMyGroupClass)
                [[self updateListProtocol] addJoinedGroupIntoList];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1){
            [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
        }
    }
}

-(void)userDidBlockFromGroup:(NSNotification*)note{
    [AppDelegate dismissGlobalHUD];
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Block_User_From_Group object:nil];
    
    if(note.userInfo){
        if([[note.userInfo valueForKey:@"errorCode"] integerValue]==0){
            
            [_btnBlockUser setSelected:NO];
            [self.groupMembersArray removeObject:selectedGroupMemberDataDict];
            
            _lblGroupMember.text=[NSString stringWithFormat:@"Members (%i)",(int)self.groupMembersArray.count];
            [self performSelector:@selector(reloadCollectionViewWithDelay) withObject:nil afterDelay:0.5];
            [AppHelper showAlertViewWithTag:103 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
    }
}

-(void)reloadCollectionViewWithDelay{
    [_collectionView reloadData];
}

-(void)userDidAddSkoopInToCalendar:(NSNotification *)notification
{
    [AppDelegate dismissGlobalHUD];
    
    NSLog(@":::%@",notification.userInfo);
    if(notification.userInfo && [[notification.userInfo valueForKey:@"errorCode"] integerValue] == 0){
        
        NSMutableDictionary *dataDict = [NSMutableDictionary dictionaryWithDictionary:[arrayForFutureScoops objectAtIndex:selectedIndex]];
        [dataDict setValue:@"1" forKey:@"added_status"];
        [dataDict setValue:selectedTime forKey:@"reminder_time"];
        [arrayForFutureScoops replaceObjectAtIndex:selectedIndex withObject:dataDict];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_Calendar object:@"refresh" userInfo:nil];
        [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Add_Skoop_Into_Calendar object:nil];
        [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_UpcomingSkoopList object:nil userInfo:(NSDictionary*)dataDict];
    }
    [AppHelper showAlertViewWithTag:1 title:AppName message:[notification.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(void)userDidReplyOnLivePortalRequest:(NSNotification *)notification
{
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Reply_LivePortal_Req object:nil];
    
    NSLog(@":::%@",notification.userInfo);
    NSDictionary *dict=notification.userInfo;
    
    if([[dict objectForKey:@"errorCode"] integerValue]==0)
    {
        [AppHelper showAlertViewWithTag:1 title:AppName message:[dict valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        
        NSMutableDictionary *dataDict=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:selectedIndex]];
        [dataDict setValue:@"1" forKey:@"reply_status"];
        [arrayForCurrentScoops replaceObjectAtIndex:selectedIndex withObject:dataDict];
        [self._uiTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[dict valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(void)userDidDeleteSkoop:(NSNotification *)note{
    
    NSLog(@"Deleter skoop Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Delete_Skoop object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            
            
            NSDictionary *dataDict;
            if(requestType == CurrentSkoop){
                
                dataDict = [arrayForCurrentScoops objectAtIndex:selectedIndex];
                [arrayForCurrentScoops removeObjectAtIndex:selectedIndex];
                _lblCurrentSkoopCount.text = [NSString stringWithFormat:@"%i",[_lblCurrentSkoopCount.text intValue]-1];
            }
            else{
                
                dataDict = [arrayForFutureScoops objectAtIndex:selectedIndex];
                [arrayForFutureScoops removeObjectAtIndex:selectedIndex];
                _lblFutureSkoopCount.text = [NSString stringWithFormat:@"%i",[_lblFutureSkoopCount.text intValue]-1];
            }
            [self._uiTableView reloadData];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_Calendar object:[dataDict valueForKey:@"skoop_id"] userInfo:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_UpcomingSkoopList object:[dataDict valueForKey:@"skoop_id"] userInfo:nil];
            [[AppDelegate getAppDelegate] deleteSkoopEventFromCalendarWithDict:dataDict];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1)
            [AppHelper showAlertViewWithTag:101 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    }
}

#pragma mark tableView Delegates
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
     return 34.0;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dictOfScoop=nil;
    int rowCount;
    if(requestType==CurrentSkoop){
        dictOfScoop=[arrayForCurrentScoops objectAtIndex:indexPath.row];
        rowCount = (int)arrayForCurrentScoops.count;
    }
    else{
        dictOfScoop=[arrayForFutureScoops objectAtIndex:indexPath.row];
        rowCount = (int)arrayForFutureScoops.count;
    }
    
    CGFloat rowheight;
    
    if([dictOfScoop objectForKey:@"reply"])
//        rowheight = 185;
    {
        if ([[dictOfScoop objectForKey:@"skoop_id"] isEqualToString:@"1"]) {
            rowheight = 93;
        } else {
            rowheight = 185;
        }
    }
    else if([[dictOfScoop objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
        rowheight = 103;
    else
        rowheight = 97;
    
    if(indexPath.row == rowCount-1)
        return rowheight + 10;
    else
        return rowheight;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    return _viewTableSectionHeader;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(requestType==CurrentSkoop)
        return arrayForCurrentScoops.count;
    else
        return arrayForFutureScoops.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell;
    NSDictionary *dictOfScoop=nil;
    if(requestType==CurrentSkoop){
        dictOfScoop=[arrayForCurrentScoops objectAtIndex:indexPath.row];
        shownCurrentCell=(int)indexPath.row;
    }
    else{
        dictOfScoop=[arrayForFutureScoops objectAtIndex:indexPath.row];
        shownFutureCell=(int)indexPath.row;
    }
    
    if([dictOfScoop objectForKey:@"reply"])
        cell = [tableView dequeueReusableCellWithIdentifier:@"SkoopReqRep"];
    else if([[dictOfScoop objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
        cell = [tableView dequeueReusableCellWithIdentifier:@"SendSkoopReq"];
    else
        cell = [tableView dequeueReusableCellWithIdentifier:@"SkoopRequest"];
    
    if (cell == nil){
        NSLog(@"****************nil*********************");
        NSArray *topLevelObjects = nil;
        if([dictOfScoop objectForKey:@"reply"])
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SkoopReqRep" owner:self options:nil];
        else if([[dictOfScoop objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SendSkoopReq" owner:self options:nil];
        else
            topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SkoopRequest" owner:self options:nil];
        // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
        cell = [topLevelObjects objectAtIndex:0];
        cell.layer.borderColor=[UIColor grayColor].CGColor;
        cell.backgroundColor=[UIColor clearColor];
        
        UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:208];
        if(profileImage){
            UITapGestureRecognizer *uiTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnSenderSkoopProfileImage:)];
            uiTap.numberOfTapsRequired=1;
            profileImage.userInteractionEnabled=YES;
            [profileImage addGestureRecognizer:uiTap];
        }
        
        if([dictOfScoop objectForKey:@"reply"]){
            UIImageView *replyProfileImage=(UIImageView *)[cell.contentView viewWithTag:219];
            UITapGestureRecognizer *uiTap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnReplierSkoopProfileImage:)];
            uiTap1.numberOfTapsRequired=1;
            replyProfileImage.userInteractionEnabled=YES;
            [replyProfileImage addGestureRecognizer:uiTap1];
        }
    }
        
    if(isCurrentScoopServiceHit && requestType==CurrentSkoop && indexPath.row==arrayForCurrentScoops.count-1){
        [self hitWebserviceForGettingSkoopListWithPageNumber:[NSString stringWithFormat:@"%i",currentPageNo]];
    }
    else if(isFutureScoopServiceHit && requestType==FutureSkoop && indexPath.row==arrayForFutureScoops.count-1){
        [self hitWebserviceForGettingSkoopListWithPageNumber:[NSString stringWithFormat:@"%i",futurePageNo]];
    }
    
    if([[dictOfScoop objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]] && ![dictOfScoop objectForKey:@"reply"]){
        
        CBAutoScrollLabel *lblSkoopName=(CBAutoScrollLabel *)[cell viewWithTag:101];
        [lblSkoopName setLabelSettingForObject:@"skoop"];
        lblSkoopName.text=[dictOfScoop valueForKey:@"searchText"];
        
        UILabel *lblLocation=(UILabel *)[cell viewWithTag:102];
        lblLocation.text=[NSString stringWithFormat:@"Group: %@",self.name];
        
        UILabel *lblDate=(UILabel *)[cell viewWithTag:103];
        lblDate.text=[NSString stringWithFormat:@"Time: %@",[dictOfScoop valueForKey:@"date"]];
        
        UILabel *lblCost=(UILabel *)[cell viewWithTag:104];
        UILabel *lblReplies=(UILabel *)[cell.contentView viewWithTag:107];
        
        if([[dictOfScoop valueForKey:@"price"] floatValue]>0)
            lblCost.text=[NSString stringWithFormat:@"$%@",[dictOfScoop valueForKey:@"price"]];
        else
            lblCost.text=@"Favor";
        
        UIImageView *imgRedCircle=(UIImageView *)[cell.contentView viewWithTag:105];
        if([[dictOfScoop valueForKey:@"live_portal"] integerValue] == 1){
            imgRedCircle.image=[UIImage imageNamed:@"noti_lp.png"];
            lblReplies.text = @"Users";
        }
        else{
            imgRedCircle.image=[UIImage imageNamed:@"notification_number.png"];
            lblReplies.text = @"Replies";
        }
        
        UILabel *lblReplyCount=(UILabel*)[cell viewWithTag:106];
        lblReplyCount.text=[dictOfScoop valueForKey:@"replyCount"];
        return  cell;
    }
    
    UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:208];
    [AppHelper getRoundedImageWithImageView:profileImage];
    
    UILabel *lblLikeCount=(UILabel *)[cell.contentView viewWithTag:210];
    lblLikeCount.backgroundColor=[UIColor clearColor];
    lblLikeCount.text=[NSString stringWithFormat:@"%i",[[dictOfScoop valueForKey:@"like"] intValue]];
    
    CBAutoScrollLabel *lblName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:212];
    [lblName setLabelSettingForObject:@"name"];
    
    CBAutoScrollLabel *lblsearchText=(CBAutoScrollLabel *)[cell.contentView viewWithTag:205];
    [lblsearchText setLabelSettingForObject:@"skoop"];
    
    UILabel *lblLocation=(UILabel *)[cell.contentView viewWithTag:206];
    UILabel *lblDate=(UILabel *)[cell.contentView viewWithTag:207];
    UILabel *lblCost=(UILabel *)[cell.contentView viewWithTag:209];
    lblCost.textColor=KTextColor;
    
    NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfScoop objectForKey:@"image"]]];
    NSString *groupImageUrL=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url=[NSURL URLWithString:groupImageUrL];
        
    if([urlString length]>0)
        [profileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    else
        profileImage.image=[UIImage imageNamed:@"defaultuser.png"];
    
    lblName.text=[dictOfScoop valueForKey:@"name"];
    lblsearchText.text=[dictOfScoop valueForKey:@"searchText"];
    lblLocation.text=[NSString stringWithFormat:@"Group: %@",self.name];
    lblDate.text=[NSString stringWithFormat:@"%@",[dictOfScoop valueForKey:@"date"]];
    if([[dictOfScoop valueForKey:@"price"] floatValue] >0)
        lblCost.text=[NSString stringWithFormat:@"$ %@",[dictOfScoop valueForKey:@"price"]];
    else
        lblCost.text=@"Favor";
    
    UIButton *btnLense=(UIButton*)[cell.contentView viewWithTag:425];
    
    if([[dictOfScoop valueForKey:@"live_portal"] integerValue]==1){
        if([[dictOfScoop valueForKey:@"reply_status"] integerValue]==0)
            [btnLense setImage:[UIImage imageNamed:@"live_poratl_small.png"] forState:UIControlStateNormal];
        else
            [btnLense setImage:[UIImage imageNamed:@"live_green.png"] forState:UIControlStateNormal];
        
        btnLense.userInteractionEnabled=NO;
        btnLense.frame=CGRectMake(275, 25, 40, 40);
    }
    else{
        [btnLense setImage:[UIImage imageNamed:@"lens_icon.png"] forState:UIControlStateNormal];
        [btnLense setImage:[UIImage imageNamed:@"lens_icon.png"] forState:UIControlStateHighlighted];
        
        [btnLense addTarget:self action:@selector(lenseButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        if(requestType==CurrentSkoop)//Can not add current skoop in to the calendar
            btnLense.userInteractionEnabled=NO;
        else
            btnLense.userInteractionEnabled=YES;
        btnLense.frame=CGRectMake(278, 27, 35, 35);
    }
    
    if([dictOfScoop objectForKey:@"reply"]){
        
        UIView *upView=(UIView*)[cell.contentView viewWithTag:901];
        UIView *bottomView=(UIView*)[cell.contentView viewWithTag:900];
        if ([[dictOfScoop objectForKey:@"skoop_id"] isEqualToString:@"1"]) {
            upView.hidden = YES;
            bottomView.frame = CGRectMake(0, 0, 320, 92);
        } else {
            upView.hidden = NO;
            bottomView.frame = CGRectMake(0, 88, 320, 92);
        }
        
        
        NSDictionary *dictOfReply=[dictOfScoop objectForKey:@"reply"];
        UIImageView *replyVideoImageView=(UIImageView *)[cell.contentView viewWithTag:202];
        
        if([[dictOfReply valueForKey:@"paymentStatus"] isEqualToString:@"1"])
            lblCost.textColor=KTextColor_Green;
    
        UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[cell.contentView viewWithTag:indexPath.row+1];
        if([dictOfScoop valueForKey:@"upload"] && [[dictOfScoop valueForKey:@"upload"] integerValue]==0){
            if(activityIndicator)
                [activityIndicator startAnimating];
            else{
                activityIndicator= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
                activityIndicator.backgroundColor=[UIColor clearColor];
                activityIndicator.alpha = 1.0;
                activityIndicator.tag=indexPath.row+1;
                activityIndicator.center = replyVideoImageView.center;
                activityIndicator.hidesWhenStopped = YES;
                [bottomView addSubview:activityIndicator];
                [activityIndicator startAnimating];
            }
        }
        else if(activityIndicator){
            [activityIndicator stopAnimating];
            [activityIndicator removeFromSuperview];
        }
        
        UIImageView *replyProfileImage=(UIImageView *)[cell.contentView viewWithTag:219];
        replyProfileImage.backgroundColor=[UIColor lightGrayColor];
        [AppHelper getRoundedImageWithImageView:replyProfileImage];
        
        NSLog(@"dicOfSkoop = %@", dictOfScoop);
        NSString *urlString;
        if ([[dictOfScoop objectForKey:@"skoop_id"] isEqualToString:@"1"]) {
            urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[[dictOfScoop objectForKey:@"reply"] objectForKey:@"image"]]];
        }else{
            urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[AppHelper userDefaultsForKey:KUserImageUrl]]];
        }
        NSString *skoopimgUrl=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url=[NSURL URLWithString:skoopimgUrl];
        if([urlString length]>0)
            [replyProfileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
        else
            replyProfileImage.image=[UIImage imageNamed:@"defaultuser.png"];
        
        if([dictOfReply objectForKey:@"thumbnail"]){
            NSString *urlString1 = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfReply objectForKey:@"thumbnail"]]];
            NSString *imgUrl1=[urlString1  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            NSURL *url1=[NSURL URLWithString:imgUrl1];
            [replyVideoImageView setImageWithURL:url1 placeholderImage:[UIImage imageNamed:@"thumbimage"]];
        }
        else
            replyVideoImageView.image=[dictOfReply valueForKey:@"thumbimage"];
        
        CBAutoScrollLabel *lblReplyName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:214];
        [lblReplyName setLabelSettingForObject:@"name"];
        lblReplyName.text=[dictOfReply valueForKey:@"name"];
        
        CBAutoScrollLabel *lblReplysearchText=(CBAutoScrollLabel *)[cell.contentView viewWithTag:1210];
        [lblReplysearchText setLabelSettingForObject:@"skoop"];
        
        if ([[dictOfReply valueForKey:@"skoop_id"] isEqualToString:@"1"]) {
            lblReplysearchText.text = [dictOfReply valueForKey:@"name"];
        } else {
            lblReplysearchText.text = [NSString stringWithFormat:@"%@(%@ Sec)",[dictOfScoop valueForKey:@"searchText"],[[dictOfScoop valueForKey:@"reply"] valueForKey:@"duration"]];
        }
        
        UILabel *lblReplyLocation=(UILabel *)[cell.contentView viewWithTag:1211];
        lblReplyLocation.text=[NSString stringWithFormat:@"Group: %@",self.name];
        
        UILabel *lblReplyDate=(UILabel *)[cell.contentView viewWithTag:215];
        lblReplyDate.text=[NSString stringWithFormat:@"%@",[dictOfReply valueForKey:@"date"]];
    }
    
    
    
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    selectedIndex = indexPath.row;
    UITableViewCell *tblCell=[self._uiTableView cellForRowAtIndexPath:indexPath];
    NSMutableDictionary *selectedData=nil;
    if(requestType==CurrentSkoop)
        selectedData=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:indexPath.row]];
    else
        selectedData=[NSMutableDictionary dictionaryWithDictionary:[arrayForFutureScoops objectAtIndex:indexPath.row]];
    
    if(requestType == CurrentSkoop){
        
        if([[selectedData valueForKey:@"live_portal"] integerValue]==1){
            
            if([[selectedData valueForKey:@"reply_status"] integerValue]==1){
                
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have already replied to this request." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
            }
            else{
                
                if([[selectedData objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]]){
                    [self performSegueWithIdentifier:@"seeskoopreply" sender:selectedData];
                }
                else{
                    if(groupJoinStatus == 1){
                        selectedIndex = indexPath.row;
                        
                        NSInteger objectIndex=[arrayForCurrentScoops indexOfObject:selectedData];
                        
                        [selectedData setValue:@"1" forKey:@"read_status"];
                        if(objectIndex<arrayForCurrentScoops.count)
                            [arrayForCurrentScoops replaceObjectAtIndex:objectIndex withObject:selectedData];
                        
                        NSIndexPath *indexPath1=[NSIndexPath indexPathForRow:objectIndex inSection:0];
                        [self performSelector:@selector(reloadTableviewAfterDelayWithIndexPath:) withObject:indexPath1 afterDelay:0.2];
                        
                        [AppHelper showAlertViewWithTag:104 title:AppName message:@"Would you like to tell this user that you are available for a Live Portal call?" delegate:self cancelButtonTitle:Alert_No otherButtonTitles:Alert_Yes];
                        
                        [[WebServicesController WebServiceMethod] readNotificationWithUserId:[AppHelper userDefaultsForKey:KUserId] notificationId:[selectedData valueForKey:@"skoop_id"] notificationType:@"skoop_request" andToken:KAppToken];
                    }
                    else{
                        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Join the group to be able to confirm live portal request." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
                    }
                }
            }
        }
        else{
            if(tblCell.tag==200){
                
                if([selectedData valueForKey:@"upload"] && [[selectedData valueForKey:@"upload"] integerValue]==0){
                    [AppHelper showAlertViewWithTag:1 title:AppName message:@"Video is not uploaded yet." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
                }
                else{
                    
                    UIStoryboard *story = [UIStoryboard storyboardWithName:@"youSkoopLayouts" bundle:nil];
                    VideoPlayerVC *videoPlayerVC = [story instantiateViewControllerWithIdentifier:@"VideoPlayerVC"];
                    videoPlayerVC.videoURL =[[selectedData valueForKey:@"reply"] valueForKey:@"video_path"];
                    videoPlayerVC.isShowingOwnVideo = YES;
                    videoPlayerVC.selecteDataDict = selectedData;
                    [self.navigationController pushViewController:videoPlayerVC animated:NO];
                }
            }
            else{
                if([[selectedData objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]]){
                    [self performSegueWithIdentifier:@"seeskoopreply" sender:selectedData];
                }
                else{
                    if(groupJoinStatus == 1){
                        prevSelectedIndex = selectedIndex;
                        NSDictionary *dataDict=[arrayForCurrentScoops objectAtIndex:indexPath.row];
                        [self performSegueWithIdentifier:@"goforreply" sender:dataDict];
                    }
                    else
                        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Join the group to be able to reply to Skoop requests." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
                }
            }
        }
    }
    else{
        
        if(groupJoinStatus == 1){
            if([[selectedData objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]]){
                [self performSegueWithIdentifier:@"seeskoopreply" sender:selectedData];
            }
            else{
                [self addSkoopIntoCalendarAndReloadRowWithIndexPath:indexPath];
            }
        }
        else{
            if([[selectedData objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Join the group to be able to see Skoop replies." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
            else
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Join the group to be able to reply to Skoop requests." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        //add code here for when you hit delete
        selectedIndex = indexPath.row;
        [AppHelper showAlertViewWithTag:105 title:AppName message:@"Are you sure you want to delete this skoop request?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
    }
}


-(void)reloadTableviewAfterDelayWithIndexPath:(NSIndexPath*)indexPath
{
    [self._uiTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark-CollectionViewDelegates

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.groupMembersArray count];
}

// The cell that is returned must be retrieved from a call to -dequeueReusableCellWithReuseIdentifier:forIndexPath:
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    UICollectionViewCell *cell =[collectionView dequeueReusableCellWithReuseIdentifier:@"cellId" forIndexPath:indexPath];
    cell.backgroundColor = [UIColor clearColor];
    
    UIImageView *imageViewUser = (UIImageView *)[cell.contentView viewWithTag:102];
    
    if([self.ownerId isEqualToString:[AppHelper userDefaultsForKey:KUserId]] && ![[[self.groupMembersArray objectAtIndex:indexPath.row] valueForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]]){
        
        UILongPressGestureRecognizer *gestureRecognizer = [[UILongPressGestureRecognizer alloc] init];
        [gestureRecognizer addTarget:self action:@selector(imgLongPressed:)];
        gestureRecognizer.delegate = self;
        imageViewUser.userInteractionEnabled=YES;
        [imageViewUser addGestureRecognizer: gestureRecognizer];
    }
    else{
     
        for (UIGestureRecognizer *recognizer in imageViewUser.gestureRecognizers) {
            [imageViewUser removeGestureRecognizer:recognizer];
        }
    }
    
    CBAutoScrollLabel *lblGroupName=(CBAutoScrollLabel*)[cell.contentView viewWithTag:103];
    [lblGroupName setLabelSettingForObject:@"name"];
    [AppHelper getRoundedRectImageWithImageView:imageViewUser withColor:[UIColor clearColor] andRadius:imageViewUser.frame.size.width/2.0 andWidth:0.0];
    
    imageViewUser.hidden = NO;
    if([[[self.groupMembersArray objectAtIndex:indexPath.row] valueForKey:@"image"] length]>0){
        [imageViewUser setImageWithURL:[NSURL URLWithString:[[self.groupMembersArray objectAtIndex:indexPath.row] valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    }
    else{
        imageViewUser.image=[UIImage imageNamed:@"defaultuser.png"];
    }
    
    lblGroupName.text=[[self.groupMembersArray objectAtIndex:indexPath.row] valueForKey:@"name"];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dataDict=[self.groupMembersArray objectAtIndex:indexPath.row];
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}


#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"%i",buttonIndex);
    if(alertView.tag==101){
        
        if(buttonIndex==0){
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidUnJoinTheGroup:) name:Notification_For_UnJoinGroup object:nil];
            [[WebServicesController WebServiceMethod] unJoinGroupWithUserId:[AppHelper userDefaultsForKey:KUserId] andGroupId:self.groupId];
        }
    }
    else if(alertView.tag==102){
        
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if(alertView.tag==103){
        
        if(buttonIndex==0){
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidBlockFromGroup:) name:Notification_Block_User_From_Group object:nil];
            [[WebServicesController WebServiceMethod] blockUserFromGroupWithUserId:[AppHelper userDefaultsForKey:KUserId] blockUserId:[selectedGroupMemberDataDict valueForKey:@"user_id"] groupId:self.groupId andReason:@"Block this user"];
        }
        else
            [_collectionView reloadData];
    }
    else if(alertView.tag==104){
        
        if(buttonIndex==1){
            
            NSMutableDictionary *dataDict=[NSMutableDictionary dictionaryWithDictionary:[arrayForCurrentScoops objectAtIndex:selectedIndex]];
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnLivePortalRequest:) name:Notification_Reply_LivePortal_Req object:nil];
            [[WebServicesController WebServiceMethod] replyOnLivePortalRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] requestId:[dataDict valueForKey:@"skoop_id"] andAppToken:KAppToken];
            
//            CallViewController *callViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"CallViewController"];
//            [self.navigationController pushViewController:callViewController animated:YES];
        }
    }
    else if(alertView.tag==105){
        
        if(buttonIndex==0){
            
            NSDictionary *dataDict;
            if(requestType == CurrentSkoop)
                dataDict=[arrayForCurrentScoops objectAtIndex:selectedIndex];
            else
                dataDict=[arrayForFutureScoops objectAtIndex:selectedIndex];
                        
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidDeleteSkoop:) name:Notification_Delete_Skoop object:nil];
            if([[dataDict objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]]){
                
                [[WebServicesController WebServiceMethod] deleteSkoopRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:[dataDict valueForKey:@"skoop_id"] andAppToken:KAppToken];
            }
            else{
                [[WebServicesController WebServiceMethod] deleteSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:[dataDict valueForKey:@"skoop_id"] andAppToken:KAppToken];
            }
        }
    }
}

#pragma mark Segue method
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
     if([segue.identifier isEqualToString:@"invite_link"]){
         
        SendRequestVC *sendReq=segue.destinationViewController;
        sendReq.groupId=self.groupId;
        sendReq.groupName=self.name;
    }
    else if([segue.identifier isEqualToString:@"sendskoop"]){
        
        SendGroupSkoop *sendSkoop=segue.destinationViewController;
        sendSkoop.groupId=self.groupId;
        sendSkoop.deligate=self;
        NSDictionary *groupDict=[[NSDictionary alloc] initWithObjectsAndKeys:self.grpName.text,@"group_name",self.groupId,@"group_id", nil];
        sendSkoop.selectedGroup=groupDict;
    }
    else  if([segue.identifier isEqual:@"goforreply"]){
        
        NSDictionary *dataDict=(NSDictionary*)sender;        
        VideoUploaderVC *videoObj=segue.destinationViewController;
        videoObj.videoLoaderDelegate=self;
        videoObj.skoopId=[dataDict valueForKey:@"skoop_id"];
        videoObj.isUploadVideoForGroup = isUploadVideoForGroup;
        videoObj.groupId = self.groupId;
    }
    else  if([segue.identifier isEqual:@"seeskoopreply"]){
        
        NSMutableDictionary *dataDict=[NSMutableDictionary dictionaryWithDictionary:(NSDictionary*)sender];
        [dataDict setValue:self.name forKey:@"group_name"];
        CellSelectionView *cellselectionobj=segue.destinationViewController;
        cellselectionobj.getInfoRequest=dataDict;
    }
    else if([segue.identifier isEqualToString:@"seeAll_link"]){
        
        IndividualGroupVC *groupObj=(IndividualGroupVC*)segue.destinationViewController;
        groupObj.groupName=self.grpName.text;
        groupObj.groupId=self.groupId;
    }
    else if([segue.identifier isEqualToString:@"userprofile"]){
        
        NSDictionary *dataDict=(NSDictionary*)sender;
        UserProfileVC *userProfileObj=segue.destinationViewController;
        userProfileObj.groupId=self.groupId;
        userProfileObj.groupOwnerId=self.ownerId;
        
        if(isShowReplierProfile){
            
            userProfileObj.name=[[dataDict valueForKey:@"reply"] valueForKey:@"name"];
            userProfileObj.imgUrl=[[dataDict valueForKey:@"reply"] valueForKey:@"image"];
            userProfileObj.blockUserId=[AppHelper userDefaultsForKey:KUserId];
        }
        else{
            
            userProfileObj.name=[dataDict valueForKey:@"name"];
            userProfileObj.imgUrl=[dataDict valueForKey:@"image"];
            userProfileObj.blockUserId=[dataDict valueForKey:@"user_id"];
        }
    }
    else if([segue.identifier isEqualToString:@"editgroup"]){
        
        NSMutableDictionary *groupDataDict=[[NSMutableDictionary alloc] init];
        [groupDataDict setValue:self.name forKey:@"group_name"];
        [groupDataDict setValue:self.groupId forKey:@"group_id"];
        
        if(self.imgUrl && [self.imgUrl length]>0)
            [groupDataDict setValue:self.grpImage.image forKey:@"cover_image"];
        if(self.groupImageUrl && [self.groupImageUrl length]>0)
            [groupDataDict setValue:self._imgGroupImage.image forKey:@"group_image"];
        
        [groupDataDict setValue:self.groupDescription forKey:@"group_description"];
        [groupDataDict setValue:self.categoryName forKey:@"category_name"];
        [groupDataDict setValue:self.categoryId forKey:@"category_id"];
        [groupDataDict setValue:self.groupType forKey:@"group_type"];
        [groupDataDict setValue:self.prEmail forKey:@"pr_email"];
        
        CreateGroupVC *creatGroup=segue.destinationViewController;
        creatGroup.deligate=self;
        creatGroup.groupDescription=groupDataDict;
        creatGroup.isEditGroup=YES;
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
