//
//  CallViewController.m
//  youskoop
//
//  Created by My Star on 11/18/15.
//  Copyright © 2015 user. All rights reserved.
//

#import "CallViewController.h"
#import "Defines.h"

@interface CallViewController ()<ooVooAVChatDelegate, ooVooVideoControllerDelegate>{


    IBOutlet UIImageView *imgViewOpponent;
    IBOutlet UILabel *lblOpponent;
    
    IBOutlet UILabel *lblCallTime;
    IBOutlet UIButton *btnDecline;
    
    IBOutlet ooVooVideoPanel *viewOpponentVideo;
    IBOutlet ooVooVideoPanel *viewMyVideo;
    
    int collapsedSeconds;
    
}

@end

@implementation CallViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    viewMyVideo.hidden = YES;
    viewOpponentVideo.hidden = YES;
    
    self.sdk = [ooVooClient sharedInstance];
    
    self.sdk.AVChat.delegate = self;
    self.sdk.AVChat.VideoController.delegate = self;
   
    [self createPanel];
    
    
    imgViewOpponent.layer.cornerRadius = imgViewOpponent.frame.size.width / 2.0;
    
    dispatch_async(dispatch_get_global_queue(0,0), ^{
        NSData * data = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString:_opponentUserImgUrl]];
        if ( data == nil )
            return;
        dispatch_async(dispatch_get_main_queue(), ^{
            [imgViewOpponent setImage:[UIImage imageWithData: data]];
        });
    });
    
    lblOpponent.text = _opponentUsername;
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)onClickDeclineButton:(id)sender {
    
    [self leaveSession];
    
    
    [self dismissViewControllerAnimated:YES completion:nil];
}

-(void)ooVooAuthorization{
    
    [[ooVooClient sharedInstance] authorizeClient:ooVooToken
                                       completion:^(SdkResult *result) {
                                           if (result.Result == sdk_error_OK)
                                           {
                                               NSLog(@"Good Authorization");
                                               [self ooVooLogin];
                                           }
                                           else
                                           {
                                               NSLog(@"Failed Authorization - Check your ooVoo token !");
                                               
                                           }
                                       }];
}

-(void)ooVooLogin{
    NSString *strVideoUserId = [NSString stringWithFormat:@"skoop_user%@", [AppHelper userDefaultsForKey:KUserId]];
    NSLog(@"userId = %@", strVideoUserId);
    
    [self.sdk.Account login:strVideoUserId
            completion:^(SdkResult *result) {
                
                //[spinner stopAnimating];
                //spinner.hidden = YES;
                //[backView removeFromSuperview];
                
                if (result.Result == sdk_error_OK)
                {
                    NSLog(@"ooVoo Login Success");
                    
                    [self.sdk.Messaging connect];
                    
                    [self createPanel];
                }
                else
                {
                    UIAlertView *alert =[[UIAlertView alloc] initWithTitle:@"Login Error" message:result.description delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
                    [alert show];
                }
            }];
}

- (void)setBackCamera{
    
    NSArray *arr_dev = [_sdk.AVChat.VideoController getDevicesList];
    NSString *deviceId = ((id<ooVooDevice>)[arr_dev objectAtIndex:0]).deviceID;
    [_sdk.AVChat.VideoController setConfig:deviceId forKey:ooVooVideoControllerConfigKeyCaptureDeviceId];
}

- (void)setResolution{
    
    [_sdk.AVChat.VideoController setConfig:@"4" forKey:ooVooVideoControllerConfigKeyResolution];
}

-(void)createPanel{
    
//    [self.sdk.AVChat.VideoController bindVideoRender:nil/*[ActiveUserManager activeUser].userId*/ render:viewMyVideo];
//    [self.sdk.AVChat.VideoController openCamera];
    
    [self.sdk.AVChat.AudioController initAudio:^(SdkResult *result) {
        //[self.sdk.AVChat.VideoController setConfig:currentRes forKey:ooVooVideoControllerConfigKeyResolution];
        
        //if([self currentEffect])
        //  [self.sdk.AVChat.VideoController setConfig:[self currentEffect] forKey:ooVooVideoControllerConfigKeyEffectId];
        
        NSLog(@"result %d description %@", result.Result, result.description);
        
        [self.sdk updateConfig:^(SdkResult *result){
            //NSString *displayName = [[ActiveUserManager activeUser].displayName length] > 0 ? [ActiveUserManager activeUser].displayName : [ActiveUserManager activeUser].userId;
            //[self.sdk.AVChat.VideoController startTransmitVideo];
            [self.sdk.AVChat join:_conferenceId user_data:@"Great!"];
            
            //viewMyVideo.hidden = NO;
            
        }];
    }];
    
}

- (void)didParticipantJoin:(id<ooVooParticipant>)participant user_data:(NSString *)user_data{
    
    viewOpponentVideo.hidden = NO;
    [self.sdk.AVChat.VideoController registerRemoteVideo:participant.participantID];
    [self.sdk.AVChat.VideoController bindVideoRender:participant.participantID render:viewOpponentVideo];
    
    collapsedSeconds = 0;
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:1.0 target:self selector:@selector(onTimer) userInfo:nil repeats:YES];
    
}

- (void)onTimer{
    
    collapsedSeconds++;
    int displaySeconds = collapsedSeconds - ooVooBlankTime;
    if (displaySeconds > 0) {
        double seconds = fmod(displaySeconds, 60.0);
        double minutes = fmod(trunc(displaySeconds / 60.0), 60.0);
        //double hours = trunc(displaySeconds / 3600.0);
        lblCallTime.text = [NSString stringWithFormat:@"%02.0f : %02.0f", minutes, seconds];
    }
    
}

- (void)didConferenceStateChange:(ooVooAVChatState)state error:(sdk_error)code{
    if (state == ooVooAVChatStateJoined && code == sdk_error_OK)
    {
        [UIApplication sharedApplication].idleTimerDisabled = (code == sdk_error_OK);
        [self.sdk.AVChat.AudioController setRecordMuted:NO];
        [self.sdk.AVChat.AudioController setPlaybackMute:NO];
        
    }
    else if (state == ooVooAVChatStateJoined || state == ooVooAVChatStateDisconnected)
    {
        if (state == ooVooAVChatStateJoined && code != sdk_error_OK)
        {
            //UIAlertView *alert =  [[UIAlertView alloc] initWithTitle:@"Join Error" message:[VideoConferenceVC getErrorDescription:code] delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil, nil];
            //[alert show];
        }
        
        if (state == ooVooAVChatStateDisconnected)
        {
            // currentRes = defaultRes;
            // [self animateViewsForState:true]; // return to first view ....
            
            
            // _isViewInTransmitMode = false;
            //[self resetAll];
            //[self refreshScrollViewContentSize];
            
            
            [self.sdk.AVChat.VideoController bindVideoRender:nil/*[ActiveUserManager activeUser].userId*/ render:viewMyVideo];
            //  [self.sdk.AVChat.VideoController setConfig:self.defaultCameraId forKey:ooVooVideoControllerConfigKeyCaptureDeviceId];
            [self.sdk.AVChat.VideoController openCamera];
        }
        
        [UIApplication sharedApplication].idleTimerDisabled = NO;
        // [self resetAndShowNavigationBarbuttons:NO];
    }
}

- (void)didNetworkReliabilityChange:(NSNumber*)score{
    NSLog(@"Reliability = %@",score);
    //[InternetActivityView setInternetActivityLevel:score];
}

- (void)didReceiveData:(NSString *)uid data:(NSData *)data {
}

- (void)didParticipantLeave:(id<ooVooParticipant>)participant{
    
    viewOpponentVideo.hidden = YES;
    viewMyVideo.hidden = YES;
    //btnAnswer.hidden = NO;
    
//    [self.sdk.AVChat.VideoController unbindVideoRender: participant.participantID render:viewOpponentVideo];
//    [self.sdk.AVChat.VideoController unRegisterRemoteVideo:participant.participantID];
    
    [self leaveSession];
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (void)didConferenceError:(sdk_error)code{
    
}




- (void)didRemoteVideoStateChange:(NSString *)uid state:(ooVooAVChatRemoteVideoState)state width:(const int)width height:(const int)height error:(sdk_error)code{
    
}


- (void)didCameraStateChange:(ooVooDeviceState)state devId:(NSString *)devId width:(const int)width height:(const int)height fps:(const int)fps error:(sdk_error)code{
    
}


- (void)didVideoTransmitStateChange:(BOOL)state devId:(NSString *)devId error:(sdk_error)code{
    
}


- (void)didVideoPreviewStateChange:(BOOL)state devId:(NSString *)devId error:(sdk_error)code{
    
}

-(void)leaveSession{
    //    [participants removeAllObjects];
    
    //[self.sdk.AVChat.VideoController closeCamera];
    [self.sdk.AVChat.VideoController unbindVideoRender:nil render:viewOpponentVideo];
    [self.sdk.AVChat leave];
    
    //[self.sdk.Messaging disconnect];
    //[self.sdk.Account logout];
    
    
    [self.sdk.AVChat.AudioController unInitAudio:^(SdkResult *result) {
        NSLog(@"unInit Resoult %d",result.Result);
        //[self dismissViewControllerAnimated:YES completion:nil];
    }];
}





-(void) didSecurityState:(bool) is_secure{
//    for (UIBarButtonItem *btn in self.navigationItem.rightBarButtonItems) {
//        if (btn.tag==200) // it's the lock image on navigation bar
//        {
//            [btn setImage:is_secure?[UIImage imageNamed:@"Lock"]:[UIImage imageNamed:@"Unlock"] ];
//            
//        }
//    }
}

@end
