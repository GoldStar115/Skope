//
//  GroupProfileVC.h
//  youskoop
//
//  Created by Richika_Golchha on 5/8/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "VideoUploaderVC.h"
#import "SendGroupSkoop.h"
#import "CreateGroupVC.h"



@protocol updateMyGroupListProtocol <NSObject>
-(void)updateMyGroupList;
@optional
-(void)markAsReadNotification;
-(void)addJoinedGroupIntoList;
@end

@interface GroupProfileVC : UIViewController<upDateSkoopListDeligate,saveDataProtocol,updateGroupProfileProtocol,UIGestureRecognizerDelegate>{
    id<updateMyGroupListProtocol> updateListProtocol;
}
@property (retain) id<updateMyGroupListProtocol> updateListProtocol;
@property BOOL isFromNotification;
@property (nonatomic, strong)NSString *reqType;

@property (weak, nonatomic) IBOutlet UITableView *_uiTableView;

@property (strong, nonatomic) NSString *groupImageUrl;
@property (strong, nonatomic) IBOutlet UIImageView *grpImage;
@property (strong, nonatomic) IBOutlet UIImageView *_imgGroupImage;

@property (strong, nonatomic) IBOutlet UILabel *grpName;
@property (weak, nonatomic) IBOutlet UILabel *_lblGroupDescription;
@property (strong,nonatomic) NSString *name;
@property (strong,nonatomic) NSString *groupDescription;
@property (strong,nonatomic) NSString *imgUrl;
@property (strong,nonatomic) NSString *coverImageUrl;
@property (strong,nonatomic) NSString *groupId;
@property (strong,nonatomic) NSString *categoryName;
@property (strong,nonatomic) NSString *categoryId;
@property (strong,nonatomic) NSString *prEmail;
@property (strong, nonatomic) NSString *groupType;
@property (strong, nonatomic) NSString *ownerId;
@property (strong, nonatomic) NSString *skoopId;
@property (strong, nonatomic) NSString *groupStatus;
@property (strong, nonatomic) NSMutableDictionary *grpDescriptionDict;
@property BOOL isFromMyGroupClass;



-(IBAction)onClickEditGroupButton:(id)sender;
- (IBAction)unjoinGrpAction:(id)sender;
- (IBAction)inviteFriendsAction:(id)sender;
- (IBAction)sendRequestAction:(id)sender;
- (IBAction)onClickSkoopRequestType:(id)sender;
- (IBAction)onClickSeeAllButton:(id)sender;
- (IBAction)backAction:(id)sender;

@end
