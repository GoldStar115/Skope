//
//  SendGroupSkoop.m
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "SendGroupSkoop.h"
#import "MapKit/MapKit.h"
#import "SBJson.h"
#import "CLController.h"
#import "AnnotationClass.h"
#import "WebServicesController.h"
///////
#import "TRAutocompleteView.h"
#import "TRGoogleMapsAutocompleteItemsSource.h"
#import "TRTextFieldExtensions.h"
#import "TRGoogleMapsAutocompletionCellFactory.h"
#import "AppHelper.h"
#import "NSDate+convenience.h"
#import "SliderSwitch.h"

@interface SendGroupSkoop ()<SliderSwitchDelegate>{
    __weak IBOutlet UILabel *_lblGroupName;
    __weak IBOutlet UIPickerView *_pickerView;
    __weak IBOutlet UIView *_viewForPicker;
    
    __weak IBOutlet UILabel *_lblCallCharge;
    __weak IBOutlet UILabel *_lblSkoopPrice2;
    __weak IBOutlet UILabel *_lblSkoopPrice1;
    __weak IBOutlet UILabel *_lblPrice;
    __weak IBOutlet UIView *_viewOffer;
    __weak IBOutlet UIView *_viewPrice;
    
    __weak IBOutlet UIImageView *_imgShowMe;
    __weak IBOutlet UIButton *_btnFutureSkoop;
    __weak IBOutlet UIView *_viewLivePortal;
    __weak IBOutlet UILabel *_lblStaticGrpName;
    __weak IBOutlet UIButton *_btnSelectGroup;
    __weak IBOutlet UIImageView *_imgSelectGroup;
    
    __weak IBOutlet UILabel *_lblYourOffer;
    __weak IBOutlet UIButton *_btnInfo;
    
    __weak IBOutlet UIButton *_btnSendReq;
    __weak IBOutlet UIImageView *_imgFutureSkoop;
    double locationLatitude;
    double locationLongitude;
    id countofusers;
    int selectedGroupIndex;
    BOOL isLongPress;
    NSInteger selectedSwitchIndex;
}
@property (strong, nonatomic) NSArray *groupNameArray;
@property (weak, nonatomic) IBOutlet UITextField *_showMeTxt;

@property (weak, nonatomic) IBOutlet UIDatePicker *_futureDate;
@property (weak, nonatomic) IBOutlet UIView *_viewForDatePicker;
@property (weak, nonatomic) IBOutlet UILabel *futureLb;

- (IBAction)_sendRequestBtnClick:(id)sender;
- (IBAction)backBtnClick:(id)sender;
- (IBAction)checkBocBtnClick:(id)sender;
- (IBAction)cancelDatePickerclick:(id)sender;
- (IBAction)doneDatePickerClick:(id)sender;

@end

@implementation SendGroupSkoop
@synthesize deligate;
@synthesize groupId;
@synthesize selectedGroup;
@synthesize isSaveSendSkoop;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    
    //Manage spacing
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
        
        //Manage views for iPhone5
//        CGRect frameRect=_imgShowMe.frame;
//        frameRect.origin.y+=20;
//        _imgShowMe.frame=frameRect;
//        frameRect=self._showMeTxt.frame;
//        frameRect.origin.y+=20;
//        self._showMeTxt.frame=frameRect;
//        
//        frameRect=_imgFutureSkoop.frame;
//        frameRect.origin.y+=25;
//        _imgFutureSkoop.frame=frameRect;
//        
//        frameRect=self.futureLb.frame;
//        frameRect.origin.y+=25;
//        self.futureLb.frame=frameRect;
//        
//        frameRect=_btnFutureSkoop.frame;
//        frameRect.origin.y+=25;
//        _btnFutureSkoop.frame=frameRect;
//        
//        frameRect=_viewLivePortal.frame;
//        frameRect.origin.y+=30;
//        _viewLivePortal.frame=frameRect;
//        
//        frameRect=_viewOffer.frame;
//        frameRect.origin.y+=35;
//        _viewOffer.frame=frameRect;
//        
//        frameRect=_viewPrice.frame;
//        frameRect.origin.y+=35;
//        _viewPrice.frame=frameRect;
//        
//        frameRect=_lblStaticGrpName.frame;
//        frameRect.origin.y+=40;
//        _lblStaticGrpName.frame=frameRect;
//        
//        frameRect=_lblGroupName.frame;
//        frameRect.origin.y+=40;
//        _lblGroupName.frame=frameRect;
//        
//        frameRect=_imgSelectGroup.frame;
//        frameRect.origin.y+=40;
//        _imgSelectGroup.frame=frameRect;
//        
//        frameRect=_btnSelectGroup.frame;
//        frameRect.origin.y+=40;
//        _btnSelectGroup.frame=frameRect;
//        
//        frameRect=_btnSendReq.frame;
//        frameRect.origin.y+=50;
//        _btnSendReq.frame=frameRect;
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    if([self.selectedGroup valueForKey:@"group_name"])
        _lblGroupName.text=[self.selectedGroup valueForKey:@"group_name"];
    selectedGroupIndex=-1;
    
    CGRect frameRect=self._viewForDatePicker.frame;
    frameRect.origin.y=568;
    
    UILabel *lblYourOffer=(UILabel*)[self.view viewWithTag:1];
    lblYourOffer.textColor=[UIColor colorWithRed:12.0/255.0 green:34.0/255.0 blue:96.0/255.0 alpha:1.0];
    _lblPrice.textColor=[UIColor colorWithRed:12.0/255.0 green:34.0/255.0 blue:96.0/255.0 alpha:1.0];
    
    UILabel *lblGroupName=(UILabel*)[self.view viewWithTag:500];
    lblGroupName.textColor=[UIColor colorWithRed:12.0/255.0 green:34.0/255.0 blue:96.0/255.0 alpha:1.0];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(goesToRootView) name:Notification_Send_to_tab_root object:nil];
    
    self._viewForDatePicker.hidden=YES;
    _btnInfo.hidden = YES;//Hide info button
    
    UIButton *radiobutton1 = (UIButton*)[self.view viewWithTag:101];
    radiobutton1.selected = YES;
    
    _viewPrice.hidden=YES;
    
    [self performSelector:@selector(getGroupNameListData) withObject:nil afterDelay:0.5];
    
    //Add custom switch view
    SliderSwitch *slideSwitchH=[[SliderSwitch alloc] init];
    [slideSwitchH setFrameHorizontal:(CGRectMake(57, 4, 200, 30)) numberOfFields:2 withCornerRadius:1.0];
    //240/3=80
    //width of each option is 80 (It should not be a fractional value)
    slideSwitchH.delegate=self;
    [slideSwitchH setFrameBackgroundColor:[UIColor clearColor]];
    [slideSwitchH setSwitchFrameColor:[UIColor clearColor]];
    UIView *sliderView=(UIView*)[self.view viewWithTag:567];
    [sliderView addSubview:slideSwitchH];
    selectedSwitchIndex=0;
}

-(void)viewWillAppear:(BOOL)animated{
    //Set skoop and love portal call price
    NSDictionary *priceDict = [AppHelper userDefaultsDictionaryDataForKey:KPriceData];
    _lblCallCharge.text = [NSString stringWithFormat:@"$%@/2 hours",[priceDict valueForKey:@"live_charge"]];
    _lblSkoopPrice1.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"skoop_charge1"]];
    _lblSkoopPrice2.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"skoop_charge2"]];
    
    //Hide tabbar
    [[AppDelegate getAppDelegate] hideTabBar:self.tabBarController];
}

-(void)viewWillDisappear:(BOOL)animated{
    //Show tabbar
    [[AppDelegate getAppDelegate] showTabBar:self.tabBarController];
}

#pragma mark - Slider Switch Delegate Methods

-(void)switchChangedSliderSwitch:(SliderSwitch *)sliderSwitch{
    
    NSDictionary *priceDict = [AppHelper userDefaultsDictionaryDataForKey:KPriceData];
    if (sliderSwitch.selectedIndex==0){//Select skoop switch
        if(selectedSwitchIndex==1){
            selectedSwitchIndex=0;
            //            _viewPrice.hidden=YES;
            //            _viewOffer.hidden=NO;
            
            _lblSkoopPrice1.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"skoop_charge1"]];
            _lblSkoopPrice2.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"skoop_charge2"]];
            _lblYourOffer.text = @"Your skoop offer";
            _btnInfo.hidden = YES;
            
//            UIButton *btnCalendar=(UIButton*)[self.view viewWithTag:179];
//            btnCalendar.userInteractionEnabled=YES;
        }
    }
    else if (sliderSwitch.selectedIndex==1){//Select live portal switch
        if(selectedSwitchIndex==0){
            selectedSwitchIndex=1;
            //            _viewOffer.hidden=YES;
            //            _viewPrice.hidden=NO;
            
            _lblSkoopPrice1.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"live_charge1"]];
            _lblSkoopPrice2.text = [NSString stringWithFormat:@"$%@",[priceDict valueForKey:@"live_charge2"]];
            _lblYourOffer.text = @"Your live portal offer";
            _btnInfo.hidden = NO;
            
//            UIButton *btnCalendar=(UIButton*)[self.view viewWithTag:179];
//            btnCalendar.userInteractionEnabled=NO;
        }
    }
}

#pragma Other methods
-(void)getGroupNameListData{
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetGroupNameList:) name: Notification_For_GetGroupList object:nil];
    [[WebServicesController WebServiceMethod] getMyGroupDataWithUserId:[AppHelper userDefaultsForKey:KUserId] SearchString:@"" pageNumber:@"1" limit:@"100" exGroupId:@"" inviteUserId:@"0" andIsGetNameList:YES];
}

-(void)goesToRootView{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Send_to_tab_root object:nil];
    [self.navigationController popToRootViewControllerAnimated:NO];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(goesToRootView) name:Notification_Send_to_tab_root object:nil];
}

-(void)valueChanged{
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init] ;
    [dateFormatter setDateStyle:NSDateFormatterLongStyle];
    [dateFormatter setTimeStyle:NSDateFormatterNoStyle];
    [dateFormatter setDateFormat:@"dd/MM/yyyy hh:mm a"];
    self.futureLb.text=[dateFormatter stringFromDate:[self._futureDate date]];
    self._viewForDatePicker.hidden=YES;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    NSLog(@"touch detect");
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    //Check date picker view and remove it
    if (touch.view.tag == 346) {
        [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionTransitionNone
                         animations:^{
                             CGRect frameRect = self._viewForDatePicker.frame;
                             frameRect.origin.y = self.view.bounds.size.height;
                             self._viewForDatePicker.frame = frameRect;
                         }
                         completion:nil];
    }
    
    
    if([self._showMeTxt isFirstResponder])
        [self._showMeTxt resignFirstResponder];
}

-(BOOL)checkMandatoryField{
    
    if([self._showMeTxt.text isEqualToString:@""]){
        [AppHelper showAlertViewWithTag:1 title:nil message:@"Oops :) Please tell us what you want to see." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        return FALSE;
    }
    else if([_lblGroupName.text isEqualToString:@"Select group"]){
        [AppHelper showAlertViewWithTag:1 title:nil message:@"Please choose group." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        return FALSE;
    }
    return TRUE;
}

#pragma mark Textfield deligate methods
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField{
    
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range     replacementString:(NSString *)string{
    
    if (range.location == 0 && [string isEqualToString:@" "])
        return NO;
    
    return YES;
}

-(BOOL)textFieldShouldClear:(UITextField *)textField{
    return YES;
}

#pragma mark-pickerViewDelegates

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [self.groupNameArray count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    return [[self.groupNameArray objectAtIndex:row] objectForKey:@"group_name"];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    _lblGroupName.text=[[self.groupNameArray objectAtIndex:row] valueForKey:@"group_name"];
    self.selectedGroup=[self.groupNameArray objectAtIndex:row];
}


#pragma mark Button action methods

- (IBAction)_sendRequestBtnClick:(id)sender{
    
    if([self._showMeTxt isFirstResponder])
        [self._showMeTxt resignFirstResponder];
    
    if([self checkMandatoryField]){
        
        UIButton *radiobutton1 = (UIButton*)[self.view viewWithTag:101];//0.0
        UIButton *radiobutton2 = (UIButton*)[self.view viewWithTag:102];//0.99
        UIButton *radiobutton3 = (UIButton*)[self.view viewWithTag:103];//9.99
        
        NSDictionary *priceDict = [AppHelper userDefaultsDictionaryDataForKey:KPriceData];
        
        NSString *offer = nil;
        if(radiobutton1.isSelected)
            offer = @"0";
        else if(radiobutton2.isSelected && selectedSwitchIndex == 0)
            offer = [NSString stringWithFormat:@"%.2f",[[priceDict valueForKey:@"skoop_charge1"] floatValue]];
        else if(radiobutton2.isSelected && selectedSwitchIndex == 1)
            offer = [NSString stringWithFormat:@"%.2f",[[priceDict valueForKey:@"live_charge1"] floatValue]];
        else if(radiobutton3.isSelected && selectedSwitchIndex == 0)
            offer = [NSString stringWithFormat:@"%.2f",[[priceDict valueForKey:@"skoop_charge2"] floatValue]];
        else if(radiobutton3.isSelected && selectedSwitchIndex == 1)
            offer = [NSString stringWithFormat:@"%.2f",[[priceDict valueForKey:@"live_charge2"] floatValue]];
        
        NSString *skoopdate = nil;
        NSTimeInterval timeDiff = 0;
        if([self.futureLb.text isEqualToString:@"Future Skoop?"]){
            skoopdate = [AppHelper getGmtDateWithGivenDate:[NSDate date]];
        }
        else{
            skoopdate = [AppHelper getGmtDateWithGivenDate:[self._futureDate date]];
            timeDiff = [[self._futureDate date] timeIntervalSinceNow];
        }
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidSendGroupSkoop:) name:Notification_for_Group_Skoop_Request object:nil];
        
        if(timeDiff >= 60){//Future skoop
            [[WebServicesController WebServiceMethod] sendGroupSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] groupId:[self.selectedGroup valueForKey:@"group_id"] skoopDate:skoopdate offer:offer searchText:self._showMeTxt.text token:KAppToken livePortal:[NSString stringWithFormat:@"%i",(int)selectedSwitchIndex] andSkoopType:@"1"];
        }
        else{//current skoop
            [[WebServicesController WebServiceMethod] sendGroupSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] groupId:[self.selectedGroup valueForKey:@"group_id"] skoopDate:skoopdate offer:offer searchText:self._showMeTxt.text token:KAppToken livePortal:[NSString stringWithFormat:@"%i",(int)selectedSwitchIndex] andSkoopType:@"0"];
        }
    }
}

-(IBAction)onClickSelectGroupButton:(id)sender{
    if(self.groupNameArray.count>0){
        [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                         animations:^{
                             CGRect frameRect=self.view.bounds;
                             frameRect.origin.y=0;
                             _viewForPicker.frame=frameRect;
                         }
                         completion:nil];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have not create any group yet." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
    
}
//Back button action
- (IBAction)backBtnClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnCalender:(id)sender{
    self._futureDate.minimumDate = [NSDate date];
    [self._showMeTxt resignFirstResponder];
    self._viewForDatePicker.hidden=NO;
    
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect=self.view.bounds;
                         frameRect.origin.y=0;
                         self._viewForDatePicker.frame=frameRect;
                     }
                     completion:nil];
    
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *currentDate = [NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setYear:30];
    NSDate *maxDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
    self._futureDate.maximumDate = maxDate;
    
    NSDateFormatter  *fomrtr = [[NSDateFormatter alloc] init] ;
    [fomrtr setDateFormat:@"dd/MM/yyyy hh:mm a"];
    self._futureDate.date=[NSDate date];
    
}

- (IBAction)cancelDatePickerclick:(id)sender
{
    [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect = self._viewForDatePicker.frame;
                         frameRect.origin.y = self.view.bounds.size.height;
                         self._viewForDatePicker.frame = frameRect;
                     }
                     completion:nil];
    self.futureLb.text = @"Future Skoop?";
}

- (IBAction)doneDatePickerClick:(id)sender
{
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init] ;
    [dateFormatter setDateFormat:@"MM-dd-yyyy hh:mm a"];
    
    self.futureLb.text=[dateFormatter stringFromDate:[self._futureDate date]];
    
    [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect = self._viewForDatePicker.frame;
                         frameRect.origin.y = self.view.bounds.size.height;
                         self._viewForDatePicker.frame = frameRect;
                     }
                     completion:nil];
}

- (IBAction)cancelPickerclick:(id)sender
{
    if(selectedGroupIndex>=0)
        self.selectedGroup=[self.groupNameArray objectAtIndex:selectedGroupIndex];
    if([self.selectedGroup objectForKey:@"group_name"])
        _lblGroupName.text=[self.selectedGroup objectForKey:@"group_name"];
    
    [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect = _viewForPicker.frame;
                         frameRect.origin.y = self.view.bounds.size.height;
                         _viewForPicker.frame = frameRect;
                     }
                     completion:nil];
}

- (IBAction)donePickerClick:(id)sender
{
    selectedGroupIndex = (int)[self.groupNameArray indexOfObject:self.selectedGroup];
    
    [UIView animateWithDuration:0.3f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect = _viewForPicker.frame;
                         frameRect.origin.y = self.view.bounds.size.height;
                         _viewForPicker.frame = frameRect;
                     }
                     completion:nil];
}

-(void)checkBocBtnClick:(id)sender{
    
    UIButton *radiobutton1 = (UIButton*)[self.view viewWithTag:101];//0.0
    UIButton *radiobutton2 = (UIButton*)[self.view viewWithTag:102];//0.99
    UIButton *radiobutton3 = (UIButton*)[self.view viewWithTag:103];//9.99
    UIButton *selectedButton = (UIButton *)sender;
    
    switch ([selectedButton tag]) {
        case 101:
            if([radiobutton1 isSelected]){
                [radiobutton1 setSelected:NO];
                [radiobutton2 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            else{
                [radiobutton1 setSelected:YES];
                [radiobutton2 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            break;
        case 102:
            if([radiobutton2 isSelected]==YES){
                [radiobutton1 setSelected:NO];
                [radiobutton2 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            else{
                [radiobutton2 setSelected:YES];
                [radiobutton1 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            break;
        case 103:
            if([radiobutton3 isSelected]==YES){
                [radiobutton1 setSelected:NO];
                [radiobutton2 setSelected:NO];
                [radiobutton3 setSelected:NO];
            }
            else{
                [radiobutton3 setSelected:YES];
                [radiobutton2 setSelected:NO];
                [radiobutton1 setSelected:NO];
            }
            break;
        default:
            break;
    }
    
    if(!([radiobutton1 isSelected]==YES || [radiobutton2 isSelected]==YES || [radiobutton3 isSelected]==YES))
        [radiobutton1 setSelected:YES];
}

-(IBAction)onClickInfoButton:(id)sender{
    [AppHelper showAlertViewWithTag:1 title:AppName message:@"1. You won’t be charged until 30 seconds into the call in case the other user is not providing what you asked for.\n\n2. If the Live Portal call should disconnect for any technical reason after you have been charged, you can call the user back with no additional charge for the next 2 hours.\n\n3. Additional data charges from your service provider may apply." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

#pragma mark Receive notification methods
-(void)userDidGetGroupNameList:(NSNotification*) notify{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_For_GetGroupList object:nil];
    if([[[notify userInfo] objectForKey:@"error_code"] intValue]==0){
        self.groupNameArray=[[notify userInfo] objectForKey:@"data"];
        [_pickerView reloadAllComponents];
//        if(self.selectedGroup)
//            [_pickerView selectRow:[self.groupNameArray indexOfObject:self.selectedGroup] inComponent:0 animated:NO];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[notify.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(void)userDidSendGroupSkoop:(NSNotification *)note{
    
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:Notification_for_Group_Skoop_Request object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Count object:nil userInfo:[NSDictionary dictionaryWithObjectsAndKeys:@"requests",@"req_type", nil]];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_Calendar object:@"refresh" userInfo:nil];
            
             if(self.groupId){
                 
                 if(([[self._futureDate date] day]==[[NSDate date] day]) && ([[self._futureDate date] month]==[[NSDate date] month]))
                      [[self deligate] updateSkoopListWithReqType:@"current" andSkoopId:[note.userInfo objectForKey:@"skoop_id"]];
                 else
                     [[self deligate] updateSkoopListWithReqType:@"future" andSkoopId:[note.userInfo objectForKey:@"skoop_id"]];
                 
                 [self.navigationController popViewControllerAnimated:YES];
             }
            else{
                
                if(!isSaveSendSkoop){
                   
                    NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[note.userInfo objectForKey:@"group_details"]];
                    if(([[self._futureDate date] day]==[[NSDate date] day]) && ([[self._futureDate date] month]==[[NSDate date] month]))
                        [dict setValue:@"current" forKey:@"skoop_type"];
                    else
                        [dict setValue:@"future" forKey:@"skoop_type"];
                    [dict setValue:[note.userInfo objectForKey:@"skoop_id"] forKey:@"skoop_id"];
                    
                    [AppHelper saveToUserDefaults:dict withKey:isSendGroupSkoop];
                }
                
                [self.navigationController popViewControllerAnimated:NO];
            }
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1){
            [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
        }
    }
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag==102){
        [self.navigationController popViewControllerAnimated:YES];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
