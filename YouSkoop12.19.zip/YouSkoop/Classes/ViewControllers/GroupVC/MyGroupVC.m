//
//  MyGroupVC.m
//  youskoop
//
//  Created by Shitesh Patel on 17/04/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "MyGroupVC.h"
#import "SendGroupSkoop.h"

@interface MyGroupVC (){
    
    NSMutableArray *myGroupArray;
    NSMutableArray * afterSearchArray;
    BOOL isSearching;
    NSString *searchText;
    NSInteger selectedGroupIndex;
    int pageNumber;
    BOOL isHitWebService;
    NSDictionary *selectedGrpDict;
}

@property (strong, nonatomic) IBOutlet UIView *_searchView;
@property (strong, nonatomic) IBOutlet UITableView *_tableView;
@property (strong, nonatomic) IBOutlet UITextField *_textField;

@end

#define PageLimit  @"30"

@implementation MyGroupVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        
        navImage.image = [UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        
        navImage.frame = CGRectMake(0, 0, 320, 44);
        navImage.image = [UIImage imageNamed:@"statusbar_6.png"];
    }
    
    if(!IS_IPHONE_5){
        
        CGRect frameRect = self._tableView.frame;
        frameRect.size.height = 306;
        self._tableView.frame = frameRect;
    }
    
    isSearching = NO;
    searchText = @"";
    
    isHitWebService = YES;
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        //Call your function or whatever work that needs to be done
        //Code in this part is run on a background thread
        pageNumber = 1;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getMyGroupData:) name:Notification_For_GetGroupList object:nil];
        [[WebServicesController WebServiceMethod] getMyGroupDataWithUserId:[AppHelper userDefaultsForKey:KUserId] SearchString:@"" pageNumber:[NSString stringWithFormat:@"%i",pageNumber] limit:PageLimit exGroupId:@"" inviteUserId:@"0" andIsGetNameList:NO];
    });
}

-(void)viewWillDisappear:(BOOL)animated{
    UIActivityIndicatorView *indicatorView = (UIActivityIndicatorView *)[self._searchView viewWithTag:1000];
    if(indicatorView)
        [indicatorView removeFromSuperview];
}

-(void)viewDidDisappear:(BOOL)animated{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_For_GetGroupList object:nil];
}

#pragma mark-GeneralMethods

-(void)getSearchDataWithText:(NSString*)string andIsShowIndicator:(BOOL)showIndicator{
    
    if(showIndicator){
        
        [AppDelegate dismissGlobalHUD];
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    }
    else{
        
        UIImageView *imgView = (UIImageView*)[self._searchView viewWithTag:706];
        imgView.hidden = YES;
        
        UIActivityIndicatorView *activityIndicator = (UIActivityIndicatorView*)[self._searchView viewWithTag:1000];
        if(activityIndicator){
            [activityIndicator startAnimating];
        }
        else{
            activityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            activityIndicator.backgroundColor = [UIColor clearColor];
            activityIndicator.alpha = 1.0;
            activityIndicator.tag = 1000;
            activityIndicator.center = imgView.center;
            activityIndicator.hidesWhenStopped = YES;
            [self._searchView addSubview:activityIndicator];
            [activityIndicator startAnimating];
        }
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getMyGroupData:) name: Notification_For_GetGroupList object:nil];
    [[WebServicesController WebServiceMethod] getMyGroupDataWithUserId:[AppHelper userDefaultsForKey:KUserId] SearchString:string pageNumber:@"1" limit:PageLimit exGroupId:@"" inviteUserId:@"0" andIsGetNameList:NO];
}

#pragma mark Receive webservices response and notifications
-(void)getMyGroupData:(NSNotification*)note{
    
    [AppDelegate dismissGlobalHUD];
    if(note.userInfo){
        if(isSearching){
            UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[self._searchView viewWithTag:1000];
            if(activityIndicator)
                [activityIndicator stopAnimating];
            
            UIImageView *imgView=(UIImageView*)[self._searchView viewWithTag:706];
            imgView.hidden = NO;
            afterSearchArray = [NSMutableArray arrayWithArray:[note.userInfo valueForKey:@"data"]];
        }
        else{
            NSArray *dataArray = [note.userInfo valueForKey:@"data"];
            if(dataArray.count > 0){
                if(pageNumber == 1){
                    if(myGroupArray.count>0)
                        [myGroupArray removeAllObjects];
                    myGroupArray = [NSMutableArray arrayWithArray:dataArray];
                }
                else{
                    for (int i = 0 ; i < dataArray.count ; i++) {
                        [myGroupArray addObject:[dataArray objectAtIndex:i]];
                    }
                }
                pageNumber++;
            }
            else{
                isHitWebService = NO;
            }
        }
        [self._tableView reloadData];
    }
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_For_GetGroupList object:nil];
}

#pragma mark Protocol methods
-(void)updateMyGroupList{
    if(isSearching){
        NSDictionary *dataDict = [afterSearchArray objectAtIndex:selectedGroupIndex];
        [afterSearchArray removeObjectAtIndex:selectedGroupIndex];
        [myGroupArray removeObject:dataDict];
    }
    else
        [myGroupArray removeObjectAtIndex:selectedGroupIndex];
    [self._tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedGroupIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
}

-(void)addJoinedGroupIntoList{
    if(isSearching)
        [afterSearchArray insertObject:selectedGrpDict atIndex:selectedGroupIndex];
    else
        [myGroupArray insertObject:selectedGrpDict atIndex:selectedGroupIndex];
    [self._tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedGroupIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark-tableViewDelegates
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    UILabel *lblNoData=(UILabel*)[self.view viewWithTag:123];
    BOOL isShowLabel=NO;
    if(isSearching && afterSearchArray.count==0)
        isShowLabel=YES;
    else if(myGroupArray.count==0)
        isShowLabel=YES;
    
    if(isShowLabel){
        if(!lblNoData){
            lblNoData=[[UILabel alloc] initWithFrame:CGRectMake(0, self._tableView.frame.size.height/2.0-15.0, 320, 30.0)];
            lblNoData.backgroundColor=[UIColor clearColor];
            lblNoData.textColor=KTextColor;
            lblNoData.tag=123;
            lblNoData.textAlignment=NSTextAlignmentCenter;
            lblNoData.text=@"No data available";
            [self._tableView addSubview:lblNoData];
        }
    }
    else
        [lblNoData removeFromSuperview];

    if(isSearching)
        return [afterSearchArray count];
    else
        return [myGroupArray count];
}

-(UITableViewCell *)tableView:(UITableView *)table_View cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [table_View dequeueReusableCellWithIdentifier:@"Cell"];
    cell.backgroundColor=[UIColor clearColor];
    
    UIImageView *image_view = (UIImageView *)[cell.contentView viewWithTag:701];
    [AppHelper getRoundedRectImageWithImageView:image_view withColor:[UIColor clearColor] andRadius:10.0 andWidth:2.0];
    
    NSDictionary *dict;
    if(isSearching==YES)
        dict=[afterSearchArray objectAtIndex:indexPath.row];
    else
        dict=[myGroupArray objectAtIndex:indexPath.row];
    
    if(!isSearching && isHitWebService && indexPath.row == myGroupArray.count-1){
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getMyGroupData:) name: Notification_For_GetGroupList object:nil];
            [[WebServicesController WebServiceMethod] getMyGroupDataWithUserId:[AppHelper userDefaultsForKey:KUserId] SearchString:@"" pageNumber:[NSString stringWithFormat:@"%i",pageNumber] limit:PageLimit exGroupId:@"" inviteUserId:@"0" andIsGetNameList:NO];
        });
    }
    
    UILabel *lblGroupName = (UILabel *)[cell.contentView viewWithTag:702];
    lblGroupName.textColor=KTextColor;
    lblGroupName.text=[dict valueForKey:@"group_name"];
    
    UILabel *lblDescription = (UILabel *)[cell.contentView viewWithTag:703];
    if([[dict valueForKey:@"owner_id"] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
        lblDescription.text=[NSString stringWithFormat:@"(%@/Admin) %@",[dict valueForKey:@"group_type"],[dict valueForKey:@"group_description"]];
    else
        lblDescription.text=[NSString stringWithFormat:@"(%@) %@",[dict valueForKey:@"group_type"],[dict valueForKey:@"group_description"]];
    
    UILabel *lblCount = (UILabel *)[cell.contentView viewWithTag:704];
    lblCount.textColor=KTextColor;
    if([[dict valueForKey:@"skoop_count"] integerValue]==1 && [[dict valueForKey:@"member_count"] integerValue]==1)
        lblCount.text=[NSString stringWithFormat:@"%@ Skoop Request - %@ Member",[dict valueForKey:@"skoop_count"],[dict valueForKey:@"member_count"]];
    else if([[dict valueForKey:@"skoop_count"] integerValue]!=1 && [[dict valueForKey:@"member_count"] integerValue]==1)
        lblCount.text=[NSString stringWithFormat:@"%@ Skoop Requests - %@ Member",[dict valueForKey:@"skoop_count"],[dict valueForKey:@"member_count"]];
    else if([[dict valueForKey:@"skoop_count"] integerValue]!=1 && [[dict valueForKey:@"member_count"] integerValue]!=1)
        lblCount.text=[NSString stringWithFormat:@"%@ Skoop Requests - %@ Members",[dict valueForKey:@"skoop_count"],[dict valueForKey:@"member_count"]];
    else if([[dict valueForKey:@"skoop_count"] integerValue]==1 && [[dict valueForKey:@"member_count"] integerValue]!=1)
        lblCount.text=[NSString stringWithFormat:@"%@ Skoop Request - %@ Members",[dict valueForKey:@"skoop_count"],[dict valueForKey:@"member_count"]];
    
    UILabel *lblAdmin = (UILabel *)[cell.contentView viewWithTag:705];
    lblAdmin.textColor=KTextColor;
    if([[dict valueForKey:@"owner_id"] integerValue]==[[AppHelper userDefaultsForKey:KUserId] integerValue])
        lblAdmin.text=@"Admin";
    else
        lblAdmin.text=@"Public";
    
    if([dict valueForKey:@"image"] && [[dict valueForKey:@"image"] length]>0)
        [image_view setImageWithURL:[NSURL URLWithString:[dict valueForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"user_default.png"]];
    else
        image_view.image=[UIImage imageNamed:@"user_default.png"];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if([self._textField isFirstResponder])//Resign keyboard if it is open
        [self._textField resignFirstResponder];
    else{
        selectedGroupIndex=indexPath.row;
        if(isSearching)
            selectedGrpDict=[afterSearchArray objectAtIndex:indexPath.row];
        else
            selectedGrpDict=[myGroupArray objectAtIndex:indexPath.row];
        [self performSegueWithIdentifier:@"groupprofile" sender:selectedGrpDict];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    int numberOfRows ;
    if(isSearching)
        numberOfRows = (int)afterSearchArray.count;
    else
        numberOfRows = (int)myGroupArray.count;
    if(indexPath.row == numberOfRows-1)
        return 107.0;
    else
        return 87.0;
}

#pragma mark Touch method
-(void) touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    if([self._textField isFirstResponder])//Resign keyboard if it is open
        [self._textField resignFirstResponder];
}

#pragma mark-textFieldDelegates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    isSearching=YES;
    searchText = [self._textField.text stringByReplacingCharactersInRange:range withString:string];
    [self getSearchDataWithText:searchText andIsShowIndicator:NO];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    NSString *searchString=[textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if([searchString length]==0){
        isSearching=NO;
        [self._tableView reloadData];
    }
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldClear:(UITextField *)textField{
    isSearching=NO;
    [self._tableView reloadData];
    return YES;
}

#pragma mark-backAction
- (IBAction)backButton:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)onClickSendRequestButton:(id)sender{
    [self performSegueWithIdentifier:@"sendskoop" sender:nil];
}

#pragma mark Prepare for segue
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    NSDictionary *groupDataDict=(NSDictionary*)sender;
    NSLog(@"%@",groupDataDict);
    if ([segue.identifier isEqualToString:@"groupprofile"]){
        
        GroupProfileVC *grpProfile=segue.destinationViewController;
        grpProfile.updateListProtocol=self;
        grpProfile.name=[groupDataDict valueForKey:@"group_name"];
        grpProfile.groupDescription=[groupDataDict valueForKey:@"group_description"];
        grpProfile.imgUrl=[groupDataDict valueForKey:@"cover_image"];
        grpProfile.groupImageUrl=[groupDataDict valueForKey:@"image"];
        grpProfile.groupId=[groupDataDict valueForKey:@"group_id"];
        grpProfile.categoryName=[groupDataDict valueForKey:@"category_name"];
        grpProfile.categoryId=[groupDataDict valueForKey:@"category_id"];
        grpProfile.groupType=[groupDataDict valueForKey:@"group_type"];
        grpProfile.ownerId=[groupDataDict valueForKey:@"owner_id"];
        grpProfile.prEmail=[groupDataDict valueForKey:@"pr_email"];
        grpProfile.isFromMyGroupClass = YES;
    }
}


#pragma mark-MemoryMethods
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
