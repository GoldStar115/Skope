//
//  SeeAllVC.h
//  youskoop
//
//  Created by Richika_Golchha on 4/28/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SeeAllVC : UIViewController

@property (strong,nonatomic) NSArray *groupDataArray;
@property (strong,nonatomic) NSString *pageTitle;
@property (strong, nonatomic) IBOutlet UITableView *_tableView;
@end
