//
//  SendRequestVC.m
//  youskoop
//
//  Created by Shitesh Patel on 17/04/14.
//  Copyright (c) 2014 user. All rights reserved.
//
//
//  InviteVC.m
//  youskoop
//
//  Created by Richika_Golchha on 5/1/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "SendRequestVC.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import <Twitter/Twitter.h>
#import "TwitterHelper.h"
#import "TWAccessTokenGenerator.h"
#import "AppHelper.h"
#import "Defines.h"
#import "youSKOOPVC.h"
#import "FacebookControllar.h"


#define is_selected  @"is_selected"

@interface SendRequestVC ()
{
    NSMutableArray *selectedFriendIds;
    NSMutableArray *selectedTwScreensName;
    
    __weak IBOutlet UIView *_viewSwitchButton;
    __weak IBOutlet UIButton *_btnFacebookSwitch;
    __weak IBOutlet UIButton *_btnSettings;
    youSKOOPVC *youSkooObj;
}

@property (strong, nonatomic) IBOutlet UIButton *sendButton;

@end

@implementation SendRequestVC
@synthesize tableView,faceBookArr;
@synthesize groupId,groupName;

#pragma mark-ViewLifecycle
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    if(!IS_IPHONE_5){
        CGRect frameRect=self.tableView.frame;
        frameRect.size.height=276;
        self.tableView.frame=frameRect;
        
        UIButton *btnSendReq=(UIButton*)[self.view viewWithTag:11111];
        CGRect btnFrameRect=btnSendReq.frame;
        if(IS_Greater_Or_Equal_to_IOS_7)
            btnFrameRect.origin.y=369.0;
        else
            btnFrameRect.origin.y=399.0;
        btnSendReq.frame=btnFrameRect;
    }
    
    _viewSwitchButton.hidden=YES;
    if([AppHelper userDefaultsForKey:KFbSwitchStatus] && [[AppHelper userDefaultsForKey:KFbSwitchStatus] integerValue]==1)
        [_btnFacebookSwitch setSelected:YES];
    else
        [_btnFacebookSwitch setSelected:NO];
    
    //Set button background color
    self.fbButton.backgroundColor=[UIColor colorWithRed:30.0/255.0 green:52.0/255.0 blue:116.0/255.0 alpha:1.0];
    self.twitterButton.backgroundColor=[UIColor colorWithRed:49.0/255.0 green:151.0/255.0 blue:216.0/255.0 alpha:1.0];
    self.youSkoopButton.backgroundColor=[UIColor colorWithRed:139.0/255.0 green:0.0/255.0 blue:224.0/255.0 alpha:1.0];
    
    self.friendsType=1;
    selectedFriendIds = [[NSMutableArray alloc] init];
    selectedTwScreensName = [[NSMutableArray alloc] init];
    NSMutableArray *fbArray=[[NSMutableArray alloc]init];
    self.faceBookArr=fbArray;
    self.tableView.backgroundColor=[UIColor clearColor];
    self.sendButton.enabled=NO;
}

#pragma mark Button action methods
- (IBAction)btnTwitterClick:(id)sender{
    if(![self.twitterButton isSelected]){
        if([_btnSettings isSelected]){
            _viewSwitchButton.hidden=YES;
            [_btnSettings setSelected:NO];
        }
        
        //Hide youskoop group list view
        if(youSkooObj)
            youSkooObj.view.hidden=YES;
        
        self.sendButton.enabled=YES;
        self.friendsType=2;
        
        [self selectTwitterAcount];
       // [self getFriendsOfTwitter];
        
        [self.fbButton setSelected:NO];
        [self.twitterButton setSelected:YES];
        [self.youSkoopButton setSelected:NO];
        self.sendButton.enabled = NO ;
    }
}

- (IBAction)facebookAction:(id)sender
{
    if(![self.fbButton isSelected])
    {
        if([_btnSettings isSelected])
        {
            _viewSwitchButton.hidden=YES;
            [_btnSettings setSelected:NO];
        }
        
        //Hide youskoop group list view
        if(youSkooObj)
            youSkooObj.view.hidden=YES;
        
        self.sendButton.enabled=YES;
        self.friendsType=1;
        
        //[AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        
        [FacebookControllar sharedFacebookControllar].requestType = RequestFacebookUserDetails;
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetFacebookDetail:) name:GetFacebookUserInfoNotification object:nil];
        NSArray *permissions = [[NSArray alloc]initWithObjects:@"publish_stream",@"publish_actions",@"user_location",@"friends_location",@"user_friends", nil];
        [[FacebookControllar sharedFacebookControllar] LoginWithFacebookWithFacebookPermission:permissions];
        
        [self.fbButton setSelected:YES];
        [self.twitterButton setSelected:NO];
        [self.youSkoopButton setSelected:NO];
        self.sendButton.enabled = NO ;
    }
}

- (IBAction)youSkoopButtonAction:(id)sender
{
    [self.fbButton setSelected:NO];
    [self.twitterButton setSelected:NO];
    [self.youSkoopButton setSelected:YES];
    
    if(youSkooObj)
    {
        //Show youskoop view and refresh data
        youSkooObj.view.hidden=NO;
        [youSkooObj getYouSkoopDataWithText:@"" andIsShowIndicator:YES];
    }
    else
    {
        //Find youskoop view and add on self view
        UIStoryboard *story=[UIStoryboard storyboardWithName:@"youSkoopLayouts" bundle:nil];
        youSkooObj=[story instantiateViewControllerWithIdentifier:@"youskoopgroup"];
        youSkooObj.navController=self.navigationController;
        youSkooObj.isHideNavigationBar=YES;
        youSkooObj.groupId=self.groupId;
        youSkooObj.view.frame=CGRectMake(0, 96, 320, 422);
        
        [self.view addSubview:youSkooObj.view];
    }
}

- (IBAction)backAction:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)onClickSettingsButton:(id)sender
{
    if([_btnSettings isSelected])
    {
        _viewSwitchButton.hidden=YES;
        [_btnSettings setSelected:NO];
    }
    else
    {
        _viewSwitchButton.hidden=NO;
        [_btnSettings setSelected:YES];
    }
}

//Facebook account logged out
-(IBAction)onClickFacebookSwitch:(id)sender
{
    
    [[FacebookControllar sharedFacebookControllar] LogoutFromFacebook];
     _viewSwitchButton.hidden=YES;
    [_btnSettings setSelected:NO];
    [AppHelper showAlertViewWithTag:1 title:AppName message:@"You have successfully disconnected your facebook account" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

- (IBAction)sendingInvitation:(id)sender
{
    if(self.friendsType==faceBook)
        [self sendFbInvitations];
    else if(self.friendsType==twitter)
        [self sendTwitterInvitations];
}

/*Method for getting facebook friends*/
-(void) accessingFBFriendsInfo
{
//    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
//    FBRequest *friendRequest = [FBRequest requestForGraphPath:@"me/friends?fields=id,name,picture,birthday,location"];
//    [ friendRequest startWithCompletionHandler:^(FBRequestConnection *connection, id result, NSError *error)
//     {
//         NSArray *data = [result objectForKey:@"data"];
//         if(self.faceBookArr.count>0)
//             [self.faceBookArr removeAllObjects];
//         
//         for (FBGraphObject<FBGraphUser> *friend in data)
//         {
//             NSString *imgUrl=[NSString stringWithFormat:@"http://graph.facebook.com/%@/picture?type=large", [friend objectForKey:@"id"]];
//             NSMutableDictionary *dict=[[NSMutableDictionary alloc] initWithObjectsAndKeys:friend.id,@"user_id",friend.name,@"name",imgUrl,@"image",[[friend valueForKey:@"location"] valueForKey:@"name"],@"location",nil];
//             [self.faceBookArr addObject:dict];
//         }
//         self.friendsType=1;
//         [self.tableView reloadData];
//         [AppDelegate dismissGlobalHUD];
//         
//         
//         [FacebookControllar sharedFacebookControllar].requestType = RequestForPostingAccessToken;
//         NSArray *permissions = [[NSArray alloc]initWithObjects:@"publish_stream",@"publish_actions",@"user_location",@"friends_location", nil];
//         [[FacebookControllar sharedFacebookControllar] LoginWithFacebookWithFacebookPermission:permissions];
//     }];
}
    
#pragma mark-TwitterMethods

//Select twitter account when more than one account added from setting
-(void) selectTwitterAcount{
    
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    [[TWAccessTokenGenerator sharedAccessTokenGenerator] initialize];
    ACAccountStore *accountStore = [[ACAccountStore alloc] init];
    ACAccountType *accountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    [accountStore requestAccessToAccountsWithType:accountType options:nil completion:^(BOOL granted, NSError *error)
     {
         if (granted)
         {
             NSArray *accounts = [accountStore accountsWithAccountType:accountType];
             // Check if the users has setup at least one Twitter account
             if (accounts.count > 0)
             {
                 ACAccount *twitterAccount = [accounts objectAtIndex:0];//Getting first account
                 
                 NSString *temp =[[twitterAccount.description componentsSeparatedByString:@"\"user_id\" = "] lastObject];
                 NSArray *temparr=[temp componentsSeparatedByString:@";"];
                 if ([temparr count]>0)
                 {
                     NSString *userName=[temparr objectAtIndex:0];
                     
                     // Creating a request to get the info about a user on Twitter
                     SLRequest *twitterInfoRequest = [SLRequest requestForServiceType:SLServiceTypeTwitter requestMethod:SLRequestMethodGET URL:[NSURL URLWithString:@"https://api.twitter.com/1.1/users/lookup.json"] parameters:[NSDictionary dictionaryWithObject:userName forKey:@"user_id"]];
                     [twitterInfoRequest setAccount:twitterAccount];
                     // Making the request
                     [twitterInfoRequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
                      {
                          dispatch_async(dispatch_get_main_queue(), ^
                                         {
                                             [AppDelegate dismissGlobalHUD];
                                             // Check if there was an error
                                             if (error)
                                             {
                                                 
                                                 return;
                                             }
                                             // Check if there is some response data
                                             if (responseData)
                                             {
                                                 [self getTwitterTokens];
                                             }
                                         });
                      }];
                 }
             }
             else
             {
                 dispatch_async(dispatch_get_main_queue(), ^
                                {
                                    [AppDelegate dismissGlobalHUD];
                                    [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please ensure that you have at least one twitter account setup and have internet connectivity. You can setup a twitter account in the iOS Settings > Twitter > login." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                                });
                 
             }
         }
         else
         {
             dispatch_async(dispatch_get_main_queue(), ^
                            {
                                [AppDelegate dismissGlobalHUD];
                                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please ensure that you have permission to access twitter account. You can turn on permission in the iOS Settings > Twitter." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                            });
         }
         if (error)
         {             //[MessageView showMessageView:@"ERROR_INTERNET_CONNECTION" onView:self.view];
         }
     }];
}

-(void)getTwitterTokens
{
    [TWAccessTokenGenerator sharedAccessTokenGenerator].view = self.view;
    [[TWAccessTokenGenerator sharedAccessTokenGenerator] refreshTwitterAccounts];
    [AppHelper saveToUserDefaults:@"YES" withKey:@"POST"];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getInfo) name:@"Twitter_Tokens_Rvcd" object:nil];
}

- (void) getInfo
{
    [AppHelper saveToUserDefaults:@"" withKey:@"POST"];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:@"Twitter_Tokens_Rvcd" object:nil];

   // [self getFriendsOfTwitter];
    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    
    AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Get_TwitterFriends]]];
    
    NSDictionary *param = [NSDictionary dictionaryWithObjectsAndKeys:KAppToken,@"token",[AppHelper userDefaultsForKey:KTwitter_id],@"twitter_uid",[AppHelper userDefaultsForKey:KTwitter_token],@"twitter_token",[AppHelper userDefaultsForKey:KUserId],KUserId, nil];
    
    NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
    [request setTimeoutInterval:Timeout_Interval];;
    AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
        NSError *error;
        NSDictionary *dataDict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
        
        if([[dataDict valueForKey:@"errorCode"] integerValue]==0){
            if(self.faceBookArr.count>0)
                [self.faceBookArr removeAllObjects];
            
            dispatch_async(dispatch_get_main_queue(), ^(void){
                
                NSArray *friendsArray = [dataDict objectForKey:@"data"];
                if(friendsArray.count){
                    
                    NSSortDescriptor *sortDescriptiors = [NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES];
                    NSArray *sortbyName = [NSArray arrayWithObject:sortDescriptiors];
                    friendsArray = [friendsArray sortedArrayUsingDescriptors:sortbyName];
                    
                    for(NSDictionary *dict in friendsArray)
                    {
                        NSDictionary *dictData=[[NSDictionary alloc]initWithObjectsAndKeys:[dict objectForKey:@"name"],@"name",[dict objectForKey:@"image"],@"image",[dict valueForKey:@"location"],@"location",[dict objectForKey:@"id"],@"user_id",[dict objectForKey:@"screen_name"],@"screen_name",nil];
                        
                        [self.faceBookArr addObject:dictData];
                    }
                }
                
                self.friendsType = 2;
                [self.tableView reloadData];
                [AppDelegate dismissGlobalHUD];
            });
        }
        else
            [AppHelper showAlertViewWithTag:1 title:AppName message:[dataDict valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        
        
    }
    failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         NSLog(@"Error....%@",[error description]);
     }
     ];
    [operation start];
    
}

-(void) getFriendsOfTwitter
{
    [AppDelegate showGlobalProgressHUDWithTitle: @""];
    ACAccountStore *accountStore = [[ACAccountStore alloc] init];
    ACAccountType *accountType = [accountStore accountTypeWithAccountTypeIdentifier:ACAccountTypeIdentifierTwitter];
    
    [accountStore requestAccessToAccountsWithType:accountType options:nil completion:^(BOOL granted, NSError *error)
     {
         if (granted)
         {
             NSArray *accounts = [accountStore accountsWithAccountType:accountType];
             // Check if the users has setup at least one Twitter account
             if (accounts.count > 0)
             {
                 ACAccount *twitterAccount = [accounts objectAtIndex:0];//Getting first account
                 
                 NSString *temp =[[twitterAccount.description componentsSeparatedByString:@"\"user_id\" = "] lastObject];
                 NSArray *temparr=[temp componentsSeparatedByString:@";"];
                 
                 if ([temparr count]>0)
                 {
                     NSString *userId=[temparr objectAtIndex:0];
                     
                     // Creating a request to get the info about a user on Twitter
                     SLRequest *twitterInfoRequest = [SLRequest requestForServiceType:SLServiceTypeTwitter requestMethod:SLRequestMethodGET URL:[NSURL URLWithString:@"https://api.twitter.com/1.1/followers/list.json"] parameters:[NSDictionary dictionaryWithObject:userId forKey:@"user_id"]];
                     
                     [twitterInfoRequest setAccount:twitterAccount];
                     // Making the request
                     [twitterInfoRequest performRequestWithHandler:^(NSData *responseData, NSHTTPURLResponse *urlResponse, NSError *error)
                      {
                          dispatch_async(dispatch_get_main_queue(), ^
                                         {
                                             // Check if there was an error
                                             if (error)
                                             {
                                                 [AppDelegate dismissGlobalHUD];
                                                 return;
                                             }
                                             // Check if there is some response data
                                             if (responseData)
                                             {
                                                 NSError *error = nil;
                                                 NSDictionary *TWData = [NSJSONSerialization JSONObjectWithData:responseData options:NSJSONReadingMutableLeaves error:&error];
                                                 
                                                 if(self.faceBookArr.count>0)
                                                     [self.faceBookArr removeAllObjects];
                                                 
                                                 for(NSDictionary *dict in [TWData objectForKey:@"users"])
                                                 {
                                                     NSDictionary *dictData=[[NSDictionary alloc]initWithObjectsAndKeys:[dict objectForKey:@"screen_name"],@"screen_name",[dict objectForKey:@"name"],@"name",[dict objectForKey:@"profile_image_url"],@"image",[dict valueForKey:@"location"],@"location",[dict objectForKey:@"id"],@"user_id",nil];
                                                     
                                                     [self.faceBookArr addObject:dictData];
                                                 }
                                                 self.friendsType=2;
                                                 [self.tableView reloadData];
                                                 [AppDelegate dismissGlobalHUD];
                                                 
                                                 
                                             }
                                         });
                      }];
                 }
                 else{
                     dispatch_async(dispatch_get_main_queue(), ^
                                    {
                                        
                                        //[MessageView showMessageView:@"TurnOn_Twitter_Privacy" onView:self.view];
                                    });
                 }
             }
             else
             {
                 NSLog(@"No twitter ac configure");
                 dispatch_async(dispatch_get_main_queue(), ^
                                {
                                    [AppDelegate dismissGlobalHUD];
                                    self.friendsType=1;
                                    [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please ensure that you have at least one twitter account setup and have internet connectivity. You can setup a twitter account in the iOS Settings > Twitter > login." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                                    //[MessageView showMessageView:@"TurnOn_Twitter_Privacy" onView:self.view];
                                });
                    }
         }
         else
         {
             NSLog(@"permission not granted");
             
             dispatch_async(dispatch_get_main_queue(), ^
                            {
                                [AppDelegate dismissGlobalHUD];
                                self.friendsType=1;
                                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please ensure that you have permission to access twitter account. You can turn on permission in the iOS Settings > Twitter." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                            });
             
             
         }
         if (error)
         {
             [AppDelegate dismissGlobalHUD];
             [AppHelper showAlertViewWithTag:0 title:AppName message:@"Please ensure that you have at least one twitter account setup and have internet connectivity. You can setup a twitter account in the iOS Settings > Twitter > login." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
             
             self.friendsType=1;
         }
     }];
}


#pragma mark Receive notification methods
-(void)userDidGetFacebookDetail:(NSNotification*)noti
{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:GetFacebookUserInfoNotification object:nil];
    NSLog(@"%@",noti);
    
    [AppDelegate dismissGlobalHUD];
    if(noti.userInfo && [[noti.userInfo valueForKey:@"isSuccess"] isEqualToString:@"Yes"])
    {
        [AppHelper saveToUserDefaults:[[noti.userInfo valueForKey:@"data"] valueForKey:@"id"] withKey:KFacebook_id];
        [self accessingFBFriendsInfo];
    }
    else
    {
        [self.faceBookArr removeAllObjects];
        [self.tableView reloadData];
    }
}

#pragma mark-tableView Delegates
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    UIButton *btnSendReq=(UIButton*)[self.view viewWithTag:11111];
    UILabel *lblNoData=(UILabel*)[self.view viewWithTag:123];
    if(self.faceBookArr.count==0){
        btnSendReq.enabled=NO;
        if(!lblNoData){
            lblNoData=[[UILabel alloc] initWithFrame:CGRectMake(0, self.tableView.frame.size.height/2.0-15.0, 320, 30.0)];
            lblNoData.backgroundColor=[UIColor clearColor];
            lblNoData.textColor=KTextColor;
            lblNoData.tag=123;
            lblNoData.textAlignment=NSTextAlignmentCenter;
            lblNoData.text=@"No data available";
            [self.tableView addSubview:lblNoData];
        }
    }
    else{
        btnSendReq.enabled=YES;
        [lblNoData removeFromSuperview];
    }
    return [self.faceBookArr count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [self.tableView dequeueReusableCellWithIdentifier: @"CellId"];
    if (cell == nil){
        cell = [[UITableViewCell alloc]
                initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"CellId"];
    }
    
    NSMutableDictionary *dictionary = [self.faceBookArr objectAtIndex:indexPath.row];
    
    UIImageView* imgCell = (UIImageView*)[cell.contentView viewWithTag:401];
    [AppHelper getRoundedImageWithImageView:imgCell];
    
    UILabel  *userNameLabel=(UILabel*)[cell.contentView viewWithTag:402];
    UILabel  *placeLabel=(UILabel*)[cell.contentView viewWithTag:403];
    UIButton *selectedButton=(UIButton*) [cell.contentView viewWithTag:404];
    
    if([selectedFriendIds containsObject:[dictionary valueForKey:@"user_id"]])
        [selectedButton setSelected:YES];
    else
        [selectedButton setSelected:NO];
    
    userNameLabel.text=[dictionary valueForKey:@"name"];
    userNameLabel.textColor=KTextColor;
    placeLabel.text=[dictionary valueForKey:@"location"];
    [imgCell setImageWithURL:[NSURL URLWithString:[dictionary objectForKey:@"image"]] placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    
    NSMutableDictionary *dict = (NSMutableDictionary*)[self.faceBookArr objectAtIndex:indexPath.row];
    [selectedFriendIds addObject:[dict valueForKey:@"user_id"]];
    UIButton *selectedButton=(UIButton*)[cell.contentView viewWithTag:404];
    [selectedButton setSelected:YES];
    
    if(self.friendsType==2){//Twitter friends
        
        [selectedTwScreensName addObject:[dict valueForKey:@"screen_name"]];
    }
    
    self.sendButton.enabled = YES ;
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
    
    NSMutableDictionary *dict=(NSMutableDictionary*)[self.faceBookArr objectAtIndex:indexPath.row];
    [selectedFriendIds removeObject:[dict valueForKey:@"user_id"]];
    if(selectedFriendIds.count == 0)
        self.sendButton.enabled = NO ;
    
    UIButton *selectedButton=(UIButton*)[cell.contentView viewWithTag:404];
    [selectedButton setSelected:NO];
    
    if(self.friendsType==2){//Twitter friends
        
        [selectedTwScreensName removeObject:[dict valueForKey:@"screen_name"]];
    }
}

#pragma mark-Send request methods
-(void) sendFbInvitations{
    
    if ([[AppDelegate getAppDelegate] checkInternateConnection]){
        NSMutableDictionary *param;
        
        if(selectedFriendIds.count >0){
            
            param=[[NSMutableDictionary alloc] initWithObjectsAndKeys:KAppToken,@"token",[AppHelper userDefaultsForKey:KUserId],@"user_id",[AppHelper userDefaultsForKey:KFacebook_id],@"fb_uid",self.groupId,@"group_id",selectedFriendIds,@"users",self.groupName,@"group_name",[AppHelper userDefaultsForKey:KFbAccessToken],@"access_token",[AppHelper userDefaultsForKey:KUserName],@"user_name" , nil];
        }
        else{
            [AppHelper showAlertViewWithTag:1 title:AppName message:@"Select Atleast One friend." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
            return;
        }
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Invite_FbFriends]]];
        NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Invite_FbFriends]);
        NSLog(@"%@",[param JSONRepresentation]);
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             NSLog(@":::::::::%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
             if(dict && [dict valueForKey:@"errorMessage"])
                 [AppHelper showAlertViewWithTag:1 title:AppName message:[dict valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
             
             [selectedFriendIds removeAllObjects];
             [self.tableView reloadData];
             [AppDelegate dismissGlobalHUD];
         }
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error");
         }
         ];
        [operation start];
        
    }
    else
    {
    }
}

-(void) sendTwitterInvitations
{
    if ([[AppDelegate getAppDelegate] checkInternateConnection])
    {
        NSMutableDictionary *param;
        
        if(selectedFriendIds.count >0)
        {
            NSDictionary *selectedFriendDict = @{@"twitter_ids":selectedFriendIds,@"screen_name":selectedTwScreensName};
            param=[[NSMutableDictionary alloc] initWithObjectsAndKeys:@"aw@#$lkj",@"token",[AppHelper userDefaultsForKey:KUserId],@"user_id",self.groupId,@"group_id",self.groupName,@"group_name",[AppHelper userDefaultsForKey:KTwitter_id],@"twitter_uid",selectedFriendDict,@"users",TwitterSecretKey,@"twitter_secret",[AppHelper userDefaultsForKey:KTwitter_token],@"twitter_token",[AppHelper userDefaultsForKey:KUserName],@"user_name", nil];
        }
        else
        {
            [AppHelper showAlertViewWithTag:1 title:AppName message:@"Select Atleast One friend." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
            return;
        }
        
        NSLog(@"%@",[param JSONRepresentation]);
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_Invite_TwitterFriends]]];
        
        NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
        [request setTimeoutInterval:Timeout_Interval];;
        AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
        
        [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
         {
             NSError *error;
             NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
             NSLog(@"=====%@",[[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
             
             if(dict && [[dict valueForKey:@"errorCode"] integerValue]==1)
             {
                 
                 [AppHelper showAlertViewWithTag:1 title:AppName message:@"Invitation sent successfully." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
                 [selectedFriendIds removeAllObjects];
                 [selectedTwScreensName removeAllObjects];
                 [self.tableView reloadData];
             }
             else
             {
                 [AppHelper showAlertViewWithTag:1 title:AppName message:[dict valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
             }
             
             [AppDelegate dismissGlobalHUD];
         }
        
        failure:^(AFHTTPRequestOperation *operation, NSError *error)
         {
             NSLog(@"Error");
         }
         ];
        [operation start];
        
    }
    else
    {
        
    }
}

#pragma mark-MemoryMethods

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

