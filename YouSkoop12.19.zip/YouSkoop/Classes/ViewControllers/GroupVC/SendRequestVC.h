//
//  SendRequestVC.h
//  youskoop
//
//  Created by Shitesh Patel on 17/04/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SendRequestVC : UIViewController

typedef enum
{
    faceBook=1,
    twitter,
    youSkoop,
} type;

@property (strong, nonatomic) IBOutlet UIButton *fbButton;
@property (strong, nonatomic) IBOutlet UIButton *twitterButton;
@property (strong, nonatomic) IBOutlet UIButton *youSkoopButton;
@property (strong, nonatomic) NSString *groupId;
@property (strong, nonatomic) NSString *groupName;

@property(nonatomic,assign) type friendsType;

@property (strong, nonatomic) NSMutableArray *faceBookArr;
@property (strong, nonatomic) IBOutlet UITableView *tableView;

@end


