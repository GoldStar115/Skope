//
//  CreateGroupVC.m
//  youskoop
//
//  Created by Shitesh Patel on 17/04/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "CreateGroupVC.h"
#import "GroupProfileVC.h"

#import "VPImageCropperViewController.h"
#import <AssetsLibrary/AssetsLibrary.h>
#import <MobileCoreServices/MobileCoreServices.h>

#define ORIGINAL_MAX_WIDTH 640.0f
#define KCropper_Height                  self.view.frame.size.width/2.5
#define KCropper_ScalRatio                  3.0

enum {
    private=0,
    public = 1,
    celebrity = 2
} categoryType;

@interface CreateGroupVC ()<VPImageCropperDelegate>
@property (weak, nonatomic) IBOutlet UIView *_categoryView;

@end

@implementation CreateGroupVC
{
    NSData *coverImageData;
    NSData *logoImageData;
    NSString *whichIcon;
    NSString *categoryId;
    NSString *prEmail;
    NSString *selectedCategory;
    NSInteger selectedCategoryIndex;
    
    NSArray *categoryTypeArray;
    
    __weak IBOutlet UIView *_viewEnterPrCode;
    __weak IBOutlet UIView *_viewAreUCeleb;
    __weak IBOutlet UIImageView *_imgEnterPrCode;
    __weak IBOutlet UIImageView *_imgAreUCeleb;
    __weak IBOutlet UITextField *_txtGroupName;
    __weak IBOutlet UITextField *_txtPrCode;
    
    __weak IBOutlet UIButton *_btnPrivate;
    __weak IBOutlet UIButton *_btnPublic;
    __weak IBOutlet UIButton *_btnCelebrity;
    
    __weak IBOutlet UIButton *_lblEditGroupImage;
    __weak IBOutlet UILabel *_lblRUCeleb;
    __weak IBOutlet UILabel *_lblPrContact;
    __weak IBOutlet UILabel *_lblAreUCeleb;
    __weak IBOutlet UILabel *_lblnavTitle;
    __weak IBOutlet UIButton *_btnCreateGroup;
    __weak IBOutlet UIButton *_btnCancelImage;
    __weak IBOutlet UIView *_viewCropImage;
    __weak IBOutlet UIButton *_btnCropImage;
    
    IBOutlet UIButton *create;
    BOOL isEditData;
    BOOL isSelectImageFromExistingImage;
}

@synthesize descriptionView,scrollView,pickerCategory,labelSelectCategory,isEditGroup,groupDescription;
@synthesize deligate;
@synthesize _imgCoverImage;
@synthesize _imgGroupIcon;

#pragma mark-ViewLifeCycle
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{

    [super viewDidLoad];
	// Do any additional setup after loading the view.
    NSLog(@"%@",groupDescription);
    selectedCategory=@"";
    prEmail=@"";
    categoryId=@"";
    selectedCategoryIndex=0;
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    self.pickerView.hidden=YES;
    [AppHelper getRoundedRectImageWithImageView:self._imgGroupIcon withColor:[UIColor clearColor] andRadius:10.0 andWidth:1.0];
    
    if(IS_IPHONE_5){
        self.scrollView.scrollEnabled=YES;
        self.scrollView.contentSize=CGSizeMake(320, 670);
    }
    else{
        self.scrollView.scrollEnabled=YES;
        self.scrollView.contentSize=CGSizeMake(320, 740);
    }
    
    [AppHelper getRoundedRectImageWithImageView:_imgAreUCeleb withColor:[UIColor clearColor] andRadius:6.0 andWidth:2.0];
    [AppHelper getRoundedRectImageWithImageView:_imgEnterPrCode withColor:[UIColor clearColor] andRadius:6.0 andWidth:2.0];
    _lblAreUCeleb.textColor=KTextColor;
    _lblRUCeleb.textColor=KTextColor;
    _lblPrContact.textColor=KTextColor;
    
    descriptionView.textColor = [UIColor lightGrayColor];
    
    if(isEditGroup){
        
        _lblnavTitle.text=@"Edit Group";
        if([self.groupDescription valueForKey:@"cover_image"]){
            self._imgCoverImage.image=[self.groupDescription valueForKey:@"cover_image"];
            coverImageData=UIImagePNGRepresentation(self._imgCoverImage.image);
        }
        else
            self._imgCoverImage.image=[UIImage imageNamed:@"cover.png"];
        
        if([self.groupDescription valueForKey:@"group_image"]){
            self._imgGroupIcon.image=[self.groupDescription valueForKey:@"group_image"];
            logoImageData=UIImagePNGRepresentation(self._imgGroupIcon.image);
        }
        else
            self._imgGroupIcon.image=[UIImage imageNamed:@"user_default.png"];
        
        _txtGroupName.text = [self.groupDescription valueForKey:@"group_name"];
        descriptionView.text = [self.groupDescription valueForKey:@"group_description"];
        labelSelectCategory.text = [self.groupDescription valueForKey:@"category_name"];
        labelSelectCategory.textColor = [UIColor blackColor];
        selectedCategory = [self.groupDescription valueForKey:@"category_name"];
        categoryId = [self.groupDescription valueForKey:@"category_id"];
        
        if([[self.groupDescription valueForKey:@"group_type"] isEqualToString:@"Public"]){
            [self selectCategoryByType:public];
        }
        else if([[self.groupDescription valueForKey:@"group_type"] isEqualToString:@"Celebrity"]){
            prEmail = [self.groupDescription valueForKey:@"pr_email"];
            _txtPrCode.text = prEmail;
            [self selectCategoryByType:celebrity];
        }
        else
            [self selectCategoryByType:private];
            
        descriptionView.textColor=[UIColor blackColor];
        
        [create setTitle:@"Save" forState:UIControlStateNormal];
        [create setTitle:@"Save" forState:UIControlStateSelected];
    }
    else{
        // Selection of private button by default
        [self selectCategoryByType:public];
        self.groupDescription = [NSMutableDictionary dictionary];
    }
    
    [self performSelector:@selector(getCategoryListData) withObject:nil afterDelay:0.5];
    
    UITapGestureRecognizer *scrollTapGesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(scrollHandleTap:)];
    scrollTapGesture.numberOfTapsRequired=1;
    scrollTapGesture.numberOfTouchesRequired=1;
    scrollTapGesture.delegate=self;
    [scrollView addGestureRecognizer:scrollTapGesture];
    
    UITapGestureRecognizer *coverTapGesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(coverHandleTap:)];
    coverTapGesture.numberOfTapsRequired=1;
    coverTapGesture.numberOfTouchesRequired=1;
    coverTapGesture.delegate=self;
    [self._imgCoverImage addGestureRecognizer:coverTapGesture];
    
    UITapGestureRecognizer *iconTapGesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(iconHandleTap:)];
    self._imgGroupIcon.userInteractionEnabled=YES;
    iconTapGesture.numberOfTapsRequired=1;
    iconTapGesture.numberOfTouchesRequired=1;
    iconTapGesture.delegate=self;
    [self._imgGroupIcon addGestureRecognizer:iconTapGesture];
    
    UITapGestureRecognizer *lblTapGesture=[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(iconHandleTap:)];
    _lblEditGroupImage.userInteractionEnabled=YES;
    lblTapGesture.numberOfTapsRequired=1;
    lblTapGesture.numberOfTouchesRequired=1;
    lblTapGesture.delegate=self;
    [_lblEditGroupImage addGestureRecognizer:lblTapGesture];
    
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapToRemoveAreUCelebView:)];
    tap.numberOfTapsRequired=1;
    tap.numberOfTouchesRequired=1;
    _viewAreUCeleb.userInteractionEnabled=YES;
    [_viewAreUCeleb addGestureRecognizer:tap];
    
    UITapGestureRecognizer * tapGesture = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTapToRemoveEnterPrCodezview:)];
    tapGesture.numberOfTapsRequired=1;
    tapGesture.numberOfTouchesRequired=1;
    _viewEnterPrCode.userInteractionEnabled=YES;
    [_viewEnterPrCode addGestureRecognizer:tapGesture];
    
    //Set crop image base view
    _viewCropImage.frame=self.view.bounds;

    //add keyboard notification
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(keyboardwillShowNotification:)
     name:UIKeyboardDidShowNotification
     object:nil];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(keyboardwillHideNotification:)
     name:UIKeyboardDidHideNotification
     object:nil];
}

-(BOOL)checkIsEditAnyDataOrNot{
    
    if(isEditData){//Return if image edited
        return YES;
    }
    else{
        if(![_txtGroupName.text isEqualToString:[self.groupDescription valueForKey:@"group_name"]]){
            return YES;
        }
        else if(![descriptionView.text isEqualToString:[self.groupDescription valueForKey:@"group_description"]]){
            return YES;
        }
        else if(![labelSelectCategory.text isEqualToString:[self.groupDescription valueForKey:@"category_name"]]){
            return YES;
        }
    }
    
//    categoryId = [self.groupDescription valueForKey:@"category_id"];
//    
//    if([[self.groupDescription valueForKey:@"group_type"] isEqualToString:@"Public"]){
//        [self selectCategoryByType:public];
//    }
//    else if([[self.groupDescription valueForKey:@"group_type"] isEqualToString:@"Celebrity"]){
//        prEmail = [self.groupDescription valueForKey:@"pr_email"];
//        _txtPrCode.text = prEmail;
//        [self selectCategoryByType:celebrity];
//    }
//    else
//        [self selectCategoryByType:private];
    
    return NO;
}

-(void)getCategoryListData{
   // [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(getCategoryData:) name: Notification_Get_CategoryNames object:nil];
        [[WebServicesController WebServiceMethod] getCategoryNamesForCreateGroup];
    });
}

#pragma mark-TapGesture

- (void)handleTapToRemoveAreUCelebView:(UITapGestureRecognizer *)gesture{
    // Do some other action as intended.
   // isEditData = YES;
    [_viewAreUCeleb removeFromSuperview];
    [self selectCategoryByType:private];
}

- (void)handleTapToRemoveEnterPrCodezview:(UITapGestureRecognizer *)gesture{
    // Do some other action as intended.
   // isEditData = YES;
    [_viewEnterPrCode removeFromSuperview];
    [self selectCategoryByType:private];
}

- (void)scrollHandleTap:(UITapGestureRecognizer *)recognizer{
    [descriptionView resignFirstResponder];
    [_txtGroupName resignFirstResponder];
}

- (void)coverHandleTap:(UITapGestureRecognizer *)recognizer{
    [descriptionView resignFirstResponder];
    [_txtGroupName resignFirstResponder];
    
    UIActionSheet *imageAction=nil;
    if([self.groupDescription valueForKey:@"cover_image"])
        imageAction=[[UIActionSheet alloc]initWithTitle:@"Change Cover Image" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Gallery",@"Edit existing image",nil];
    else
        imageAction=[[UIActionSheet alloc]initWithTitle:@"Change Cover Image" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Gallery",nil];
    
    whichIcon=@"Cover";
    imageAction.delegate=self;
    [imageAction showInView:self.view];
}

- (void)iconHandleTap:(UITapGestureRecognizer *)recognizer{
    [descriptionView resignFirstResponder];
    [_txtGroupName resignFirstResponder];
    
    UIActionSheet *imageAction=nil;
    if([self.groupDescription valueForKey:@"group_image"]){
        
        imageAction=[[UIActionSheet alloc]initWithTitle:@"Change Profile Image" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Gallery",@"Edit existing image",nil];
    }
    else{
        
        imageAction=[[UIActionSheet alloc]initWithTitle:@"Change Profile Image" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Gallery",nil];
    }
    
    whichIcon=@"Icon";
    imageAction.delegate=self;
    [imageAction showInView:self.view];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    UITouch *touch = [touches anyObject];
    if (touch.view.tag==345){//Touched view is category picker view
    
        //hide category picker
        [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                         animations:^{
                             CGRect frameRect = self.pickerView.frame;
                             frameRect.origin.y = 568;
                             self.pickerView.frame = frameRect;
                         }
                         completion:nil];
        
        if(selectedCategoryIndex==0)
            self.labelSelectCategory.text = @"Select category";
        else
            self.labelSelectCategory.text = selectedCategory;
        
        self.scrollView.contentOffset = CGPointMake(0, 0);
        if(IS_IPHONE_5)
            [self.scrollView setContentSize:CGSizeMake(320, 300)];
        else
            [self.scrollView setContentSize:CGSizeMake(320,740)];
    }
}

#pragma mark-ActionSheetDelegate
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    switch (buttonIndex){
        case 0:{
            NSLog(@"camera");
            isSelectImageFromExistingImage = NO;
            UIImagePickerController *image_picker=nil;
            image_picker = [[UIImagePickerController alloc] init];
            image_picker.delegate =self;
            image_picker.allowsEditing = NO;
            image_picker.navigationBar.barStyle = UIBarStyleBlackOpaque;
            UIImagePickerControllerSourceType sourceType =UIImagePickerControllerSourceTypeCamera;
            if ([UIImagePickerController isSourceTypeAvailable: sourceType]){
                image_picker.sourceType = sourceType;
                [self presentViewController:image_picker animated:YES completion:nil];
            }
            else
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Device has no camera." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
            break;
        }
        case 1:{
            NSLog(@"gallery");
            isSelectImageFromExistingImage = NO;
            UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
            imagePicker.delegate = self;
            imagePicker.allowsEditing = NO;
            
            UIImagePickerControllerSourceType sourcetype =UIImagePickerControllerSourceTypePhotoLibrary;
            if ([UIImagePickerController isSourceTypeAvailable: sourcetype]){
                imagePicker.sourceType = sourcetype;
                [self presentViewController:imagePicker animated:YES completion:nil];
            }
            break;
        }
        case 2:{
            
            NSLog(@"Edit existing image");
            isSelectImageFromExistingImage = YES;
            UIImage *portraitImg = nil;
            VPImageCropperViewController *imgCropperVC = nil;
            if([whichIcon isEqualToString:@"Cover"] && [self.groupDescription valueForKey:@"cover_image"]){
                
                portraitImg = [self.groupDescription valueForKey:@"cover_image"];
                portraitImg = [self imageWithImage:portraitImg scaledToWidth:self.view.frame.size.width*KCropper_ScalRatio];
                imgCropperVC = [[VPImageCropperViewController alloc] initWithImage:portraitImg cropFrame:CGRectMake(0, self.view.bounds.size.height/2.0 - KCropper_Height/2.0, self.view.bounds.size.width, KCropper_Height) limitScaleRatio:KCropper_ScalRatio];
                imgCropperVC.delegate = self;
                // present the cropper view controller
                [self presentViewController:imgCropperVC animated:NO completion:nil];
            }
            else if([whichIcon isEqualToString:@"Icon"] && [self.groupDescription valueForKey:@"group_image"]){
                
                portraitImg = [self.groupDescription valueForKey:@"group_image"];
                portraitImg = [self imageWithImage:portraitImg scaledToWidth:self.view.frame.size.width*KCropper_ScalRatio];
                imgCropperVC = [[VPImageCropperViewController alloc] initWithImage:portraitImg cropFrame:CGRectMake(self.view.bounds.size.width/2-60, self.view.bounds.size.height/2.0 - 60, 120, 120) limitScaleRatio:KCropper_ScalRatio];
                imgCropperVC.delegate = self;
                // present the cropper view controller
                [self presentViewController:imgCropperVC animated:NO completion:nil];
            }
            break;
        }
        default:
            break;
    }
}

-(UIImage*)imageWithImage: (UIImage*) sourceImage scaledToWidth: (float) i_width{
    float oldWidth = sourceImage.size.width;
    float scaleFactor = i_width / oldWidth;
    
    float newHeight = sourceImage.size.height * scaleFactor;
    float newWidth = oldWidth * scaleFactor;
    
    UIGraphicsBeginImageContext(CGSizeMake(newWidth, newHeight));
    [sourceImage drawInRect:CGRectMake(0, 0, newWidth, newHeight)];
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    return newImage;
}

#pragma mark VPImageCropperDelegate
- (void)imageCropper:(VPImageCropperViewController *)cropperViewController didFinished:(UIImage *)editedImage originalImage:(UIImage *)originalImage{
    
    isEditData = YES;
    if([whichIcon isEqualToString:@"Cover"]){
        
        self._imgCoverImage.image = editedImage;
        coverImageData=UIImageJPEGRepresentation(editedImage, 1.0);
        if(![self.groupDescription valueForKey:@"cover_image"] || !isSelectImageFromExistingImage)
            [self.groupDescription setValue:originalImage forKey:@"cover_image"];
    }
    else if([whichIcon isEqualToString:@"Icon"]){
        
        self._imgGroupIcon.image = editedImage;
        logoImageData=UIImageJPEGRepresentation(editedImage, 1.0);
        if(![self.groupDescription valueForKey:@"group_image"] || !isSelectImageFromExistingImage)
            [self.groupDescription setValue:originalImage forKey:@"group_image"];
    }
    [cropperViewController dismissViewControllerAnimated:YES completion:nil];
}

- (void)imageCropperDidCancel:(VPImageCropperViewController *)cropperViewController{
    [cropperViewController dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - UIImagePickerControllerDelegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    
    [picker dismissViewControllerAnimated:NO completion:^() {
        
        [AppHelper stausBarColorChange];
        UIImage *portraitImg = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        //portraitImg = [self imageByScalingToMaxSize:portraitImg];
        
        if([whichIcon isEqualToString: @"Cover"]){
            
            // present the cropper view controller
            VPImageCropperViewController *imgCropperVC = nil;
            imgCropperVC = [[VPImageCropperViewController alloc] initWithImage:portraitImg cropFrame:CGRectMake(0, self.view.bounds.size.height/2.0 - KCropper_Height/2.0, self.view.bounds.size.width, KCropper_Height) limitScaleRatio:KCropper_ScalRatio];
            imgCropperVC.delegate = self;
            [self presentViewController:imgCropperVC animated:NO completion:nil];
        }
        else{
            
            // present the cropper view controller
            VPImageCropperViewController *imgCropperVC = nil;
            imgCropperVC = [[VPImageCropperViewController alloc] initWithImage:portraitImg cropFrame:CGRectMake(self.view.bounds.size.width/2-60, self.view.bounds.size.height/2.0 - 60, 120, 120) limitScaleRatio:KCropper_ScalRatio];
            imgCropperVC.delegate = self;
            [self presentViewController:imgCropperVC animated:NO completion:nil];
        }
    }];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark image scale utility
- (UIImage *)imageByScalingToMaxSize:(UIImage *)sourceImage{
    if (sourceImage.size.width < ORIGINAL_MAX_WIDTH) return sourceImage;
    CGFloat btWidth = 0.0f;
    CGFloat btHeight = 0.0f;
    if (sourceImage.size.width > sourceImage.size.height) {
        btHeight = ORIGINAL_MAX_WIDTH;
        btWidth = sourceImage.size.width * (ORIGINAL_MAX_WIDTH / sourceImage.size.height);
    } else {
        btWidth = ORIGINAL_MAX_WIDTH;
        btHeight = sourceImage.size.height * (ORIGINAL_MAX_WIDTH / sourceImage.size.width);
    }
    CGSize targetSize = CGSizeMake(btWidth, btHeight);
    return [self imageByScalingAndCroppingForSourceImage:sourceImage targetSize:targetSize];
}

- (UIImage *)imageByScalingAndCroppingForSourceImage:(UIImage *)sourceImage targetSize:(CGSize)targetSize{
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    if (CGSizeEqualToSize(imageSize, targetSize) == NO){
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        
        if (widthFactor > heightFactor)
            scaleFactor = widthFactor; // scale to fit height
        else
            scaleFactor = heightFactor; // scale to fit width
        scaledWidth  = width * scaleFactor;
        scaledHeight = height * scaleFactor;
        
        // center the image
        if (widthFactor > heightFactor){
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }
        else if (widthFactor < heightFactor){
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }
    UIGraphicsBeginImageContext(targetSize); // this will crop
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width  = scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    
    [sourceImage drawInRect:thumbnailRect];
    
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil) NSLog(@"could not scale image");
    
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    return newImage;
}


#pragma mark Textfield deligates
-(void)keyboardwillShowNotification:(NSNotification*)note{
    NSLog(@"keyboardwillShowNotification");
    if(IS_IPHONE5)
        [self.scrollView setContentSize:CGSizeMake(320,720)];
    else
        [self.scrollView setContentSize:CGSizeMake(320,810)];
    self.scrollView.scrollEnabled=YES;
}

-(void)keyboardwillHideNotification:(NSNotification*)note{
    NSLog(@"keyboardwillHideNotification");
    if(IS_IPHONE_5){
        self.scrollView.scrollEnabled=YES;
        self.scrollView.contentOffset=CGPointMake(0, 0);
    }
    else
        [self.scrollView setContentSize:CGSizeMake(320,588)];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField{
    [textField becomeFirstResponder];
    self.scrollView.scrollEnabled=YES;
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}
- (void)textFieldDidEndEditing:(UITextField *)textField{
    if(textField==_txtPrCode)
        prEmail=textField.text;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    NSString *textFieldString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if(textField==_txtGroupName){
        if([textFieldString length]<=40)
            return YES;
        else
            return NO;
    }
    return YES;
}


#pragma mark-TextViewDelegates
- (void)textViewDidBeginEditing:(UITextView *)textView{
    [UIView animateWithDuration:0.4 delay:0.0 options:UIViewAnimationOptionTransitionNone
                     animations:^(void) {
                         CGRect frameRect=self.scrollView.frame;
                         frameRect.origin.y-=40;
                         self.scrollView.frame=frameRect;
                     }
                     completion:^(BOOL finished){
                     }];
    
    if([descriptionView.text isEqualToString:@"Brief Description"]){
        descriptionView.text = @"";
        descriptionView.textColor = [UIColor lightGrayColor];
    }
    else
        descriptionView.textColor = [UIColor blackColor];
}

-(void) textViewDidChange:(UITextView *)textView{
    if(descriptionView.text.length == 0){
        descriptionView.textColor = [UIColor lightGrayColor];
        descriptionView.text = @"Brief Description";
        [descriptionView resignFirstResponder];
    }
    else
        descriptionView.textColor = [UIColor blackColor];
}

- (void)textViewDidEndEditing:(UITextView *)textView{
    if([[textView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0 || [textView.text isEqualToString:@"Brief Description"]){
        descriptionView.text = @"Brief Description";
        descriptionView.textColor = [UIColor lightGrayColor];
    }
    else
        descriptionView.textColor = [UIColor blackColor];
    
    [UIView animateWithDuration:0.4 delay:0.0 options:UIViewAnimationOptionTransitionNone
                     animations:^(void) {
                         CGRect frameRect=self.scrollView.frame;
                         if(IS_Greater_Or_Equal_to_IOS_7)
                             frameRect.origin.y=64;
                         else
                             frameRect.origin.y=44;
                         self.scrollView.frame=frameRect;
                     }
                     completion:^(BOOL finished){
                     }];
    
    self.scrollView.contentOffset=CGPointMake(0, 0);
    if(IS_IPHONE_5)
        self.scrollView.contentSize=CGSizeMake(320, 670);
    else
        [self.scrollView setContentSize:CGSizeMake(320,740)];
}
- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    NSString *textViewString = [textView.text stringByReplacingCharactersInRange:range withString:text];
    if(textView==self.descriptionView){
        if([textViewString length]<=100)
            return YES;
        else
            return NO;
    }
    return YES;
}

#pragma mark- ButtonActionMethod
-(IBAction)onClickYesButton:(id)sender{
    [_viewAreUCeleb removeFromSuperview];
    [self.view addSubview:_viewEnterPrCode];
}
-(IBAction)onClickNoButton:(id)sender{
    [_viewAreUCeleb removeFromSuperview];
    //[self selectCategoryByType:private];
}
-(IBAction)onClickCancelButton:(id)sender{
    [_viewEnterPrCode removeFromSuperview];
    [self selectCategoryByType:public];
}
-(IBAction)onClickOkButton:(id)sender{
    
    if([_txtPrCode.text length]>0){
        [_txtPrCode resignFirstResponder];
        [_viewEnterPrCode removeFromSuperview];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:@"Please enter PR email or phone number." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

- (IBAction)addCoverImageButton:(id)sender{
    UIActionSheet *imageAction=nil;
    if([self.groupDescription valueForKey:@"cover_image"]){
        imageAction = [[UIActionSheet alloc] initWithTitle:@"Change Cover Image" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Gallery",@"Edit existing image",nil];
    }
    else{
        imageAction = [[UIActionSheet alloc] initWithTitle:@"Change Cover Image" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Camera", @"Gallery",nil];
    }
    
    whichIcon=@"Cover";
    imageAction.delegate=self;
    [imageAction showInView:self.view];
}

- (IBAction)cancelSelectedImage:(id)sender
{
    [_viewCropImage removeFromSuperview];
}

- (IBAction)cropSelectedImage:(id)sender{
    if([whichIcon isEqualToString: @"Cover"]){
        //self._imgCoverImage.image = [self.cropImage getCroppedImage];
        coverImageData=UIImageJPEGRepresentation(self._imgCoverImage.image, 0.6);
    }
    else if ([whichIcon isEqualToString: @"Icon"]){
        //self._imgGroupIcon.image = [self.cropImage getCroppedImage];
        logoImageData=UIImageJPEGRepresentation(self._imgGroupIcon.image, 0.6);
    }
    [_viewCropImage removeFromSuperview];
}

- (IBAction)selectCategory:(id)sender{
    self.pickerView.hidden=NO;
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect=self.view.bounds;
                         if(IS_Greater_Or_Equal_to_IOS_7)
                             frameRect.origin.y=-20;
                         else
                             frameRect.origin.y=0;
                         self.pickerView.frame=frameRect;
                     }completion:nil];
    
    [pickerCategory reloadAllComponents];
    
    if([_txtGroupName isFirstResponder])
        [_txtGroupName resignFirstResponder];
    if([descriptionView isFirstResponder])
        [descriptionView resignFirstResponder];
    self.scrollView.scrollEnabled=YES;
    
    float yCord = self.scrollView.contentSize.height - self.scrollView.bounds.size.height;
    if(yCord < 0)
        yCord = 165;
    CGPoint bottomOffset = CGPointMake(0, yCord);
    [self.scrollView setContentOffset:bottomOffset animated:YES];
}
- (IBAction)privateButtonSelected:(id)sender{
    if(![_btnPrivate isSelected]){
        isEditData = YES;
        [self selectCategoryByType:private];
    }
}
- (IBAction)publicButtonSelected:(id)sender{
    if(![_btnPublic isSelected]){
        isEditData = YES;
        [self selectCategoryByType:public];
    }
}

- (IBAction)celebrityButtonSelected:(id)sender{
    if(![_btnCelebrity isSelected]){
        isEditData = YES;
        [self.view addSubview:_viewAreUCeleb];
        [self selectCategoryByType:celebrity];
    }
}

-(void)selectCategoryByType:(NSInteger)catType{
    switch (catType) {
        case private:
            [_btnPrivate setSelected:YES];
            [_btnPublic setSelected:NO];
            [_btnCelebrity setSelected:NO];
            categoryType=private;
            self._categoryView.hidden = NO;
            break;
        case public:
            [_btnPrivate setSelected:NO];
            [_btnPublic setSelected:YES];
            [_btnCelebrity setSelected:NO];
            self._categoryView.hidden = NO;
            categoryType=public;
            break;
        case celebrity:
            [_btnPrivate setSelected:NO];
            [_btnPublic setSelected:NO];
            [_btnCelebrity setSelected:YES];
            self._categoryView.hidden = YES;
            categoryType=celebrity;
            break;
        default:
            break;
    }
}

- (IBAction)createGroup:(id)sender{
    
    NSString *errorMessage=@"";
    if([[_txtGroupName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0)
        errorMessage=@"Please enter group name.";
    else  if(![descriptionView.text isEqualToString:@"Brief Description"] && [[descriptionView.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]] length]==0)
        errorMessage=@"Please enter group description.";
    else if( [categoryId length]==0 && categoryType !=2 )
        errorMessage=@"Please select category type.";
    
    if([errorMessage length]>0){
        [AppHelper showAlertViewWithTag:1 title:AppName message:errorMessage delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
    }
    else{
        if(isEditGroup){
            
            if([self checkIsEditAnyDataOrNot]){
                
                NSDictionary *paramDict=[[NSDictionary alloc] initWithObjectsAndKeys:_txtGroupName.text,@"group_name",[AppHelper userDefaultsForKey:KUserId],@"user_id",descriptionView.text,@"group_description",KAppToken,@"token",[self.groupDescription valueForKey:@"group_id"],@"group_id",prEmail,@"pr_email",categoryId,@"category_id",[NSString stringWithFormat:@"%i",categoryType],@"type", nil];
                
                if ([[AppDelegate getAppDelegate] checkInternateConnection]){
                    
                    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
                    AFHTTPClient *httpClient = [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:BaseURLString]];
                    NSDictionary *params = [NSDictionary dictionaryWithDictionary:paramDict];
                    
                    NSMutableURLRequest *request = [httpClient multipartFormRequestWithMethod:@"POST" path:Method_Edit_Group parameters:params constructingBodyWithBlock: ^(id <AFMultipartFormData>formData){
                        if (coverImageData){
                            [formData appendPartWithFileData:coverImageData name:@"cover_image" fileName:@"temp.jpeg" mimeType:@"image/jpeg"];
                        }
                        if (logoImageData)
                            [formData appendPartWithFileData:logoImageData name:@"profile_image" fileName:@"temp.jpeg" mimeType:@"image/jpeg"];
                    }];
                    [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
                    
                    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
                    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
                        
                        NSError *error;
                        NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
                        NSLog(@"=====%@",dict);
                        dispatch_async(dispatch_get_main_queue(),^{
                            
                            [AppDelegate dismissGlobalHUD];
                            [AppHelper showAlertViewWithTag:1 title:AppName message:@"Group edited successfully. Nice!" delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                            [AppHelper saveToUserDefaults:@"1" withKey:isUpdateGroupProfile];
                            
                            NSDictionary *editedGroupData=[[NSDictionary alloc] initWithObjectsAndKeys:self._imgCoverImage.image,@"cover_image",self._imgGroupIcon.image,@"profile_image",_txtGroupName.text,@"group_name",self.descriptionView.text,@"group_description",[NSString stringWithFormat:@"%i",categoryType],@"type",prEmail,@"pr_email",categoryId,@"category_id",self.labelSelectCategory.text,@"category_name", nil];
                            
                            [[self deligate] updateGroupProfileWithDataDict:editedGroupData];
                            [self.navigationController popViewControllerAnimated:YES];
                        });
                        
                    } failure:^(AFHTTPRequestOperation *operation, NSError *error)
                     {
                         [AppDelegate dismissGlobalHUD];
                     }];
                    [operation start];
                }else{
                    [AppDelegate dismissGlobalHUD];
                    [AppHelper showAlertViewWithTag:1 title:AppName message:ERROR_INTERNET delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                }
            }
            else{
                [self.navigationController popViewControllerAnimated:YES];
            }
        }
        else{
            
            NSDictionary *paramDict=[[NSDictionary alloc] initWithObjectsAndKeys:_txtGroupName.text,@"group_name",categoryId,@"category_id",[AppHelper userDefaultsForKey:KUserId],@"user_id",descriptionView.text,@"group_description",[NSString stringWithFormat:@"%i",categoryType],@"type",KAppToken,@"token",prEmail,@"pr_email", nil];
            NSLog(@"::%@",[paramDict JSONRepresentation]);
            NSLog(@"====%@",Method_Create_Group);
            
            if ([[AppDelegate getAppDelegate] checkInternateConnection]){
                [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
                
                AFHTTPClient *httpClient = [AFHTTPClient clientWithBaseURL:[NSURL URLWithString:BaseURLString]];
                NSDictionary *params = [NSDictionary dictionaryWithDictionary:paramDict];
                
                NSMutableURLRequest *request = [httpClient multipartFormRequestWithMethod:@"POST" path:Method_Create_Group parameters:params constructingBodyWithBlock: ^(id <AFMultipartFormData>formData){
                    if (coverImageData)
                        [formData appendPartWithFileData:coverImageData name:@"cover_image" fileName:@"temp.jpeg" mimeType:@"image/jpeg"];
                    if (logoImageData)
                        [formData appendPartWithFileData:logoImageData name:@"profile_image" fileName:@"temp.jpeg" mimeType:@"image/jpeg"];
                    
                }];
                [httpClient registerHTTPOperationClass:[AFHTTPRequestOperation class]];
                
                AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
                [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject) {
                    
                    [AppDelegate dismissGlobalHUD];
                    
                    NSError *error;
                    NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
                    NSLog(@"===%@",dict);
                    
                    if([[dict valueForKey:@"errorCode"] integerValue] == 0){
                        
                        if(categoryType==2 && [prEmail length]>0)
                            [AppHelper showAlertViewWithTag:1 title:AppName message:@"Your group will go live as soon as it has been approved." delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                        else
                            [AppHelper showAlertViewWithTag:1 title:AppName message:@"Group created successfully. Nicely done!" delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
                        
                        [AppHelper saveToUserDefaults:@"1" withKey:isUpdateGroupProfile];
                        
                        NSDictionary *groupData=nil;
                        
                        if(categoryType == 0){//Private
                            groupData=[NSDictionary dictionaryWithObjectsAndKeys:_txtGroupName.text,@"group_name",self.descriptionView.text,@"group_description",@"Private",@"group_type",selectedCategory,@"category_name",[[dict valueForKey:@"data"] valueForKey:@"group_id"],@"group_id",[[dict valueForKey:@"data"] valueForKey:@"cover_image"],@"cover_image",[[dict valueForKey:@"data"] valueForKey:@"profile_image"],@"image",categoryId,@"category_id", nil];
                        }
                        else if(categoryType == 1){//Public
                            groupData=[NSDictionary dictionaryWithObjectsAndKeys:_txtGroupName.text,@"group_name",self.descriptionView.text,@"group_description",@"Public",@"group_type",selectedCategory,@"category_name",[[dict valueForKey:@"data"] valueForKey:@"group_id"],@"group_id",[[dict valueForKey:@"data"] valueForKey:@"cover_image"],@"cover_image",[[dict valueForKey:@"data"] valueForKey:@"profile_image"],@"image",categoryId,@"category_id", nil];
                        }
                        else if(categoryType ==2 ){//Celebrity
                            groupData=[NSDictionary dictionaryWithObjectsAndKeys:_txtGroupName.text,@"group_name",self.descriptionView.text,@"group_description",@"Celebrity",@"group_type",selectedCategory,@"category_name",[[dict valueForKey:@"data"] valueForKey:@"group_id"],@"group_id",[[dict valueForKey:@"data"] valueForKey:@"cover_image"],@"cover_image",[[dict valueForKey:@"data"] valueForKey:@"profile_image"],@"image",categoryId,@"category_id", nil];
                        }
                        
                        [self performSegueWithIdentifier:@"groupprofile" sender:groupData];
                    }
                    else{
                        [AppHelper showAlertViewWithTag:1 title:AppName message:[dict valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
                    }
                    
                } failure:^(AFHTTPRequestOperation *operation, NSError *error)
                 {
                     NSLog(@"::%@",[error description]);
                     [AppDelegate dismissGlobalHUD];
                 }];
                [operation start];
            }else{
                [AppDelegate dismissGlobalHUD];
                [AppHelper showAlertViewWithTag:1 title:AppName message:ERROR_INTERNET delegate:nil cancelButtonTitle:nil otherButtonTitles:Alert_Ok];
            }
        }
    }
}

- (IBAction)pickerDoneAction:(id)sender{
    
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect=self.pickerView.frame;
                         frameRect.origin.y=568;
                         self.pickerView.frame=frameRect;
                     }
                     completion:nil];
    
    if(selectedCategoryIndex>0)
        categoryId=[[categoryTypeArray objectAtIndex:selectedCategoryIndex] valueForKey:@"category_id"];
        
    selectedCategory=[[categoryTypeArray objectAtIndex:selectedCategoryIndex] valueForKey:@"category_name"];
    
    self.labelSelectCategory.text=selectedCategory;
    self.labelSelectCategory.textColor=[UIColor blackColor];
    
    self.scrollView.contentOffset=CGPointMake(0, 0);
    if(IS_IPHONE_5)
        self.scrollView.contentSize=CGSizeMake(320, 670);
    else
        [self.scrollView setContentSize:CGSizeMake(320,740)];
}

- (IBAction)pickerCancelAction:(id)sender{
    
    [UIView animateWithDuration:0.5f delay:0.0f options:UIViewAnimationOptionTransitionNone
                     animations:^{
                         CGRect frameRect=self.pickerView.frame;
                         frameRect.origin.y=568;
                         self.pickerView.frame=frameRect;
                     }
                     completion:nil];
    
    if(selectedCategoryIndex == 0){
        self.labelSelectCategory.text=@"Select category";
    }
    else{
        if([selectedCategory length] > 0)
            self.labelSelectCategory.text=selectedCategory;
    }
    
    self.scrollView.contentOffset=CGPointMake(0, 0);
    if(IS_IPHONE_5)
        self.scrollView.contentSize=CGSizeMake(320, 670);
    else
        [self.scrollView setContentSize:CGSizeMake(320,740)];
}

- (IBAction)backButton:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark-pickerViewDelegates

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    return [categoryTypeArray count];
}
- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    
    return [[categoryTypeArray objectAtIndex:row] valueForKey:@"category_name"];
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    selectedCategoryIndex=row;
}

#pragma mark-generalMethods
-(void)getCategoryData:(NSNotification*)note{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_CategoryNames object:nil];
    NSLog(@"%@",note.userInfo);
    categoryTypeArray=[NSArray arrayWithArray:[note.userInfo valueForKey:@"data"]];
    [pickerCategory reloadAllComponents];
    if(categoryTypeArray.count>0 && isEditGroup && [categoryId integerValue]>0){
        for (int i=0; i<categoryTypeArray.count; i++){
            NSDictionary *dataDict=[categoryTypeArray objectAtIndex:i];
            
            if([[dataDict valueForKey:@"category_id"] integerValue]==[categoryId integerValue]){
                [self.pickerCategory selectRow:i inComponent:0 animated:NO];
                selectedCategoryIndex=i;
                break;
            }
        }
    }
    [AppDelegate dismissGlobalHUD];
}

#pragma mark Prepare for segue
-(void) prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender{
    NSDictionary *groupDataDict=(NSDictionary*)sender;
    
    if ([segue.identifier isEqualToString:@"groupprofile"]){
        
        GroupProfileVC *grpProfile=segue.destinationViewController;
        grpProfile.name=[groupDataDict valueForKey:@"group_name"];
        grpProfile.groupDescription=[groupDataDict valueForKey:@"group_description"];
        grpProfile.imgUrl=[groupDataDict valueForKey:@"cover_image"];
        grpProfile.groupImageUrl=[groupDataDict valueForKey:@"image"];
        grpProfile.groupId=[groupDataDict valueForKey:@"group_id"];
        grpProfile.categoryName=[groupDataDict valueForKey:@"category_name"];
        grpProfile.categoryId=[groupDataDict valueForKey:@"category_id"];
        grpProfile.groupType=[groupDataDict valueForKey:@"group_type"];
        grpProfile.ownerId=[AppHelper userDefaultsForKey:KUserId];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
