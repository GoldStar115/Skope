//
//  CalendarVC.m
//  youskoop
//
//  Created by Shitesh Patel on 12/06/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "CalendarVC.h"
#import "NSDate+convenience.h"
#import "RequestViewViewController.h"
#import "CellSelectionView.h"
#import "UserProfileVC.h"
#import <EventKit/EventKit.h>
#import "ReplyOnSkoopVC.h"
#import "VideoPlayerVC.h"
#import "AppcustomTabbar.h"
#include "VRGCalendarView.h"
#import "VideoUploaderVC.h"

#define pageLimit  @"30"

@interface CalendarVC ()<updateMyProfileData,VRGCalendarViewDelegate,saveDataProtocol,UITableViewDelegate>
{
    UIView *viewForCalendarBase;
    
    NSMutableArray *monthDataArray; //Array for showing skoop list of selected month
    NSMutableArray *dateSkoopArray; //Array for showing selected date skoops
    
    NSArray *skoopDateArray;      //Array for skoop date used for date marking on calendar
    NSArray *currentMonthDateArray; //Array for skoop date used for date marking on calendar when user tap on today button
    NSArray *currentMonthDataArray;//Array for sync skoop data when user is on calendar
    
    VRGCalendarView *calendar;
    int pageNumber;
    NSInteger selectedIndex;
    BOOL isHitWebService;
    BOOL isShowReplierProfile;
    BOOL isUpdateSkoopList;
    
    __weak IBOutlet UIView *_viewTableviewBase;
    __weak IBOutlet UITableView *_tableView;
    __weak IBOutlet UITableView *_tableViewSkoopReq;
    __weak IBOutlet UIButton *_btnMonth;
    __weak IBOutlet UIButton *_btnList;
    __weak IBOutlet UIButton *_btnToday;
    __weak IBOutlet UIButton *_btnPrevMonth;
    __weak IBOutlet UIButton *_btnNextMonth;
    __weak IBOutlet UILabel *_lblMonth;
    __weak IBOutlet UIButton *_btnSendRequest1;
    __weak IBOutlet UIButton *_btnSendRequest;
    __weak IBOutlet UIButton *_btnSyncCalendar;
    __weak IBOutlet UIButton *_btnSyncCalendar1;
    __weak IBOutlet UIView *_viewReqAnsSyncButton;
    __weak IBOutlet UIView *_viewSkoopRequest;
    __weak IBOutlet UIView *_viewSkoopViewReply;
    __weak IBOutlet UIView *_viewReqAndSyncButton;
}
@end

@implementation CalendarVC

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.frame.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidRefreshCalendar:) name:Notification_Refresh_Calendar object:nil];
    
    _viewTableviewBase.hidden = YES;
    _viewSkoopRequest.hidden = YES;
    _viewSkoopViewReply.hidden = YES;
    
    selectedIndex=-1;
    [_btnMonth setSelected:YES];
    [_btnMonth setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
    [_btnList setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [_btnToday setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [_btnSyncCalendar setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [_btnSendRequest setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [_btnSyncCalendar1 setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [_btnSendRequest1 setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    
    _lblMonth.userInteractionEnabled=YES;
    
    UISwipeGestureRecognizer *rightSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(rightSwipedGesture:)];
    rightSwipe.direction = UISwipeGestureRecognizerDirectionRight;
    rightSwipe.numberOfTouchesRequired = 1;
    [_lblMonth addGestureRecognizer:rightSwipe];
    
    UISwipeGestureRecognizer *leftSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(leftSwipedGesture:)];
    leftSwipe.direction = UISwipeGestureRecognizerDirectionLeft;
    leftSwipe.numberOfTouchesRequired = 1;
    [_lblMonth addGestureRecognizer:leftSwipe];
    
    UIImageView *profileImage=(UIImageView *)[_viewSkoopRequest viewWithTag:208];
    
    UITapGestureRecognizer *uiTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnSenderSkoopProfileImage:)];
    uiTap.numberOfTapsRequired=1;
    profileImage.userInteractionEnabled=YES;
    [profileImage addGestureRecognizer:uiTap];
    
    UIImageView *replyProfileImage=(UIImageView *)[_viewSkoopRequest viewWithTag:219];
    replyProfileImage.backgroundColor=[UIColor lightGrayColor];
    
    UITapGestureRecognizer *uiTap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnReplierSkoopProfileImage:)];
    uiTap1.numberOfTapsRequired=1;
    replyProfileImage.userInteractionEnabled=YES;
    [replyProfileImage addGestureRecognizer:uiTap1];
    
    viewForCalendarBase=[[UIView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, 200)];
    viewForCalendarBase.backgroundColor=[UIColor clearColor];
    
    CGRect frameRect=_tableViewSkoopReq.frame;
    
    if(IS_Greater_Or_Equal_to_IOS_7){
        frameRect.origin.y=104;
        frameRect.size.height=self.view.bounds.size.height-104-42;
        _viewTableviewBase.frame=CGRectMake(0, 104, self.view.frame.size.width, self.view.bounds.size.height-63-104);
    }
    else{
        frameRect.origin.y=84;
        frameRect.size.height=self.view.bounds.size.height-64-12;
        _viewTableviewBase.frame=CGRectMake(0, 84, self.view.frame.size.width, self.view.bounds.size.height-12-84);
    }
    _tableViewSkoopReq.frame=frameRect;

    pageNumber=1;
    isHitWebService=YES;
    monthDataArray=[[NSMutableArray alloc] init];
    [AppHelper saveToUserDefaults:@"1" withKey:isGetMonthSkoop];
    [AppHelper saveToUserDefaults:@"1" withKey:isGetextMonthSkoop];
    
    //Add calendar
    calendar = [[VRGCalendarView alloc] init];
    calendar.delegate=self;
    [viewForCalendarBase addSubview:calendar];
    
    //Add swip geature on calendar
    UISwipeGestureRecognizer * swipeleft=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(onClickRightArrowButton:)];
    swipeleft.direction=UISwipeGestureRecognizerDirectionLeft;
    [calendar addGestureRecognizer:swipeleft];
    
    UISwipeGestureRecognizer * swipeleft1=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(onClickRightArrowButton:)];
    swipeleft1.direction=UISwipeGestureRecognizerDirectionLeft;
    [_viewTableviewBase addGestureRecognizer:swipeleft1];
    
    UISwipeGestureRecognizer * swipeRight=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(onClickLeftArrowButton:)];
    swipeRight.direction=UISwipeGestureRecognizerDirectionRight;
    [calendar addGestureRecognizer:swipeRight];
    
    UISwipeGestureRecognizer * swipeRight1=[[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(onClickLeftArrowButton:)];
    swipeRight1.direction=UISwipeGestureRecognizerDirectionRight;
    [_viewTableviewBase addGestureRecognizer:swipeRight1];
    
    //Add tableview on self.view to show selected date skoops
    _tableViewSkoopReq.tableHeaderView=viewForCalendarBase;
    [self.view addSubview:_tableViewSkoopReq];
    
    viewForCalendarBase.backgroundColor=[UIColor clearColor];
    
    //Set month background color
    UIImageView *imgView=(UIImageView*)[self.view viewWithTag:5555];
    imgView.backgroundColor=[UIColor colorWithRed:76.0/255.0 green:30.0/255.0 blue:130.0/255.0 alpha:1.0];
}

-(void)viewWillAppear:(BOOL)animated{
    if([_btnList isSelected])
        [_tableView reloadData];
    else
        [_tableViewSkoopReq reloadData];
}

-(void)getCurrentMonthSkoopDataWithBool:(BOOL)isGetSkoopDates{
    
    //Hit service for getting skoop date to show dots on calender
    if(isGetSkoopDates){
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetMonthSkoopData:) name:Notification_Get_Month_Skoop object:nil];
        [[WebServicesController WebServiceMethod] getMonthSkoopsWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopMonth:[NSString stringWithFormat:@"%i-%i",[[calendar currentMonth] year],[[calendar currentMonth] month]] andAppToken:KAppToken andSkoopdate:@""];
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetListData:) name:Notification_Get_Calendar_Skoop object:nil];
     
    if([_btnList isSelected]){
        
        if(isUpdateSkoopList)
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        
        [[WebServicesController WebServiceMethod] getUserSkoopsWithUserId:[AppHelper userDefaultsForKey:KUserId] pageNumber:[NSString stringWithFormat:@"%i",pageNumber] pagelimit:pageLimit skoopDate:[NSString stringWithFormat:@"%i-%i",[[calendar currentMonth] year],[[calendar currentMonth] month]] andAppToken:KAppToken];
    }
    else{
        [[WebServicesController WebServiceMethod] getUserSkoopsWithUserId:[AppHelper userDefaultsForKey:KUserId] pageNumber:@"1" pagelimit:@"0" skoopDate:[NSString stringWithFormat:@"%i-%i",[[calendar currentMonth] year],[[calendar currentMonth] month]] andAppToken:KAppToken];
    }
}

#pragma mark Swipgasture methods

- (void)rightSwipedGesture:(UIGestureRecognizer *)recognizer
{
    NSLog(@"I swiped right;)");
//    if([_btnMonth isSelected] || [_btnToday isSelected])
//    {
//        dateSkoopArray=nil;
//        [_tableViewSkoopReq reloadData];
//    }
    
    [calendar showPreviousMonth];
}

- (void)leftSwipedGesture:(UIGestureRecognizer *)recognizer
{
    NSLog(@"I swiped left;)");
//    if([_btnMonth isSelected] || [_btnToday isSelected])
//    {
//        dateSkoopArray=nil;
//        [_tableViewSkoopReq reloadData];
//    }
    [calendar showNextMonth];
}

#pragma mark Protocol methods
-(void)setRequiredBoolVariable:(BOOL)boolValue
{
    
}

-(void)updateSkoopReplyDataWithDataDict:(NSDictionary*)dataDict
{
    NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[dateSkoopArray objectAtIndex:selectedIndex]];
    [dict setValue:@"0" forKey:@"upload"];
    [dict setValue:dataDict forKey:@"reply"];
    [dateSkoopArray replaceObjectAtIndex:selectedIndex withObject:dict];
    [_tableViewSkoopReq reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
    
    [[WebServicesController WebServiceMethod] parseSkoopReplyDataWithDataDictionary:dataDict];
}

-(void)updateLPReplyStatusOnCalendatTab{
    
    //dateSkoopArray
    NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[dateSkoopArray objectAtIndex:selectedIndex]];
    [dict setValue:@"1" forKey:@"reply_status"];
    [dateSkoopArray replaceObjectAtIndex:selectedIndex withObject:dict];
    [_tableViewSkoopReq reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark Button action methods

-(IBAction)onClickBackButton:(id)sender{
    
    //Select skoop tab
    [self.tabBarController.delegate tabBarController:self.tabBarController shouldSelectViewController:[[self.tabBarController viewControllers] objectAtIndex:[[AppHelper userDefaultsForKey:KPreSelectedTab] integerValue]]];
    [self.tabBarController setSelectedIndex:[[AppHelper userDefaultsForKey:KPreSelectedTab] integerValue]];
}

-(IBAction)onClickMonthButton:(id)sender
{
    NSLog(@"onClickMonthButton");
    _viewSkoopRequest.hidden = YES;
    _viewSkoopViewReply.hidden = YES;
    
    [_btnMonth setSelected:YES];
    [_btnList setSelected:NO];
    [_btnToday setSelected:NO];
    
    [_btnMonth setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
    [_btnList setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [_btnToday setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    
    _tableViewSkoopReq.hidden=NO;
    _viewTableviewBase.hidden=YES;
}

-(IBAction)onClickListButton:(id)sender{
    
    [_btnMonth setSelected:NO];
    [_btnList setSelected:YES];
    [_btnToday setSelected:NO];
    
    [_btnList setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
    [_btnMonth setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [_btnToday setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    
    if(pageNumber==1)
    {
        isUpdateSkoopList=YES;
        [self getCurrentMonthSkoopDataWithBool:NO];
    }
    _tableViewSkoopReq.hidden=YES;
    _viewTableviewBase.hidden=NO;
    [self performSelector:@selector(reloadListTableView) withObject:nil afterDelay:0.2];
}

-(void)reloadListTableView
{
    [_tableView reloadData];
}

-(IBAction)onClickTodayButton:(id)sender{
    
    NSLog(@"onClickTodayButton");
    _viewSkoopRequest.hidden = YES;
    _viewSkoopViewReply.hidden = YES;
    
    [_btnMonth setSelected:NO];
    [_btnList setSelected:NO];
    [_btnToday setSelected:YES];
    
    [_btnToday setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
    [_btnList setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    [_btnMonth setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    
    if([[NSDate date] day]==[[calendar currentMonth] day] && [[NSDate date] month]==[[calendar currentMonth] month] && [[NSDate date] year]==[[calendar currentMonth] year])
    {
        [calendar selectDate:[[NSDate date] day]];
    }
    else
    {
        [calendar selectCurrentMonthAndDate];
        skoopDateArray=nil;
        skoopDateArray = [NSArray arrayWithArray:currentMonthDateArray];
        [calendar.delegate calendarView:calendar switchedToMonth:[calendar.currentMonth month] targetHeight:[calendar calendarHeight] animated:NO];
       // [_tableViewSkoopReq reloadData];
        
        [self performSelector:@selector(setSelectedMonth) withObject:nil afterDelay:0.2];
    }
    
    _tableViewSkoopReq.hidden=NO;
    _viewTableviewBase.hidden=YES;
    //[_tableViewSkoopReq reloadData];
}

-(void)setSelectedMonth
{
    _lblMonth.text=calendar.labelCurrentMonth.text;
    [calendar selectDate:[[NSDate date] day]];
}

-(IBAction)onClickLeftArrowButton:(id)sender
{
    if([_btnMonth isSelected] || [_btnToday isSelected])
    {
        dateSkoopArray=nil;
       // [_tableViewSkoopReq reloadData];
        if([_btnToday isSelected])
        {
            [_btnMonth setSelected:YES];
            [_btnList setSelected:NO];
            [_btnToday setSelected:NO];
            
            [_btnMonth setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
            [_btnList setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
            [_btnToday setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        }
    }
    else if([_btnList isSelected])
    {
        _viewSkoopRequest.hidden = YES;
        _viewSkoopViewReply.hidden = YES;
    }
    [calendar showPreviousMonth];
}

-(IBAction)onClickRightArrowButton:(id)sender
{
    if([_btnMonth isSelected] || [_btnToday isSelected])
    {
        if([_btnToday isSelected])
        {
            [_btnMonth setSelected:YES];
            [_btnList setSelected:NO];
            [_btnToday setSelected:NO];
            
            [_btnMonth setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
            [_btnList setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
            [_btnToday setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        }
    }
    else if([_btnList isSelected])
    {
        _viewSkoopRequest.hidden = YES;
        _viewSkoopViewReply.hidden = YES;
    }
    
    [calendar showNextMonth];
}

-(IBAction)onClickSendRequestButton:(id)sender
{
    if((UIButton*)sender==_btnSendRequest)
    {
        [_btnSendRequest setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
        [_btnSyncCalendar setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    }
    else if((UIButton*)sender==_btnSendRequest1)
    {
        [_btnSendRequest1 setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
        [_btnSyncCalendar1 setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    }
    
    [self performSegueWithIdentifier:@"sendrequest" sender:nil];
}

-(IBAction)onClickSyncCalendarButton:(id)sender{
    
    if((UIButton*)sender == _btnSyncCalendar){
        
        [_btnSyncCalendar setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
        [_btnSendRequest setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    }
    else if((UIButton*)sender == _btnSyncCalendar1){
        
        [_btnSyncCalendar1 setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
        [_btnSendRequest1 setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    }
    
    BOOL isNoSkoopReq=YES;
    NSString *skoopIds=@"";
    
    if([_btnList isSelected]){
        
        for (int i=0,j=0; i<monthDataArray.count; i++){
            
            NSDictionary *dataDict=[monthDataArray objectAtIndex:i];
           // if(![[dataDict valueForKey:@"sync_status"] isKindOfClass:[NSNull class]] && [[dataDict valueForKey:@"sync_status"] integerValue]==0){
                
                isNoSkoopReq=NO;
                if(j==0)
                    skoopIds=[skoopIds stringByAppendingString:[dataDict valueForKey:@"skoop_id"]];
                else
                    skoopIds=[skoopIds stringByAppendingString:[NSString stringWithFormat:@",%@",[dataDict valueForKey:@"skoop_id"]]];
                j++;
                
                [self createReminderWithData:dataDict];
           // }
        }
    }
    else{
        
        for (int i=0,j=0; i<currentMonthDataArray.count; i++){
            
            NSDictionary *dataDict=[currentMonthDataArray objectAtIndex:i];
           // if(![[dataDict valueForKey:@"sync_status"] isKindOfClass:[NSNull class]] && [[dataDict valueForKey:@"sync_status"] integerValue]==0){
                
                isNoSkoopReq=NO;
                if(j==0)
                    skoopIds=[skoopIds stringByAppendingString:[dataDict valueForKey:@"skoop_id"]];
                else
                    skoopIds=[skoopIds stringByAppendingString:[NSString stringWithFormat:@",%@",[dataDict valueForKey:@"skoop_id"]]];
                j++;
                
                [self createReminderWithData:dataDict];
            //}
        }
    }
    
    [self performSelector:@selector(getBlockedGroupSkoop) withObject:Nil afterDelay:1.0];
}

//Get blocked group skoop
-(void)getBlockedGroupSkoop{
    
    //Get group blocked skoops
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetGroupBlockedSkoops:) name:Notification_Get_Blocked_Skoop object:Nil];
        [[WebServicesController WebServiceMethod] getBlockedSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] andAppToken:KAppToken];
    });
}

-(IBAction)onClickReplyOnSkoop:(id)sender
{
    NSDictionary *dataDict=[monthDataArray objectAtIndex:selectedIndex];
    if([dataDict valueForKey:@"reply"]){
        VideoPlayerVC *videoPlayerVC = [self.storyboard instantiateViewControllerWithIdentifier:@"VideoPlayerVC"];
        videoPlayerVC.videoURL =[[dataDict valueForKey:@"reply"] valueForKey:@"video_path"];
        videoPlayerVC.isShowingOwnVideo = YES;
        videoPlayerVC.selecteDataDict = [NSMutableDictionary dictionaryWithDictionary:dataDict];
        [self.navigationController pushViewController:videoPlayerVC animated:NO];
    }
    else{
        [self performSegueWithIdentifier:@"skoop_req" sender:dataDict];
    }
}

-(IBAction)onClickShowReplyOnSkoop:(id)sender
{
    NSDictionary *dataDict=[monthDataArray objectAtIndex:selectedIndex];
    [self performSegueWithIdentifier:@"showskoopreply" sender:dataDict];
}

#pragma mark Services response and receive notifications

-(void)userDidGetMonthSkoopData:(NSNotification*)note{
    
    NSLog(@"%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Month_Skoop object:nil];
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0){
        skoopDateArray=nil;
        
        NSArray *dateArray=[note.userInfo valueForKey:@"data"];
        NSDictionary *skoopDataDict=[NSDictionary dictionaryWithObjectsAndKeys:[dateArray valueForKey:@"request"],@"request",[dateArray valueForKey:@"skoop"],@"skoop", nil];
        
        skoopDateArray=[NSArray arrayWithObject:skoopDataDict];
        
        //Save current month skoop date in currentMonthDateArray array for today button functionality
        if([[calendar currentMonth] month]==[[NSDate date] month] && !currentMonthDateArray)
            currentMonthDateArray=[NSArray arrayWithArray:skoopDateArray];
        
        [calendar.delegate calendarView:calendar switchedToMonth:[calendar.currentMonth month] targetHeight:[calendar calendarHeight] animated:NO];
        
        if([dateArray valueForKey:@"skoopRequest"]){
            
            //Add tableview for show selected date skoops
            if([_tableViewSkoopReq superview] == nil)
                [self.view addSubview:_tableViewSkoopReq];
            
            dateSkoopArray=nil;
            dateSkoopArray=[NSMutableArray arrayWithArray:[dateArray valueForKey:@"skoopRequest"]];
            [_tableViewSkoopReq reloadData];
        }
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(void)userDidGetDateSkoopData:(NSNotification*)note{
    
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Calendar_Skoop object:nil];
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0){
        
        //Add tableview for show selected date skoops
        if([_tableViewSkoopReq superview] == nil)
            [self.view addSubview:_tableViewSkoopReq];
        
        dateSkoopArray=nil;
        dateSkoopArray=[NSMutableArray arrayWithArray:[note.userInfo valueForKey:@"data"]];
        [_tableViewSkoopReq reloadData];
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(void)userDidGetListData:(NSNotification*)note{
    
    [AppDelegate dismissGlobalHUD];
    NSLog(@"%@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Calendar_Skoop object:nil];
    if(note.userInfo && [[note.userInfo valueForKey:@"errorCode"] integerValue]==0){
        
        NSArray *dataArray=[note.userInfo valueForKey:@"data"];
        if([_btnList isSelected]){
            
            NSMutableArray *newRows = [NSMutableArray array];
            int previousRowCount = (int)monthDataArray.count;
            if(dataArray.count>0){
                for (NSDictionary * dict in dataArray) {
                    [monthDataArray addObject:dict];
                    [newRows addObject:[NSIndexPath indexPathForRow:previousRowCount++ inSection:0]];
                }
            }
            else
                isHitWebService=NO;
            
            pageNumber++;
            if(isUpdateSkoopList){
                
                _viewSkoopRequest.hidden = YES;
                _viewSkoopViewReply.hidden = YES;
                
                [_tableView reloadData];
                [calendar.delegate calendarView:calendar switchedToMonth:[calendar.currentMonth month] targetHeight:[calendar calendarHeight] animated:NO];
            }
            else{
                if(newRows.count){
                    [_tableView beginUpdates];
                    [_tableView insertRowsAtIndexPaths:newRows withRowAnimation:UITableViewRowAnimationNone];
                    [_tableView endUpdates];
                }
            }
        }
        else
        {
            currentMonthDataArray=dataArray;
        }
    }
    else
        [AppHelper showAlertViewWithTag:1 title:AppName message:[note.userInfo valueForKey:@"errorMessage"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
}

-(void)userDidReplyOnSkoop:(NSNotification *)notification
{
    
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_reply_on_skoop object:nil];
    
    if([notification.userInfo valueForKey:@"skoop_id"])
    {
        [[WebServicesController WebServiceMethod] deleteFileFromDocumentDirectoryWithFileName:[NSString stringWithFormat:@"movie%@.mov",[notification.userInfo valueForKey:@"skoop_id"]]];
        [[WebServicesController WebServiceMethod] deleteSkoopWithSkoopId:[notification.userInfo valueForKey:@"skoop_id"]];
    }
    
    if(selectedIndex<dateSkoopArray.count)
    {
        NSMutableDictionary *dict=[NSMutableDictionary dictionaryWithDictionary:[dateSkoopArray objectAtIndex:selectedIndex]];
        [dict setValue:@"1" forKey:@"upload"];
        NSMutableDictionary *replyDict=[NSMutableDictionary dictionaryWithDictionary:[dict valueForKey:@"reply"]];
        
        if([notification.userInfo valueForKey:@"video_path"] && [[notification.userInfo valueForKey:@"skoop_id"] isEqualToString:[dict valueForKey:@"skoop_id"]])
        {
            [replyDict setValue:[notification.userInfo valueForKey:@"video_path"] forKey:@"video_path"];
            if([replyDict valueForKey:@"video_data"])
                [replyDict removeObjectForKey:@"video_data"];
            [dict setValue:replyDict forKey:@"reply"];
            [dateSkoopArray replaceObjectAtIndex:selectedIndex withObject:dict];
            [_tableViewSkoopReq reloadRowsAtIndexPaths:[NSArray arrayWithObject:[NSIndexPath indexPathForRow:selectedIndex inSection:0]] withRowAnimation:UITableViewRowAnimationNone];
        }
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnSkoop:) name:Notification_reply_on_skoop object:nil];
}

-(void)userDidSyncSkoopIntoCalendar:(NSNotification *)notification
{
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Sync_Skoop object:nil];
    if (notification.userInfo){
        
        if([[notification.userInfo objectForKey:@"errorCode"] intValue]==0)
            [AppHelper showAlertViewWithTag:1 title:AppName message:@"Awesome! You just synced all the Skoop requests from other users with your phone’s default calendar." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetGroupBlockedSkoops:) name:Notification_Get_Blocked_Skoop object:Nil];
            [[WebServicesController WebServiceMethod] getBlockedSkoopWithUserId:[AppHelper userDefaultsForKey:KUserId] andAppToken:KAppToken];
        });
    }
}

-(void)userDidGetGroupBlockedSkoops:(NSNotification *)notification{
    
    NSLog(@":::%@",notification.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Get_Blocked_Skoop object:nil];
    if (notification.userInfo){
        
        if([[notification.userInfo objectForKey:@"errorCode"] intValue] ==0 ){
            
            if([notification.userInfo objectForKey:@"data"] && [[notification.userInfo objectForKey:@"data"] count]>0){
                
                NSArray *blockSkoopData = [notification.userInfo objectForKey:@"data"];
                for (NSDictionary *dataDict in blockSkoopData) {
                    
                    [[AppDelegate getAppDelegate] deleteSkoopEventFromCalendarWithDict:dataDict];
                }
            }
        }
    }
}

-(void)userDidRefreshCalendar:(NSNotification *)notification{
    
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Refresh_Calendar object:nil];
    
    if([_btnMonth isSelected] || [_btnToday isSelected]){
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetMonthSkoopData:) name:Notification_Get_Month_Skoop object:nil];
        if([calendar selectedDate] && notification.object && [notification.object isEqualToString:@"refresh"]){//Update skoop list when user blocked or unblocked from any group
            
           [[WebServicesController WebServiceMethod] getMonthSkoopsWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopMonth:[NSString stringWithFormat:@"%i-%i",[[calendar currentMonth] year],[[calendar currentMonth] month]] andAppToken:KAppToken andSkoopdate:[NSString stringWithFormat:@"%i-%i-%i",[[calendar currentMonth] year],[[calendar currentMonth] month],[[calendar selectedDate] day]]];
        }
        else if(notification.object && dateSkoopArray && dateSkoopArray.count){//Update skoop list of selected date if anyone has deleted
           
            for (NSDictionary *dataDict in dateSkoopArray) {
                
                if([[dataDict valueForKey:@"skoop_id"] isEqualToString:(NSString*)notification.object]){
                    
                    [dateSkoopArray removeObject:dataDict];
                    [_tableViewSkoopReq reloadData];
                    break;
                }
             }
            [[WebServicesController WebServiceMethod] getMonthSkoopsWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopMonth:[NSString stringWithFormat:@"%i-%i",[[calendar currentMonth] year],[[calendar currentMonth] month]] andAppToken:KAppToken andSkoopdate:@""];
        }
        else{
            
            [[WebServicesController WebServiceMethod] getMonthSkoopsWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopMonth:[NSString stringWithFormat:@"%i-%i",[[calendar currentMonth] year],[[calendar currentMonth] month]] andAppToken:KAppToken andSkoopdate:@""];
        }
    }
    else
    {
        _viewSkoopRequest.hidden = YES;
        _viewSkoopViewReply.hidden = YES;
        
        if(monthDataArray && [monthDataArray count]>0)
            [monthDataArray removeAllObjects];
            
        isHitWebService=YES;
        pageNumber=1;
        isUpdateSkoopList=YES;
        [self getCurrentMonthSkoopDataWithBool:NO];
    }
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidRefreshCalendar:) name:Notification_Refresh_Calendar object:nil];
}


#pragma mark Sync calendar data
-(void)createReminderWithData:(NSDictionary*)dataDict
{
    EKEventStore *eventStore = [[EKEventStore alloc] init];
    [eventStore requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error)
     {
         if (!granted) { return; }
         
         EKEvent *event  = [EKEvent eventWithEventStore:eventStore];
         
         NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
         [dateFormatter setDateFormat:@"EEE,hh:mm a,MM/dd, yyyy"];
                  
         NSDate *evenStartDate=[dateFormatter dateFromString:[dataDict valueForKey:@"date"]];
         
         event.startDate=evenStartDate;
         if([dataDict valueForKey:@"reminder_time"] && [[dataDict valueForKey:@"reminder_time"] integerValue]>0)
             evenStartDate=[evenStartDate dateByAddingTimeInterval:[[dataDict valueForKey:@"reminder_time"] integerValue]*60];
         else
             evenStartDate=[evenStartDate dateByAddingTimeInterval:3600];
         event.endDate=evenStartDate;
         
         if([dataDict valueForKey:@"searchText"])
         {
             if([[dataDict valueForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
                 event.title = [NSString stringWithFormat:@"youSKOOP:%@(My Request)",[dataDict valueForKey:@"searchText"]];
             else
                 event.title = [NSString stringWithFormat:@"youSKOOP:%@(User Request)",[dataDict valueForKey:@"searchText"]];
         }
         else
             event.title = @"youSKOOP:Reminder";
         
         event.location=[dataDict valueForKey:@"location"];
         event.notes=[dataDict valueForKey:@"location"];
         
         // Get an array of all the calendars.
         NSArray *calendars = [eventStore calendarsForEntityType:EKEntityTypeEvent];
         
         // Get the default calendar, set by the user in preferences.
         EKCalendar *defaultCal = eventStore.defaultCalendarForNewEvents;
         
         // Find out if this calendar is modifiable.
         BOOL isDefaultCalModifiable = defaultCal.allowsContentModifications ;
         
         NSPredicate *predicate = [eventStore predicateForEventsWithStartDate:event.startDate
                                                                 endDate:event.endDate calendars:calendars];
         
         NSArray *matchingEvents = [eventStore eventsMatchingPredicate:predicate];         
         
         if( ! isDefaultCalModifiable) {
             // The default calendar is not modifiable
             NSLog(@"The default calendar is not modifiable");
             [AppHelper showAlertViewWithTag:1 title:AppName message:@"The default calendar is not modifiable" delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
             return ;
         }
         
         if([matchingEvents count] > 0)
         {
             NSLog(@"Event already added");
             return ;
         }
         
         [event setCalendar:[eventStore defaultCalendarForNewEvents]];
         
         NSError *err;
         BOOL isSuccess= [eventStore saveEvent:event span:EKSpanThisEvent error:&err];
         NSLog(@"isSuccess:::::%i              :::::::%@",isSuccess,err);
     }];
}

#pragma mark Calendar deligates
-(void)calendarView:(VRGCalendarView *)calendarView switchedToMonth:(int)month targetHeight:(float)targetHeight animated:(BOOL)animated{
    
    [calendar markDates:skoopDateArray];
    
    if([_btnMonth isSelected] || [_btnToday isSelected]){
        
        CGRect frameRect1=viewForCalendarBase.frame;
        frameRect1.size.height=[calendar calendarHeight]-35;
        viewForCalendarBase.frame=frameRect1;
        _tableViewSkoopReq.tableHeaderView=nil;
        _tableViewSkoopReq.tableHeaderView=viewForCalendarBase;
    }
    
    if([_btnList isSelected]){
        
        if([AppHelper userDefaultsForKey:isGetextMonthSkoop]){//Check to prevent loop
            
            [AppHelper removeFromUserDefaultsWithKey:isGetextMonthSkoop];
            
            if(monthDataArray && monthDataArray.count>0)
                [monthDataArray removeAllObjects];
            
            pageNumber=1;
            isHitWebService=YES;
            isUpdateSkoopList=YES;
            [self getCurrentMonthSkoopDataWithBool:YES];
        }
    }
    else if ([_btnMonth isSelected] || [_btnToday isSelected]){
        
        if([AppHelper userDefaultsForKey:isGetMonthSkoop]){//Check to prevent loop
            
            [AppHelper removeFromUserDefaultsWithKey:isGetMonthSkoop];
            [self getCurrentMonthSkoopDataWithBool:YES];
        }
    }
    _lblMonth.text=calendar.labelCurrentMonth.text;
}

-(void)calendarView:(VRGCalendarView *)calendarView dateSelected:(NSDate *)date{
    
    if([date day]==[[NSDate date] day]){
        
        [_btnMonth setSelected:NO];
        [_btnList setSelected:NO];
        [_btnToday setSelected:YES];
        
        [_btnToday setBackgroundColor:[UIColor colorWithRed:67.0/255.0 green:91.0/255.0 blue:144.0/255.0 alpha:1.0]];
        [_btnList setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
        [_btnMonth setBackgroundColor:[UIColor colorWithRed:14.0/255.0 green:62.0/255.0 blue:129.0/255.0 alpha:1.0]];
    }
    else{
        [self onClickMonthButton:nil];
    }
    
    BOOL isDatePresent=NO;
    
    NSArray *requestArray=[NSArray arrayWithArray:[[skoopDateArray objectAtIndex:0] valueForKey:@"request"]];
    NSArray *skoopArray=[NSArray arrayWithArray:[[skoopDateArray objectAtIndex:0] valueForKey:@"skoop"]];
    
    for (int i=0; i<requestArray.count; i++){
        if([[requestArray objectAtIndex:i] integerValue]==[date day]){
            isDatePresent=YES;
            break;
        }
    }
    
    if(!isDatePresent){
        for (int i=0; i<skoopArray.count; i++){
            if([[skoopArray objectAtIndex:i] integerValue]==[date day]){
                isDatePresent=YES;
                break;
            }
        }
    }
    
    if(isDatePresent){
        
        [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidGetDateSkoopData:) name:Notification_Get_Calendar_Skoop object:nil];
        [[WebServicesController WebServiceMethod] getUserSkoopsWithUserId:[AppHelper userDefaultsForKey:KUserId] pageNumber:@"0" pagelimit:@"0" skoopDate:[NSString stringWithFormat:@"%i-%i-%i",[date year],[date month],[date day]] andAppToken:KAppToken];
    }
    else{
        dateSkoopArray=nil;
        [_tableViewSkoopReq reloadData];
    }
}

#pragma mark tableView Delegates
//- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
//    if(tableView==_tableView)
//        return 40;
//    else
//        return 0;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if(tableView==_tableViewSkoopReq)
        return 40;
    else
        return 0;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if(tableView==_tableViewSkoopReq)
        return _viewReqAnsSyncButton;
    else
        return nil;
}

//- (UIView *)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
//{
//    if(tableView==_tableView)
//        return _viewReqAndSyncButton;
//    else
//        return nil;
//}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == _tableView)//Listview cell height
        return 59;
    else{
        NSDictionary *dictOfScoop = [dateSkoopArray objectAtIndex:indexPath.row];
        CGFloat cellHeight ;
        if([dictOfScoop valueForKey:@"reply"])
            cellHeight = 185;
        else if([[dictOfScoop valueForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
            cellHeight = 103;
        else
            cellHeight = 97;
        
        if(indexPath.row == dateSkoopArray.count-1)
            return cellHeight + 20;
        else
            return cellHeight;
    }
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView==_tableView)
        return monthDataArray.count;
    else
        return dateSkoopArray.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dictOfScoop=nil;
    
    if(tableView==_tableView && indexPath.row<monthDataArray.count)
        dictOfScoop=[monthDataArray objectAtIndex:indexPath.row];
    else if(indexPath.row<dateSkoopArray.count)
        dictOfScoop=[dateSkoopArray objectAtIndex:indexPath.row];
    
    UITableViewCell *cell=nil;
    
    if(tableView==_tableView)//Tableview for showing list tab skoops
    {
        cell = [tableView dequeueReusableCellWithIdentifier:@"ListCell"];
        
        if(cell==nil)
        {
            NSArray *topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"ListCell" owner:self options:nil];
            // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
            cell = [topLevelObjects objectAtIndex:0];
            cell.layer.borderColor=[UIColor grayColor].CGColor;
            cell.backgroundColor=[UIColor clearColor];
            
            UIView *customColorView = [[UIView alloc] init];
            customColorView.backgroundColor = [UIColor colorWithRed:126/255.0 green:170/255.0 blue:251/255.0 alpha:0.5];
            cell.selectedBackgroundView =  customColorView;
        }
        
        if(indexPath.row==monthDataArray.count-1 && isHitWebService)
        {
            isUpdateSkoopList=NO;
            [self getCurrentMonthSkoopDataWithBool:NO];
        }
        
        UIImageView *skoopTypeImage=(UIImageView *)[cell.contentView viewWithTag:1];
        if([[dictOfScoop valueForKey:@"user_id"] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
        {
            skoopTypeImage.image=[UIImage imageNamed:@"skoop_icon.png"];
            CGRect frameRect=skoopTypeImage.frame;
            frameRect.size.height=25.0;
            frameRect.size.width=20.0;
            skoopTypeImage.frame=frameRect;
        }
        else
        {
            skoopTypeImage.image=[UIImage imageNamed:@"lens_icon.png"];
            CGRect frameRect=skoopTypeImage.frame;
            frameRect.size.height=35.0;
            frameRect.size.width=35.0;
            skoopTypeImage.frame=frameRect;
        }
        
        UILabel *lblDay=(UILabel *)[cell.contentView viewWithTag:2];
        lblDay.text=[[[[dictOfScoop valueForKey:@"date"] componentsSeparatedByString:@","] objectAtIndex:0] uppercaseString];
        
        UILabel *lblDate=(UILabel *)[cell.contentView viewWithTag:3];
        lblDate.textColor= KTextColor;
        
        if([[[dictOfScoop valueForKey:@"date"] componentsSeparatedByString:@","] count]>2)
            lblDate.text=[[[dictOfScoop valueForKey:@"date"] componentsSeparatedByString:@","] objectAtIndex:2];
        
        UILabel *lblTime=(UILabel *)[cell.contentView viewWithTag:4];
        lblTime.textColor=KTextColor;
        if([[[dictOfScoop valueForKey:@"date"] componentsSeparatedByString:@","] count]>1)
            lblTime.text=[[[dictOfScoop valueForKey:@"date"] componentsSeparatedByString:@","] objectAtIndex:1];
        
        UILabel *lblTitle=(UILabel *)[cell.contentView viewWithTag:5];
        UILabel *lblTitle1=(UILabel *)[cell.contentView viewWithTag:8];
        
        NSString *str=@"this is to test line 12 and line 2 calendar list view";
        str=[dictOfScoop valueForKey:@"searchText"];
        
        //Show string in to 2 lines
        if([str length] > 22)
        {
            if([[str substringWithRange:NSMakeRange(22, 1)] isEqual:@" "])
            {
                lblTitle1.text=[str substringWithRange:NSMakeRange(0, 22)];
                lblTitle.text=[str substringWithRange:NSMakeRange(23, [str length]-23)];
            }
            else
            {
                int i;
                for (i=22; i>=0; i--) {
                    if([[str substringWithRange:NSMakeRange(i, 1)] isEqual:@" "])
                        break;
                }
                
                lblTitle1.text=[str substringWithRange:NSMakeRange(0, i)];
                lblTitle.text=[str substringWithRange:NSMakeRange(i, [str length]-i)];
            }
        }
        else
            lblTitle.text=str;
        
        
        UILabel *lblLocationOrGroup=(UILabel *)[cell.contentView viewWithTag:6];
        lblLocationOrGroup.textColor=KTextColor;
        if([[dictOfScoop valueForKey:@"group_id"] integerValue]>0)
            lblLocationOrGroup.text=[NSString stringWithFormat:@"Group: %@",[dictOfScoop valueForKey:@"group_name"]];
        else
            lblLocationOrGroup.text=[NSString stringWithFormat:@"Location: %@",[dictOfScoop valueForKey:@"location"]];
        
        UILabel *lblPrice=(UILabel *)[cell.contentView viewWithTag:7];
        lblPrice.textColor=KTextColor;
        if([[dictOfScoop valueForKey:@"price"] floatValue]>0)
            lblPrice.text=[NSString stringWithFormat:@"$%@",[dictOfScoop valueForKey:@"price"]];
        else
            lblPrice.text=@"Favor";
    }
    else//Tableview for showing selected date skoop
    {
        
        if([dictOfScoop objectForKey:@"reply"])
            cell = [tableView dequeueReusableCellWithIdentifier:@"SkoopReqRep"];
        else if([[dictOfScoop objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
            cell = [tableView dequeueReusableCellWithIdentifier:@"SendSkoopReq"];
        else
            cell = [tableView dequeueReusableCellWithIdentifier:@"SkoopRequest"];
        
        if (cell == nil)
        {
            NSLog(@"****************nil*********************");
            NSArray *topLevelObjects = nil;
            if([dictOfScoop objectForKey:@"reply"])
                topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SkoopReqRep" owner:self options:nil];
            else if([[dictOfScoop objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
                topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SendSkoopReq" owner:self options:nil];
            else
                topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SkoopRequest" owner:self options:nil];
            // Grab a pointer to the first object (presumably the custom cell, as that's all the XIB should contain).
            cell = [topLevelObjects objectAtIndex:0];
            cell.layer.borderColor=[UIColor grayColor].CGColor;
            cell.backgroundColor=[UIColor clearColor];
            
            if([dictOfScoop objectForKey:@"reply"])
            {
                UIImageView *replyProfileImage=(UIImageView *)[cell.contentView viewWithTag:219];
                UITapGestureRecognizer *uiTap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnReplierSkoopProfileImage:)];
                uiTap1.numberOfTapsRequired=1;
                replyProfileImage.userInteractionEnabled=YES;
                [replyProfileImage addGestureRecognizer:uiTap1];
            }
            else if([[dictOfScoop objectForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
            {
                
            }
            else
            {
                UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:208];
                UITapGestureRecognizer *uiTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnSenderSkoopProfileImage:)];
                uiTap.numberOfTapsRequired=1;
                profileImage.userInteractionEnabled=YES;
                [profileImage addGestureRecognizer:uiTap];
            }
        }
        
        //Condition for user's created skoops
        if([[dictOfScoop valueForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]])
        {
            CBAutoScrollLabel *lblSkoopName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:101];
            [lblSkoopName setLabelSettingForObject:@"skoop"];
            lblSkoopName.text=[dictOfScoop valueForKey:@"searchText"];
            
            UILabel *lblLocation=(UILabel *)[cell.contentView viewWithTag:102];
            if([dictOfScoop valueForKey:@"group_name"] && [[dictOfScoop valueForKey:@"group_name"] length]>0)
                lblLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfScoop valueForKey:@"group_name"]];
            else
                lblLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfScoop valueForKey:@"location"]];
            
            UILabel *lblDate=(UILabel *)[cell.contentView viewWithTag:103];
            lblDate.text=[NSString stringWithFormat:@"Time: %@",[dictOfScoop valueForKey:@"date"]];
            
            UILabel *lblCost=(UILabel *)[cell.contentView viewWithTag:104];
            UILabel *lblReplies=(UILabel *)[cell.contentView viewWithTag:107];
            
            if([[dictOfScoop valueForKey:@"price"] floatValue]>0)
                lblCost.text=[NSString stringWithFormat:@"$%@",[dictOfScoop valueForKey:@"price"]];
            else
                lblCost.text=@"Favor";
            
            UIImageView *imgRedCircle=(UIImageView *)[cell.contentView viewWithTag:105];
            if([[dictOfScoop valueForKey:@"live_portal"] integerValue] == 1){
                imgRedCircle.image=[UIImage imageNamed:@"noti_lp.png"];
                lblReplies.text = @"Users";
            }
            else{
                imgRedCircle.image=[UIImage imageNamed:@"notification_number.png"];
                lblReplies.text = @"Replies";
            }
            
            UILabel *lblReplyCount=(UILabel*)[cell.contentView viewWithTag:106];
            lblReplyCount.text=[dictOfScoop valueForKey:@"replyCount"];
            
            return cell;
        }
        
        
        UIImageView *profileImage=(UIImageView *)[cell.contentView viewWithTag:208];
        [AppHelper getRoundedImageWithImageView:profileImage];
        
        NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfScoop objectForKey:@"image"]]];
        NSString *imgUrl=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        NSURL *url=[NSURL URLWithString:imgUrl];
        
        if([imgUrl length]>0)
            [profileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
        else
            profileImage.image=[UIImage imageNamed:@"defaultuser.png"];
        
        UILabel *lblLikeCount=(UILabel *)[cell.contentView viewWithTag:210];
        lblLikeCount.backgroundColor=[UIColor clearColor];
        lblLikeCount.text=[NSString stringWithFormat:@"%i",[[dictOfScoop valueForKey:@"like"] intValue]];
        
        CBAutoScrollLabel *lblName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:212];
        [lblName setLabelSettingForObject:@"name"];
        
        CBAutoScrollLabel *lblsearchText=(CBAutoScrollLabel *)[cell.contentView viewWithTag:205];
        [lblsearchText setLabelSettingForObject:@"skoop"];
        
        UILabel *lblLocation=(UILabel *)[cell.contentView viewWithTag:206];
        UILabel *lblDate=(UILabel *)[cell.contentView viewWithTag:207];
        UILabel *lblCost=(UILabel *)[cell.contentView viewWithTag:209];
        lblCost.textColor=KTextColor;
        
        lblName.text=[dictOfScoop valueForKey:@"name"];
        lblsearchText.text=[dictOfScoop valueForKey:@"searchText"];
        
        if([dictOfScoop valueForKey:@"group_name"] && [[dictOfScoop valueForKey:@"group_name"] length]>0)
            lblLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfScoop valueForKey:@"group_name"]];
        else
            lblLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfScoop valueForKey:@"location"]];
        
        lblDate.text=[NSString stringWithFormat:@"%@",[dictOfScoop valueForKey:@"date"]];
        if([[dictOfScoop valueForKey:@"price"] floatValue]>0)
            lblCost.text=[NSString stringWithFormat:@"$%@",[dictOfScoop valueForKey:@"price"]];
        else
            lblCost.text=@"Favor";
        
        UIButton *btnLense=(UIButton*)[cell.contentView viewWithTag:425];
        btnLense.userInteractionEnabled = NO;
        
        if([[dictOfScoop valueForKey:@"live_portal"] integerValue] == 1){
            
            if([[dictOfScoop valueForKey:@"reply_status"] integerValue] == 0){
                
                [btnLense setImage:[UIImage imageNamed:@"live_poratl_small.png"] forState:UIControlStateNormal];
                [btnLense setImage:[UIImage imageNamed:@"live_poratl_small.png"] forState:UIControlStateHighlighted];
            }
            else{
                
                [btnLense setImage:[UIImage imageNamed:@"live_green.png"] forState:UIControlStateNormal];
                [btnLense setImage:[UIImage imageNamed:@"live_green.png"] forState:UIControlStateHighlighted];
            }
            
            btnLense.frame=CGRectMake(275, 25, 40, 40);
        }
        else{
            
            [btnLense setImage:[UIImage imageNamed:@"lens_icon.png"] forState:UIControlStateNormal];
            [btnLense setImage:[UIImage imageNamed:@"lens_icon.png"] forState:UIControlStateHighlighted];
            btnLense.frame=CGRectMake(278, 27, 35, 35);
        }
        
        if([dictOfScoop objectForKey:@"reply"]){
            
            NSDictionary *dictOfReply=[dictOfScoop objectForKey:@"reply"];
            UIImageView *replyVideoImageView=(UIImageView *)[cell.contentView viewWithTag:202];
            
            if([[dictOfReply valueForKey:@"paymentStatus"] isEqualToString:@"1"])
                lblCost.textColor=KTextColor_Green;
            
            UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[cell.contentView viewWithTag:indexPath.row+1];
            
            if([dictOfScoop valueForKey:@"upload"] && [[dictOfScoop valueForKey:@"upload"] integerValue]==0){
                
                if(activityIndicator)
                    [activityIndicator startAnimating];
                else{
                    
                    activityIndicator= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
                    activityIndicator.backgroundColor=[UIColor clearColor];
                    activityIndicator.alpha = 1.0;
                    activityIndicator.tag=indexPath.row+1;
                    activityIndicator.center = replyVideoImageView.center;
                    activityIndicator.hidesWhenStopped = YES;
                    [cell.contentView addSubview:activityIndicator];
                    [activityIndicator startAnimating];
                }
            }
            else{
                if(activityIndicator)
                    [activityIndicator startAnimating];
            }
            
            UIImageView *replyProfileImage=(UIImageView *)[cell.contentView viewWithTag:219];
            replyProfileImage.backgroundColor=[UIColor lightGrayColor];
            [AppHelper getRoundedImageWithImageView:replyProfileImage];
            
            NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[AppHelper userDefaultsForKey:KUserImageUrl]]];
            NSString *imgUrl=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            NSURL *url=[NSURL URLWithString:imgUrl];
            
            if([urlString length]>0)
                [replyProfileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
            else
                replyProfileImage.image=[UIImage imageNamed:@"defaultuser.png"];
            
            
            if([dictOfReply objectForKey:@"thumbnail"]){
                NSString *urlString1 = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfReply objectForKey:@"thumbnail"]]];
                NSString *imgUrl1=[urlString1  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                NSURL *url1=[NSURL URLWithString:imgUrl1];
                if([imgUrl1 length]>0)
                    [replyVideoImageView setImageWithURL:url1 placeholderImage:[UIImage imageNamed:@"thumbimage"]];
            }
            else
                replyVideoImageView.image=[dictOfReply valueForKey:@"thumbimage"];
            
            CBAutoScrollLabel *lblReplyName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:214];
            [lblReplyName setLabelSettingForObject:@"name"];
            lblReplyName.text=[dictOfReply valueForKey:@"name"];
            
            CBAutoScrollLabel *lblReplysearchText=(CBAutoScrollLabel *)[cell.contentView viewWithTag:1210];
            [lblReplysearchText setLabelSettingForObject:@"skoop"];
            lblReplysearchText.text = [NSString stringWithFormat:@"%@(%@ Sec)",[dictOfScoop valueForKey:@"searchText"],[[dictOfScoop valueForKey:@"reply"] valueForKey:@"duration"]];
            
            UILabel *lblReplyLocation=(UILabel *)[cell.contentView viewWithTag:211];
            if([dictOfScoop valueForKey:@"group_name"] && [[dictOfScoop valueForKey:@"group_name"] length]>0)
                lblReplyLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfScoop valueForKey:@"group_name"]];
            else
                lblReplyLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfScoop valueForKey:@"location"]];
            
            UILabel *lblReplyDate=(UILabel *)[cell.contentView viewWithTag:215];
            lblReplyDate.text=[NSString stringWithFormat:@"%@",[dictOfReply valueForKey:@"date"]];
        }
    }
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSDictionary *dataDict;
    selectedIndex=indexPath.row;
    if(tableView==_tableView){//List tableview
    
        _viewSkoopRequest.backgroundColor=[UIColor clearColor];
        dataDict=[monthDataArray objectAtIndex:indexPath.row];
        
        CGRect tableViewFrame=_tableView.frame;
        
        //Set selected skoop view frame
        CGRect selectedSkoopViewFrame = _viewSkoopRequest.frame;
        
        if([[dataDict valueForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]]){//Check for skoop is sent by user or other
            
            _viewSkoopRequest.hidden = YES;
            _viewSkoopViewReply.hidden = NO;
            
            selectedSkoopViewFrame = _viewSkoopViewReply.frame;
            CGRect syncBtnFrame = _viewReqAndSyncButton.frame;
            tableViewFrame.size.height = _viewTableviewBase.frame.size.height - _viewReqAndSyncButton.frame.size.height - _viewSkoopViewReply.frame.size.height;
            
            syncBtnFrame.origin.y = tableViewFrame.origin.y + tableViewFrame.size.height;
            _viewReqAndSyncButton.frame = syncBtnFrame;
            
            selectedSkoopViewFrame.origin.y = syncBtnFrame.origin.y + syncBtnFrame.size.height;
            _viewSkoopViewReply.frame = selectedSkoopViewFrame;
            
            NSDictionary *dictOfRequests=[monthDataArray objectAtIndex:indexPath.row];
            
            CBAutoScrollLabel *lblSkoopName=(CBAutoScrollLabel *)[_viewSkoopViewReply viewWithTag:101];
            [lblSkoopName setLabelSettingForObject:@"skoop"];
            lblSkoopName.text=[dictOfRequests valueForKey:@"searchText"];
            
            UILabel *lblLocation=(UILabel *)[_viewSkoopViewReply viewWithTag:102];
            if([dictOfRequests valueForKey:@"group_name"] && [[dictOfRequests valueForKey:@"group_name"] length]>0)
                lblLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfRequests valueForKey:@"group_name"]];
            else
                lblLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfRequests valueForKey:@"location"]];
            
            UILabel *lblDate=(UILabel *)[_viewSkoopViewReply viewWithTag:103];
            lblDate.text=[NSString stringWithFormat:@"Time: %@",[dictOfRequests valueForKey:@"date"]];
            
            UILabel *lblCost=(UILabel *)[_viewSkoopViewReply viewWithTag:104];
            
            if([[dictOfRequests valueForKey:@"price"] floatValue]>0)
                lblCost.text=[NSString stringWithFormat:@"$%@",[dictOfRequests valueForKey:@"price"]];
            else
                lblCost.text=@"Favor";
            
            UILabel *lblReplyCount=(UILabel*)[_viewSkoopViewReply viewWithTag:106];
            lblReplyCount.text=[dictOfRequests valueForKey:@"replyCount"];
            
        }
        else{
            
            _viewSkoopRequest.hidden = NO;
            _viewSkoopViewReply.hidden = YES;
            
            UIImageView *profileImage=(UIImageView *)[_viewSkoopRequest viewWithTag:208];
            UILabel *lblLikeCount=(UILabel *)[_viewSkoopRequest viewWithTag:210];
            CBAutoScrollLabel *lblName=(CBAutoScrollLabel *)[_viewSkoopRequest viewWithTag:212];
            [lblName setLabelSettingForObject:@"name"];
            
            CBAutoScrollLabel *lblsearchText=(CBAutoScrollLabel *)[_viewSkoopRequest viewWithTag:205];
            [lblsearchText setLabelSettingForObject:@"skoop"];
            
            UILabel *lblCost=(UILabel *)[_viewSkoopRequest viewWithTag:209];
            UILabel *lblLocation=(UILabel *)[_viewSkoopRequest viewWithTag:206];
            UILabel *lblDate=(UILabel *)[_viewSkoopRequest viewWithTag:207];
            
            [AppHelper getRoundedImageWithImageView:profileImage];
            
            UITapGestureRecognizer *uiTap=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnSenderSkoopProfileImage:)];
            uiTap.numberOfTapsRequired=1;
            profileImage.userInteractionEnabled=YES;
            [profileImage addGestureRecognizer:uiTap];
            
            NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dataDict objectForKey:@"image"]]];
            NSString *imgUrl=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            NSURL *url=[NSURL URLWithString:imgUrl];
            
            if([imgUrl length]>0)
                [profileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
            else
                profileImage.image=[UIImage imageNamed:@"defaultuser.png"];
            lblLikeCount.backgroundColor=[UIColor clearColor];
            lblLikeCount.text=[NSString stringWithFormat:@"%i",[[dataDict valueForKey:@"like"] intValue]];
            
            lblName.text=[dataDict valueForKey:@"name"];
            lblsearchText.text=[dataDict valueForKey:@"searchText"];
            
            if([dataDict valueForKey:@"group_name"] && [[dataDict valueForKey:@"group_name"] length]>0)
                lblLocation.text=[NSString stringWithFormat:@"Group: %@",[dataDict valueForKey:@"group_name"]];
            else
                lblLocation.text=[NSString stringWithFormat:@"Location: %@",[dataDict valueForKey:@"location"]];
            
            lblDate.text=[NSString stringWithFormat:@"%@",[dataDict valueForKey:@"date"]];
            if([[dataDict valueForKey:@"price"] floatValue] >0)
                lblCost.text=[NSString stringWithFormat:@"$ %@",[dataDict valueForKey:@"price"]];
            else
                lblCost.text=@"Favor";
            
            selectedSkoopViewFrame.size.height = 80;
            
            if([dataDict valueForKey:@"reply"]){
                
                selectedSkoopViewFrame.size.height = 161;
                
                NSDictionary *dictOfReply=[dataDict objectForKey:@"reply"];
                
                UIImageView *replyVideoImageView=(UIImageView *)[_viewSkoopRequest viewWithTag:202];
                UIImageView *replyProfileImage=(UIImageView *)[_viewSkoopRequest viewWithTag:219];
                CBAutoScrollLabel *lblReplyName=(CBAutoScrollLabel *)[_viewSkoopRequest viewWithTag:214];
                [lblReplyName setLabelSettingForObject:@"name"];
                
                CBAutoScrollLabel *lblReplysearchText=(CBAutoScrollLabel *)[_viewSkoopRequest viewWithTag:220];
                [lblReplysearchText setLabelSettingForObject:@"skoop"];
                
                UILabel *lblReplyLocation=(UILabel *)[_viewSkoopRequest viewWithTag:211];
                UILabel *lblReplyDate=(UILabel *)[_viewSkoopRequest viewWithTag:215];
                
                replyProfileImage.backgroundColor=[UIColor lightGrayColor];
                [AppHelper getRoundedImageWithImageView:replyProfileImage];
                
                UITapGestureRecognizer *uiTap1=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapOnReplierSkoopProfileImage:)];
                uiTap1.numberOfTapsRequired=1;
                replyProfileImage.userInteractionEnabled=YES;
                [replyProfileImage addGestureRecognizer:uiTap1];
                
                NSString *urlString = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfReply objectForKey:@"image"]]];
                NSString *imgUrl=[urlString  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                NSURL *url=[NSURL URLWithString:imgUrl];
                
                if([urlString length]>0)
                    [replyProfileImage setImageWithURL:url placeholderImage:[UIImage imageNamed:@"defaultuser.png"]];
                else
                    replyProfileImage.image=[UIImage imageNamed:@"defaultuser.png"];
                
                if([dictOfReply objectForKey:@"thumbnail"])
                {
                    NSString *urlString1 = [NSString stringWithFormat:@"%@",[NSURL URLWithString:[dictOfReply objectForKey:@"thumbnail"]]];
                    NSString *imgUrl1=[urlString1  stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
                    NSURL *url1=[NSURL URLWithString:imgUrl1];
                    [replyVideoImageView setImageWithURL:url1 placeholderImage:[UIImage imageNamed:@"thumbimage"]];
                }
                else
                    replyVideoImageView.image=[dictOfReply valueForKey:@"thumbimage"];
                
                lblReplyName.text=[dictOfReply valueForKey:@"name"];
                lblReplysearchText.text=[dataDict valueForKey:@"searchText"];
                
                if([dataDict valueForKey:@"group_name"] && [[dataDict valueForKey:@"group_name"] length]>0)
                    lblReplyLocation.text=[NSString stringWithFormat:@"Group: %@",[dataDict valueForKey:@"group_name"]];
                else
                    lblReplyLocation.text=[NSString stringWithFormat:@"Location: %@",[dataDict valueForKey:@"location"]];
                
                lblReplyDate.text=[NSString stringWithFormat:@"%@",[dictOfReply valueForKey:@"date"]];
            }
            
            CGRect syncBtnFrame = _viewReqAndSyncButton.frame;
            tableViewFrame.size.height = _viewTableviewBase.frame.size.height - _viewReqAndSyncButton.frame.size.height - selectedSkoopViewFrame.size.height;
            
            syncBtnFrame.origin.y = tableViewFrame.origin.y + tableViewFrame.size.height;
            _viewReqAndSyncButton.frame = syncBtnFrame;
            
            selectedSkoopViewFrame.origin.y = syncBtnFrame.origin.y + syncBtnFrame.size.height;
            _viewSkoopRequest.frame = selectedSkoopViewFrame;
        }
        
        _tableView.frame = tableViewFrame;
    }
    else if(tableView==_tableViewSkoopReq){//Tableview for show skoop after selecting a specific date on calendar
    
        dataDict=[dateSkoopArray objectAtIndex:indexPath.row];
        if([[dataDict valueForKey:KUserId] isEqualToString:[AppHelper userDefaultsForKey:KUserId]]){
            
            [self performSegueWithIdentifier:@"showskoopreply" sender:dataDict];
        }
        else if ([dataDict valueForKey:@"reply"]){
            
//            UIView *playerBaseView=[[UIView alloc] init];
//            playerBaseView.frame=self.view.bounds;
//            playerBaseView.tag=4444;
//            playerBaseView.userInteractionEnabled=YES;
//            playerBaseView.backgroundColor=[UIColor clearColor];
//            
//            UIImageView *baseImg=[[UIImageView alloc] initWithFrame:playerBaseView.frame];
//            baseImg.image=[UIImage imageNamed:@"blackoverlay.png"];
//            baseImg.alpha=0.7;
//            [playerBaseView addSubview:baseImg];
            
            NSDictionary *selectedData=[dateSkoopArray objectAtIndex:indexPath.row];
            if([selectedData valueForKey:@"upload"] && [[selectedData valueForKey:@"upload"] integerValue]==0){
                [AppHelper showAlertViewWithTag:1 title:AppName message:@"Video is not uploaded yet." delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
            }
            else{
                
                VideoPlayerVC *videoPlayerVC = [self.storyboard instantiateViewControllerWithIdentifier:@"VideoPlayerVC"];
                videoPlayerVC.videoURL =[[dataDict valueForKey:@"reply"] valueForKey:@"video_path"];
                videoPlayerVC.isShowingOwnVideo = YES;
                videoPlayerVC.selecteDataDict = [NSMutableDictionary dictionaryWithDictionary:dataDict];
                [self.navigationController pushViewController:videoPlayerVC animated:NO];
                
//                NSURL *fileURL = [NSURL URLWithString:[[selectedData valueForKey:@"reply"] valueForKey:@"video_path"]];
//                
//                NSLog(@"::::%@",fileURL);
//                
//                MPMoviePlayerController *moviePlayerController = [[MPMoviePlayerController alloc] initWithContentURL:fileURL];
//                [moviePlayerController setShouldAutoplay:YES];
//                [moviePlayerController.view setFrame:CGRectMake(0, (playerBaseView.frame.size.height-270)/2, self.view.frame.size.width, 270)];
//                moviePlayerController.fullscreen = YES;
//                
//                [moviePlayerController setScalingMode:MPMovieScalingModeAspectFit];
//                moviePlayerController.view.autoresizingMask = UIViewAutoresizingFlexibleWidth|UIViewAutoresizingFlexibleHeight;
//                
//                [[NSNotificationCenter defaultCenter] addObserver: self
//                                                         selector: @selector(movieLoadStateDidChange:)
//                                                             name: MPMoviePlayerLoadStateDidChangeNotification
//                                                           object: moviePlayerController];
//                [moviePlayerController play];
//                [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
//                self.moviePlayer=moviePlayerController;
//                [playerBaseView addSubview:self.moviePlayer.view];
//                
//                UIButton *cancelButton=[UIButton buttonWithType:UIButtonTypeCustom];
//                cancelButton.frame=CGRectMake(300, moviePlayerController.view.frame.origin.y-20, 40, 40);
//                [cancelButton setImage:[UIImage imageNamed:@"cross_button.png"] forState:UIControlStateNormal];
//                [cancelButton setImage:[UIImage imageNamed:@"cross_button.png"] forState:UIControlStateSelected];
//                cancelButton.contentEdgeInsets = UIEdgeInsetsMake(0, 0, 20, 20);
//                [cancelButton addTarget:self action:@selector(removeRunningVideoView) forControlEvents:UIControlEventTouchUpInside];
//                [playerBaseView addSubview:cancelButton];
//                [self.view addSubview:playerBaseView];
            }
        }
        else{
            
            [self performSegueWithIdentifier:@"skoop_req" sender:dataDict];
        }
    }
}
    
#pragma mark Tap gesture method
-(void)tapOnSenderSkoopProfileImage:(UITapGestureRecognizer*)tapGesture
{
    UITableViewCell *tableVewCell=nil;
    if(IS_Greater_Or_Equal_to_IOS_7)
        tableVewCell=(UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[tapGesture.view superview] superview];
    NSIndexPath *indexPath=nil;
    NSDictionary *dataDict=nil;
    
    if([_btnList isSelected])
    {
        dataDict=[monthDataArray objectAtIndex:selectedIndex];
    }
    else
    {
        indexPath=[_tableViewSkoopReq indexPathForCell:tableVewCell];
        dataDict=[dateSkoopArray objectAtIndex:indexPath.row];
    }
    isShowReplierProfile=NO;
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

-(void)tapOnReplierSkoopProfileImage:(UITapGestureRecognizer*)tapGesture
{
    UITableViewCell *tableVewCell=nil;
    if(IS_IOS_7)
        tableVewCell=(UITableViewCell*)[[[tapGesture.view superview] superview] superview];
    else
        tableVewCell=(UITableViewCell*)[[tapGesture.view superview] superview];
    
    NSIndexPath *indexPath=nil;
    NSDictionary *dataDict=nil;
    if([_btnList isSelected])
    {
        dataDict=[monthDataArray objectAtIndex:selectedIndex];
    }
    else
    {
        indexPath=[_tableViewSkoopReq indexPathForCell:tableVewCell];
        dataDict=[dateSkoopArray objectAtIndex:indexPath.row];
    }
    isShowReplierProfile=YES;
    [self performSegueWithIdentifier:@"userprofile" sender:dataDict];
}

#pragma mark Segur method
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqual:@"replyonskoop"]){
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidReplyOnSkoop:) name:Notification_reply_on_skoop object:nil];
        NSDictionary *dataDict=(NSDictionary*)sender;
        NSLog(@"::::%@",dataDict);
        VideoUploaderVC *videoObj=segue.destinationViewController;
        videoObj.videoLoaderDelegate=self;
        videoObj.skoopId=[dataDict valueForKey:@"skoop_id"];
    }
    else if([segue.identifier isEqual:@"showskoopreply"]){
        NSDictionary *dataDict=(NSDictionary*)sender;
        CellSelectionView *cellselectionobj=segue.destinationViewController;
        cellselectionobj.getInfoRequest=[NSMutableDictionary dictionaryWithDictionary:dataDict];
    }
    else if([segue.identifier isEqualToString:@"userprofile"])
    {
        NSDictionary *dataDict=(NSDictionary*)sender;
        UserProfileVC *userProfileObj=segue.destinationViewController;
        userProfileObj.groupId=@"";
        userProfileObj.groupOwnerId=@"";
        if(isShowReplierProfile)
        {
            userProfileObj.name=[[dataDict valueForKey:@"reply"] valueForKey:@"name"];
            userProfileObj.imgUrl=[[dataDict valueForKey:@"reply"] valueForKey:@"image"];
            userProfileObj.blockUserId=[AppHelper userDefaultsForKey:KUserId];
        }
        else
        {
            userProfileObj.name=[dataDict valueForKey:@"name"];
            userProfileObj.imgUrl=[dataDict valueForKey:@"image"];
            userProfileObj.blockUserId=[dataDict valueForKey:@"user_id"];
        }
    }
    else if([segue.identifier isEqual:@"skoop_req"]){
        
        NSDictionary *dataDict=(NSDictionary*)sender;
        ReplyOnSkoopVC *destViewController=segue.destinationViewController;
        destViewController.skoopId=[dataDict valueForKey:@"skoop_id"];
        destViewController.isShowFutureSkoop=[[dataDict valueForKey:@"skoop_type"] integerValue];
        destViewController.isComesFromCalendarClass = YES;
        destViewController.deligate = self;
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
