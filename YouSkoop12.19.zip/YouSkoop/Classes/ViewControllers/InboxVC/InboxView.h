//
//  InboxView.h
//  youskoop
//
//  Created by user on 3/14/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InboxView : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    
}
@property (strong, nonatomic) NSMutableArray *afterSearchData;
@property (strong, nonatomic) UIRefreshControl *refreshControl;
@property(strong,nonatomic) NSMutableDictionary *dictOfRequests;

@property (weak, nonatomic) IBOutlet UITextField *_searchTxtField;
@property (strong, nonatomic) IBOutlet UIView *_headerView;
@property (weak, nonatomic) IBOutlet UITableView *outletTableView;

- (IBAction)btnBack:(id)sender;
@end
