//
//  InboxView.m
//  youskoop
//
//  Created by user on 3/14/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "InboxView.h"
#include "AppHelper.h"
#import "Defines.h"
#import "WebServicesController.h"
#import "UIImageView+AFNetworking.h"
#import "CellSelectionView.h"
#import "RequestViewViewController.h"

#define pageLimit           @"50"

@interface InboxView ()
{
    NSMutableArray *arrayOfRequests;
    NSMutableArray *afterSearchData;
    NSMutableDictionary *userinfo;
    int pageNo;
    int selectedIndex;
    BOOL isHitWebService;
    BOOL isSearching;
    BOOL isFirstHit;
}
@end

@implementation InboxView


@synthesize outletTableView;
@synthesize afterSearchData;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self)
    {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    //Set navigation image according to ios version
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    
    isFirstHit=YES;
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(goesToRootView) name:Notification_Send_to_tab_root object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateConfirmLivePortalCount:) name:Notification_Update_LivePortal_Count object:nil];
    
    pageNo=1;
    isHitWebService=NO;
    arrayOfRequests=[[NSMutableArray alloc] init];
    userinfo=[[NSMutableDictionary alloc] init];
    NSMutableArray *array=[[NSMutableArray alloc] init];
    self.afterSearchData=array;
    
    [userinfo setValue:[AppHelper userDefaultsForKey:KUserId] forKey:KUserId];
    [userinfo setValue:@"1" forKey:@"page"];
    [userinfo setValue:pageLimit forKey:@"limit"];
    [userinfo setValue:@"current" forKey:@"requestType"];
    [userinfo setValue:KAppToken forKey:@"token"];
    
    self.refreshControl = [[UIRefreshControl alloc] init];
    self.refreshControl.attributedTitle = [[NSAttributedString alloc] initWithString:@"Refreshing data..."];
    self.refreshControl.tintColor = [UIColor grayColor];
    [self.refreshControl addTarget:self action:@selector(refresh:) forControlEvents:UIControlEventValueChanged];
    [self.outletTableView addSubview:self.refreshControl];
    
    [self performSelector:@selector(callInboxWebService) withObject:nil afterDelay:0.2];
}

-(void)callInboxWebService{
    
    [userinfo setValue:[AppHelper getGmtDifference] forKey:@"gmt"];
    [userinfo setValue:[AppHelper getGmtDateWithGivenDate:[NSDate date]] forKey:@"gmt_date"];
    [self getInboxSkoopDataWithDictionary:userinfo andIsShowIndicator:YES];
}

//Get inbox data
-(void)getInboxSkoopDataWithDictionary:(NSMutableDictionary*)paramDict andIsShowIndicator:(BOOL)showIndicator
{
    if(showIndicator){
        if(isFirstHit){
            [AppDelegate dismissGlobalHUD];
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
        }
    }
    else{
        UIImageView *imgView=(UIImageView*)[self._headerView viewWithTag:501];
        imgView.hidden=YES;
        UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[self._headerView viewWithTag:502];
        if(activityIndicator)
            [activityIndicator startAnimating];
        else{
            activityIndicator= [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
            activityIndicator.backgroundColor=[UIColor clearColor];
            activityIndicator.alpha = 1.0;
            activityIndicator.tag=502;
            activityIndicator.center = imgView.center;
            activityIndicator.hidesWhenStopped = YES;
            [self._headerView addSubview:activityIndicator];
            [activityIndicator startAnimating];
        }
    }
    
    AFHTTPClient *client=[AFHTTPClient clientWithBaseURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_my_skoop]]];
    //Cancel all previous request
    [client cancelAllHTTPOperationsWithMethod:Method_skoop_my_skoop path:BaseURLString];
    
    NSDictionary *param=[[NSDictionary alloc]initWithDictionary:paramDict];
    NSLog(@"%@",[param JSONRepresentation]);
    NSLog(@"%@",[NSString stringWithFormat:@"%@%@",BaseURLString,Method_skoop_my_skoop]);
    NSMutableURLRequest *request=[client requestWithMethod:@"post" path:nil parameters:param];
    [request setTimeoutInterval:Timeout_Interval];;
    AFHTTPRequestOperation *operation=[[AFHTTPRequestOperation alloc]initWithRequest:request];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject){
        
        NSError *error;
        NSDictionary *dict=[NSJSONSerialization JSONObjectWithData:responseObject options:kNilOptions error:&error];
        
        dispatch_async(dispatch_get_main_queue(), ^(void){
           
            [self.refreshControl endRefreshing];
            if([[dict objectForKey:@"errorCode"] intValue]==0)
            {
                if(!isSearching)
                    pageNo++;
                
                NSArray *dataArray=[dict valueForKey:@"data"];
                NSLog(@"************got response*****************::::%i",(int)dataArray.count);
                if(dataArray.count>0){
                    if(isSearching){
                        self.afterSearchData = [NSMutableArray arrayWithArray:dataArray];
                    }
                    else{
                        for (int i=0; i<dataArray.count; i++) {
                            [arrayOfRequests addObject:[dataArray objectAtIndex:i]];
                        }
                        isFirstHit=NO;
                        [self performSelector:@selector(changeBoolVariable) withObject:nil afterDelay:1.0];
                    }
                }
                else{
                    if(isSearching){
                        self.afterSearchData=[NSMutableArray array];
                    }
                    else{
                        isHitWebService=NO;
                    }
                }
            }
            else if ([[dict objectForKey:@"errorCode"] intValue]==1){
                isHitWebService=NO;
                if(isFirstHit)
                    [AppHelper showAlertViewWithTag:100 title:AppName message:[dict objectForKey:@"errorMessage"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                isFirstHit=NO;
                if(isSearching){
                    self.afterSearchData=[NSMutableArray array];
                }
            }
            
            [self.outletTableView reloadData];
            
            if(showIndicator)
                [AppDelegate dismissGlobalHUD];
            else{
                UIActivityIndicatorView *activityIndicator=(UIActivityIndicatorView*)[self._headerView viewWithTag:502];
                if(activityIndicator)
                    [activityIndicator stopAnimating];
                UIImageView *imgView=(UIImageView*)[self._headerView viewWithTag:501];
                imgView.hidden=NO;
            }
            
        });
    }
    failure:^(AFHTTPRequestOperation *operation, NSError *error)
     {
         NSLog(@"Error....:::::%@",[error description]);
         [AppDelegate dismissGlobalHUD];
     }
     ];
    
    [operation start];
}

-(void)scrollTableViewWithIndexPath:(NSIndexPath*)indexPath
{
    NSLog(@"scroll.........");
    [self.outletTableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
}

-(void)goesToRootView{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Send_to_tab_root object:nil];
    [self.navigationController popToRootViewControllerAnimated:NO];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(goesToRootView) name:Notification_Send_to_tab_root object:nil];
}

- (void)refresh:(id)sender
{
    // do your refresh here and reload the tablview
    NSLog(@"**********************");
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"MMM d, h:mm a"];
    NSString *lastUpdated = [NSString stringWithFormat:@"Last updated on %@",[formatter stringFromDate:[NSDate date]]];
    self.refreshControl.attributedTitle = [[NSAttributedString alloc] initWithString:lastUpdated];

    [userinfo setValue:[NSString stringWithFormat:@"%i",pageNo] forKey:@"page"];
    [userinfo setValue:[AppHelper getGmtDifference] forKey:@"gmt"];
    [userinfo setValue:[AppHelper getGmtDateWithGivenDate:[NSDate date]] forKey:@"gmt_date"];
    [self getInboxSkoopDataWithDictionary:userinfo andIsShowIndicator:YES];
}

- (IBAction)btnBack:(id)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark Textfield deligates
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    return YES;
}
- (BOOL)textFieldShouldEndEditing:(UITextField *)textField
{
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    isSearching=YES;
    NSString *searchText = [textField.text stringByReplacingCharactersInRange:range withString:string];
    [userinfo setValue:searchText forKey:@"searchText"];
    [userinfo setValue:[AppHelper getGmtDifference] forKey:@"gmt"];
    [userinfo setValue:[AppHelper getGmtDateWithGivenDate:[NSDate date]] forKey:@"gmt_date"];
    [self getInboxSkoopDataWithDictionary:userinfo andIsShowIndicator:NO];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    NSString *searchString=[textField.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    if([searchString length]==0){
        isSearching=NO;
        [self.outletTableView reloadData];
    }
    [textField resignFirstResponder];
    return YES;
}
- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    isSearching=NO;
    [self.outletTableView reloadData];
    return YES;
}

#pragma mark Receive services response and notfications

-(void)userDidLReadNotification:(NSNotification*)note
{
    NSLog(@"Dictionary: %@",note.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Read_Notofication object:nil];
}

-(void)userDidDeleteSkoop:(NSNotification *)note
{
    NSLog(@"Deleted skoop Notification======%@",note.userInfo);
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Delete_Skoop object:nil];
    if (note.userInfo){
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0)
        {
            
            NSDictionary *dataDict;
            if(isSearching)
            {
                dataDict=[afterSearchData objectAtIndex:selectedIndex];
                [afterSearchData removeObject:dataDict];
                [arrayOfRequests removeObject:dataDict];
            }
            else
            {
                dataDict=[arrayOfRequests objectAtIndex:selectedIndex];
                [arrayOfRequests removeObject:dataDict];
            }
            [self.outletTableView reloadData];
    
            //Refresh calendar screen
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_Calendar object:[dataDict valueForKey:@"skoop_id"] userInfo:nil];
            //Delete skoop event from calendar
            [[AppDelegate getAppDelegate] deleteSkoopEventFromCalendarWithDict:dataDict];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1)
            [AppHelper showAlertViewWithTag:101 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    }
}

-(void)updateConfirmLivePortalCount:(NSNotification*)noti
{
    NSLog(@":::::::::%@",noti.userInfo);
    [[NSNotificationCenter defaultCenter] removeObserver:self name:Notification_Update_LivePortal_Count object:nil];
    
    for (int i=0; i<arrayOfRequests.count; i++)
    {
        NSMutableDictionary *dataDict=[NSMutableDictionary dictionaryWithDictionary:[arrayOfRequests objectAtIndex:i]];
        if([[dataDict valueForKey:@"skoop_id"] isEqualToString:[noti.userInfo valueForKey:@"skoop_id"]])
        {
            NSLog(@"change count");
            [dataDict setValue:[NSString stringWithFormat:@"%i",[[dataDict valueForKey:@"replyCount"] integerValue]+1] forKey:@"replyCount"];
            [dataDict setValue:@"0" forKey:@"read_status"];
            [arrayOfRequests replaceObjectAtIndex:i withObject:dataDict];
            [self reloadTableviewAfterDelayWithIndexPath:[NSIndexPath indexPathForRow:i inSection:0]];
        }
    }
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateConfirmLivePortalCount:) name:Notification_Update_LivePortal_Count object:nil];
}

-(void)changeBoolVariable{
    isHitWebService=YES;
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag==100){
        [self.navigationController popViewControllerAnimated:YES];
    }
    else if(alertView.tag==101){
        
        if(buttonIndex==0){
            
            NSDictionary *dataDict;
            if(isSearching)
                dataDict=[afterSearchData objectAtIndex:selectedIndex];
            else
                dataDict=[arrayOfRequests objectAtIndex:selectedIndex];
            
            [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
            [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(userDidDeleteSkoop:) name:Notification_Delete_Skoop object:nil];
            [[WebServicesController WebServiceMethod] deleteSkoopRequestWithUserId:[AppHelper userDefaultsForKey:KUserId] skoopId:[dataDict valueForKey:@"skoop_id"] andAppToken:KAppToken];
        }
    }
}

#pragma mark tableView Delegate methods

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    UILabel *lblNoData=(UILabel*)[self.view viewWithTag:123];
    
    if((isSearching && afterSearchData.count==0) || arrayOfRequests.count == 0 ){
        
        if(!lblNoData){
            lblNoData=[[UILabel alloc] initWithFrame:CGRectMake(0, self.outletTableView.frame.size.height/2.0-15.0, 320, 30.0)];
            lblNoData.textAlignment=NSTextAlignmentCenter;
            lblNoData.backgroundColor=[UIColor clearColor];
            lblNoData.textColor=KTextColor;
            lblNoData.tag=123;
            lblNoData.text=@"No data available";
            [self.outletTableView addSubview:lblNoData];
        }
    }
    else
        [lblNoData removeFromSuperview];
    
    if(isSearching)
        return [afterSearchData count];
    else
        return [arrayOfRequests count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SendSkoopReq"];
    
    if(cell==nil){
        NSLog(@"***********************nil***********************");
        NSArray *topLevelObjects = topLevelObjects = [[NSBundle mainBundle] loadNibNamed:@"SendSkoopReq" owner:self options:nil];
        cell = [topLevelObjects objectAtIndex:0];
        cell.layer.borderColor=[UIColor grayColor].CGColor;
        cell.backgroundColor=[UIColor clearColor];
        
        if(!IS_IOS_7){
            UIImageView *imgView = [[UIImageView alloc] initWithFrame:cell.frame];
            imgView.image = [UIImage imageNamed:@"unread_notify_bg.png"];
            imgView.tag = 777;
            [cell.contentView addSubview:imgView];
        }
    }
    
    
    NSDictionary *dictOfRequests;
    if(isSearching)
        dictOfRequests=[afterSearchData objectAtIndex:indexPath.row];
    else
        dictOfRequests=[arrayOfRequests objectAtIndex:indexPath.row];
    
    if(IS_IOS_7){
        if(![[dictOfRequests valueForKey:@"read_status"] isKindOfClass:[NSNull class]] && [[dictOfRequests valueForKey:@"read_status"] integerValue]==1)
            cell.backgroundColor=[UIColor clearColor];
        else
            cell.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"unread_notify_bg.png"]];
    }
    else{
        UIImageView *imgView=(UIImageView *)[cell.contentView viewWithTag:777];
        if(![[dictOfRequests valueForKey:@"read_status"] isKindOfClass:[NSNull class]] && [[dictOfRequests valueForKey:@"read_status"] integerValue]==1)
            imgView.hidden=YES;
        else
            imgView.hidden=NO;
    }

    if(indexPath.row == arrayOfRequests.count-5 && isHitWebService && !isSearching){
        
        NSLog(@"**************hit web service*****************");
        [userinfo setValue:[NSString stringWithFormat:@"%i",pageNo] forKey:@"page"];
        [userinfo setValue:[AppHelper getGmtDifference] forKey:@"gmt"];
        [userinfo setValue:[AppHelper getGmtDateWithGivenDate:[NSDate date]] forKey:@"gmt_date"];
        [self getInboxSkoopDataWithDictionary:userinfo andIsShowIndicator:YES];
    }
    
    CBAutoScrollLabel *lblSkoopName=(CBAutoScrollLabel *)[cell.contentView viewWithTag:101];
    [lblSkoopName setLabelSettingForObject:@"skoop"];
    lblSkoopName.font = [UIFont systemFontOfSize:14.0];
    lblSkoopName.text=[dictOfRequests valueForKey:@"searchText"];
    
    UILabel *lblLocation=(UILabel *)[cell.contentView viewWithTag:102];
    if([dictOfRequests valueForKey:@"group_name"] && [[dictOfRequests valueForKey:@"group_name"] length]>0)
        lblLocation.text=[NSString stringWithFormat:@"Group: %@",[dictOfRequests valueForKey:@"group_name"]];
    else
        lblLocation.text=[NSString stringWithFormat:@"Location: %@",[dictOfRequests valueForKey:@"location"]];
    
    UILabel *lblDate=(UILabel *)[cell.contentView viewWithTag:103];
    lblDate.text=[NSString stringWithFormat:@"Time: %@",[dictOfRequests valueForKey:@"date"]];

    UILabel *lblCost=(UILabel *)[cell.contentView viewWithTag:104];
    UILabel *lblReplies=(UILabel *)[cell.contentView viewWithTag:107];
    UIImageView *imgRedCircle=(UIImageView *)[cell.contentView viewWithTag:105];
    
    if([[dictOfRequests valueForKey:@"price"] floatValue]>0)
        lblCost.text=[NSString stringWithFormat:@"$%@",[dictOfRequests valueForKey:@"price"]];
    else
        lblCost.text=@"Favor";
    
    if([[dictOfRequests valueForKey:@"live_portal"] integerValue] == 1){
        imgRedCircle.image=[UIImage imageNamed:@"noti_lp.png"];
        lblReplies.text = @"Users";
    }
    else{
        imgRedCircle.image=[UIImage imageNamed:@"notification_number.png"];
        lblReplies.text = @"Replies";
    }
    
    UILabel *lblReplyCount=(UILabel*)[cell viewWithTag:106];
    lblReplyCount.text=[dictOfRequests valueForKey:@"replyCount"];
    return  cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    if([self._searchTxtField isFirstResponder]){
        [self._searchTxtField resignFirstResponder];
    }
    else{
        
        NSMutableDictionary *dataDict;
        if(isSearching)
            dataDict=[NSMutableDictionary dictionaryWithDictionary:[afterSearchData objectAtIndex:indexPath.row]];
        else
            dataDict=[NSMutableDictionary dictionaryWithDictionary:[arrayOfRequests objectAtIndex:indexPath.row]];
        
        [self performSegueWithIdentifier:@"cellIDentifier" sender:[dataDict mutableCopy]];
        
        if([[dataDict valueForKey:@"replyCount"] integerValue]){
            NSInteger objectIndex;
            NSIndexPath *indexPath1;
            
            if(isSearching){
                objectIndex=[afterSearchData indexOfObject:dataDict];
                if(objectIndex<afterSearchData.count)
                {
                    NSInteger objectIndex1=[arrayOfRequests indexOfObject:dataDict];
                    
                    [dataDict setValue:@"1" forKey:@"read_status"];
                    [afterSearchData replaceObjectAtIndex:objectIndex withObject:dataDict];
                    indexPath1=[NSIndexPath indexPathForRow:objectIndex inSection:0];
                    
                    if(objectIndex1<arrayOfRequests.count)
                        [arrayOfRequests replaceObjectAtIndex:objectIndex1 withObject:dataDict];
                }
            }
            else{
                objectIndex=[arrayOfRequests indexOfObject:dataDict];
                [dataDict setValue:@"1" forKey:@"read_status"];
                if(objectIndex<arrayOfRequests.count)
                    [arrayOfRequests replaceObjectAtIndex:objectIndex withObject:dataDict];
                indexPath1=[NSIndexPath indexPathForRow:objectIndex inSection:0];
            }
            [self performSelector:@selector(reloadTableviewAfterDelayWithIndexPath:) withObject:indexPath1 afterDelay:0.5];
        }
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete)
    {
        //add code here for when you hit delete
        selectedIndex= (int)indexPath.row;
        [AppHelper showAlertViewWithTag:101 title:AppName message:@"Do you want to delete this Skoop request?" delegate:self cancelButtonTitle:Alert_Yes otherButtonTitles:Alert_No];
    }
}

-(void)reloadTableviewAfterDelayWithIndexPath:(NSIndexPath*)indexPath
{
    [self.outletTableView reloadRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationNone];
}

#pragma mark Segue method
-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqual:@"cellIDentifier"])
    {
        NSMutableDictionary *dataDict=[NSMutableDictionary dictionaryWithDictionary:(NSDictionary*)sender];
        [dataDict setValue:[AppHelper userDefaultsForKey:KUserName] forKey:@"name"];
        CellSelectionView *cellselectionobj=segue.destinationViewController;
        cellselectionobj.getInfoRequest=[NSMutableDictionary dictionaryWithDictionary:dataDict];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
