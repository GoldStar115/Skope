//
//  PasswordRetrieveView.h
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PasswordRetrieveView : UIViewController<UIScrollViewDelegate,UITextFieldDelegate>
{
    NSMutableDictionary *dictforgotinfo;
}

@property (weak, nonatomic) IBOutlet UITextField *txtPasscode;
@property (weak, nonatomic) IBOutlet UITextField *txtNewPassword;
@property (weak, nonatomic) IBOutlet UITextField *txtConfirmPassword;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property(strong,nonatomic)NSMutableDictionary *dictforgotinfo;

- (IBAction)btnBack:(id)sender;
- (IBAction)btnSend:(id)sender;
@end
