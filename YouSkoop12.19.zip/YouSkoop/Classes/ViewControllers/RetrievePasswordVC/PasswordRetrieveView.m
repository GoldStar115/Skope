//
//  PasswordRetrieveView.m
//  youskoop
//
//  Created by user on 3/10/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "PasswordRetrieveView.h"
#import "AppDelegate.h"
#import "WebServicesController.h"

@interface PasswordRetrieveView ()

@end

@implementation PasswordRetrieveView

@synthesize scrollView,txtConfirmPassword,txtNewPassword,txtPasscode,dictforgotinfo;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UIImageView *navImage=(UIImageView*)[self.view viewWithTag:333333];
    if(IS_Greater_Or_Equal_to_IOS_7){
        navImage.image=[UIImage imageNamed:@"statusbar_7.png"];
    }
    else{
        navImage.frame=CGRectMake(0, 0, self.view.bounds.size.width, 44);
        navImage.image=[UIImage imageNamed:@"statusbar_6.png"];
    }
    UILabel *lblEnterEmail=(UILabel*)[self.view viewWithTag:5];
    lblEnterEmail.textColor=KTextColor;
     [AppHelper stausBarColorChange];
    
    //add keyboard notification
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(keyboardwillShowNotification:)
     name:UIKeyboardDidShowNotification
     object:nil];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(keyboardwillHideNotification:)
     name:UIKeyboardDidHideNotification
     object:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark- button back
- (IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark-Change Password Button
- (IBAction)btnSend:(id)sender
{
    [txtPasscode resignFirstResponder];
    [txtConfirmPassword resignFirstResponder];
    [txtNewPassword resignFirstResponder];
    [self.scrollView setContentOffset:CGPointMake(0,0) animated:NO];
    NSString *str =nil;
    
    if([txtPasscode.text length]==0)
        str=@"Please enter passcode.";
    else if([self.txtNewPassword.text length] == 0)
        str = @"Please enter new password.";
    else if([self.txtNewPassword.text length]<=6)
    {
        str=@"Password length must be greater than six.";
        self.txtNewPassword.text=@"";
    }
    else if([self.txtConfirmPassword.text length] == 0)
        str=@"Please enter confirm password.";
    else if(![txtNewPassword.text isEqualToString:txtConfirmPassword.text])
    {
        str=@"Password & Confirm Password does not match.";
        txtConfirmPassword.text=@"";
        txtNewPassword.text=@"";
    }
    if (str)
        [AppHelper showAlertViewWithTag:0 title:AppName message:str delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    else
    {
        NSMutableDictionary *dict=[NSMutableDictionary dictionary];
        NSString *email=[dictforgotinfo valueForKey:@"email"];
        NSLog(@"email=%@",email);
                if (txtPasscode.text!=nil)
                {
                    [dict setObject:txtPasscode.text forKey:@"passcode"];
                }
                if (self.txtNewPassword.text!=nil)
                {
                    [dict setObject:self.txtNewPassword.text forKey:@"password"];
                    [dict setObject:email forKey:@"email"];
                    [dict setObject:KAppToken forKey:@"token"];
                  
                    [AppDelegate showGlobalProgressHUDWithTitle:@"Loading..."];
                    [[NSNotificationCenter defaultCenter] addObserver:self
                                                             selector:@selector(getChangePassword:)
                                                                 name:Notification_For_ChangePassword
                                                               object:nil];
                    [[WebServicesController WebServiceMethod] changePassword:dict];
                    
                }
        }
}
        
-(void)getChangePassword:(NSNotification *)note
{
    NSLog(@"postUserRegistration======%@",note.userInfo);
    
    [AppDelegate dismissGlobalHUD];
    [[NSNotificationCenter defaultCenter]removeObserver:self name:Notification_For_ChangePassword object:nil];
    if (note.userInfo)
    {
        if([[note.userInfo objectForKey:@"errorCode"] intValue]==0)
        {
            [AppHelper showAlertViewWithTag:67890 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        }
        else if ([[note.userInfo objectForKey:@"errorCode"] intValue]==1)
        {
            
            [AppHelper showAlertViewWithTag:690 title:AppName message:[note.userInfo objectForKey:@"errorMessage"] delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
            
        }
        else
        {
            
        }
    }
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    
    if (alertView.tag==67890)
    {
        
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
    }
    if (alertView.tag==690)
    {
        [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:1] animated:YES];
    }
    
}


#pragma mark-Textbox
-(void)keyboardwillShowNotification:(NSNotification*)note
{
    if(IS_IPHONE5)
        [self.scrollView setContentSize:CGSizeMake(244,315)];
    else
        [self.scrollView setContentSize:CGSizeMake(244,415)];
    
    scrollView.scrollEnabled=YES;
}

-(void)keyboardwillHideNotification:(NSNotification*)note
{
    self.scrollView.scrollEnabled=NO;
    [self.scrollView setContentSize:CGSizeMake(0,0)];
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    NSLog(@"*****************");
    [self.txtPasscode resignFirstResponder];
    [self.txtNewPassword resignFirstResponder];
    [self.txtConfirmPassword resignFirstResponder];
    [self.scrollView setContentOffset:CGPointMake(0,0) animated:NO];
    [super touchesBegan:touches withEvent:event];
}

-(void)textFieldDidBeginEditing:(UITextField*) textField
{
    if(!IS_IPHONE5)
    {
        if (textField==self.txtPasscode)
            [self.scrollView setContentOffset:CGPointMake(0,20) animated:YES];
        else if (textField==self.txtNewPassword)
            [self.scrollView setContentOffset:CGPointMake(0,40) animated:YES];
        else if (textField==self.txtConfirmPassword)
            [self.scrollView setContentOffset:CGPointMake(0,60) animated:NO];
    }
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    if (textField==self.txtPasscode)
    {
        [self.txtPasscode resignFirstResponder];
        [self.txtNewPassword becomeFirstResponder];
    }
    else if (textField==self.txtNewPassword)
    {
        [self.txtNewPassword resignFirstResponder];
        [self.txtConfirmPassword becomeFirstResponder];
    }
    else if (textField==self.txtConfirmPassword)
    {
        [self.txtConfirmPassword resignFirstResponder];
        if (!IS_IPHONE5)
            [self.scrollView setContentOffset:CGPointMake(0,0) animated:NO];
    }
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    if (textField.text.length==0 && [string isEqualToString:@" "])
    {
        return NO;
    }

    return YES;
}


@end
