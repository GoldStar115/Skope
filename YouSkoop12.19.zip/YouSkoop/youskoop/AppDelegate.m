//
//  AppDelegate.m
//  youskoop
//
//  Created by user on 3/7/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import "AppDelegate.h"
#import "HomeView.h"
#import "WelcomeView.h"
#import "AppcustomTabbar.h"
#import <EventKit/EventKit.h>
#import "VideoPlayerVC.h"
#import "CLController.h"
#import "SSKeychain.h"
#import "ReceiveCallViewController.h"
#import "CallViewController.h"

static AppDelegate * myAppDelegate = nil;

@interface AppDelegate()
{
    UIImageView *tab1;
    UIImageView *tab2;
    UIImageView *tab3;
    NSDictionary *pushDataDict;
    UIAlertView *_alertView;
    BOOL isHideTabBar;
}
@end

@implementation AppDelegate

//@synthesize tabBarController;


@synthesize managedObjectContext = _managedObjectContext;
@synthesize managedObjectModel = _managedObjectModel;
@synthesize persistentStoreCoordinator = _persistentStoreCoordinator;

- (BOOL) checkInternateConnection
{
	Reachability *reg = [Reachability reachabilityWithHostName:@"www.google.com"];
	NetworkStatus internetStatus = [reg currentReachabilityStatus];
	if ((internetStatus != ReachableViaWiFi) && (internetStatus != ReachableViaWWAN))
		return NO;
	else
		return YES;
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [[FBSDKApplicationDelegate sharedInstance] application:application
                                                          openURL:url
                                                sourceApplication:sourceApplication
                                                       annotation:annotation
            ];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions{
    
    [[UIApplication sharedApplication] setApplicationIconBadgeNumber:0];
    
    [[FBSDKApplicationDelegate sharedInstance] application:application
                             didFinishLaunchingWithOptions:launchOptions];
    
    pushDataDict = [[NSDictionary alloc] init];
    
    [AppHelper stausBarColorChange];
    [self getDeviceId];
    
    NSLog(@"device_token = %@", [AppHelper userDefaultsForKey:Device_Token]);
    if(![AppHelper userDefaultsForKey:Device_Token]){
        
        if([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0) {
            
            UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes: (UIRemoteNotificationTypeBadge
                                                                                                  |UIRemoteNotificationTypeSound
                                                                                                  |UIRemoteNotificationTypeAlert) categories:nil];
            [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
        } else {
            
            //register to receive notifications
            UIRemoteNotificationType myTypes = UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound;
            [[UIApplication sharedApplication] registerForRemoteNotificationTypes:myTypes];
        }
    }
    
    self.window.backgroundColor=[UIColor colorWithPatternImage:[UIImage imageNamed:@"main_bg.png"]];
    
    UIStoryboard *story = [UIStoryboard storyboardWithName:@"youSkoopLayouts" bundle:nil];
    
    if([AppHelper userDefaultsForKey:KUserId]){
        AppcustomTabbar *tabBar = [story instantiateViewControllerWithIdentifier:@"tabBar"];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:tabBar];
        nav.navigationBarHidden=YES;
        
        self.window.rootViewController = nav;
    }
    else{
        WelcomeView *loginView = [story instantiateViewControllerWithIdentifier:@"WelcomeView"];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:loginView];
        self.window.rootViewController = nav;
    }
    myAppDelegate = self;
    return YES;
}

-(void)getDeviceId{
    
    NSString *udid = @"";
    udid = [SSKeychain passwordForService:@"com.YouScoop.com" account:@"AppUser" error:nil];
    if (!udid){
        
        NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
        [formatter setLocale:[[NSLocale alloc] initWithLocaleIdentifier:@"en_US"]];
        [formatter setDateFormat:@"MMddYYYY-HHmmss"];
        CFUUIDRef uuidObject = CFUUIDCreate(kCFAllocatorDefault);
        NSString *uuidStr = ( NSString *)CFBridgingRelease(CFUUIDCreateString(kCFAllocatorDefault, uuidObject)) ;
        CFRelease(uuidObject);
        NSString *generatedId = [NSString stringWithFormat:@"%@-%@", [formatter stringFromDate:[NSDate date]], uuidStr];
        [SSKeychain setPassword:generatedId forService:@"com.YouScoop.com" account:@"AppUser"];
        udid=generatedId;
    }
    udid=[udid stringByReplacingOccurrencesOfString:@"-" withString:@""];
    [AppHelper saveToUserDefaults:udid withKey:Device_Id];
    NSLog(@"udid:::---%@",udid);
}

//Method for enable and disable device screen lock
-(void)setIdleTimerDisabledWithBool:(BOOL)isLock
{
    [[UIApplication sharedApplication] setIdleTimerDisabled:isLock];
}

#pragma mark Configure video chat


+ (AppDelegate*) getAppDelegate
{
    AppDelegate * app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    return app;
}
- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    
    [FBSDKAppEvents activateApp];
    
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    

//    if(sessionExpiratioDate)
//    {
//        NSLog(@"sessionExpiratioDate::::::::::%@",sessionExpiratioDate);
//        NSLog(@"Current date::::::::::%@",[NSDate date]);
//        NSTimeInterval interval=[sessionExpiratioDate timeIntervalSinceNow];
//        NSLog(@":::%f",interval);
//        if(interval<=0)
//        {
//            //Create new session
//           // [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Create_Quickblox_Session object:self userInfo:nil];
//        }
//    }
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

#pragma mark User did logged out
-(void)loggedOutFromApp{
    
    
    //[[AppDelegate getAppDelegate].tabBarController.view removeFromSuperview];
    
    [AppHelper removeFromUserDefaultsWithKey:KUserId];
    [AppHelper removeFromUserDefaultsWithKey:KSaveReqData];
    [AppHelper removeFromUserDefaultsWithKey:isSyncData];
    [AppHelper removeFromUserDefaultsWithKey:KAvailableCredit];
    [AppHelper removeFromUserDefaultsWithKey:KSavedCCInfo];
    [[CLController sharedInstance] stopLocationUpdate];
    
    UIStoryboard *story=[UIStoryboard storyboardWithName:@"youSkoopLayouts" bundle:nil];
    WelcomeView *welcome=[story instantiateViewControllerWithIdentifier:@"WelcomeView"];
    
    UINavigationController *nav=[[UINavigationController alloc] initWithRootViewController:welcome];
    self.window.rootViewController=nav;
}

#pragma mark Check device orientation
- (NSUInteger)application:(UIApplication *)application supportedInterfaceOrientationsForWindow:(UIWindow *)windowx
{
    if ([[self.window.rootViewController presentedViewController] isKindOfClass:[VideoPlayerVC class]] ||
        [[self.window.rootViewController presentedViewController] isKindOfClass:NSClassFromString(@"MPInlineVideoFullscreenViewController")])
    {
        if ([self.window.rootViewController presentedViewController].isBeingDismissed)
        {
            return UIInterfaceOrientationMaskPortrait;
        }
        else
        {
            return UIInterfaceOrientationMaskAllButUpsideDown;
        }
    }
    else
    {
        return UIInterfaceOrientationMaskPortrait;
    }
}

#pragma mark - Remote Notification Delegates
- (void)application:(UIApplication *)app didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
    NSString* deviceTkn = [[NSString stringWithFormat:@"%@",deviceToken] stringByReplacingOccurrencesOfString:@"<" withString:@""];
    deviceTkn = [deviceTkn stringByReplacingOccurrencesOfString:@">" withString:@""];
    deviceTkn = [deviceTkn stringByReplacingOccurrencesOfString:@" " withString:@""];
    [AppHelper saveToUserDefaults:deviceTkn withKey:Device_Token];
    NSLog(@"Device token: %@",deviceTkn);
}

#ifdef __IPHONE_8_0
- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:   (UIUserNotificationSettings *)notificationSettings
{
    //register to receive notifications
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString   *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler{
    
    //handle the actions
    NSDictionary *apsInfo = [userInfo objectForKey:@"aps"];
    pushDataDict=apsInfo;
    NSLog(@"======********%@",pushDataDict);
    
    if([pushDataDict valueForKey:@"push_type"]){
        
        //Post notification to refresh calendar if any user gets block or unblock from any group
        if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Block_from_group] || [[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Unblock_from_group]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_Calendar object:@"refresh" userInfo:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_UpcomingSkoopList object:nil userInfo:nil];
        }
        if([[pushDataDict valueForKey:@"push_type"] isEqualToString:@"logout"]){
            
            [self loggedOutFromApp];
            [AppHelper showAlertViewWithTag:1 title:AppName message:[pushDataDict valueForKey:@"alert"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
        else if([[pushDataDict valueForKey:@"push_type"] isEqualToString:KPush_User_Comment]){
            
            [AppHelper showAlertViewWithTag:1 title:AppName message:[pushDataDict valueForKey:@"alert"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
        else{
            
            if(_alertView){
                if([_alertView isVisible])
                    [_alertView dismissWithClickedButtonIndex:-1 animated:YES];
                _alertView = nil;
            }
            [self performSelector:@selector(showAlertViewWithDelay) withObject:nil afterDelay:0.7];
        }
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Only_Notofication_Count object:nil userInfo:pushDataDict];
}
#endif

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    
    NSLog(@"userInfo = %@", userInfo);
    
    NSString *apsInfo = [[userInfo objectForKey:@"aps"] objectForKey:@"sound"];
    NSError *jsonError;
    NSData *data = [apsInfo dataUsingEncoding:NSUTF8StringEncoding];
    NSDictionary *jsonResponse = [NSJSONSerialization JSONObjectWithData:data
                                                                 options:kNilOptions
                                                                   error:&jsonError];
    pushDataDict = jsonResponse;
    NSLog(@"NotificationInfo = %@", pushDataDict);
   
    if([pushDataDict valueForKey:@"push_type"]){
        
        if ([[pushDataDict objectForKey:@"push_type"] isEqualToString:Notification_LivePortal_Call]) {
            [self showReceiveCallViewController];
        }
        
        //Post notification to refresh calendar if any user gets block or unblock from any group
        if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Block_from_group] || [[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Unblock_from_group]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_Calendar object:@"refresh" userInfo:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_UpcomingSkoopList object:nil userInfo:nil];
        }
        
        if([[pushDataDict valueForKey:@"push_type"] isEqualToString:@"logout"]){
            
            [self loggedOutFromApp];
            [AppHelper showAlertViewWithTag:1 title:AppName message:[pushDataDict valueForKey:@"alert"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
        else if([[pushDataDict valueForKey:@"push_type"] isEqualToString:KPush_User_Comment]){
            
            [AppHelper showAlertViewWithTag:1 title:AppName message:[pushDataDict valueForKey:@"alert"] delegate:nil cancelButtonTitle:Alert_Ok otherButtonTitles:nil];
        }
        else{
           
            if(_alertView){
                if([_alertView isVisible])
                    [_alertView dismissWithClickedButtonIndex:-1 animated:YES];
                _alertView = nil;
            }
            [self performSelector:@selector(showAlertViewWithDelay) withObject:nil afterDelay:0.7];
        }
    }
    [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Only_Notofication_Count object:nil userInfo:pushDataDict];
}

- (void)showReceiveCallViewController{
    
    NSLog(@"%@", [pushDataDict objectForKey:@"skoop_id"]);
    
    
    UIStoryboard *mainStoryboard = [UIStoryboard storyboardWithName:@"youSkoopLayouts" bundle:nil];
    ReceiveCallViewController *receiveCallViewController = [mainStoryboard instantiateViewControllerWithIdentifier:@"ReceiveCallViewController"];
    receiveCallViewController.conferenceId = [NSString stringWithFormat:@"skoopid%@", [pushDataDict objectForKey:@"skoop_id"]];
    receiveCallViewController.opponentUsername = [pushDataDict objectForKey:@"opponent_name"];
    receiveCallViewController.opponentUserImgUrl = [pushDataDict objectForKey:@"opponent_image"];

    [self.window.rootViewController presentViewController:receiveCallViewController animated:YES completion:nil];
    
    
}

-(void)showAlertViewWithDelay{
    
    _alertView = [[UIAlertView alloc] initWithTitle:AppName message:[pushDataDict objectForKey:@"alert"] delegate:self cancelButtonTitle:Alert_Cancel otherButtonTitles:Alert_View, nil];
    [_alertView show];
}

//If there is a problem in obtaining the token, iPhone OS informs the delegate by calling the following method
- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)err
{
    [AppHelper saveToUserDefaults:Default_device_token withKey:Device_Token] ;
}

#pragma mark Alertview deligates
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if(buttonIndex==1){
        
        if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_For_Get_Skoop_Request]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notofication_Count object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_For_Get_Skoop_Reply]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notofication_Count object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Confirm_Live_Portal]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notofication_Count object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_For_Get_Group_Skoop_Request]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notofication_Count object:nil userInfo:pushDataDict];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notification_List object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_For_Group_Req]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notofication_Count object:nil userInfo:pushDataDict];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notification_List object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Block_from_group]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notification_List object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Unblock_from_group]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notification_List object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Block_from_app]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notification_List object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Unblock_from_app]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notification_List object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Verify_celeb_grp]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notification_List object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Verify_celeb_grp]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notification_List object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict objectForKey:@"push_type"] isEqualToString:KPush_Join_grp]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notification_List object:nil userInfo:pushDataDict];
        }
        else if([[pushDataDict valueForKey:@"push_type"] isEqualToString:KPush_Buy_Skoop]){
            
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Refresh_BuysSkoopList object:nil userInfo:nil];
            [[NSNotificationCenter defaultCenter] postNotificationName:Notification_Update_Notofication_Count object:nil userInfo:pushDataDict];
        }
    }
}

#pragma mark - Global MBProgressHUD
+ (MBProgressHUD *)showGlobalProgressHUDWithTitle:(NSString *)title{
    UIWindow *window = [[[UIApplication sharedApplication] windows] lastObject];
    [MBProgressHUD hideAllHUDsForView:window animated:YES];
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:window animated:YES];
    hud.labelText = title;
    // Set the hud to display with a color
    //	hud.color = [UIColor colorWithRed:255/255.0 green:111/255.0 blue:18/255.0 alpha:0.90];
    hud.dimBackground = YES;
    return hud;
}

+ (void)dismissGlobalHUD
{
    UIWindow *window = [[[UIApplication sharedApplication] windows] lastObject];
    [MBProgressHUD hideHUDForView:window animated:YES];
}
- (void)saveContext
{
    NSError *error = nil;
    NSManagedObjectContext *managedObjectContext = self.managedObjectContext;
    if (managedObjectContext != nil) {
        if ([managedObjectContext hasChanges] && ![managedObjectContext save:&error]) {
            // Replace this implementation with code to handle the error appropriately.
            // abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
            NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
            abort();
        }
    }
}

#pragma mark - Core Data stack

// Returns the managed object context for the application.
// If the context doesn't already exist, it is created and bound to the persistent store coordinator for the application.
- (NSManagedObjectContext *)managedObjectContext
{
    if (_managedObjectContext != nil) {
        return _managedObjectContext;
    }
    
    NSPersistentStoreCoordinator *coordinator = [self persistentStoreCoordinator];
    if (coordinator != nil) {
        _managedObjectContext = [[NSManagedObjectContext alloc] init];
        [_managedObjectContext setPersistentStoreCoordinator:coordinator];
    }
    return _managedObjectContext;
}

// Returns the managed object model for the application.
// If the model doesn't already exist, it is created from the application's model.
- (NSManagedObjectModel *)managedObjectModel
{
    if (_managedObjectModel != nil) {
        return _managedObjectModel;
    }
    NSURL *modelURL = [[NSBundle mainBundle] URLForResource:@"Model" withExtension:@"momd"];
    _managedObjectModel = [[NSManagedObjectModel alloc] initWithContentsOfURL:modelURL];
    return _managedObjectModel;
}

// Returns the persistent store coordinator for the application.
// If the coordinator doesn't already exist, it is created and the application's store added to it.
- (NSPersistentStoreCoordinator *)persistentStoreCoordinator
{
    if (_persistentStoreCoordinator != nil) {
        return _persistentStoreCoordinator;
    }
    
    NSURL *storeURL = [[self applicationDocumentsDirectory] URLByAppendingPathComponent:@"Model.sqlite"];
    
    NSError *error = nil;
    _persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel:[self managedObjectModel]];
    if (![_persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeURL options:nil error:&error]) {
        /*
         Replace this implementation with code to handle the error appropriately.
         
         abort() causes the application to generate a crash log and terminate. You should not use this function in a shipping application, although it may be useful during development.
         
         Typical reasons for an error here include:
         * The persistent store is not accessible;
         * The schema for the persistent store is incompatible with current managed object model.
         Check the error message to determine what the actual problem was.
         
         
         If the persistent store is not accessible, there is typically something wrong with the file path. Often, a file URL is pointing into the application's resources directory instead of a writeable directory.
         
         If you encounter schema incompatibility errors during development, you can reduce their frequency by:
         * Simply deleting the existing store:
         [[NSFileManager defaultManager] removeItemAtURL:storeURL error:nil]
         
         * Performing automatic lightweight migration by passing the following dictionary as the options parameter:
         @{NSMigratePersistentStoresAutomaticallyOption:@YES, NSInferMappingModelAutomaticallyOption:@YES}
         
         Lightweight migration will only work for a limited set of schema changes; consult "Core Data Model Versioning and Data Migration Programming Guide" for details.
         
         */
        NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
        abort();
    }
    
    return _persistentStoreCoordinator;
}

#pragma mark - Application's Documents directory

// Returns the URL to the application's Documents directory.
- (NSURL *)applicationDocumentsDirectory
{
    return [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject];
}

#pragma mark-Tab Bar Delegates
- (void)tabBarController:(UITabBarController *)tabBarControllers didSelectViewController:(UIViewController *)viewController{
    
    if (tabBarControllers.selectedIndex == 0){
        
        tab1.image=[UIImage imageNamed:@"group_active_tab_mrenu_icon.png"];
        tab2.image=[UIImage imageNamed:@"skoop_tab_mrenu_icon.png"];
        tab3.image=[UIImage imageNamed:@"calender_tab_mrenu_icon.png"];
    }
    else if (tabBarControllers.selectedIndex == 1){
        
        tab1.image=[UIImage imageNamed:@"group_tab_mrenu_icon.png"];
        tab2.image=[UIImage imageNamed:@"skoop_active_tab_mrenu_icon.png"];
        tab3.image=[UIImage imageNamed:@"calender_tab_mrenu_icon.png"];
        [AppHelper saveToUserDefaults:[NSString stringWithFormat:@"%d",(int)tabBarControllers.selectedIndex] withKey:@"selectedTab"];
    }
    else if (tabBarControllers.selectedIndex == 2){
        
        tab1.image=[UIImage imageNamed:@"group_tab_mrenu_icon.png"];
        tab2.image=[UIImage imageNamed:@"skoop_tab_mrenu_icon.png"];
        tab3.image=[UIImage imageNamed:@"calender_active_tab_mrenu_icon.png"];
    }
}

-(void)showTabBar:(UITabBarController *)tabBar{
    
   // if(isHideTabBar){
       
//        [UIView animateWithDuration:0.5 animations:^{
//            for (UIView *view in tabBar.view.subviews) {
//                if ([view isKindOfClass:[UITabBar class]]) {
//                    [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y-84.f, view.frame.size.width, view.frame.size.height)];
//                }
//                else {
//                    [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y, view.frame.size.width, view.frame.size.height-84.f)];
//                }
//            }
//        } completion:^(BOOL finished) {
            //do smth after animation finishes
            tabBar.tabBar.hidden = NO;
            isHideTabBar = NO;
      //  }];
    //}
}

-(void)hideTabBar:(UITabBarController *)tabBar{
    
    //if(!isHideTabBar){
        
//        [UIView animateWithDuration:0.1 animations:^{
//            for (UIView *view in tabBar.view.subviews) {
//                if ([view isKindOfClass:[UITabBar class]]) {
//                    [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y+84.f, view.frame.size.width, view.frame.size.height)];
//                }
//                else {
//                    [view setFrame:CGRectMake(view.frame.origin.x, view.frame.origin.y, view.frame.size.width, view.frame.size.height+84.f)];
//                }
//            }
//        } completion:^(BOOL finished) {
            //do smth after animation finishes
            tabBar.tabBar.hidden = YES;
            isHideTabBar = YES;
      //  }];
   // }
    
}

//Method for delete saved event from calendar
-(void)deleteSkoopEventFromCalendarWithDict:(NSDictionary*)dataDict{
    
    NSLog(@"::::::%@",dataDict);
    EKEventStore *eventStore = [[EKEventStore alloc] init];
    [eventStore requestAccessToEntityType:EKEntityTypeEvent completion:^(BOOL granted, NSError *error){
        if (!granted) { return; }
        
        EKEvent *event  = [EKEvent eventWithEventStore:eventStore];
        
        NSDateFormatter *dateFormatter=[[NSDateFormatter alloc] init];
        NSDate *evenStartDate = Nil;
        [dateFormatter setDateFormat:@"hh:mm a / MMM dd, yyyy"];
        
        evenStartDate = [dateFormatter dateFromString:[dataDict valueForKey:@"date"]];
        event.startDate = evenStartDate;
        
        if([dataDict valueForKey:@"reminder_time"] && [[dataDict valueForKey:@"reminder_time"] integerValue]>0)
            evenStartDate = [evenStartDate dateByAddingTimeInterval:[[dataDict valueForKey:@"reminder_time"] integerValue]*60];
        else
            evenStartDate = [evenStartDate dateByAddingTimeInterval:3600];
        
        event.endDate = evenStartDate;
        
        // Get an array of all the calendars.
        NSArray *calendars = [eventStore calendarsForEntityType:EKEntityTypeEvent];
        
        // Get the default calendar, set by the user in preferences.
        EKCalendar *defaultCal = eventStore.defaultCalendarForNewEvents;
        
        // Find out if this calendar is modifiable.
        BOOL isDefaultCalModifiable = defaultCal.allowsContentModifications ;
        
        NSPredicate *predicate = [eventStore predicateForEventsWithStartDate:event.startDate
                                                                     endDate:event.endDate calendars:calendars];
        NSArray *matchingEvents = [eventStore eventsMatchingPredicate:predicate];
        
        if( ! isDefaultCalModifiable) {
            // The default calendar is not modifiable
            NSLog(@"The default calendar is not modifiable");
            return ;
        }
        
        [event setCalendar:[eventStore defaultCalendarForNewEvents]];
        if([matchingEvents count ] > 0){
            [eventStore removeEvent:[matchingEvents objectAtIndex:0] span:EKSpanThisEvent error:&error];
        }
    }];
}

@end
