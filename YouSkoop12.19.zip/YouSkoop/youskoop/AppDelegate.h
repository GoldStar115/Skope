//
//  AppDelegate.h
//  youskoop
//
//  Created by user on 3/7/14.
//  Copyright (c) 2014 user. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>
#import "MBProgressHUD.h"
#import <FBSDKCoreKit/FBSDKCoreKit.h>
#import <FBSDKLoginKit/FBSDKLoginKit.h>
#import "Reachability.h"



@interface AppDelegate : UIResponder <UIApplicationDelegate,UITabBarDelegate,UITabBarControllerDelegate>{
 
 
}
@property (readonly, strong, nonatomic) NSManagedObjectContext *managedObjectContext;
@property (readonly, strong, nonatomic) NSManagedObjectModel *managedObjectModel;
@property (readonly, strong, nonatomic) NSPersistentStoreCoordinator *persistentStoreCoordinator;

- (void)saveContext;
- (NSURL *)applicationDocumentsDirectory;

@property (strong, nonatomic) UIWindow *window;
//@property (nonatomic,retain) UITabBarController *tabBarController;


+ (AppDelegate*) getAppDelegate;
-(void)loggedOutFromApp;
+ (MBProgressHUD *)showGlobalProgressHUDWithTitle:(NSString *)title;
+ (void)dismissGlobalHUD;
- (BOOL) checkInternateConnection;
//-(void)ConfigureTabBar;
//-(void)configureVideoChatCredentials;
-(void)setIdleTimerDisabledWithBool:(BOOL)isLock;
//Method for delete saved event from calendar
-(void)deleteSkoopEventFromCalendarWithDict:(NSDictionary*)dataDict;
-(void)showTabBar:(UITabBarController *)tabBar;
-(void)hideTabBar:(UITabBarController *)tabBar;
@end
