//
//  ViewController.m
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 19/01/2016.
//  Copyright (c) 2016 H SHEIKH. All rights reserved.
//

#import "ViewController.h"



@implementation ViewController

-(IBAction)ReturnKeyButton:(id)sender {
    
    [sender resignFirstResponder];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    credentialsDictionary = [[NSDictionary alloc] initWithObjects:[NSArray arrayWithObjects:@"password",@"hasan786", nil] forKeys:[NSArray arrayWithObjects:@"username",@"hsheikh2", nil]];
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)enterCredentials;

{
    if ([[credentialsDictionary objectForKey:usernameField.text]isEqualToString:passwordField.text]){
       
        //correct password
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Correct Password" message:@"This password is correct." delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
        [alert show];
    }
    else {
        //incorrect password
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Incorrect Password" message:@"This password is incorrect." delegate:self cancelButtonTitle:@"Dismiss" otherButtonTitles:nil];
        [alert show];
    }
    
}



@end
