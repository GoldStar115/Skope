//
//  FeedbackEmail.h
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 15/02/2016.
//  Copyright © 2016 H SHEIKH. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>



@interface FeedbackEmail : UIViewController
- (IBAction)showEmail:(id)sender;


@end
