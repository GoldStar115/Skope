//
//  d101ViewController.h
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 19/01/2016.
//  Copyright (c) 2016 H SHEIKH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface d101ViewController : UIViewController <UIScrollViewDelegate>


{
    NSInteger total;
    NSInteger total2;
    NSInteger total3;
    IBOutlet UILabel *screen;
    IBOutlet UILabel *screen1;
    IBOutlet UILabel *screen2;
}


@property (weak, nonatomic) IBOutlet UIImageView *imageSave;
-(IBAction)save:(id)sender;

-(IBAction)increment:(id)sender;
-(IBAction)incremen1:(id)sender;
-(IBAction)incremen2:(id)sender;

-(IBAction)decrement:(id)sender;

-(IBAction)clear:(id)sender;

- (IBAction)handlePinch:(UIGestureRecognizer *) sender;

-(IBAction)Download;

@property (weak, nonatomic) IBOutlet UIImageView *imageView1;

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView1;

@end
