//
//  Booking.h
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 23/02/2016.
//  Copyright © 2016 H SHEIKH. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "sqlite3.h"


@interface Booking : UIViewController<UIPickerViewDataSource,UIPickerViewDelegate>

@property (weak, nonatomic) IBOutlet UIPickerView *picker;

@property (weak, nonatomic) IBOutlet UILabel *label;

-(IBAction)room:(id)sender;

-(IBAction)uob:(id)sender;

-(IBAction)datetime:(id)sender;

-(IBAction)persons:(id)sender;


@end



