//
//  timetablesViewController.m
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 08/03/2016.
//  Copyright © 2016 H SHEIKH. All rights reserved.
//

#import "timetablesViewController.h"

@interface timetablesViewController ()




@end

@implementation timetablesViewController

//- (IBAction)handlePinch:(UIGestureRecognizer *) sender {
//    //NSLog(@"pinched");
    
//    CGFloat lastScaleFactor =1;
//    CGFloat factor = [(UIPinchGestureRecognizer *) sender scale];
//
//    if (factor >1) { //zooming in
//        _imageView.transform=CGAffineTransformMakeScale(
//                    lastScaleFactor + (factor -1),
//                    lastScaleFactor + (factor -1));
//    }else { //zooming out
//        _imageView.transform=CGAffineTransformMakeScale(
//                    lastScaleFactor * factor,
//                    lastScaleFactor * factor);
//
//    }
//    if(sender.state==UIGestureRecognizerStateEnded)
//    {
//       if (factor > 1)
//            lastScaleFactor += (factor-1);
//        else
//            lastScaleFactor *= factor;
//    }
//
//}










- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.imageView1 setImage:[UIImage imageNamed:@"d101.jpg"]];
    [self.imageView2 setImage:[UIImage imageNamed:@"uoblogo.png"]];
    [self.imageView3 setImage:[UIImage imageNamed:@"d121.png"]];
    [self.imageView4 setImage:[UIImage imageNamed:@"d124.png"]];
    [self.imageView5 setImage:[UIImage imageNamed:@"d126.png"]];
    
    [self.scrollView1 setMaximumZoomScale:5.0f];
    [self.scrollView1 setClipsToBounds:YES];
    
    [self.scrollView2 setMaximumZoomScale:5.0f];
    [self.scrollView2 setClipsToBounds:YES];
    
    [self.scrollView3 setMaximumZoomScale:5.0f];
    [self.scrollView3 setClipsToBounds:YES];
    
    [self.scrollView4 setMaximumZoomScale:5.0f];
    [self.scrollView4 setClipsToBounds:YES];
    
    [self.scrollView5 setMaximumZoomScale:5.0f];
    [self.scrollView5 setClipsToBounds:YES];
    
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView

{
    return self.imageView1;

}




@end
