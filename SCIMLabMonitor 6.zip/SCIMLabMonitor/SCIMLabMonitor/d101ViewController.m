//
//  d101ViewController.m
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 19/01/2016.
//  Copyright (c) 2016 H SHEIKH. All rights reserved.
//

#import "d101ViewController.h"

@interface d101ViewController ()




{
    CGFloat imageMaxScale;
    CGFloat imageMinScale;
    CGFloat imageCurrentScale;
    
}



@property (weak, nonatomic) IBOutlet UIImageView *myimageview;

@end

@implementation d101ViewController
@synthesize imageSave;





- (void)viewDidLoad

{
    [super viewDidLoad];
    
    [imageSave initWithImage:[UIImage imageNamed:@"d101.jpg"]];
    
}
-(IBAction)save:(id)sender
    
{
    UIImageWriteToSavedPhotosAlbum(imageSave.image, self, nil, nil);
        NSLog(@"Image Saved");
}


    
//    [self.imageView1 setImage:[UIImage imageNamed:@"d101.jpg"]];



//    [self.scrollView1 setMaximumZoomScale:5.0f];
//    [self.scrollView1 setClipsToBounds:YES];
    
//    imageCurrentScale = 1.0;
//    imageMaxScale = 2.0;
//    imageMinScale = 0.6;
    
//    UIPinchGestureRecognizer *pinchGestureRecogniser = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(handlePinch)];
//    [[self myimageview] addGestureRecognizer:pinchGestureRecogniser];
//    [[self myimageview] setUserInteractionEnabled:YES];
//}

//- (void)handlePinch:(UIPinchGestureRecognizer *)pinchGesture
//{
//    CGAffineTransform zoomTransform = CGAffineTransformMakeScale([pinchGesture scale], [pinchGesture scale]);
//    [[pinchGesture view] setTransform:zoomTransform];
//
//    if (imageCurrentScale * [pinchGesture scale] > imageMinScale && imageCurrentScale * [pinchGesture scale] < imageMaxScale) {
//        imageCurrentScale = imageCurrentScale * [pinchGesture scale];
//        CGAffineTransform zoomTransform = CGAffineTransformMakeScale(imageCurrentScale, imageCurrentScale);
//        [[pinchGesture view] setTransform:zoomTransform];
//
//    }
//    [pinchGesture setScale:1.0];
//}

//- (void)didReceiveMemoryWarning {
//    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
//}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)exit:(id)sender {
    
    [self.navigationController
     popViewControllerAnimated:YES];
    
}
- (IBAction)exit1:(id)sender {
    
    [self.navigationController
     popViewControllerAnimated:YES];
    
}

-(IBAction)increment:(id)sender

{
    total++;
    [screen setText:[NSString stringWithFormat:@"Empty: %ld", (long)total]];
    
}

-(IBAction)increment1:(id)sender
{
    total2++;
    [screen1 setText:[NSString stringWithFormat:@"Busy: %ld", (long)total3]];

}


-(IBAction)increment2:(id)sender
{
    total3++;
    [screen2 setText:[NSString stringWithFormat:@"Full: %ld", (long)total3]];
    
}


/*-(IBAction)decrement:(id)sender
     
{
        
    total--;
    [screen setText:[NSString stringWithFormat:@"Empty: %ld", (long)total]];
         
}

-(IBAction)clear:(id)sender
     
{
        
    total = 0;
    [screen setText:[NSString stringWithFormat:@"Empty: %ld", total]];
    
}
*/


@end
