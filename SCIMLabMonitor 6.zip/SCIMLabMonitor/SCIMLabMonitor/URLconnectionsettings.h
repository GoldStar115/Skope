//
//  URLconnectionsettings.h
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 22/02/2016.
//  Copyright © 2016 H SHEIKH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface URLconnectionsettings : UIViewController

@end
