//
//  Booking.m
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 23/02/2016.
//  Copyright © 2016 H SHEIKH. All rights reserved.
//

#import "Booking.h"


@interface Booking ()

{
    NSArray *colorArray;
    NSArray *seasonArray;
    
    
}




@end

NSString *myDB=@"booklab.db";
//table name is booklab
//fields are room, uob, datetime, persons

@implementation Booking
@synthesize picker,label;














-(IBAction)ReturnKeyButton:(id)sender {
    
    [sender resignFirstResponder];
    
}



- (void)viewDidLoad {
    [super viewDidLoad];
    colorArray = [[NSArray alloc]initWithObjects:@"Horton", nil];
    seasonArray = [[NSArray alloc]initWithObjects:@"D1.01",@"D1.03",@"D1.21",@"D1.24",@"D1.26", nil];
    
    [picker selectRow:1 inComponent:0 animated:YES];
    [picker selectRow:1 inComponent:0 animated:YES];
    
    
    // Do any additional setup after loading the view.
}

-(NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView

{
    return 2;
    
}


-(NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    
    switch (component) {
        case 0:
            return colorArray.count;
            break;
        case 1:
            return seasonArray.count;
            break;
        default:
            break;
    }
    return 0;
    
}

-(NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    switch (component) {
        case 0:
            return [colorArray objectAtIndex:row];
            break;
        case 1:
            return [seasonArray objectAtIndex:row];
            break;
        default:
            break;
    }
    return 0;
    
}

-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component

{
    
    label.text = [NSString stringWithFormat:@"You have selected the lab: "@"%@ %@",[colorArray objectAtIndex:[picker selectedRowInComponent:0]],[seasonArray objectAtIndex:[picker selectedRowInComponent:1]]];
    
    
}








- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/



@end
