//
//  timetablesViewController.h
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 08/03/2016.
//  Copyright © 2016 H SHEIKH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface timetablesViewController : UIViewController <UIScrollViewDelegate>

- (IBAction)handlePinch:(UIGestureRecognizer *) sender;

@property (strong, nonatomic) IBOutlet UIImageView *imageView;



@property (weak, nonatomic) IBOutlet UIImageView *imageView1;

@property (weak, nonatomic) IBOutlet UIImageView *imageView2;

@property (weak, nonatomic) IBOutlet UIImageView *imageView3;

@property (weak, nonatomic) IBOutlet UIImageView *imageView4;

@property (weak, nonatomic) IBOutlet UIImageView *imageView5;



@property (weak, nonatomic) IBOutlet UIScrollView *scrollView1;

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView2;

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView3;

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView4;

@property (weak, nonatomic) IBOutlet UIScrollView *scrollView5;



@end
