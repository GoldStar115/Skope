//
//  ViewController.h
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 19/01/2016.
//  Copyright (c) 2016 H SHEIKH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController {
    //text box outlets
    IBOutlet UITextField *usernameField;
    IBOutlet UITextField *passwordField;
    //credentials
    NSDictionary *credentialsDictionary;
    //where the user will enter credentials
}

- (IBAction)enterCredentials;


- (IBAction)ReturnKeyButton:(id)sender;



@end


