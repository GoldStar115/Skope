//
//  bookingconfirm.h
//  SCIMLabMonitor
//
//  Created by H SHEIKH on 23/03/2016.
//  Copyright © 2016 H SHEIKH. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface bookingconfirm : UIViewController

@end
